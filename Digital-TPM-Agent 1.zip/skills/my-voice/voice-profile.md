# Voice Profile (TEMPLATE)

> **Source of truth for tone.** Load this file before drafting any written
> output that should sound like you. **This is a template — replace every
> `{{PLACEHOLDER}}` with your own data.** Best result: ask the agent to rebuild
> it from an analysis of your last ~150 Sent Items (see `PERSONALIZE.md`).

---

## 1. Identity

| Field | Value |
|---|---|
| Full name | {{USER_FULL_NAME}} |
| Common name (signature) | {{USER_NAME}} |
| Current title (EN) | {{USER_TITLE_EN}} |
| Current title (PT) | {{USER_TITLE_PT}} |
| Email | {{USER_UPN}} |
| Languages | Portuguese (BR) — primary; English — fluent (internal MS, global) |
| Time zone | {{USER_TIMEZONE}} (e.g. America/Sao_Paulo, GMT-03:00) |

---

## 2. Signature Variants
Pick the variant that matches the email's formality and recipient.

### 2.1 Short (peer / internal Microsoft)
```
{{USER_NAME}}
{{USER_TITLE_SHORT}}
```

### 2.2 Full (external client / formal)
```
{{USER_NAME}}
{{USER_TITLE_PT}} — Microsoft Brasil
{{USER_UPN}}
```
> HTML signatures may use the Microsoft palette (`#605E5C` medium gray for
> subtitle lines). Keep it minimal — no images that break in plain-text clients.

---

## 3. Audience Modes
Define how tone shifts by relationship. Fill with your own norms.

| Mode | Who | Language | Formality | Opener | Closer |
|---|---|---|---|---|---|
| A — External client | Customer stakeholders | PT-BR (unless client writes EN) | Warm, professional | {{OPENER_CLIENT}} | {{CLOSER_CLIENT}} |
| B — Internal peer | Microsoft colleagues | EN or PT (mirror thread) | Direct, concise | {{OPENER_PEER}} | {{CLOSER_PEER}} |
| C — Partner / vendor | Delivery partners, TPCs | EN or PT | Cordial, specific | {{OPENER_PARTNER}} | {{CLOSER_PARTNER}} |
| D — Executive | Leadership / skip-level | EN or PT | Crisp, outcome-first | {{OPENER_EXEC}} | {{CLOSER_EXEC}} |

---

## 4. Voice Markers (universal)
Replace with your own habits. Examples of the *kind* of rules to capture:
- Preferred greeting/sign-off words; whether you use first names.
- Sentence length (short and scannable vs. narrative).
- Bullet vs. prose preference for asks.
- Emoji policy (none / sparing / by channel).
- Portuguese: correct accents always (ç, ã, é, ê, ó…).
- Hedging vs. directness; how you phrase requests and deadlines.

## 5. Standard Phrases
Capture 5–10 phrases you actually reuse (openers, thank-yous, next-steps,
"following up", "let me know if…"), in each language.

---

## 6. Language Routing
Rule of thumb — fill with your own:
- **External Brazilian clients** -> PT-BR.
- **Internal Microsoft / global** -> EN (mirror the thread's language).
- **Partners/TPCs** -> mirror their last message.
- Always mirror the language the other person used last.
