---
name: my-voice
description: >
  Single source of truth for the user's writing voice — signatures, openers,
  closers, audience modes (external client / internal peer / partner / executive),
  language routing rules (PT-BR vs EN by domain), voice markers, and standard
  phrases. Other skills load `voice-profile.md` from this folder instead of
  hardcoding signature blocks or inventing tone. Use whenever drafting any email,
  Teams message, MSX comment, or written output that should sound like the user.
  Triggers: my voice, minha voz, voice profile, meu estilo, write as me, escreva
  como eu, draft in my style, rascunhe no meu tom, my-voice, voice-profile.
---

# My Voice — Writing Style Profile (TEMPLATE)

> ⚠️ **PERSONALIZE THIS SKILL.** The shipped `voice-profile.md` is a generic
> template with `{{PLACEHOLDERS}}`. Fill it with **your own** identity,
> signatures, and tone before relying on it. See `PERSONALIZE.md` at the package
> root. (Best result: let the agent rebuild this profile from an analysis of
> *your* Sent Items — see the PERSONALIZE "Voice profile" step.)

This skill is **passive data**, not orchestration. Other skills/agents load
[`voice-profile.md`](voice-profile.md) and apply the patterns in it.

## How other skills should use this

### Pattern 1 — Load before composing
At the start of any email/message-drafting workflow, read the profile:

```text
view: {{COPILOT_HOME}}\skills\my-voice\voice-profile.md
```

Then apply the audience mode that matches the recipient:
- Identify recipient domain -> look up "Language Routing" rule
- Identify recipient relationship -> pick "Audience Mode"
- Use the opener/closer/signature from that mode
- Apply universal "Voice Markers"

### Pattern 2 — Keep it in sync
When your role, title, or signature changes, update `voice-profile.md` (and, if
present, `../my-voice-en/voice-profile-en.md`). Treat this file as the single
source of truth for tone so no other skill hardcodes a signature.
