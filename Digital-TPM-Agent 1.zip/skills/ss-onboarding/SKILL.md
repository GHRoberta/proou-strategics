---
name: ss-onboarding
description: >
  Onboarding walkthrough for Solution Specialists. Guides new users through toolkit setup:
  Azure CLI, GitHub CLI, MSX login, Power BI connection, and Agency enforcement
  for VS Code. Triggers: onboarding, setup, getting started, new user, first time,
  configure, install.
---

# Solution Specialist Onboarding

Welcome to your toolkit setup. I'll walk you through everything step by step. We'll check what's working, fix what isn't, and get you running.

## Step 1: Check Your Foundation

Let me make sure the basics are in place. I'll check a few things:

**Azure CLI** -- This is how your tools talk to Microsoft's sales database.
- Run this in your terminal: `az account show`
- If you get an error saying "az" is not recognized, we need to install it: `winget install Microsoft.AzureCLI` -- then close and reopen your terminal.
- If it works but shows the wrong account, run `az login` and sign in with your @microsoft.com account.

**GitHub CLI** -- This connects you to the repo where the toolkit lives.
- Run: `gh auth status`
- If it says "not logged in," run `gh auth login` and follow the prompts. Pick GitHub.com, HTTPS, and browser login.

## Step 2: Connect to Your Sales Data (MSX)

MSX is where all your pipeline data lives -- deals, accounts, territories.

Just say to me: **"log me into MSX"**

A browser window will open. Sign in with your @microsoft.com account. Once you see "Authentication successful," you're connected. This lasts about an hour before you need to sign in again.

**Test it:** Say "show me my pipeline summary" -- you should see your deals grouped by stage with dollar amounts.

## Step 3: Connect to Azure Consumption Data (Power BI)

This lets you look up how much a customer is spending on Azure and what services they use.

The first time you ask a consumption question, a browser sign-in will pop up. Complete it with your @microsoft.com credentials. After that, it's cached.

**Test it:** Say "what Power BI datasets can I see?" -- you should get a list of available datasets.

If it times out, try this in VS Code: press `Ctrl+Shift+P`, type "MCP: List Servers", find `powerbi-remote`, click Start, and complete the sign-in there. Then come back here.

## Step 4: Agency Enforcement (VS Code Users)

If you use Copilot in VS Code (not just the terminal), there's one extra step. VS Code normally bypasses the Microsoft security wrapper. We fix that with a setup script.

In your terminal, run:
```powershell
& "scripts\agent_scripts\setup_agency_enforcement.ps1"
```

Then restart VS Code completely (close all windows and reopen). After that, every Copilot session in VS Code goes through Microsoft's secure channel automatically.

**Skip this step** if you only use Copilot from the terminal (not VS Code).

## Step 5: You're Ready

Here's what you can do now. Try any of these:

| Say this | What happens |
|----------|-------------|
| "Show me my deals" | See every opportunity you're on, with values and stages |
| "Brief me on [company name]" | Get a full account snapshot -- pipeline, team, recent activity |
| "What's the ACR baseline for [company name]?" | See their Azure spending breakdown |
| "What emails did I get about [company] this week?" | Search your Outlook and Teams |
| "Generate my monthly report" | Auto-create your monthly opportunity update |
| "Prepare for my meeting with [person/company]" | Get a briefing with context from your calendar, emails, and pipeline |
| "Size a MACC deal for [company]" | Get a data-driven MACC commitment estimate |

## What else can I do?

The toolkit has a lot more -- automation that scans your accounts daily, strategic analysis that runs weekly, dashboards for each account. Ask me about any of these and I'll walk you through setting them up.

**What would you like to try first?**
