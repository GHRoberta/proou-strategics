---
name: teams-search
description: >
  Search and extract Teams chat/channel messages via WorkIQ CLI (FlightDeck).
  Bypasses Graph API Conditional Access restrictions by using WAM/SSO auth.
  Supports group chats, 1:1 chats, and channel messages with time-scoped,
  topic-filtered, and sender-filtered queries. Use when user asks to search
  Teams chats, find messages, extract chat history, scan channels, or build
  digests from Teams data.
  Triggers: search teams, find in teams, teams history, chat history,
  extract teams, scan teams, dream team, team chat messages, buscar teams,
  pesquisar teams, histórico teams, digest teams.
---

# Teams Search — WorkIQ CLI Skill

## When to Use

Load this skill when the user wants to:

- **Search** Teams chat messages by topic, sender, or time range
- **Extract** messages from a specific group chat (e.g., "Americas Dream Team")
- **Scan** Teams channels for updates
- **Build digests** or summaries from Teams conversations
- **Find** what was discussed about a topic across chats

**Do NOT use** when:

- User wants to **send** a Teams message (use **teams-chat** skill instead)
- User wants to **reply** to a chat (use **teams-chat** skill)
- User wants **email** search only (use **outlook-email** or **workiq-patterns** skill)
- User wants meeting **transcripts** (use **workiq-patterns** directly — same CLI, different query pattern)

## Why This Skill Exists

The Microsoft corporate tenant blocks Graph API access to Teams chats through:
- **53003** — Conditional Access blocks non-approved apps
- **530033** — Device Code Flow fails device compliance (polling device ≠ user device)
- **530084** — Token Protection policy requires PoP-bound tokens via WAM
- **Admin consent** — `Chat.Read` scope requires admin approval for Graph SDK

**WorkIQ CLI bypasses all of these** because it uses MSAL + WAM (Windows Account Manager)
for silent SSO, binding tokens to the user's managed device automatically.

## Prerequisites

1. **FlightDeck** installed (`winget install FlightDeck.FlightDeck`)
2. **WorkIQ EULA** accepted (one-time: run `& $workiq accept-eula`)
3. **Windows device** enrolled in Intune (corporate-managed)
4. Internet access to Microsoft 365

## WorkIQ Binary Location

```powershell
$workiq = "C:\Program Files\FlightDeck\resources\app.asar.unpacked\node_modules\@microsoft\workiq\bin\win-x64\workiq.exe"
```

> **IMPORTANT:** WorkIQ is bundled inside FlightDeck, not a standalone install.
> Do NOT try `dotnet tool install workiq` (requires internal NuGet feed).
> Always use the full path above.

## Installation (if not present)

```powershell
# Check if WorkIQ binary exists
$workiq = "C:\Program Files\FlightDeck\resources\app.asar.unpacked\node_modules\@microsoft\workiq\bin\win-x64\workiq.exe"
if (-not (Test-Path $workiq)) {
    Write-Host "Installing FlightDeck (includes WorkIQ)..."
    winget install FlightDeck.FlightDeck --accept-source-agreements --accept-package-agreements
}

# Verify
& $workiq --version

# Accept EULA (one-time)
& $workiq accept-eula
```

## Auth Model

- **Auth method:** MSAL + WAM (Windows Account Manager) — silent SSO
- **No manual login required** — uses the Windows SSO session automatically
- **Token binding:** Tokens are PoP-bound to the device's TPM, satisfying token protection policies
- **Refresh:** 90-day sliding window, auto-refreshes silently
- **No cache file to manage** — WAM handles everything

> **Key difference from teams-chat skill:** The teams-chat skill uses Device Code Flow
> which is BLOCKED by Conditional Access. This skill uses WAM which passes all CA policies.

---

## Query Patterns

### 1. Search a Specific Group Chat by Name

```powershell
$workiq = "C:\Program Files\FlightDeck\resources\app.asar.unpacked\node_modules\@microsoft\workiq\bin\win-x64\workiq.exe"

# Search by chat name + time range
& $workiq ask -q "Show me Teams chat messages from the past 4 weeks from any chat with 'Dream Team' in the title. Include sender name, date, and full message content."
```

**Key tips:**
- Use the chat's display name/topic in quotes: `'Dream Team'`, `'Carlos Pardo'`
- Always specify a time range: `past 7 days`, `past 4 weeks`, `since March 1`
- Request `sender name` and `full message content` explicitly for complete data

### 2. Filter by Topic/Category

```powershell
# Extract only training-relevant messages
& $workiq ask -q "From the Americas Dream Team chat in the past 4 weeks, extract ALL messages related to: 1) training course updates, 2) PD/OE/TSP policy changes, 3) certification exam news. For each, include sender name and full message. Group by topic."
```

**Effective category prompts:**
- `training course updates or changes`
- `PD/OE/TSP policy changes`
- `Copilot licensing or agent availability`
- `certification exam news`
- `operational issues or tips`
- `customer escalations or success stories`

### 3. Filter by Sender

```powershell
# Messages from a specific person
& $workiq ask -q "Show me Teams chat messages from Carlos Pardo in the past 2 weeks from any group chat. Include full message content."
```

### 4. Search Across All Chats by Topic

```powershell
# Topic search across all chats
& $workiq ask -q "Search all my Teams chats from the past 7 days for messages mentioning '[CLIENTE]' or '[CLIENTE]' or '[CLIENTE]'. Include chat name, sender, and message."
```

### 5. Search Teams Channels

```powershell
# Channel messages (different from chats)
& $workiq ask -q "Show me messages from Teams channels I'm a member of that mention 'catalog update' or 'new course' from the past 2 weeks."
```

> **Note:** Channel access depends on `ChannelMessage.Read.All` scope.
> WorkIQ may or may not have this scope — test and note results.

### 6. Extract Action Items / Decisions

```powershell
# Ask WorkIQ to synthesize, not just retrieve
& $workiq ask -q "From the Americas Dream Team chat in the past 2 weeks, identify: 1) decisions that were made, 2) action items assigned to anyone, 3) unresolved questions. Format as a structured list."
```

### 7. Multi-Chat Scan (Digest Pattern)

```powershell
# Scan multiple chats sequentially for a digest
$workiq = "C:\Program Files\FlightDeck\resources\app.asar.unpacked\node_modules\@microsoft\workiq\bin\win-x64\workiq.exe"
$period = "past 4 weeks"

# Chat 1: Dream Team
$dreamTeam = & $workiq ask -q "From the Americas Dream Team chat in the $period, extract messages about training updates, policy changes, certifications, and operational issues. Group by topic, include sender names."

# Chat 2: Team Chat with manager
$teamChat = & $workiq ask -q "Show me Teams chat messages from the $period from any group chat that includes Carlos Pardo. Include sender name and full message. Exclude the Americas Dream Team chat."

# Chat 3: Specific customer chat
$customerChat = & $workiq ask -q "Show me Teams chat messages from the $period from any chat mentioning '[CLIENTE]' or '[CLIENTE]'. Include sender and content."
```

---

## Performance & Limitations

| Aspect | Detail |
|---|---|
| **Query time** | 30-90 seconds per query (depends on data volume) |
| **Max results** | WorkIQ returns summarized/grouped results, not raw message dumps |
| **Timestamps** | Per-message timestamps may not be available; chat-level dates are provided |
| **Message truncation** | Very long messages may be truncated by the search index |
| **Deduplication** | Same chat may appear multiple times with different message batches |
| **Rate limits** | No known hard limits, but avoid >10 queries in quick succession |
| **Auth failures** | If WAM token expires (rare), just re-run — auto-refreshes silently |

## Known Quirks

1. **Same chat, multiple results:** WorkIQ may return the same group chat as 2+ entries
   with different message batches. This is normal — merge results when processing.

2. **No exact timestamps:** Teams search index doesn't expose per-message timestamps.
   You get chat-level dates and relative timing ("last Wednesday").

3. **Summarization vs verbatim:** WorkIQ uses AI to structure responses. It will
   faithfully reproduce message content but may add section headers and grouping.
   Request "verbatim" or "full message text" explicitly when you need exact quotes.

4. **`Start-Job` loses auth:** WAM tokens are process-bound. Never use `Start-Job`
   or `Start-Process` for WorkIQ queries — always run inline in the current session.

5. **Channel vs Chat:** Teams chats (1:1, group) and Teams channels are different
   data sources. Query them separately for best results.

## Troubleshooting

| Issue | Solution |
|---|---|
| `workiq` not found | Install FlightDeck: `winget install FlightDeck.FlightDeck` |
| EULA not accepted | Run `& $workiq accept-eula` |
| Empty results | Broaden time range or simplify search query |
| Auth error | Ensure Windows SSO is active (try `whoami`); restart terminal |
| Slow response (>2min) | Narrow the time range or reduce scope of query |
| "No chats found" | Try different chat name variations; WorkIQ matches on topic/title |
| Truncated messages | Ask a follow-up query targeting specific messages by sender/date |

## Relationship to Other Skills

| Skill | Use For |
|---|---|
| **teams-search** (this) | Reading/searching Teams chat & channel messages |
| **teams-chat** | Sending/replying to Teams messages (Graph API + Device Code) |
| **workiq-patterns** | General WorkIQ patterns (emails, calendar, transcripts, SharePoint) |
| **outlook-email** | Sending emails via Outlook COM |
| **email-auto-draft** | Auto-generating email draft replies |

## Workflow: Weekly Training Digest

The primary use case for this skill is the **TPM Training Digest** agent.
Here's the recommended scan sequence:

```
1. Americas Dream Team chat        → Policy changes, tips, certifications
2. Team Chat (Carlos Pardo)        → Leadership priorities, customer guidance
3. TPM Chat Room channel           → Community questions and answers
4. Org Skilling Alerts channel     → Breaking changes and announcements
5. TSPc and PDc HyperCare channel  → TSP credits, PD ops, reporting bugs, token updates
6. TPMWeb General channel           → General updates (low traffic — last post Oct 2024)
```

### Channel Activity Notes
| Channel | Activity Level | Content Type |
|---|---|---|
| TPM Chat Room | **High** | Q&A, policy, catalog, labs, exams |
| TSPc and PDc HyperCare | **Medium** | TSP credits, PBI refreshes, reporting bugs |
| Org Skilling Alerts | **Low-Medium** | Live site incidents, breaking changes |
| General | **Very Low** | Rare announcements (last post Oct 2024) |

For each source, use the topic-filtered pattern (Section 2 above) to extract
only training-relevant content, then deduplicate across sources before composing.
