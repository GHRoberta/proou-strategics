---
name: dynamight-esi-admin
description: >
  Navigation guide and data patterns for the ESI Admin Dynamics 365 CRM (Dynamight).
  URL: https://esiadmin.crm.dynamics.com/
  Use when working with ESI deliveries, training catalog, customer accounts (TPID/Skilling Account),
  TSP engagements, credits, bookings, or budget. Covers all 12 navigation sections and 72 entities.
  Triggers: dynamight, ESI admin, deliveries, delivery, turma, turmas, catalog, catálogo,
  skilling account, training entitlement, TSP engagement, TSPc, PDc, booking, schedule board,
  exam voucher, delivery change log, rate card, budget, learning path.
---

# Dynamight — ESI Admin (Dynamics 365) Navigation Guide

> **URL:** https://esiadmin.crm.dynamics.com/
> **App ID:** `722b5c82-0825-40db-b769-3603d146879f`
> **Platform:** Dynamics 365 / Dataverse (Unified Client Interface)

## Access

- Requires Microsoft Entra ID authentication (corporate account)
- Cannot be accessed via web_fetch or API without interactive login
- Best accessed via browser (Edge recommended) or Playwright automation
- Direct view links follow the pattern:
  ```
  https://esiadmin.crm.dynamics.com/main.aspx?appid=722b5c82-0825-40db-b769-3603d146879f&forceUCI=1&pagetype=entitylist&etn={entity_logical_name}&viewid={view_guid}&viewType=4230
  ```

## Navigation Structure (12 Sections, 72 Entities)

### 1. ESI Members — Customer management

| Entity | Description | Key Fields |
|--------|-------------|------------|
| **Accounts** | Customer organizations enrolled in ESI | Name, Skilling Account ID, TPID, PartnerOneID, TPM, GPS, Area, Sales Unit |
| Linked Accounts | Accounts linked to ESI enrollment | — |
| Contacts | Customer contacts | — |
| Technical Skills Re... | Technical skills requests | — |
| Offers | Offers available to customers | — |
| **Training Entitlements** | Training entitlements per account (seats, credits) | — |
| **TSP Engagements** | Engagements linking customers to Training Service Partners | — |
| Safelisted Domains | Authorized email domains for ESI access | — |

**Common tasks:**
- Look up a customer by TPID or name → Accounts
- Check what training credits a customer has → Training Entitlements
- See which TSP is assigned to a customer → TSP Engagements

### 2. Scheduling — Delivery management (⭐ most used)

| Entity | Description | Key Fields |
|--------|-------------|------------|
| **Deliveries** | ⭐ Scheduled training sessions (turmas) — THE core entity | Delivery ID, Course, Date, Time, Seats, Status, Account, Instructor |
| Multi-Account | Deliveries serving multiple accounts | — |
| **Bookings** | Instructor/resource reservations for deliveries | — |
| Schedule Board | Visual scheduling board (calendar view) | — |
| Non-Delivery Time | Blocked time (PTO, holidays, admin) for resources | — |
| **Exam Vouchers** | Certification exam vouchers | — |
| **Delivery Resources** | Instructors/resources assigned to deliveries | — |
| **Delivery Change Log** | Audit trail of delivery modifications (reschedules, cancellations) | — |
| Additional Resources | Extra resources for deliveries | — |

**Common tasks:**
- Find upcoming deliveries for a customer → Deliveries (filter by Account)
- Check instructor assignments → Delivery Resources
- Track changes/cancellations → Delivery Change Log
- View exam vouchers issued → Exam Vouchers

### 3. Training Service Partners (TSP) — Partner management

| Entity | Description |
|--------|-------------|
| Accounts | TSP organizations (e.g., Green Tecnologia, Ka Solution) |
| Contacts | TSP contacts (e.g., Marcelo Bidart @ Green) |
| **TSP Engagements** | Credits/engagements linking TSPs to customer deliveries |
| TSP Locations | Physical/virtual delivery locations for TSPs |
| TSP Offerings | What courses a TSP can deliver |

**Common tasks:**
- Look up TSP credit allocations → TSP Engagements
- Find which TSP delivers for a customer → TSP Engagements (filter by Account)
- Check TSP capabilities → TSP Offerings

### 4. Budget Management

| Entity | Description |
|--------|-------------|
| ALL Budget | Overall budget view |
| AE Request | Account Executive budget requests |

### 5. Budget Admin

| Entity | Description |
|--------|-------------|
| Edit Field Mapping | Field mapping configuration |
| **TSPc Rate Card** | Pricing table for TSP credits (TSPc) |
| **PDc Rate Card** | Pricing table for Private Delivery credits (PDc) |

### 6. Catalog — Course catalog (⭐ reference data)

| Entity | Description | Key Fields |
|--------|-------------|------------|
| **Catalog Items** | ⭐ All available courses | Title, Offering, Standard Duration, Catalog Item Type (MOC Courseware), Default Role, External URL |
| Catalog Item Tags | Tags/labels for courses | — |
| Solution Areas | AI, Security, Data, etc. | — |
| Solution Plays | Strategic plays per solution area | — |
| Offering Catalog Items | Items grouped by offering | — |
| Catalog Sources | Source of catalog items | — |
| Microsoft Certifications | Certification exams | — |
| Microsoft Roles | Target roles (AI Engineer, Developer, etc.) | — |
| Modalities | Delivery modalities (VILT, ILT, etc.) | — |
| WWL Programs | Worldwide Learning programs | — |
| Special Programs | Special delivery programs | — |
| Catalog Items Targets | Target audiences | — |

**Common tasks:**
- Look up a course by code or title → Catalog Items
- Find courses for a specific role → Catalog Items (filter by Default Role)
- Get course URL → External URL field

**Known Offerings:**
- Cloud & AI (most courses fall here)

**Known Catalog Item Types:**
- MOC Courseware (standard Microsoft Official Courseware)

### 7. General — Configuration & reference

| Entity | Description |
|--------|-------------|
| Offerings | Offering categories (Cloud & AI, etc.) |
| Areas | Geographic areas (United States, North Europe, MEA, Japan, India, etc.) |
| Territories | Sales territories |
| Users | System users |
| Reports | Built-in reports |
| Reasons | Reason codes (for cancellations, changes) |
| Delivery SubStatus | Sub-status options for deliveries |
| Characteristics | Resource characteristics/skills |
| Teams | Organizational teams |
| CRM Configuration | System configuration |
| Organizational Units | Org units |
| Master Detail Items | Master data items |
| Postal Codes | Postal codes |

### 8. LxP — Learning Experience Platform

| Entity | Description |
|--------|-------------|
| Learning Paths | Curated learning paths (trilhas) |
| Learning Path Templates | Templates for learning paths |
| LP Offering | Offerings linked to learning paths |
| LE Groups | Learning experience groups |
| LE Group Mappings | Group-to-entity mappings |

### 9. Offers — Pricing & SKUs

| Entity | Description |
|--------|-------------|
| Memberships | Customer memberships |
| MembershipOfferings | Offerings per membership |
| Price Lists | Pricing tables |
| SKUs | Stock keeping units |
| Unit Groups | Unit groupings |

### 10. Scheduling Settings

| Entity | Description |
|--------|-------------|
| Booking Setup Metadata | Booking configuration |
| Scheduling Admin | Admin settings for scheduling |
| Scheduling Parameters | System parameters |

### 11. Knowledge

| Entity | Description |
|--------|-------------|
| Knowledge Articles | Help articles and documentation |
| Knowledge Search | Search interface |
| Categories | Article categories |

### 12. Survey & Flow

| Entity | Description |
|--------|-------------|
| Response | Survey responses |
| Error Logs | Flow/automation error logs |

---

## ESI Portal (esi.microsoft.com) Integration

The public-facing ESI portal for learners is at https://esi.microsoft.com

**Registration link pattern:**
```
https://esi.microsoft.com/Deliveryonly?delid={delivery_id}
```

Where `{delivery_id}` is the numeric Delivery ID from the Dynamight Deliveries entity.

**Portal sections:**
- Cursos com instrutor (ILT catalog with registration)
- Treinamento do Copilot para Microsoft 365
- Vídeo dos cursos
- Microsoft Learn para Organizações
- Credenciais da Microsoft
- Microsoft Virtual Training Days
- Training Services Partners

**Learner limits:** 3 simultaneous registrations per user.

---

## Key Relationships (Entity Model)

```
Account (Customer)
  ├── Training Entitlements (what they're entitled to)
  ├── TSP Engagements (which TSP delivers for them)
  │     └── TSP Account (e.g., Green Tecnologia)
  ├── Deliveries (scheduled sessions)
  │     ├── Catalog Item (which course)
  │     ├── Delivery Resources (instructors)
  │     ├── Bookings (resource reservations)
  │     └── Delivery Change Log (audit trail)
  └── Exam Vouchers (certification credits)
```

---

## TPM Workflow Cheat Sheet

| Task | Where to go | Filter by |
|------|------------|-----------|
| Check customer deliveries | Scheduling → Deliveries | Account name or TPID |
| See TSP credit allocation | ESI Members → TSP Engagements | Account + TSP name |
| Find a course in catalog | Catalog → Catalog Items | Title or code |
| Check instructor availability | Scheduling → Schedule Board | Date range |
| Track delivery changes | Scheduling → Delivery Change Log | Delivery ID |
| Issue exam vouchers | Scheduling → Exam Vouchers | Account |
| Look up TSP rate card | Budget Admin → TSPc Rate Card | — |
| Build a learning path | LxP → Learning Paths | — |
| View customer entitlements | ESI Members → Training Entitlements | Account |
| Export data | Any view → toolbar → Export to Excel | — |

---

## Known Customers (from Accounts view sample)

| Name | Skilling Account ID | TPID | Area | Sales Unit |
|------|-------------------|------|------|------------|
| CCA Global Partners | 31886 | 8935674 | United States | Industry.SMEC.Co... |
| Cox Corporate Services, Inc. | 12301 | 645812 | United States | USA - Telco, Med... |
| Credit.Com | 24347 | 12893386 | United States | USA - SMB - Co... |
| Marathon Petroleum Company LP | 11651 | 9713267 | United States | USA - Oil, Gas, En... |
| Ministerstwo Funduszy i Polityki Regionalnej | 27811 | 80109331 | North Europe | NE.PL.Ent.PS |
| Ministry of Works & Transport | 10148 | 13478244 | MEA | Uganda.SMECC.C... |
| NTT, Inc. | 12960 | 7710604 | Japan | JP.EC |
| Travel Food Services Ltd | 20313 | 14065607 | India | India SC.SMECC... |

---

## Notes & Limitations

1. **Authentication required** — All access requires interactive Entra ID login. Cannot be scraped via web_fetch.
2. **Dataverse API** — Theoretically accessible via Dataverse Web API if an app registration with proper permissions exists. Endpoint would be: `https://esiadmin.crm.dynamics.com/api/data/v9.2/`
3. **Export to Excel** — Available on all list views via the toolbar. Useful for bulk data extraction.
4. **View customization** — Users can create custom views, edit columns, and apply filters on any entity list.
5. **Delivery ID** — The numeric ID that links Dynamight deliveries to ESI portal registration URLs.
