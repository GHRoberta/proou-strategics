---
name: onenote-patterns
description: >
  OneNote access patterns for the Work Hub. Load this skill when working with
  OneNote notebooks, COM API automation, page extraction, section management, or
  troubleshooting OneNote sync issues. Covers three access methods: Agent365
  Copilot Search (interactive), COM API via PS 5.1 (batch scripts), and Graph
  SDK (parked). Triggers: onenote, COM, notebook, section, page, sync,
  GetHierarchy, OneNoteAutomation, onenote_extract.
---

# OneNote Access Patterns

## Three Access Methods

| Method | Runtime | Use Case | Status |
|--------|---------|----------|--------|
| **Agent365 Copilot Search** | `agent365-copilot-search` MCP | Interactive search across M365 incl. OneNote | ACTIVE |
| **COM API** (PS 5.1 only) | `powershell.exe -STA` | Batch scripts, full CRUD | ACTIVE |
| **Graph PowerShell SDK** | pwsh (PS 7) | Future replacement for COM | PARKED (tenant consent blocked) |

**Why not PS7 + COM?** PowerShell 7 (.NET Core) fundamentally cannot do Office COM interop. PIAs are .NET Framework only. This is permanent.

**Why not community MCP server?** `danosb/onenote-mcp` can't authenticate in the Microsoft corporate tenant (Token Protection CA policy requires WAM-brokered tokens; Node.js can't do WAM).

## Agent365 Copilot Search (Interactive)

Use `agent365-copilot-search` MCP to search OneNote content. Returns content summaries + SharePoint deep links. Read-only -- cannot create/edit pages.

- Timezone MUST be IANA format (`America/Chicago`)
- Persist `conversationId` across multi-turn searches

## COM API Critical Gotcha

> **SharePoint-hosted notebooks:** `GetHierarchy("", N, ...)` from root does NOT expand sections for cloud notebooks. Returns self-closing `<one:Notebook ... />` with 0 children.
> **You MUST query each notebook ID individually** (scope=1 for sections, scope=4 per section for pages).

### Two-Step Pattern (required for cloud notebooks)

**Step 1: List notebooks** (root scope=0)
```powershell
powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -Command {
    $onenote = New-Object -ComObject OneNote.Application
    $xml = ""
    $onenote.GetHierarchy("", 0, [ref]$xml)
    $doc = [xml]$xml
    $ns = @{one = "http://schemas.microsoft.com/office/onenote/2013/onenote"}
    $doc | Select-Xml -XPath "//one:Notebook" -Namespace $ns | ForEach-Object {
        Write-Output "Notebook: $($_.Node.name) | ID: $($_.Node.ID)"
    }
}
```

**Step 2: Get sections** (scope=1 from notebook ID, NOT root)
```powershell
$onenote.GetHierarchy($notebookId, 1, [ref]$xml)  # 1 = sections
```

**Step 3: Get pages** (scope=4 from section ID)
```powershell
$onenote.GetHierarchy($sectionId, 4, [ref]$xml)  # 4 = pages
```

**Step 4: Read page text**
```powershell
function Get-PageText($onenote, $pageId) {
    $ns = @{one = "http://schemas.microsoft.com/office/onenote/2013/onenote"}
    $xml = ""; $onenote.GetPageContent($pageId, [ref]$xml, 0)
    $doc = [xml]$xml
    $texts = $doc | Select-Xml -XPath "//one:T" -Namespace $ns
    $lines = @()
    foreach ($t in $texts) {
        $clean = $t.Node.InnerText -replace '<[^>]+>', ''
        if ($clean.Trim()) { $lines += $clean.Trim() }
    }
    return ($lines -join "`n")
}
```

## OneNoteAutomation Module

Import: `Import-Module "$env:LOCALAPPDATA\PSModules\OneNoteAutomation\1.0.2\OneNoteAutomation.psd1"`

Cmdlets: `Get-OneNoteNotebook`, `Get-OneNoteSection`, `Get-OneNotePage`, `New-OneNotePage`, `Update-OneNotePage`, `Show-OneNote`, `Get-OneNoteHierarchy`

Requires `powershell.exe -STA -ExecutionPolicy Bypass`.

## Full Extract Pattern

For extracting all content from a notebook to file, see `References/playbook/onenote.md` lines 117-155 for the complete script. Key: iterate sections (scope=1) then pages (scope=4), call Get-PageText per page, write to `onenote_extract.txt`.

## Creating Pages and Sections

For page/section creation patterns (XML construction, outline elements, CDATA content), see `References/playbook/onenote.md` lines 158-193.

## Graph SDK Status (PARKED)

Entra app "WorkHub" registered (`d1aa8af5-4dc3-45d2-8b0e-234d3c3d0e9b`) with `User.Read`, `Sites.Selected`, `Notes.ReadWrite`. Blocked by SPACE admin consent requirements. Revisit when Microsoft publishes easier auth for internal apps.
