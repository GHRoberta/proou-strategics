---
name: ms-learn
description: >
  Navega Microsoft Learn — documentação, Learning Paths, Modules,
  certificações, exames, Applied Skills, roles, products, levels — via
  Learn Catalog API pública (https://learn.microsoft.com/api/catalog) e
  ferramentas MCP nativas (microsoft_docs_search, microsoft_docs_fetch,
  microsoft_code_sample_search). Use sempre que o usuário pedir conteúdo
  de Learn, certificações Microsoft, exames, paths de capacitação,
  módulos, roadmaps por role, busca de docs Azure/M365, exemplos de
  código oficiais ou queira montar uma trilha de estudos.
  Triggers: ms learn, microsoft learn, learning path, módulo, certificação,
  exame, AI-102, AZ-104, MS-900, applied skill, roadmap, trilha de estudos,
  docs azure, docs microsoft, sample code, exemplo de código, certified,
  jornada de aprendizado, learn catalog.
---

# MS Learn — Navegação em Microsoft Learn

Skill para descobrir, filtrar e montar trilhas em Microsoft Learn.
Combina **Learn Catalog API** (catálogo estruturado completo, pt-br
nativo) com as ferramentas MCP nativas para busca de conteúdo livre.

## Fontes de dados

### 1) Ferramentas MCP nativas (sempre disponíveis)

| Ferramenta | Quando usar |
|------------|-------------|
| `microsoft_docs_search` | Busca semântica em texto livre na doc Microsoft/Azure (até 10 trechos, ~500 tokens cada). Para perguntas conceituais. |
| `microsoft_docs_fetch` | Baixa página inteira de Learn em markdown. Use depois de `_search` para aprofundar. |
| `microsoft_code_sample_search` | Snippets oficiais com filtro por linguagem (csharp, python, powershell, javascript, typescript, java, go, etc.). |

### 2) Learn Catalog API (REST público, sem autenticação)

**Endpoint base:** `https://learn.microsoft.com/api/catalog/`

**Sempre passe `?locale=pt-br`** (ou en-us) e, opcionalmente, `&type=...`
para filtrar.

**Tipos retornados:**

| Tipo (param `type=`) | Quantidade aprox. | Conteúdo |
|----------------------|-------------------|----------|
| `modules` | ~3.500 | Módulos auto-paced |
| `units` | ~28.000 | Unidades dentro dos módulos |
| `learningPaths` | ~850 | Trilhas (sequências de módulos) |
| `appliedSkills` | ~35 | Avaliações práticas (lab credenciado) |
| `certifications` | ~140 | Certificações Microsoft |
| `mergedCertifications` | ~140 | Certificações pós-fusão de roles |
| `exams` | ~140 | Exames (AI-102, AZ-104, MS-900, etc.) |
| `courses` | ~157 | Cursos ILT/OD oficiais |
| `levels` | 3 | beginner / intermediate / advanced |
| `products` | ~58 | Azure, M365, GitHub, Power Platform, etc. |
| `roles` | ~35 | Developer, Administrator, Solution Architect, etc. |
| `subjects` | 6 | cloud-computing, ai-machine-learning, etc. |

## Schema dos objetos principais

### Learning Path
```json
{
  "uid": "learn.azure-linux",
  "title": "Linux no Azure",
  "summary": "...",
  "levels": ["beginner"],
  "roles": ["solution-architect","administrator","developer"],
  "products": ["azure","azure-virtual-machines"],
  "subjects": ["cloud-computing"],
  "duration_in_minutes": 200,
  "popularity": 0.51,
  "url": "https://learn.microsoft.com/pt-br/training/paths/azure-linux/",
  "modules": ["learn.introduction-to-linux-on-azure", "..."],
  "number_of_children": 4,
  "icon_url": "...", "social_image_url": "..."
}
```

### Certification
```json
{
  "uid": "certification.azure-for-sap-workloads-specialty",
  "title": "Microsoft Certificado: ...",
  "subtitle": "<HTML>",
  "url": "https://learn.microsoft.com/pt-br/credentials/certifications/...",
  "exams": ["exam.az-120"], "products": [...], "roles": [...],
  "levels": [...], "subjects": [...], "renewal_frequency_in_days": 365,
  "retirement_date": null
}
```

## Workflow padrão

### A) Listar Learning Paths por role

```powershell
$role = 'developer'   # ou 'administrator', 'data-engineer', 'security-engineer'...
$r = Invoke-RestMethod "https://learn.microsoft.com/api/catalog/?locale=pt-br&type=learningPaths&role=$role"
$r.learningPaths |
  Sort-Object popularity -Descending |
  Select-Object title, duration_in_minutes, @{n='Modulos';e={$_.number_of_children}}, url -First 15 |
  Format-Table -AutoSize
```

### B) Buscar certificações por produto

```powershell
$r = Invoke-RestMethod "https://learn.microsoft.com/api/catalog/?locale=pt-br&type=certifications&product=azure"
$r.certifications |
  Where-Object { $_.title -match 'AI|Copilot' } |
  Select-Object title, @{n='Exames';e={$_.exams -join ','}}, url
```

### C) Montar trilha completa para um exame

```powershell
$exam = 'ai-102'
$r = Invoke-RestMethod "https://learn.microsoft.com/api/catalog/?locale=pt-br&type=exams"
$e  = $r.exams | Where-Object { $_.uid -eq "exam.$exam" }
$e | Select-Object title, url, study_guide
# Depois pegue learningPaths que cobrem esse exam:
$lp = (Invoke-RestMethod "https://learn.microsoft.com/api/catalog/?locale=pt-br&type=learningPaths").learningPaths
$lp | Where-Object { $_.exams -contains "exam.$exam" } | Select-Object title, duration_in_minutes, url
```

### D) Buscar conceito específico (combo)

1. `microsoft_docs_search` com query natural ("how to deploy a container app to ACA with Bicep")
2. Para os 1-2 resultados mais relevantes, chame `microsoft_docs_fetch` com a URL para conteúdo completo
3. Se for tarefa de código, `microsoft_code_sample_search` com `language="bicep"` ou similar

## Parâmetros úteis do Catalog API

| Parâmetro | Valor | Efeito |
|-----------|-------|--------|
| `locale` | `pt-br`, `en-us`, `es-es` | Idioma |
| `type` | ver tabela acima | Filtra retorno a um único array |
| `level` | `beginner` / `intermediate` / `advanced` | Nível |
| `role` | `developer`, `administrator`, etc. | Role-based filter |
| `product` | `azure`, `m365`, `github`, `power-platform` | Produto |
| `subject` | `cloud-computing`, `ai-machine-learning`, etc. | Tema |
| `popularity` | (não filtra, usar client-side `Sort-Object popularity -Desc`) | Ordenação |
| `last_modified` | (client-side) | Recência |

> A API **não** suporta full-text search server-side. Para texto livre,
> baixe o array filtrado por `type` e use `Where-Object -match` em pt-br.

## Padrões de saída para o usuário

**Lista de paths/certs** → tabela com Título, Duração/Exames, URL clicável.

**Trilha de estudos** → seção com:
1. Visão geral (overview da meta)
2. Pré-requisitos (levels mais baixos)
3. Sequência recomendada (paths em ordem, com duração total)
4. Validação (Applied Skill ou exame)
5. Próximos passos (cert avançada ou role adjacente)

**Sempre inclua** URLs `learn.microsoft.com/pt-br/...` (não en-us) quando
o usuário interage em português.

## Cross-reference com outros skills

- **oe-schedule** — quando o usuário quer turma OE (instructor-led) que
  cubra o mesmo conteúdo do Learn path.
- **training-slas** — para prazos de inscrição/cancelamento.
- **business-value-study** / **treinamento-plan-designer** — quando a
  trilha entra num plano de capacitação para cliente.
- **private-deliveries** — para pedir delivery dedicada de um curso.

## Erros e recuperação

| Erro | Causa | Solução |
|------|-------|---------|
| 404 em Catalog API | UID inválido | Liste sem `uid` filter para descobrir o correto |
| Conteúdo em inglês mesmo com `locale=pt-br` | Item ainda não traduzido | Mostrar título original + nota; ou usar `en-us` consistentemente |
| `microsoft_docs_search` retorna trechos curtos | Limite de ~500 tokens por trecho | Use `microsoft_docs_fetch` na URL para conteúdo completo |
| Lista de modules muito grande | 3.500 itens | Sempre filtre por `product` ou `role` antes de retornar ao usuário |
| Certificação aposentada | Campo `retirement_date` preenchido | Sinalizar e sugerir cert merged equivalente |
