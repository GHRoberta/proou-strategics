# VISUAL_SYSTEM

Official FY26 Organizational Skilling slide design rules, including the
approved `SV1` visual standard.

## SV1 standard

`SV1` means Skilling Visual v1: the refined Organizational Skilling visual
system for learner-facing Microsoft Day / ESI decks. It combines the official
FY26 template DNA with the energetic title and gradient system refined during
customer-facing sessions.

Use `SV1` by default for Organizational Skilling decks:

- Warm-gray/light content slides with generous whitespace.
- Large Segoe UI Semibold headline color runs: Microsoft blue -> purple ->
  magenta.
- Native PowerPoint soft-gradient hero cards, never PNG cards or stacked
  rectangle simulations.
- Large colored numbered badges, never small black circles.
- Direct learner-facing language and action challenges.
- Rich speaker notes with narrative, useful talking points, and transitions.
- Final filenames in the format `CLIENTE_NomeApresentacao_vX_SVX.pptx`.

## Canvas and grid

- Widescreen 16:9: 13.33" x 7.5".
- Primary margin: 0.64" from top and left.
- Minimum safe margin: 0.5" from slide edges.
- Microsoft logo height: 0.32", placed at x 0.64" / y 0.64" on template-led
  slides.
- Main content starts at x 0.64"; align columns and visual blocks to this grid.
- Text boxes should use no internal padding when precise alignment matters.

## Typography

- Headings: Segoe UI Semibold.
- Body: Segoe UI.
- Cover and section divider titles: 40pt, sentence case.
- SV1 content slide titles: 38-52pt Semibold color runs for learner-facing
  Microsoft Day decks; do not fall back to quiet 20pt template titles unless
  the deck is explicitly template-only.
- Big headline slides: 60-66pt.
- Agenda items: 30-32pt.
- Slide subtitles: 18pt or larger.
- Body and card copy: target 16-18pt; use 14pt only for short secondary details.
- Captions, source lines, footers, badges, and metadata: 14pt minimum.
- No visible slide text should be below 14pt. If text does not fit at 14pt+,
  shorten the wording, increase whitespace, split the slide, or move supporting
  detail to speaker notes. Never solve density by shrinking core text.
- Line spacing: single; space after 0.
- Use sentence case. Avoid punctuation at the end of headlines unless needed.
- Large headlines may use slightly condensed character spacing.

## Palette

Use restrained Microsoft brand colors. Do not introduce random blues.

| Role | Color |
|---|---|
| Light base | `E8E6DF` |
| Soft light cards | `F4F3F5`, `FFF8F3`, `D9D9D6`, `D7D2CB` |
| Dark base | `091F2C` or `091F2D` |
| Light text | `FFFFFF` |
| Dark text | `000000` |
| Primary teal | `318581` |
| Microsoft blue | `0078D4` |
| SV1 title purple | `7356D9` |
| SV1 title magenta | `D83BCE` |
| Gradient teal | `49C5B1` |
| Gradient light blue | `8DC8E8` |
| Gradient purple | `A58AD4`, `C5B4E3` |
| Soft learner-card stops | `0078D4`, `7356D9`, `D83BCE` with high transparency/luminance |
| Neutral dark | `454142`, `8C8279` |

Maintain accessible contrast, targeting at least 4.5:1 for meaningful text.

## Visual rhythm

- Use a "sandwich" structure: dark/gradient cover, light content slides, dark or
  gradient section/bookend slides.
- Keep slides sparse and presenter-led; avoid filling every inch.
- Favor large type, whitespace, and two or three aligned blocks over dense
  bullets.
- Use a presenter-led layout bias: slides carry the thesis and a few readable
  anchors; speaker notes carry explanation, caveats, and evidence.
- Do not use decorative title underlines. They are not part of the template DNA.
- Use accent colors as grouping signals, not decoration.
- For learner-facing Microsoft Day / SV1 skilling decks, use expressive
  headline color runs: Microsoft blue -> purple -> magenta. Titles should feel
  large and energetic, closer to 38-52pt than the default 20pt template title.
  Keep the background and body layout from the Organizational Skilling template,
  but let the title system carry the SV1 visual energy.
- When drawing SV1 custom titles on template layouts, remove all inherited
  placeholders first. PowerPoint placeholder prompts such as "Click to add
  title" can render visually behind custom title text even when text extraction
  does not show them.
- Numbered steps should use large colored badges (blue, purple, magenta, teal,
  coral) rather than small black circles. Never leave PowerPoint layout
  placeholders visible behind custom step lists.
- For learner-facing hero/callout cards, use the approved SV1 soft-gradient
  treatment: one native PowerPoint rounded rectangle with `a:gradFill`
  blue -> purple -> magenta, high transparency/luminance, and a very soft
  shadow. Do not simulate this with multiple overlaid rectangles, because
  those render as visible bands in PowerPoint/OneDrive. Do not use external PNG
  cards unless the user explicitly approves an image-based design.
- Cover slides may use the same SV1 energy with large 46-52pt Segoe UI Semibold
  title runs, warm-gray background, concise event metadata, and a simple
  duration pill. Keep the cover editorial and spacious; avoid dense logos or
  decorative clutter.
- Do not label this visual style as `[CLIENTE]` in filenames. The reusable standard is
  `SV1`.

## Learner-facing language

- Speak directly to the learner in PT-BR: "você", "sua jornada", "seu próximo
  passo", "escolha um caminho".
- Challenge action without sounding like a project plan: "Escolha uma trilha",
  "Reserve uma turma", "Transforme interesse em prática".
- Avoid organization/account ownership language unless the deck is explicitly
  leader-facing.

## File-handling rules

- Treat a valid `.pptx` as a ZIP file with header `PK`.
- If a generated file starts with `D0 CF 11 E0`, it is an OLE/legacy file and
  should be regenerated or recopied from a valid ZIP source.
- Prefer `python-pptx` for reliable generation in this environment.
- Do not rely on PowerPoint `SaveAs` for final `.pptx` persistence unless the
  output format is explicitly validated.
- Work in `{{WORKDIR_LOCAL}}\` and copy the final artifact to OneDrive only once
  after validation.
- Use final filenames shaped as `CLIENTE_NomeApresentacao_vX_SVX.pptx`.
