# SLIDE_RECIPES

Reusable slide patterns for Organizational Skilling decks using the approved
`SV1` visual standard unless the user asks otherwise.

## 1. Title cover

- Background: warm-gray/light base, or deep blue-black for dark mode.
- Logo: top-left at x 0.64" / y 0.64", 0.32" high.
- Title: for Microsoft Day / learner-facing decks, use large SV1-style color-run
  title text at 46-52pt, blue -> purple -> magenta, left aligned.
- Metadata: 14-16pt near lower-left or under title; duration can be a small
  rounded blue pill.
- File output for this visual standard should end in `_SV1.pptx` unless a newer
  skilling visual standard has been explicitly defined.
- Use for: event/session title, customer day opening, standalone deck cover.

## 2. Conversation map

- Background: light base.
- Title: SV1-style color-run, 38-42pt, with a concise subtitle.
- Before adding the SV1 title, delete inherited title/content placeholders from
  the template layout. Do not rely only on text extraction; visually inspect for
  gray placeholder prompts behind titles.
- Left side: one native PowerPoint soft-gradient rounded card using blue ->
  purple -> magenta stops. Use the card itself as the emphasis; do not add a
  separate "Mensagem-chave" pill unless there is no card.
- Main prompt: two short lines at 22-26pt, well spaced, with a concise 14-16pt
  explanation below.
- Right side: three or four numbered items with large colored badges; avoid
  small black circles and avoid placeholder text.
- Use for: "O que você leva desta sessão" or "Nossa conversa hoje".

## 3. Agenda / journey list

- Background: light or dark.
- Title: use the SV1-style blue -> purple -> magenta run for learner-facing
  decks; default template 20pt titles are too quiet for Microsoft Day moments.
- Items: 30-32pt, large vertical spacing, no heavy bullets.
- Use numbers only when order matters.
- Use for: simple agenda, learner journey overview, certification path preview.

## 4. Big-headline summary

- Background: light base.
- Headline: 60-66pt, left aligned, vertically centered in upper half.
- Supporting copy: one or two 16-18pt columns aligned below.
- Use for: "Capacitação é estratégia de carreira" or a major thesis slide.

## 5. Two-column explainer

- Background: light base.
- Title: 20pt Semibold.
- Columns: each about 5.7" wide, aligned to x 0.64" and x 6.83".
- Subheads: 16pt Semibold; body: 16pt.
- Use for: "Microsoft Learn + ESI", "fundamento + especialização", or "aprender
  + validar".

## 6. Three-column path cards

- Background: light base.
- Columns: x 0.64", 4.77", 8.89"; width about 3.8".
- Subheads: concise; top edges aligned.
- Body: 16pt target, 14pt minimum for short secondary details, two or three
  short lines per column.
- Use for: Azure / Dados / Segurança, or Learn / Prática / Certificação.

## 7. Timeline / operating model

- Background: light base.
- Central band or arrow: dark base across the middle.
- Milestones: alternate above and below the band.
- Milestone titles: 16pt with SV1 accent sequence when used in a learner-facing
  deck; details: 14pt minimum.
- Step markers: large colored badges, never small black circles.
- Use for: assess -> plan -> learn -> practice -> validate.

## 8. OE schedule slide

- Background: light base.
- Use grouped cards by month or theme, not dense tables.
- Include only current rows from Dynamight/OE schedule.
- Show date, course title in simplified PT-BR, modality if known, and call to
  register.
- If there are many courses, show curated highlights and move full schedule to
  appendix or email.

## 9. Section divider

- Background: full-slide teal-blue-purple gradient.
- Title: 40pt white, left aligned.
- Use for: turning from "why" to "how", or from program overview to action.
- Keep text minimal; one phrase only.

## 10. Resources / close

- Resources slide: stacked link groups, clear labels, generous spacing.
- Closing slide: centered or left-balanced large "Obrigado" / "Thank you" with
  subtle gradient treatment and Microsoft footer.
- Include certification handoff when another session follows: create curiosity,
  do not duplicate exam mechanics.

## 11. Presenter notes

- Use notes as a presenter narrative, not a script to read verbatim.
- Recommended structure: `Narrativa`, `Pontos para pontuar`, and either
  `Transição`, `Pergunta para engajar`, or `Mensagem-chave`.
- Notes should help the presenter bridge slides, add useful context, and avoid
  overloading the slide itself.
- For 30-minute decks, write notes with a 2-3 minute delivery rhythm: one thesis,
  three to five useful talking points, and one transition line.

## QA gotchas

- Check that subheads do not wrap inconsistently across columns.
- Check month/course cards for overflow when course names are long.
- Keep at least 0.3" between cards and 0.5" from edges.
- Remove all template designer notes and placeholder text.
- Check contrast for teal/purple text on warm-gray backgrounds.
- If one slide becomes dense, split or simplify; do not shrink body text below
  14pt for visible content.
- Run a font-size QA pass with `python-pptx`: every visible text run must have
  an explicit font size and no run may be below 14pt. Unknown/inherited visible
  sizes should be fixed explicitly, because they can render differently in
  PowerPoint and OneDrive.
- After increasing type, export previews and re-check title/subtitle spacing,
  source/footer collisions, card overflow, and inherited template artifacts such
  as tiny copyright lines.
