---
name: organizational-skilling-slides
description: >
  Create and refresh Microsoft Organizational Skilling / ESI PowerPoint decks
  using the official FY26 visual system: Segoe typography, warm-gray/dark
  backgrounds, gradient section dividers, agenda/summary/resource layouts,
  the approved SV1 visual standard, learner-facing storytelling, Microsoft
  Learn and certification handoff, and current open-enrollment schedule data
  when needed. Use this skill whenever the user asks for Organizational
  Skilling slides, ESI presentations,
  Microsoft skilling decks, learner-facing training decks, Microsoft Day
  skilling sessions, capacitação Microsoft presentations, or a reusable
  standard slide style for skilling. Triggers: Organizational Skilling, ESI
  deck, Programa de Capacitação Microsoft, skilling slides, learning journey
  deck, Microsoft Day capacitação, OE schedule slide, certification handoff.
---

# Organizational Skilling Slides

Create or refresh `.pptx` decks for Microsoft Organizational Skilling and ESI
presentations using the official FY26 visual language and a learner-facing
storyline.

## Prerequisites

- Load the `pptx` skill for every workflow; if any source is SharePoint or
  OneDrive-hosted, follow `pptx/sharepoint.md` before downloading or editing.
- Use `python-pptx` for deck generation/editing unless an existing template
  must be edited at the XML level.
- Use Dynamight/OE schedule sources only when the deck includes open enrollment
  classes; do not invent dates or course availability.
- Use Microsoft Learn/catalog sources when referencing Learn paths,
  certifications, exams, or Applied Skills.
- Work locally under `{{WORKDIR_LOCAL}}\<temporary-folder>` and copy the final
  artifact to OneDrive only once after validation.
- Name every final deck as `CLIENTE_NomeApresentacao_vX_SVX.pptx`.
  Use ASCII tokens and underscores. `vX` tracks content/story version; `SVX`
  tracks the skilling visual standard. The current approved standard is `SV1`.

## Workflow

### 1. Classify the deck

Identify audience and purpose before writing slides:

| Mode | Use when | Default tone |
|---|---|---|
| Learner-facing | Broad employee/audience session | Direct, action-oriented: "você", "sua jornada", "escolha um caminho" |
| Leader-facing | HR, enablement, sponsors, account teams | Program operating model, adoption, metrics, next steps |
| Hybrid | Customer day or Microsoft Day with leaders and learners | Start with learner value, then explain program mechanics |

Avoid customer/account phrasing in learner-facing decks: use "seu desafio",
"sua próxima escolha", "o caminho que você quer trilhar" instead of
"próximos passos para a organização".

### 2. Build the storyline

Use a concise 30-minute structure unless the user asks otherwise:

| Slide | Role |
|---|---|
| Cover | Session promise and context |
| Conversation map | What the audience will leave knowing |
| Why skilling now | Business/technology change without fear framing |
| From role to journey | Learner chooses a role/theme path |
| Microsoft skilling ecosystem | Learn, ESI, workshops, credentials |
| Organizational Skilling model | Assess, plan, learn, practice, validate |
| Learning paths by theme | Azure, data, apps/agents, security, Power Platform |
| Open enrollment | Current classes from Dynamight when relevant |
| Certification bridge | Create demand for the next certification session |
| Action challenge | Concrete learner action in the next 24-48 hours |
| Close | Thank you / resources |

Do not make Copilot the center unless the source agenda or user explicitly
requests Copilot. Treat Copilot as one possible specialization, not the default
story.

### 3. Apply the visual system

Use the official FY26 design system plus the approved `SV1` refinements from
[Visual System](references/VISUAL_SYSTEM.md) and the slide recipes from
[Slide Recipes](references/SLIDE_RECIPES.md). Prefer warm-gray light slides for
content, dark/gradient slides for bookends and section turns. `SV1` is the
default for all Organizational Skilling / Microsoft Day skilling decks unless
the user explicitly asks for another visual system.

### 4. Generate or refresh the deck

When creating from scratch:

1. Use widescreen 13.33" x 7.5".
2. Use Segoe UI Semibold for headings and Segoe UI for body.
3. Reuse the layout recipes instead of inventing ad hoc layouts.
4. Keep body copy short enough for presenter-led delivery.
5. Apply the SV1 readability floor: no visible slide text below 14pt. Target
   16-18pt for card/body text, 18pt+ for subtitles, and 14pt minimum for
   sources, footers, captions, badges, and metadata. If content does not fit,
   simplify or split the slide instead of shrinking text.
6. Include speaker notes as presenter guidance: narrative, useful talking
   points, engagement question or transition. Keep slides sparse and let the
   notes carry supporting context.

When refreshing an existing deck:

1. Preserve the approved storyline unless the user asks to rewrite it.
2. Replace visual treatments with official templates/layout recipes.
3. Remove template placeholders, designer notes, old customer/account framing,
   and stale course dates.
4. Keep factual content traceable to source decks, Learn, or Dynamight.
5. If the user manually improves a cover, gradient card, or title treatment,
   treat the adjusted deck as the visual source of truth and fold the learning
   back into `SV1` guidance.

### 5. Validate and QA

Run the required `pptx` QA loop:

1. Extract text with `python -m markitdown`.
2. Search for placeholders such as `lorem`, `ipsum`, `xxxx`,
   `Designer note`, and old account-specific next-step wording.
3. Validate the file as a real ZIP `.pptx`; PowerPoint/OneDrive conversions may
   create OLE/legacy files if saved incorrectly.
4. Programmatically inspect visible text runs and confirm all explicit font
   sizes are at least 14pt. Treat inherited/unknown sizes on visible text as a
   QA issue to fix before delivery.
5. Export slides to images and inspect visually, ideally with a fresh
   subagent, before declaring the deck done.
6. Confirm the final filename follows `CLIENTE_NomeApresentacao_vX_SVX.pptx`;
   replace legacy suffixes such as `OrgSkillingVisual_B3` with `SV1`.

## Output Format

Return the final deck path and a short note with the major changes:

```text
Deck created: <absolute path>
Filename: CLIENTE_NomeApresentacao_vX_SVX.pptx
Focus: learner-facing Organizational Skilling story, SV1 visual standard,
current OE schedule, certification handoff.
```

## Error Handling

| Error | Likely cause | Recovery |
|---|---|---|
| SharePoint/OneDrive URL cannot be downloaded | Auth or sharing limitation | Follow `pptx/sharepoint.md`; use a local synced copy if available |
| PPTX opens as corrupt or has `D0 CF 11 E0` header | Saved as OLE/legacy file | Regenerate/copy a valid ZIP `.pptx` whose header starts with `PK` |
| OE schedule has no rows | Filters too narrow or Dynamight unavailable | State the data gap and create a resource slide without dates |
| Slide looks off despite valid file | Layout overflow or PowerPoint rendering difference | Export to JPG/PDF and fix by inspection, not by assuming XML validity |
| Final filename has legacy visual suffix | Old iteration name leaked into output | Rename to `CLIENTE_NomeApresentacao_vX_SVX.pptx`; for the approved skilling visual style use `SV1` |

## References

| Reference | Use |
|---|---|
| [Visual System](references/VISUAL_SYSTEM.md) | Fonts, colors, spacing, template DNA |
| [Slide Recipes](references/SLIDE_RECIPES.md) | Reusable slide layouts and QA gotchas |

## Post-Run Reflection

After completing a multi-step workflow, follow the
[core § 5 Post-Run Reflection](../../installed-plugins/_direct/mcaps-microsoft--MSX-MCP/skills/core/SKILL.md#5-post-run-reflection-continuous-improvement)
protocol when available.
