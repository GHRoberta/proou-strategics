---
name: tpm-cockpit
description: >
  Build, maintain, audit, and update the TPM Cockpit kanban dashboard
  (kanban_view.html + kanban_data.js) that tracks FY26 Skilling activity
  for {{USER_NAME}}'s portfolio (PD, TSPc, OE, SWM). Use whenever the
  user asks to add/move/remove a card, change status, sync with
  Dynamight AERs, audit rule violations, change UI labels, translate the
  dashboard, rename the title, regenerate KPIs, or do anything else with
  the kanban / cockpit / dashboard / quadro / painel of training
  activities. Triggers: TPM Cockpit, kanban, dashboard, painel, quadro,
  card, coluna, status, mover card, criar card, atualizar card, sincronizar
  AER, validar regras, traduzir dashboard, weekly update, daily update, update cockpit, atualização semanal, atualizar cockpit.
---

## ⚡ Daily Update — `update cockpit`

When the user types **"update cockpit"** (or "atualizar cockpit"),
execute this lightweight 5-step routine — meant for daily use, not the
full weekly refresh.

| # | Step | Tool / Workflow | Output |
|---|---|---|---|
| 1 | **Refresh intel on all non-Done cards** | `tpm-intel-refresh` skill — incremental WorkIQ scan over `discussion`, `submit`, `pending`, `approved` (window = `since lastScan - 1d`, default 7-day overlap if no `lastScan`). **BEFORE the WorkIQ scan**, enrich each card via `account-agent` (resolve customer → canonical MSX account: TPID, ATU, opportunity pipeline) and `customer-network` (account team + virtual/deal team + customer-side contacts). Use the enriched account name + key contacts list to drive higher-precision per-customer scans (see § "Account/Network enrichment" below). **Special attention to inbound customer emails** (sender domain ≠ `microsoft.com` ≠ partner domains, cross-checked against the customer-network contact list): tag each such update with `"customerEmail": true` in `intel.updates[]`. **Always run a dedicated [CONTATO] sweep** (see § "[CONTATO] TPC sweep" below) and merge any matches into the relevant cards' intel with `"katherineSignal": true` + classified `subtype` (status / blocker / hold / denial / approval / question). | Updated `card.intel.updates[]`, `lastSignalAt`, `lastScan`, plus `card.intel.account` (TPID/ATU/opp summary) and `card.intel.contacts` (key stakeholders). |
| 2 | **Pull Dynamight deltas for `pending` + `approved` only** | `private-deliveries` skill — for each card with an AER in `pending`/`approved`, refetch the AER's `esi_areaempowermentstatus`, `esi_dateutilized`, `esi_completedcredits`, `esi_estimatedlearners`, plus any new line items / engagements / work orders. Skip `discussion`/`submit` (no AER) and `done`/`backlog` (no daily change expected). | Per-card status diffs. |
| 3 | **Move cards to the appropriate column** | Apply transitions from Step 2: Submitted→`pending`, Approved+future month→`approved`, Approved+`dateutilized` set→`done`. **Auto-apply only deterministic transitions** (driven entirely by AER state). Anything requiring judgement (e.g., promote `discussion`→`submit` because a TPC email arrived) → flag and ask. | List of moves with rationale. |
| 4 | **Highlight cards needing attention** | Set `card.attention = { flagged: true, reason, since, source }` on every card that meets ANY trigger below. The view renders a 🚨 ATTN badge + red glow + a dismiss × button (manual dismiss persists in localStorage until `since` advances). | Updated `card.attention` blocks. |
| 5 | **Discover & file new to-submit requests** (TSP + customer) | WorkIQ scan for **inbound training/credit requests that still need a formal submission** — see § "To-Submit Request Discovery". Window = `meta.lastDailyUpdate → now` (fallback 30d). Two scans: (a) **TSP-originated** (Fast Lane/Green/KA Solution/ALLYIS/NetCom sizing or proposing new credits/deliveries); (b) **customer-originated** (a customer/CSAM asking for new training not yet submitted). Triage to genuine to-submit only, **dedupe vs existing cards in every column**, then create one `submit` card per request (`customer`, `title`, `month`, `projectedLearners`; evidence in `intel.updates[]`; `attention.flagged=true`, source `teams`/`email`, trigger `to-submit-request`). | New `submit` cards + a list of skipped/duplicate signals. |

### Attention triggers (Step 4)

A card gets `attention.flagged = true` when ANY of these are true since
the last run:

| Trigger | `source` | Priority |
|---|---|---|
| **Inbound customer email** detected in Step 1 (any update with `customerEmail: true` since `attention.since`) | `email` | 🔴 highest |
| **[CONTATO] TPC signal** with `subtype` ∈ {`blocker`, `hold`, `denial`} (e.g., AER on hold, credit denied, request blocked, missing info) | `tpc` | 🔴 highest |
| **[CONTATO] TPC signal** with `subtype` ∈ {`status`, `approval`, `question`} (status change, approval issued, info needed) | `tpc` | 🟡 |
| Any new Teams message from a customer-domain sender | `teams` | 🔴 |
| AER status changed in Step 2 (Submitted→Approved, hold/cancellation) | `dyna` | 🟡 |
| Card sitting in `pending` for **>10 days** without status change | `dyna` | 🟡 |
| Card in `approved` whose `deliverymonth` is within **next 14 days** and `trainedLearners` still null | `dyna` | 🟡 |
| Audit rule violation (R5/R6/R7/R8/R_TSP_MISSING_WITH_AER) newly introduced | `audit` | 🟠 |

### Attention data model

```js
card.attention = {
  flagged: true,
  reason: "Customer email from joao@cliente.com on 2026-04-24 — RE: Copilot training scope",
  since: "2026-04-24T16:20:00Z",   // ISO; bump whenever a NEW signal arrives
  source: "email" | "teams" | "dyna" | "audit" | "tpc",
  triggers: ["customer-email"]      // optional list when multiple fire at once
}
```

### View-layer rules (locked-in 24-Apr-2026)

- **Float-to-top:** within every column (Status view), cards with
  `attention.flagged === true` are sorted to the top of the pile (stable
  order otherwise). Implemented in `renderColumn` via a
  `(b.attn - a.attn) || (a.i - b.i)` sort key.
- **Badge style:** the persistent attention indicator is a single 🚨 icon
  plus an inline `×` dismiss button, anchored to the **top-right corner**
  of the card (`position: absolute; top: 4px; right: 4px;`). No "ATTN"
  text label. The reason string surfaces on the back face
  (`.attn-reason` strip) for context.
- **Fresh-alert red frame:** when a card receives a NEW `attention.since`
  (i.e., a signal newer than what the user has acknowledged), it renders
  with a pulsing red frame (`.attention-fresh` class). The frame goes
  away when EITHER:
    1. the user expands the card by clicking it (`openCardDetail` clears
       the class and bumps the per-card "seen" timestamp in
       `localStorage["tpm_cockpit_attn_seen_v1"]`), OR
    2. the next page refresh — `bumpAllFreshSeen()` runs 1.5 s after
       render and writes every currently-fresh `since` value to the
       "seen" map, so the next reload sees them as already acknowledged.
  When a brand-new signal advances `attention.since` again, the frame
  re-appears automatically. Console escape hatches:
  `window.tpmResetAttnSeen()` and `window.tpmResetAttnDismiss()`.
- **Dismiss `×`:** writes the card key + current `attention.since` into
  `localStorage["tpm_cockpit_attn_dismiss_v1"]`. The 🚨 badge AND the
  red frame both reappear the next time `attention.since` advances (a
  newer signal arrives).

### Account/Network enrichment (mandatory pre-step in Step 1)

Before scanning WorkIQ for a customer's signals, chain in two skills to
lock the right account context. This avoids ambiguity (e.g., "[CLIENTE]"
vs "[CLIENTE] Seguros" vs "[CLIENTE] S/A"), reduces false positives on
`customerEmail` tagging, and grounds every signal in the current
opportunity pipeline.

#### ⚠️ Name-resolution rule (mandatory — added 28-Apr-2026)

`msx-mcp-get_account_overview(tpid=…)` returns the **TPID
master / legal-holding entity name** in its header (e.g., `PARATI SA`
for TPID [TPID], `Centro Distribuidor de Cervejas SA` for AMBEV).
This name is OFTEN NOT the operating-brand account that the deal team
and customer use day-to-day (e.g., the operating account in MSX UI
is `[CLIENTE] SA`, owner [CONTATO]).

Symptom of getting it wrong: the briefing tells the user
"Account in MSX: PARATI SA" and the user immediately catches it
because their MSX UI shows `[CLIENTE] SA`.

**Resolution algorithm — apply EVERY time:**
1. Call `get_account_overview(tpid=<n>)` → capture the tool's `name`
   header as `account.legalEntity` (NOT as `account.name`).
2. Inspect the `Account Team` and pipeline rows: the **owner of the
   highest-value opportunity** is virtually always assigned to the
   operating account, not the holding entity.
3. Resolve `account.name` (the operating-brand label) by EITHER:
   a) Querying `accounts` entity for child accounts with the same
      TPID and picking the one whose `name` best matches the card's
      `customer` field (case-insensitive contains, longest match wins);
      OR
   b) Cross-referencing with the user-recognizable name already in
      `card.customer` — if the card already uses the operating brand
      (e.g., `customer: "AMERICANAS"`), keep that brand and just add
      the formal version (`[CLIENTE] SA`) as `account.name`.
   c) Asking the user via `ask_user` if neither (a) nor (b) yields
      a confident match.
4. Persist BOTH names so the discrepancy is auditable:
   - `account.name` = operating brand (used in briefings, reports)
   - `account.legalEntity` = holding/master name (kept for completeness)
   - `account.nameResolutionNote` = short string explaining the
     mapping when it's non-trivial.
5. NEVER use the legal-entity name in user-facing briefings unless the
   user explicitly asks for legal/contractual context.

**Order of operations per card** (in `discussion`, `submit`, `pending`,
`approved`):

1. **`account-agent`** — resolve `card.customer` → canonical MSX account.
   Capture: TPID, **operating-brand display name (per name-resolution
   rule above)**, **legal-entity name**, ATU group, primary industry,
   list of open opportunities (id, name, stage, value, close date,
   sales play, solution area). Persist a compact summary under
   `card.intel.account = {tpid, name, legalEntity, atu, opps:[…],
   nameResolutionNote, refreshedAt}`.

2. **`customer-network`** — pull the account team + virtual/deal team
   for that TPID + known customer-side contacts (sponsors, champions,
   POCs from prior emails). Persist under
   `card.intel.contacts = {internal:[…], customer:[…], partner:[…]}`
   keeping only `{name, email, role}` per entry.

3. **Then** run the per-customer WorkIQ scan, passing the enriched
   account name AND the contact list as scope hints. Use the
   `customer.email` set to drive `customerEmail` tagging deterministically
   (an inbound email from any address in `card.intel.contacts.customer`
   is a confirmed customer email — overrides the generic deny-list
   heuristic).

**When to skip enrichment:**
- Card has `legacy: true` (frozen historical bucket).
- `card.intel.account.refreshedAt` < 14 days old AND no AER status
  change in Step 2 — reuse the cached enrichment to save API calls.
- `account-agent` returns no match (e.g., true prospect not yet in MSX)
  → log under `meta.unmatchedAccounts[]` and proceed with raw
  `card.customer` for the WorkIQ scan.

**Cache cadence:** `card.intel.account.refreshedAt` is bumped only when
`account-agent` is actually invoked (every 14 days, or on-demand via
weekly update). The contact list (`card.intel.contacts.refreshedAt`)
follows the same rhythm.

### [CONTATO] TPC sweep (mandatory in Step 1)

[CONTATO] Barboza Salazar (Training Program Coordinator) is the
gatekeeper for every TSPc credit request and PD submission. **Her
signals frequently arrive without naming the customer in the subject
line** (e.g., "RE: AER-134785 — credit-back" or "Hold on Q4 batch") —
so a per-customer WorkIQ scan can miss them. The daily routine MUST
run a dedicated [CONTATO] sweep alongside the per-customer scans.

**Sweep query (WorkIQ):**
```
List all emails and Teams messages exchanged with [CONTATO] Barboza
Salazar in the last <N> days where she is sender or recipient AND the
content mentions any of: TSPc, TSP credits, AER, AER-, PD, Private
Delivery, SWM, hold, blocked, denied, denial, cancelled, credit-back,
status, approval, submitted, pending. For each: date, source, direction
(to/from [CONTATO]), AER ID if mentioned, customer if mentioned, 1-2
sentence summary, and classify subtype as one of:
  - status      (mere status update / FYI)
  - approval    (AER approved or credits granted)
  - blocker     (something is blocking submission/execution)
  - hold        ([CONTATO] put it on hold pending input)
  - denial      (request denied / credits not granted / cancelled)
  - question    ([CONTATO] asking for info)
```
- `<N>` = days since `meta.lastDailyUpdate` + 1 (default 7 if missing).
- **Routing**: each match must be linked to a card. Match priority:
  (1) AER ID present in message → find card by `aer.id` / `aers[].id`;
  (2) Customer name in message → find card(s) by `customer`; if multiple,
      attach to all matching `pending`/`approved` cards;
  (3) No customer/AER → log under `meta.unroutedKatherineSignals[]` and
      surface in the daily report so the user can route manually.
- Mark each routed update with `"katherineSignal": true` and
  `"subtype": "<one of above>"` inside the card's `intel.updates[]`.
- Trigger `card.attention` per the table above based on `subtype`
  severity (denial/hold/blocker = 🔴; status/approval/question = 🟡).
- The reason string MUST start with `[CONTATO] — ` and include the
  subtype + AER (if any), e.g.:
  `"[CONTATO] — HOLD on AER-134785 pending [CLIENTE] confirmation (2026-04-22)"`.


**Behavioral rules:**
- **Setting `flagged: true`** — always overwrite `since` to the timestamp
  of the freshest triggering signal. This is what causes a previously-
  dismissed alert to **reappear** automatically (the view compares
  `attention.since > localStorage[dismiss]`).
- **Manual dismiss** is stored client-side in `localStorage` under key
  `tpm_cockpit_attn_dismiss_v1`. It is **NEVER written back to
  `kanban_data.js`** — keep the data file as the single source of
  triggers; the dismiss layer is purely a UX overlay.
- **Reset all dismissals**: in browser console, call `tpmResetAttnDismiss()`.
- **Clearing `flagged` from data**: only do this when the underlying
  condition is genuinely resolved (e.g., card moved to Done). Otherwise
  leave `flagged: true` and let the user dismiss visually.
- **Customer email detection**: PRIMARY source is the
  `card.intel.contacts.customer[]` set populated by `customer-network`
  in the enrichment pre-step — any inbound email from one of these
  addresses is a confirmed customer email. FALLBACK heuristic when no
  contact list is available (or the sender isn't in it): WorkIQ doesn't
  always expose sender domain — use a deny-list of internal/partner
  domains: `microsoft.com`, `green.com.br`, `fastlaneus.com`,
  `ka-solution.com.br`, `{{EMAIL}}`. Anything else with a
  real personal sender (not `noreply@`, not `notifications@`) counts
  as a customer email.

## To-Submit Request Discovery (TSP + customer)

> Added 22-Jun-2026 (V2.2). The routines previously only refreshed intel on
> **existing** cards — they were blind to **inbound new requests** that need a
> formal submission (a TSP sizing credits for a customer, or a customer asking
> for a new training). Those sat in email/Teams and never reached the board.
> This step mines Teams + Outlook for **requests that still need to be
> submitted** and files them as `submit` cards. First run (22-Jun-2026)
> surfaced [CLIENTE]/Prefeitura-SP (Fast Lane, ~52 TSPc) and [CLIENTE] (Green, 434
> seats).

### When it runs & the scan window

- **Daily** (`update cockpit`): Step 5. Window = `meta.lastDailyUpdate → now`.
- **Weekly** (`Weekly Update`): Step 1b. Window = `meta.lastWeeklyUpdate → now`.
- Fallback when the cursor is missing: **30-day** lookback (used for the
  first backfill).

### WorkIQ access (operational — important)

WorkIQ is reachable two ways; both hit the same engine:
- **MCP tool** (when the `workiq` MCP server is registered as a tool):
  `workiq.ask_work_iq`.
- **CLI** (always available, no MCP tool needed — use this when WorkIQ is not
  in the tool list):
  ```powershell
  & "{{COPILOT_HOME}}\bin\workiq.cmd" ask -q "<question>"
  ```
  The wrapper pipes the question to `workiq.exe ask` on stdin and streams the
  answer to stdout. Output carries ANSI color + OSC-8 hyperlink escape codes —
  tolerate or strip them. For clean parsing, redirect to a file
  (`… ask -q "…" *> _wq.txt`) and read the file. Queries take ~60–120 s; in
  sync mode use a long `initial_wait` (≥180 s) or the file-redirect pattern.

### The two scans (run both, every time)

**(a) TSP-originated** — a Training Service Partner proposing/**sizing** a new
delivery or credits for a customer:
```
Search my Teams + Outlook from the last {N} days (since {YYYY-MM-DD}).
List every message where a TSP (Fast Lane/Ana Teixeira, Green, KA Solution,
ALLYIS, NetCom) is requesting/proposing/sizing a NEW training delivery or
training CREDITS for a customer that I'd need to formally SUBMIT to my TPC.
For each: CUSTOMER | PARTNER+person | DATE | CHANNEL | TRAINING(courses) |
SCALE(credits/seats) | EVIDENCE(verbatim quote). Separate with ===.
Exclude anything already approved/submitted/delivered.
```

> ⚠️ **Run scan (a) once PER partner** — issue a separate focused query for
> **each** TSP (Fast Lane, Green, KA Solution, ALLYIS, NetCom), ideally keyed
> on the partner email domain (`fastlaneus.com`, `green.com.br`,
> `ka-solution.com.br`). A single combined multi-TSP query **under-surfaces
> lower-volume partners**: in the 22-Jun-2026 first pass the combined query
> returned only Fast Lane ([CLIENTE]) + Green ([CLIENTE]) and **missed KA Solution's
> [CLIENTE] and [CLIENTE] ESI skilling plans** — they only appeared once
> a dedicated `ka-solution.com.br` scan was run. When per-partner, also relax
> the filter (ask for "new request / sizing / unclear", not only strict new
> asks) and triage yourself.
>
> 🎯 **Also spot-check each active TSP's known customer portfolio BY NAME.**
> Partner emails whose subject does **not** name the customer (e.g., KA
> Solution's *"Treinamentos Microsoft - Ka Solution"*) get missed even by a
> per-domain partner scan. When a TSP is active, run a quick per-customer
> scan for each of its known accounts (KA Solution → [CLIENTE], Einstein, [CLIENTE],
> [CLIENTE]; Green → [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE]…; Fast
> Lane → [CLIENTE]/[CLIENTE], [CLIENTE] AI-3025). On 22-Jun-2026 the Einstein
> ~2,000 Copilot Premium plan (KA Solution) surfaced **only** via an
> Einstein-named scan, after both the combined and the KA-domain scans
> missed it.

**(b) Customer-originated** — a customer (bank/gov/enterprise), or a Microsoft
AE/CSAM/ATS relaying on their behalf, asking for new training not yet
submitted:
```
Search my Teams + Outlook from the last {N} days (since {YYYY-MM-DD}).
List every message where a CUSTOMER (not a TSP) is requesting NEW Microsoft
training (Copilot, Azure, security, GitHub Copilot, certs…) not yet submitted
for credits/approval. For each: CUSTOMER | REQUESTER+email | DATE | CHANNEL |
TRAINING | SCALE | EVIDENCE. Separate with ===. Exclude already
approved/submitted/delivered and newsletters.
```

### Triage — what qualifies as "to submit"

INCLUDE only genuine, actionable asks where the next step is **you submitting**
a credit/AER request:
- TSP has **sized/aligned** credits but no AER submitted yet (e.g., Ana/Fast
  Lane: "52 créditos, já alinhei com eles" for [CLIENTE]).
- Customer/CSAM **explicitly asks** to enable a delivery ("solicitar apoio para
  viabilizarmos um webinar … ~2000 participantes").
- A TSP asks for a **(re)submission** of a plan for evaluation.

EXCLUDE (the scans pre-filter these; double-check):
- Already approved / submitted / delivered (AER exists, tokens used, "Request
  ID … submitted", "credits approved").
- Pure status/alignment follow-ups with **no quantified new ask**.
- Exploratory sizing with no customer alignment yet → that's **discussion**,
  not submit.
- Internal Microsoft chatter not originating a request.

### Dedup (mandatory before creating a card)

For each surviving candidate, check existing cards by customer:
- Same customer already in **`pending`/`approved`/`done`** for the **same**
  scope → **do NOT** create a card (already in flight); log as skipped dup.
- Customer already in **`discussion`** on the **same** thread → **do NOT**
  duplicate; surface it and let the user decide on a `discussion → submit`
  promotion.
- A **follow-on / next batch** beyond a *delivered* AER **is** a new card
  (e.g., the June [CLIENTE] ~52-credit round is distinct from the delivered May
  AER-137526).
- Reuse the existing folder/spelling to avoid fragmenting customers ([CLIENTE] →
  `[CLIENTE]`; [CLIENTE] group → `[CLIENTE]`).

### Create the `submit` card, then stamp + build

One card per qualified request at `cockpit-cards/<CUSTOMER>/<id>.md`:
- Required: `customer`, `column: submit`, `type` (`tsp` if partner-delivered →
  also set `tsp:`), `title`, `month` (or `TBD`).
- `projectedLearners` (R7 requires it in `submit`) from the sized scale.
- `intel.updates[]` carrying the **evidence** (date, source, from, verbatim
  summary). Not `customerEmail` unless the sender is the customer.
- `attention: { flagged: true, since: <now>, source: teams|email,
  triggers: ["to-submit-request"], reason: "NEW to-submit (WorkIQ <date>): …" }`.
- Body: `## Action` = the concrete "▶ submit …" next step; `## Notes` =
  provenance + open questions (entity to confirm, attachment to open).

```powershell
$env:PYTHONUTF8="1"
python cockpit_robot_write.py --stamp   # signs the new card(s)
python cockpit_build.py                 # regenerates kanban_data.js + validates
```

### Report

List created `submit` cards (customer · scale · evidence date) **and**,
separately, every skipped/duplicate signal with its reason — so nothing
inbound is silently dropped.

### Daily vs Weekly — when to use which

| Aspect | Daily (`update cockpit`) | Weekly (`Weekly Update`) |
|---|---|---|
| Intel scope | All non-Done cards (incremental, ~7-day overlap) | All non-Done cards (incremental, 90-day base on first run per card) |
| Dynamight scope | `pending` + `approved` only (status + actuals) | All FY26 AERs full pull |
| PBI Attainment | Skipped | Refreshed via `pbi_export_attainment.py` |
| 3-way reconciliation | Skipped | Full Health audit via `sync_cockpit.py` |
| Card moves | Deterministic only (AER state) | Deterministic + R0b promotions (with confirmation) |
| KPI refresh | Skipped (use Step 6 of weekly) | Yes, full refresh |
| Attention flagging | **Yes — primary purpose** | Yes (inherited; weekly also sets it) |
| To-submit discovery | Step 5 — scan `lastDailyUpdate → now` | Step 1b — scan `lastWeeklyUpdate → now` |
| Estimated runtime | 1–2 min | 5–10 min |

---



## ⚡ Weekly Update — single-command full refresh

When the user types **"Weekly Update"** (or "atualização semanal"), execute
the full 6-step routine in order. Each step has a dedicated workflow
elsewhere in this skill or in a sibling skill — this section is the
orchestration contract, not a reimplementation.

| # | Step | Tool / Workflow | Output |
|---|---|---|---|
| 1 | **Refresh intel on all non-Done cards** | `tpm-intel-refresh` skill — runs WorkIQ scan over `discussion`, `submit`, `pending`, `approved` columns (90-day window, incremental via `intel.lastScan`). **BEFORE the WorkIQ scan**, enrich each card via `account-agent` + `customer-network` (see § "Account/Network enrichment") to lock canonical TPID/ATU/opp pipeline + stakeholder list. Then run `R0b` audit on `backlog`: any Inactive customer with signals in last 30 days → flag for promotion. | Updated `card.intel.updates[]` + `lastSignalAt` + `lastScan` + `card.intel.account` + `card.intel.contacts`. List of Inactive promotion candidates. |
| 1b | **Discover & file new to-submit requests** (TSP + customer) | WorkIQ TSP-originated + customer-originated scans (window `meta.lastWeeklyUpdate → now`) — see § "To-Submit Request Discovery". Triage to genuine to-submit, **dedupe vs all columns**, create one `submit` card per request (evidence in `intel.updates[]`, `attention.flagged=true`). Independent of the numbered steps below. | New `submit` cards + skipped-duplicate list. |
| 2 | **Sync Dynamight (AERs + actuals)** | `private-deliveries` skill § 1 — pull all FY26 AERs `_esi_accounttpm_value eq <me>`. For each, capture status, productcategory, deliverymonth, dateutilized, esi_tspaccount, estimatedlearners, completedcredits, creditbackqty. Pull TSPc actuals from `esi_learningpartnerengagements.esi_reportedlearnerscount`. Pull PD actuals from `msdyn_workorder.esi_attendancecount`. | New AERs found, status changes, fresh actuals. |
| 3 | **Refresh PBI Attainment Report** | `python pbi_export_attainment.py --headless` (see § 5.5). | Updated `attainment_FY26.xlsx`, `attainment_summary.json`. Verify grand-total reconciles to PBI headline. |
| 4 | **Reconcile (3-way audit)** | `python sync_cockpit.py` — generates `health_audit.json` + `health_audit.js` for the 🩺 Health tab. Surface every status: `OK`, `CARD_AHEAD_DYNA`, `MISSING_AER_IN_KANBAN`, `MISSING_CARD_IN_DYNA`, `PBI_PRIMARY`. | Health diff report grouped by status. |
| 5 | **Move cards to the appropriate column** | Apply column transitions per § 1 entry criteria using Step 2 data: Draft AER → `submit`; Submitted → `pending`; Approved + future deliverymonth → `approved`; Approved + dateutilized set → `done`. Promote Step 1 R0b candidates from `backlog` → `discussion` (ask user for confirmation per current convention). Apply Step 4 fixes (e.g., add missing AERs to cards via `MISSING_AER_IN_KANBAN`). | Card movements + before/after column counts. |
| 6 | **Update all metrics** | Refresh `kpis.{tspc,pd}` (headline + `byQuarter`) from Step 2 Dynamight rollups. Run `python sync_cockpit.py --apply` to push Dynamight actuals into `card.trainedLearners` (skips `pbiPrimary` cards). Run validator (§ 6) and report violations. | Updated KPIs + final audit ribbon. |

**Behavioral rules:**
- Steps run **sequentially** — Step 4 needs Steps 2+3 outputs; Step 5 needs Steps 1+2+4; Step 6 needs Steps 2+5.
- **Never auto-mutate `kanban_data.js` for promotions** that require human judgement (R0b Inactive→Discussing, new MSX opportunities). Flag and ask the user. Auto-apply is fine for AER status transitions, learner counts, and KPI numbers — those are deterministic from Dynamight/PBI.
- **Final report format**: a per-step section with counts (cards touched, AERs found, signals added, learners synced) + a "📋 Action Required" block listing any pending user decisions (promotions, rule violations, missing AERs, MISSING_CARD_IN_DYNA mismatches).
- **If any step fails**, stop and report — do NOT silently skip. Common failure modes: Dynamight auth expired (run `msx-mcp-msx_login`), PBI export race (re-run Step 3), Excel COM unavailable (Step 3).
- **Cache-friendly**: Step 1 uses `intel.lastScan` to scope WorkIQ queries to "since last scan + 7-day overlap"; Step 2 should request `modifiedon ge <last weekly run>` when possible. Record the run date in `meta.lastWeeklyUpdate` after Step 6 succeeds.
- **Estimated runtime**: 5–10 min total (Step 1: ~2 min for ~20 customers, Step 2: ~1 min, Step 3: ~60 s, Step 4: <10 s, Step 5: ~30 s, Step 6: ~30 s).


# TPM Cockpit — FY26 Skilling Kanban

> **V1.2 — released 24-Apr-2026.** Ships the **attention-flag system**
> driven by the Daily Update routine: floating-to-top sorted cards,
> top-right 🚨 badge with × dismiss, fresh-alert red frame that auto-clears
> on click or next refresh. Also a render-perf refactor (per-pass
> localStorage snapshot — previously 60+ LS hits per render became 2)
> and a `data-card-key` DOM attribute that replaced fragile text-scrape
> lookups. See § 15 for the full V1.2 changelog.

> **V1.1 — released 24-Apr-2026.** Adds 🩺 Health tab (3-way Cockpit ⇄
> Dynamight ⇄ PBI reconciliation), Open Enrollment side-bar inside the
> Skilling Pipeline row, `pbiPrimary` card flag, and a major view-layer
> refactor that removed ~80 lines of dead localStorage/override code.
> See § 14 for the full V1.1 changelog and § 13 for V1.

The single source of truth for {{USER_FIRSTNAME}}'s training-activity workflow. Two
files only:

| File | Role |
|---|---|
| `{{WORKDIR}}\kanban_view.html` | View layer (renders columns, tabs, KPIs, Skilling Pipeline + OE side-bar, Period filter, validator, 🩺 Health tab) |
| `{{WORKDIR}}\kanban_data.js`   | Data layer (`window.KANBAN_DATA = {meta, kpis, columns}` — `kpis.{tspc,pd,oe}` carry both FY totals and `byQuarter` blocks) |
| `{{WORKDIR}}\health_audit.js`  | Auto-generated by `sync_cockpit.py`; loaded by the view as `window.HEALTH_AUDIT` to power the 🩺 Health tab (no fetch/CORS) |
| `{{WORKDIR}}\sync_cockpit.py`  | 3-way audit (Cockpit ⇄ Dynamight ⇄ PBI) + `--apply` to push Dynamight actuals into card `trainedLearners` |

Open `kanban_view.html` in a browser — it is fully client-side, no server.

## When to use this skill

Always when the user asks to:
- Add/move/remove a kanban card
- Change a card's status (column), TSP, AER linkage, dates, seats
- Sync the dashboard with Dynamight (AERs created/approved/canceled)
- Audit rule violations (cards in wrong column, missing AER, missing TSP)
- Update KPIs (budget, booked, consumed, learners trained, planned seats)
- Translate or rename UI elements
- Add new chips, badges, columns, view tabs
- Regenerate the dashboard from a fresh Dynamight pull

> 🔒 **Source-of-truth rule:** for any AER/credit/learner number,
> ALWAYS reread it from Dynamight via the `private-deliveries` skill.
> Never invent values. The kanban is a *projection* of Dynamight, not
> the source.

## 1. The 6-column workflow (canonical)

| # | Column ID | Title | Entry criteria | Required fields |
|---|---|---|---|---|
| 1 | `backlog`     | 📋 Inactive         | Dormant customers — not appearing in any other column **AND** no detected discussion activity (email/Teams) in the last **30 days**. **De-dup rule:** any customer present in stages 2–6 must NOT also appear here. **Recency rule:** if recent M365 signals are detected (via `card.intel.lastSignalAt` or freshest `card.intel.updates[].date` ≤ 30 days), the card must be promoted to Discussing. | `customer`, `title` |
| 2 | `discussion`  | 💬 Discussing       | Skilling discussions underway — Customer record linked in Dynamight | `customer`, `title`, *(future: `dynamightId`)* |
| 3 | `submit`      | ✍️ To Submit        | Approved opportunity awaiting submission to TPC ([CONTATO]) → approval by Carlos or SWR. **MSX Opportunity linked.** | `customer`, `title`, `month` |
| 4 | `pending`     | ⏳ Waiting Approval | Formal credit/AER request email sent to [CONTATO] (TPC). The AER creation/approval cycle inside Dynamight is **opaque to the TPM** — once the request is on [CONTATO]'s queue, the card lives here regardless of whether the AER number has been issued yet. | `customer`, `title`, `month` |
| 5 | `approved`    | ✅ Executing        | In execution (MTT PD or TSP-Partners) — **approved AER required**. | `customer`, `title`, `month`, `aer`, `tsp` (if TSPc) |
| 6 | `done`        | 🏁 Done             | Closed — **AER approved AND participants correctly reported**. | `customer`, `title`, `month`, `aer`/`aers`, `tsp` (if TSPc) |

**Mandatory:** any card in stages 5 or 6 MUST have `aer:{id,guid}` or
`aers:[{id,guid},…]`. The view layer surfaces violations via the
self-validation banner (see § 6).

**Legacy exemption:** historical/summary cards predating systematic
AER tracking can be marked with `legacy: true` to bypass the AER
requirement. Use sparingly and ONLY for genuine legacy buckets — never
to suppress the alarm on real new deliveries.

**PBI-primary exemption (V1.1):** cards that intentionally aggregate the
**PBI Attainment Report total** instead of Dynamight (e.g., a customer
whose deliveries are spread across multiple AERs not all in the TPM's
portfolio) can be marked with `pbiPrimary: true`. These cards:
- are skipped by `sync_cockpit.py --apply` (their `trainedLearners` is
  never overwritten by the Dynamight roll-up);
- show status `PBI_PRIMARY` (purple badge) in the 🩺 Health tab — never
  flagged as `CARD_AHEAD_DYNA`;
- should carry `trainedSource: "pbi-attainment"` and a short `note`
  explaining the mismatch (which Delivery IDs / AERs are aggregated).
Example: [CLIENTE] AER-132923 — 18 PBI Delivery IDs span FY25
carryover and AERs not in the current TPM portfolio.

**Duplication rule (split TSP):** when 2+ TSPs serve the same customer
in the same period, create **one card per TSP** (e.g., [CLIENTE]-Green +
[CLIENTE]-Fast Lane). Each card carries only its own AERs.

## 2. Card data model

```js
{
  type: "tsp" | "pd" | "oe" | "swm" | "disc",   // delivery model (see § 3)
  customer: "[CLIENTE] Seguros",                  // proper noun, NEVER translated
  month: "Jun/26" | "TBD",                       // English abbreviation, FY26 = Jul/25..Jun/26
  tsp: "Green" | "Fast Lane" | "KA Solution",    // ONLY when type=tsp; mirrors AER esi_tspaccount
  aer:  { id:"AER-136172", guid:"…" },           // ONE AER (single-AER cards)
  aers: [{ id, guid }, …],                        // MANY AERs (rolled-up done cards)
  title: "MS-4023 · 3 classes via Green<br><small>context · POC · dates</small>",
  chips: [
    { type:"tsp"|"pd"|"swm"|"oe"|"disc", txt:"TSPc" },
    { type:"seats", txt:"1,500" },                // visual chip — derived from projectedLearners/trainedLearners
    { type:"date",  txt:"02/09/11-Jun" }
  ],
  projectedLearners: 1500,                           // planned reach (forecast/committed pipeline only)
  trainedLearners: 1480,                          // OFFICIAL Power BI / Dynamight number — Done column only; null = pending sync
  quarter: "Q1" | "Q2" | "Q3" | "Q4",            // FISCAL quarter the AER consumes (used by the Period filter — required on Executing & Done cards that carry an AER)
  badges: ["urgent" | "hold"],                    // optional
  badgeText: "URG" | "ON HOLD" | "20K",           // overlay label
  action: "▶ Next concrete step (start with ▶, 🔴, 🟡, ✅)"
}
```

**Field rules:**
- `type` is the delivery-model classifier and MUST equal the AER's
  `esi_productcategory` (see § 3 mapping).
- `customer` matches the Dynamight account display name. Never
  translate Brazilian proper nouns.
- `month` uses English 3-letter abbreviations + `/YY` slot (`May/26`,
  `Jun/26`, `Jul/25`). `MONTH_ORDER` and `MONTH_STYLES` in
  `kanban_view.html` MUST stay in lockstep with these strings.
- `tsp` is mandatory whenever `type==="tsp"` AND an AER exists.
  Source: `_esi_tspaccount_value@OData.Community.Display.V1.FormattedValue`
  on the AER (NOT `_esi_trainingservicepartner_value`, which is empty).
- `aer.guid` enables the click-through link to Dynamight.
- Number separators: en-US (`1,500`, `4,000`). Never pt-BR (`1.500`).
- **`projectedLearners`** (numeric, required for stages 2–5):
  source = AER `esi_estimatedlearners` (header) or sum of line
  `esi_expectednumberoflearners`. Use the value AS-IS — **no
  high-volume overrides** (those are deprecated for the cockpit, see
  `private-deliveries` § 5b).
- **`trainedLearners`** (numeric, required for `done` column):
  - **Primary source (TSPc):** `esi_learningpartnerengagements.esi_reportedlearnerscount`
    keyed on AER GUID — pull live from Dynamight (see `private-deliveries`
    SKILL § 5b authoritative actuals). Cross-checked against the FY26 TPM
    Learner Attainment Power BI report (https://aka.ms/FieldExecutionReports).
  - **PD source:** `msdyn_workorder.esi_attendancecount` (Check-in count)
    summed across all work orders linked to the card's AER GUIDs (FK
    `_esi_areaempowermentrequest_value`). See `private-deliveries` SKILL § 5b
    PD authoritative actuals.
  - **One-time exception (Manual SWM, pre-Q3 FY26):** Two legacy cards
    (`[CLIENTE] — Manual SWM` 6,425 and `[CLIENTE] — Manual SWM` 2,552) carry actuals
    sourced directly from the FY26 TPM Learner Attainment Excel (rows where
    Delivery ID = "Manual SWM ###"). These pre-date operational SWM AERs and
    are exempt from R6_AER_MISSING / R8_TRAINED_MISSING via `legacy:true`.
    **From the date of these deliveries onward, AER linkage in Done is
    mandatory** — no further Manual SWM exceptions are allowed.
  - Use `null` for cards still awaiting actuals. The cockpit shows
    "— pending Power BI sync" when all Done cards are null.

## 3. Delivery-model mapping (AER → card.type)

| AER `esi_productcategory` (FormattedValue) | Code | card.type | Notes |
|---|---|---|---|
| Private Delivery | 859270000 | `pd` | MTT delivery (Microsoft FTE/v-). Variant **SWM** = scaled-webinar; mark `type:"swm"` and add `{type:"swm",txt:"SWM"}` chip |
| Open Enrollment | 859270001 | `oe` | Open public class via ESI / Microsoft Learn |
| TSPc | 859270002 | `tsp` | Delivered by partner; `tsp` field MANDATORY |
| (no AER yet — pre-discussion) | – | `disc` | Discussion stage only; gets dropped once an AER classifies it |

**Common terms:**
- **VILT** — Virtual Instructor-Led Training (umbrella for PD + TSPc)
- **PD** — Private Delivery (Microsoft MTT)
- **TSPc** — TSP Credits (partner-delivered using credits)
- **OE** — Open Enrollment (multi-customer public class)
- **SWM** — Scale Webinars Microsoft (PD variant for scaled events)

## 4. TSP inventory (FY26)

| TSP | Typical customers |
|---|---|
| **Green** | majority of TSPc workload ([CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE], [CLIENTE]…) |
| **Fast Lane** | [CLIENTE], [CLIENTE] AI-3025 high-volume |
| **KA Solution** | [CLIENTE], Einstein, [CLIENTE] (Dec/25), [CLIENTE] Seguros |

If the user mentions a TSP not in this list, ask before adding — it
may be a typo or rebrand.

## 5. Standard workflows

### 5.1 Add a new card
1. Determine the column from the entry criteria (§ 1).
2. Resolve the customer name (must match Dynamight account display).
3. Resolve `type` from the AER `esi_productcategory` (or `disc` if
   pre-AER).
4. If TSPc, resolve `tsp` from `_esi_tspaccount_value` on the AER.
5. Build chips: `{type, txt}` for category + `{type:"seats",txt}` +
   `{type:"date",txt}`.
6. `edit` `kanban_data.js` — append the card to the target column's
   `cards: [...]` array.

### 5.2 Move a card across columns
- `edit` to remove from source column's `cards: [...]` array and
  insert into target column's array.
- If moving to **Executing** or **Done** without an AER, refuse
  (rule violation) — first query Dynamight to obtain the AER.

### 5.3 Sync with Dynamight (full reconciliation)
1. Run the `private-deliveries` skill workflow § 1 ("List My AERs as
   TPM"). Filter `_esi_accounttpm_value eq <me>` and `createdon ge`
   start of FY26 (`2025-07-01T00:00:00Z`).
2. For every AER, capture: `esi_aerequestid`, `guid`,
   `esi_productcategory@FormattedValue`, `esi_areaempowermentstatus@FormattedValue`,
   `{{EMAIL}}`, `esi_deliverymonth@FormattedValue`,
   `_esi_tspaccount_value@FormattedValue`, `esi_estimatedlearners`.
3. Map each AER to a card or report it as orphan (no card yet):
   - status `Approved` + `esi_dateutilized` set → **Done**
   - status `Approved` + future `esi_deliverymonth` → **Executing**
   - status `Submitted` + has AER → **Waiting Approval**
   - status `Draft` (TPC has not submitted yet) → **To Submit**
4. Update each card's `tsp` field from the AER (overwrite — AER wins).
5. Validate via § 6 audit and surface violations.

### 5.4 Update KPIs
KPI numbers are split into **two pools** (TSPc, PD) and **two flavours**:

**Credit-side** (static fields in `kpis.{tspc,pd}`, edited manually from
Dynamight rollups):
- **TSPc booked** = Σ `esi_tspvcredits` − Σ `esi_creditbackqty` where status=Approved AND productcategory=TSPc, FY26 (always net of credit-back; e.g., AER-134785 [CLIENTE] 36 credits refunded → must be subtracted)
- **TSPc consumed** = Σ `esi_completedcredits` (TSPc, Approved, FY26)
- **PD booked** = Σ `esi_totalcredits` (PD, Approved, FY26)
- **PD consumed** = Σ `esi_consumedcredits` (PD, Approved, FY26)

**Learner-side** (derived from cards at render time — NO static numbers):
- **Projected Learners (TSPc / PD)** = Σ `card.projectedLearners` for cards in
  stages 1–5 (i.e., NOT in Done), grouped by pool (`type==='tsp'` → TSPc;
  `type ∈ {'pd','swm'}` → PD). Used for forecast and committed pipeline only.
- **Trained Learners (TSPc / PD)** = Σ `card.trainedLearners` for cards in
  Done, same grouping. Source is the FY26 TPM Learner Attainment Power BI
  report. Cards with `trainedLearners == null` count as "pending sync" and
  the UI shows "— pending Power BI sync" when all Done cards are still null.
- ⚠️ **NO heuristic seat overrides.** [CLIENTE] 80k cap, [CLIENTE] 1000/session,
  generic 500–1000 — all deprecated for cockpit use (see
  `private-deliveries` § 5b).

See `private-deliveries` SKILL § 5–6 for credit formulas and Q4 carry-over.

### 5.5 Sync Trained Learners from PBI report (automated)

**One-command refresh** of `card.trainedLearners` for all Done cards:

```powershell
cd '{{WORKDIR}}'
python pbi_export_attainment.py --headless
```

**What it does (zero-touch, ~60 s):**
1. Opens Edge headless with persistent profile `.pbi_profile/` (one-time
   sign-in already cached). Uses `login_hint={{EMAIL}}` to
   skip the account picker if it ever appears.
2. Navigates to the FY26 TPM Learner Target Attainment report
   (URL `appShareLink` of app `62ab3a32-…964`, page `b663309b…`).
3. Hovers the Delivery Details visual → clicks `…` (More options) →
   "Export data" → "Summarized data" → captures the download.
4. The export is an MIP-encrypted XLS (sensitivity label baked in) —
   the script drives Excel via COM (`win32com`) to convert to a plain
   CSV, which auto-decrypts because the user is signed in to M365.
5. Aggregates per `Account Name` and emits:
   - `attainment_FY26.xlsx` (raw encrypted)
   - `attainment_FY26.csv` (decrypted)
   - `attainment_summary.json` (per-account totals — primary input for the merger)
   - `attainment_rows.json` (full flat rows, for debugging)

**Reconciliation:** grand total MUST equal the report headline (currently
**34,174**). If it doesn't, re-run — the Export click occasionally races
with visual load.

**Dependencies:** `playwright` (with `msedge` channel), `pandas`,
`pywin32`, `openpyxl`. Excel must be installed locally (M365 install
suffices).

**Anti-pattern (deprecated):** the old `pbi_attainment_scraper.py` +
`decode_attainment.py` pipeline that intercepted internal DSR query
XHRs and decoded Power BI's columnar protocol. It was 99.1% accurate
(missed ~300 rows due to virtual-scroll pagination) and brittle to PBI
protocol changes. **Do not use.** The official Export route is exact
and stable.

## 6. Self-validation (audit rules)

The view layer SHOULD run a one-pass validator on load and report
violations to the console + a small banner. Violations:

| Code | Rule |
|---|---|
| `R0_INACTIVE_DUP` | Customer in Inactive (`backlog`) also appears in any other column — must be removed from Inactive. |
| `R0b_INACTIVE_RECENT_ACTIVITY` | Customer in Inactive has detected M365 signals (email/Teams) within the last **30 days** — must be promoted to Discussing. Detection source: `card.intel.lastSignalAt` or the freshest `card.intel.updates[].date`. A customer only legitimately stays in Inactive when (a) it has no card in any other column AND (b) no discussion activity in the last 30 days. |
| `R5_AER_MISSING` | Card in `approved` (Executing) without `aer`/`aers` |
| `R6_AER_MISSING` | Card in `done` without `aer`/`aers` |
| `R7_PROJECTED_MISSING` | Card in stages 3–5 (column IDs `submit`, `pending`, `approved`) without `projectedLearners`. Discussing is exempt — numbers materialize once the MSX opp is identified. |
| `R8_TRAINED_MISSING` | Card in `done` without `trainedLearners` (legacy:true exempt) |
| `R_TSP_MISSING_WITH_AER` | Card with `type:"tsp"` and `aer`/`aers` but no `tsp` field |
| `R_DUPLICATE_AER`        | Same AER ID appears in 2+ cards (only allowed on intentional split-TSP duplicates) |
| `R_BAD_TYPE`             | `type` not in `[tsp, pd, oe, swm, disc]` |
| `R_BAD_MONTH`            | `month` not in `MONTH_ORDER` and not `TBD` |
| `R_TSP_UNKNOWN`          | `tsp` not in `KNOWN_TSPS` (Green, Fast Lane, KA Solution, Microsoft) |

The validator is implemented in `kanban_view.html` (function
`runAudit(data)`) and renders findings in a yellow ribbon under the
header. It is non-blocking — it only flags.

## 7. UI conventions

- **Title:** `TPM Cockpit` (no emoji, no FY suffix — the cockpit is FY-pervasive; the active FY/quarter is selected via the Period filter chips, see § 7.1)
- **Language:** English UI; customer proper nouns preserved
  ([CLIENTE], [CLIENTE], Sentinel Saúde, [CLIENTE], [CLIENTE]…).
- **View tabs:** Status / Month / Customer / TSP / Modality
- **Number locale:** en-US (commas)
- **Action prefixes:** `▶` next step · `🔴` blocker · `🟡` watch · `✅` done
- **Chip palette:** `tsp` (blue), `pd` (green), `swm` (purple),
  `oe` (gray), `disc` (orange), `seats` (neutral), `date` (neutral)
- **Badges:** `urgent` (red), `hold` (amber)

### 7.1 Period filter (Quarter / FY)

Header chips: `FY26 · Q1 · Q2 · Q3 · Q4`. State lives in `currentQuarter`
(default `'FY'`) inside `kanban_view.html`.

**Scope rule (intentional asymmetry):**
- **Pre-execution columns** (`backlog`, `discussion`, `submit`, `pending`)
  → ALWAYS visible regardless of the active filter — pipeline conversations
  are not yet quarter-bound.
- **Executing (`approved`) + Done** → filtered by `card.quarter`. A card
  whose `quarter` is null/missing only appears under `FY` and never under a
  specific Q.

**KPI rescoping** — when a quarter is active, every KPI block, the
Skilling Pipeline ("Total Trained Learners / Committed Pipeline / Total
Forecast"), and the audit aggregation switch to the matching `byQuarter`
block. Implementation: `pickKpi(k)` substitutes
`{budget, booked, consumed}` from `k.byQuarter[currentQuarter]`.

**Quarter-assignment rule (set by the data author):**
- TSPc AERs: prefer `esi_dateutilized` quarter; fall back to
  `esi_deliverymonth` quarter.
- PD AERs: most-common line-item `esi_deliverymonth` quarter (header has
  no `deliverymonth`).
- Cards carrying multiple AERs across quarters: latest quarter wins
  (Q4 > Q3 > Q2 > Q1).

**FY26 budget split (TSPc, granted by the user 22-Apr-2026):**
| Quarter | Budget | Booked | Used |
|---|---:|---:|---:|
| Q1 | 750 | 0 | 0 |
| Q2 | 750 | 1,857 | 1,857 |
| Q3 | 900 | 1,326 | 1,260 |
| Q4 | 2,417 | 2,292 | 192 |
| **FY** | **4,817** | **5,475** | **3,309** |

PD per-quarter budget is split evenly (25/25/25/25 of a 100-credit
budget) — placeholder until Carlos confirms a different cadence.

### 7.2 Skilling Pipeline row (derived, not stored)

Three cells, all rescoped by the active Period filter:
| Cell | Formula |
|---|---|
| Total Trained Learners | `Σ card.trainedLearners` over Done cards (TSP + PD) |
| Committed Pipeline | `Σ card.projectedLearners` over `approved` (Executing) cards |
| Total Forecast (highlighted) | Total Trained Learners + Committed Pipeline |

There is **no `pipeline` block in `kanban_data.js`** — the previous
static snapshot was removed in V1; values are computed every render.

## 8. Microsoft Day pattern ([CLIENTE] precedent — Apr 2026)

When a customer requests a Kickoff / Microsoft Day:
1. Pull last 90 days of meetings + emails from that customer (Calendar
   + Mail tools) to extract scope.
2. Read the latest organizer message (Teams chat) to anchor the
   agenda format.
3. Produce: (a) **Excel agenda** (time, title, description, speaker)
   via `build_microsoft_day_agenda.py`, (b) **draft email** to
   organizers thanking + summarizing + attaching the agenda.
4. Disclaim coffee-break funding until budget confirmed.
5. Add a card in **Discussing** until commitments lock in.

## 9. Glossary anchors (cross-skill terminology)

| Term | Anchor |
|---|---|
| AER | `private-deliveries` SKILL § Critical Distinction |
| TSPc credits | `private-deliveries` SKILL § Cost Calculation |
| MTT | Microsoft Technical Trainer (FTE/v-) |
| TPC | Training Program Coordinator ([CONTATO]) |
| TPM | Training Program Manager ({{USER_FIRSTNAME}}) |
| SWR | Skilling Win Room — approval forum |

## 10. Anti-patterns (do NOT do)

- ❌ Translate customer proper nouns ([CLIENTE] stays [CLIENTE], never "BANK").
- ❌ Use pt-BR number formatting (`1.500`) — use en-US (`1,500`).
- ❌ Move a card to Executing/Done without an AER.
- ❌ Set `tsp` on a `pd`/`oe`/`disc` card — only `tsp` cards carry it.
- ❌ Read TSP from `_esi_trainingservicepartner_value` (empty). Use
  `_esi_tspaccount_value`.
- ❌ Edit `kanban_data.js` without re-running the validator.
- ❌ Sum PDc + TSPc credits as a single number — different pools.
- ❌ Invent KPI values. Always re-roll from Dynamight.

## 11. Files & quick refs

| Path | Purpose |
|---|---|
| `kanban_view.html` | View layer — KNOWN_TSPS, detectTsp, detectModalidade, MONTH_ORDER/STYLES, runAudit |
| `kanban_data.js`   | Data layer — `meta`, `kpis.{tspc,pd}` (with `byQuarter`), 6 `columns` |
| `build_microsoft_day_agenda.py` | Microsoft Day Excel generator |
| `Dashboard_PD_TSP_OE_*.html` / `Dashboard_PD_TSP_OE_Kanban_*.html` | Frozen snapshots (do not edit — used as historical reference) |
| `GLOSSARIO_DELIVERY_TYPES.md` | Portuguese glossary kept for legacy context |

## 12. Post-run reflection

After any update, run the audit (§ 6) and report violations to the
user. If a card had to be left in violation (e.g., missing AER awaiting
Dynamight sync), explicitly flag it in the response and propose the
follow-up query.

## 13. V1 changelog (23-Apr-2026)

| Area | Change |
|---|---|
| Title | "📊 TPM Cockpit — FY26 Skilling" → **"TPM Cockpit"** (no emoji, no FY suffix). HTML `<title>` aligned. |
| Header | Audit ribbon moved to the **left** under the subtitle. Toolbar buttons softened (no icons, light-grey). Period filter chips placed **below** the toolbar with muted colors. |
| Period filter | New `FY26 / Q1 / Q2 / Q3 / Q4` chip set — rescopes Executing+Done cards, KPI blocks, and the Skilling Pipeline (see § 7.1). |
| KPIs | TSPc & PD blocks now carry per-quarter `byQuarter` blocks. TSPc booked **always net of credit-back** (`Σ esi_tspvcredits − Σ esi_creditbackqty`). |
| KPI titles | "📘 TSPc / 📗 PD" → **"TSP Credits" / "MTT Private Deliveries"**; "FY26 Credits" unit pill removed. |
| Pipeline row | Renamed **Skilling Pipeline**, dynamic only — derived from `card.projectedLearners` and `card.trainedLearners`. The static `pipeline` block was deleted from `kanban_data.js`. |
| Card model | Added `quarter` field (Q1/Q2/Q3/Q4) — required on Executing & Done AERs. Backfilled on 33 AER-bearing cards. |
| Trained learners | Officialized: TSPc from `esi_learningpartnerengagements.esi_reportedlearnerscount`; PD from work-order `esi_attendancecount`. Two legacy Manual SWM cards ([CLIENTE] 6,425 + [CLIENTE] 2,552) carry actuals from the FY26 TPM Learner Attainment Excel and are exempt via `legacy:true`. |
| Projected learners | Renamed from "Target". Source: AER `esi_estimatedlearners` (header) or sum of line `esi_expectednumberoflearners`. No high-volume overrides. |
| TSPc efficiency | Divisor changed: **Used** (consumed) credits — was Approved. PD still divides by Approved. |
| Audit | Fixed `R7_PROJECTED_MISSING` to use real column IDs (`discussion`, `submit`, `pending`, `approved`). Was checking nonexistent IDs and silently passing. |
| Columns | "📋 Backlog" → **"📋 Inactive"** (column ID kept as `backlog` for backwards compatibility). "🏁 Done FY26" → **"🏁 Done"**. |
| Audit | New **`R0_INACTIVE_DUP`** rule: a customer cannot appear in Inactive AND any active column at the same time. Cleared 3 dups (Einstein, [CLIENTE], [CLIENTE] Brasil). |
| Data hygiene | TSPc `consumed` headline reconciled to 3,309 to match `Σ byQuarter`. **PD `byQuarter.Q4.consumed` reconciled to 48.25 to match headline.** Removed dead `pipeline` block. Merged duplicate cards ([CLIENTE], etc.). |

## 14. V1.1 changelog (24-Apr-2026)

| Area | Change |
|---|---|
| Layout | **Open Enrollment bar moved to the right of the Skilling Pipeline** (`.pipe-wrap` grid `1fr 320px`); OE row restructured from horizontal 8-col to vertical compact strip (header + 4 quarters + Accounts/Trained totals). |
| Label | "Total Forecast" → **"Total Pipeline"** in the Skilling Pipeline card. |
| 🩺 Health tab | New audit tab driven by `health_audit.js` (auto-generated by `sync_cockpit.py`). 3-way reconciliation between **Cockpit (kanban_data.js)** ⇄ **Dynamight AERs** ⇄ **PBI Attainment Report**. Status codes: `OK`, `CARD_AHEAD_DYNA`, `MISSING_AER_IN_KANBAN`, `MISSING_CARD_IN_DYNA`, `PBI_PRIMARY`. |
| `pbiPrimary` flag | New per-card flag for cards whose `trainedLearners` is sourced from PBI (multi-AER aggregation outside the TPM portfolio). Skipped by `sync_cockpit.py --apply` so the AER-driven roll-up never overwrites the PBI total. Pair with `trainedSource:"pbi-attainment"` and a `note`. |
| Render | **Eliminated DOM round-trip.** New helper `deriveKpi(kpi, trained, projected, denomKey)` computes Balance / Eff Real / Eff Proj / progress bar width+gradient directly in memory. KPI cells no longer carry `id` attributes — values are inlined into the template, no second pass needed. |
| Defensive | OE quarter access via new `oeQVal(q)` helper — returns 0 when `byQuarter` or a specific quarter is missing instead of throwing `TypeError`. |
| Cleanup | Removed ~80 lines of dead persistence layer: `STORAGE_KEY`, `EDITABLE_IDS`, `pn()`, `getOverrides`, `applyOverrides`, `saveOverrides`, `loadOverrides`, `flashStatus`, `exportState`, `importState`, `loadFromFile`, `resetState`, `bindKpis`, `recalcPool`, `recalcAll`. Removed Export / Import / Reset toolbar + `saveStatus` span + hidden file input + orphan `.toolbar` CSS. KPIs are read-only since V1 — the persistence layer was unreachable code. |
| Version marker | `COCKPIT_VERSION = 'v1.2'` constant rendered in the subtitle and footer. Bump this when shipping view-layer changes. |
| Reconciliation tools | `sync_cockpit.py` now writes both `health_audit.json` (CI consumable) and `health_audit.js` (browser global `window.HEALTH_AUDIT`), avoiding `file://` CORS when opening the dashboard locally. |

## 15. V1.2 changelog (24-Apr-2026)

| Area | Change |
|---|---|
| Daily Update routine | New `update cockpit` orchestration shipped (see § "⚡ Daily Update"): incremental intel scan + dedicated [CONTATO] TPC sweep + customer-email priority + deterministic column moves + attention flagging. Records `meta.lastDailyUpdate`. |
| Attention model | New per-card field `card.attention = {flagged, reason, since: ISO, source, triggers?}`. Source values: `email`, `teams`, `dyna`, `audit`, `tpc`. The `since` ISO is the contract — bump it whenever a new signal arrives, otherwise dismissed/seen state persists. |
| Float-to-top | Attention-flagged cards are sorted to the top of every column in Status view (`renderColumn` stable sort). |
| Attention badge | Single 🚨 icon + inline × dismiss, anchored top-right of the card (`position: absolute`). No "ATTN" text. The reason string surfaces on the back face via the `.attn-reason` strip. |
| Fresh-alert frame | Pulsing red frame (`.attention-fresh`) appears the first refresh after `attention.since` advances. Cleared by EITHER (a) clicking/expanding the card or (b) the next page refresh — `bumpAllFreshSeen()` writes all currently-fresh `since` values to `localStorage["tpm_cockpit_attn_seen_v1"]` 1.5 s after render. |
| Persistence | Two independent localStorage maps: `tpm_cockpit_attn_dismiss_v1` (explicit ×, kills badge + frame) and `tpm_cockpit_attn_seen_v1` (implicit acknowledgement, kills frame only). Console escape hatches: `tpmResetAttnDismiss()`, `tpmResetAttnSeen()`. |
| Perf refactor | New `attnSnapshot()` reads both LS maps **once per render** and threads the snapshot through `renderBoard → renderColumn → renderCard`. Was: ~60 `localStorage.getItem` calls per board paint. Now: 2. |
| Refactor | New tiny `LS = {get, set}` helper deduplicates the try/catch JSON wrapping that was previously copy-pasted across 4 functions. |
| DOM contract | Cards now carry `data-card-key="<customer>||<title-snippet>"`. `openCardDetail` uses it to look up the in-memory card in O(1) — replaces the previous brittle text-scrape (`card-customer.textContent` + back-face title regex). |
| Public helpers | `isAttentionActive(card)` and `isAttentionFresh(card)` remain available for ad-hoc callers; the render path uses the cheaper `*On(card, snap)` variants. |
| Skill spec | New § "⚡ Weekly Update — single-command full refresh", "⚡ Daily Update — `update cockpit`", "[CONTATO] TPC sweep (mandatory in Step 1)", and "View-layer rules (locked-in)". Trigger phrases extended in description: `weekly update`, `daily update`, `update cockpit`, `atualização semanal`, `atualizar cockpit`. |

## 16. V1.3 changelog (28-Apr-2026)

| Area | Change |
|---|---|
| Step 1 enrichment | New mandatory pre-step in both Daily and Weekly Update routines: chain `account-agent` (resolve customer → canonical MSX account: TPID, ATU, opp pipeline) and `customer-network` (account team + virtual/deal team + customer-side contacts) BEFORE the WorkIQ scan. Drives higher-precision per-customer queries and grounds every signal in the current opportunity context. |
| Card data model | Two new sub-objects under `card.intel`: `account = {tpid, name, atu, opps:[…], refreshedAt}` and `contacts = {internal:[…], customer:[…], partner:[…], refreshedAt}`. Cached for 14 days unless an AER status change in Step 2 forces a refresh. |
| Customer email detection | PRIMARY source is now the `card.intel.contacts.customer[]` set populated by `customer-network` — deterministic match by sender address. Domain deny-list (`microsoft.com`, `green.com.br`, `fastlaneus.com`, `ka-solution.com.br`, `{{EMAIL}}`) is now a FALLBACK only, used when the contact list is unavailable or the sender isn't in it. |
| Skill spec | New § "Account/Network enrichment (mandatory pre-step in Step 1)" between the daily-vs-weekly comparison and the [CONTATO] TPC sweep. Step 1 rows in both the Daily and Weekly tables updated to reference the enrichment. |
| Unmatched accounts | New `meta.unmatchedAccounts[]` log for cards whose customer doesn't resolve via `account-agent` (true prospects pre-MSX). Surfaced in the daily report so the user can attach a TPID manually. |

## 17. V1.3.1 patch (28-Apr-2026, late afternoon)

| Area | Change |
|---|---|
| Name-resolution rule | New mandatory sub-rule under § "Account/Network enrichment": `msx-mcp-get_account_overview(tpid=…)` returns the TPID master / legal-holding entity name in its header (e.g., "PARATI SA" for TPID [TPID]), which is OFTEN NOT the operating-brand account. The card data model now carries BOTH `account.name` (operating brand, used in briefings) AND `account.legalEntity` (holding name, kept for audit). Resolution algorithm: prefer the highest-value opp owner's account, or match against `card.customer`, or ask the user. Triggered by user catching "PARATI SA" in a [CLIENTE] briefing. |
| Card data model | `card.intel.account` gains `legalEntity` and `nameResolutionNote` fields. |
| Daily run integrity | Added contract: the daily-update agent must NOT mark a card as `enriched` in the report unless it actually wrote `intel.account` to the file. The 28-Apr run reported "24/24 enriched" but [CLIENTE] was silently skipped — `lastScannedAt` proved no write occurred. Future runs MUST re-read the file and verify the write before counting it as success. |




## 🪪 V2.1 — `m365CopilotSeats` field with freeze rule (28-Apr-2026)

Surfaces each customer's M365 Copilot license footprint (total seats /
enabled users / MAU) on the card front. Drives the conversation hook
during early stages and freezes as a historical baseline once the deal
moves into execution.

### Data shape (robot-owned, optional)

```yaml
m365CopilotSeats:
  total:    1500          # Actual Seats (Closed Month) — MSXI Tab 3
  enabled:  1480          # Enabled Users
  mau:      1100          # Monthly Active Users
  wau:      850           # Weekly Active Users (optional)
  pau:      0             # Paid Active Users — telemetry (optional)
  tpid:     "[TPID]"     # TPID used to look up the row in MSXI
  asOf:     "2026-05-05"  # Snapshot date
  source:   "msxi-tab3"   # Provenance
  frozen:   false         # Becomes true on transition to submit/pending/approved/done
  frozenAt: null          # Date the snapshot was frozen
```

### Freeze rule (enforced by `cockpit_robot_write.update_card`)

- **Live** while card.column ∈ {`backlog`, `discussion`} — refreshed by
  every weekly update from MSXI Tab 3.
- **Frozen** when card.column ∈ {`submit`, `pending`, `approved`, `done`}
  — `update_card` raises `FrozenFieldError` on any subsequent write
  unless the caller passes `force=True`. A repeat write with the
  identical value is silently dropped (no-op) so daily refreshers don't
  need to special-case the column.
- An identical freeze fires when `m365CopilotSeats.frozen == True`,
  regardless of column (allows manual freeze for special cases).
- The first write into a frozen column should set `frozen: true` and
  `frozenAt: <today>` so the lifecycle event is visible in diffs.

### View rendering (`kanban_view.html`)

- New helper `m365SeatsHtml(card)` emits a fourth pill in the card-front
  `front-pills` row when `m365CopilotSeats.total != null`:
  - `🪪 1,500 M365` — base label, MS-blue palette (`#EFF6FC` / `#0078D4`).
  - `🪪 1,500 M365 📌` — appended when `frozen === true`.
  - Tooltip: `M365 Copilot seats (MSXI Tab 3) — Enabled: 1,480 · MAU: 1,100 · as of 2026-05-05`.
- `total: 0` STILL renders (intentional — the absence of a Copilot
  footprint is itself a conversation hook for Discussing-stage cards).

### Source pipeline

Data should come from MSXI Tab 3 (M365 Copilot Usage) per the
`msxi-copilot-e2e` skill — bulk extraction by TPID is a follow-up
(`scripts/extract_account_seats.py` not yet built). Until then, seed
manually via `demo_seats_seed.py` or by editing the card markdown
directly.

## V2.1 changelog

| Area | Change |
|---|---|
| Schema | New `m365CopilotSeats` block in `cockpit-cards/_meta/schema.json` (object with `total/enabled/mau/wau/pau/tpid/asOf/source/frozen/frozenAt`), `x-ownership: "robot"`. |
| Config | `m365CopilotSeats` added to `config.yml::ownership.robot_owned_fields`. |
| Build | `m365CopilotSeats` appended to `cockpit_build.py::CARD_KEY_ORDER` for stable JS ordering. |
| Robot writer | New `FrozenFieldError` + freeze guard in `cockpit_robot_write.update_card`. Frozen columns: `{submit, pending, approved, done}`. Snapshot fields: `{m365CopilotSeats}`. New `force=True` kwarg to override. No-op on identical-value rewrite. |
| View | New `m365SeatsHtml(card)` helper; new `.pill.m365seats` CSS rule (MS-blue); pill injected into `front-pills` between `learnersHtml` and the trainings line. |
| Tooling | `demo_seats_seed.py` — one-shot seeder + freeze-guard self-test. |


## 🗄️ V2.0 — Markdown Tree Source of Truth (28-Apr-2026)

**`kanban_data.js` is now an AUTO-GENERATED build artifact.** Do NOT edit it
by hand. The single source of truth is the `cockpit-cards/` markdown tree:

```
cockpit-cards/
  _meta/
    config.yml          ← ownership lists, columns, TSPs, FY dates
    schema.json         ← JSON Schema for YAML front-matter
    runtime.yml         ← meta + kpis + columns metadata (regenerated each migration)
    README.md           ← architecture doc
    kpis.md             ← manual KPI overrides (TSPc/PD per-quarter budgets)
  <CUSTOMER>/
    _customer.md        ← shared customer-level facts (TPID, ATU, team)
    <id>.md             ← one card = one opportunity (YAML front-matter + body)
    _done/              ← optional archive subfolder
```

### New toolchain

| Script | Role |
|---|---|
| `js_to_markdown.py`     | One-shot bootstrap: parses `kanban_data.js` and emits the `cockpit-cards/` tree. Idempotent (refuses to overwrite without `--force`). |
| `cockpit_validate.py`   | Validates schema, field-ownership, marker balance, duplicate IDs/AERs, parent cycles. Runs FIRST in every workflow. |
| `cockpit_build.py`      | Regenerates `kanban_data.js` from markdown. Calls validator first. Atomic write via `os.replace()`. |
| `cockpit_robot_write.py`| Library used by all robot writers (intel scan, daily-update agent). Provides `update_card(path, yaml_patch={...}, body_marker_patches={...})` with hermetic guarantees. |

### Hermetic boundary contract (the 7 rules)

| # | Rule | Enforced by |
|---|---|---|
| 1 | Field ownership in YAML — robot may only write keys in `config.ownership.robot_owned_fields`; human owns the rest. | `cockpit_validate.py` + `cockpit_robot_write.update_card` |
| 2 | Body section ownership via `<!-- ROBOT:NAME START/END -->` markers (ACCOUNT, CONTACTS, UPDATES, KPIS, AERS_DETAIL). Anything outside markers is human-owned. | validator (marker balance) + robot library |
| 3 | Atomic writes: read all → modify in memory → write `.tmp` → byte-verify human regions → `os.replace()` | `cockpit_robot_write.update_card` |
| 4 | Each card carries a `<!-- _robot_signature: sha256:... -->` of human regions. Verified before every robot write; abort on mismatch. | `cockpit_robot_write.update_card` |
| 5 | `kanban_data.js` is read-only — fully overwritten each build, never patched. | `cockpit_build.py` |
| 6 | Migration is idempotent — `js_to_markdown.py` refuses to overwrite without `--force`. | `js_to_markdown.py` |
| 7 | Validator runs FIRST in every workflow; hard-stop on errors. | `cockpit_build.py` (and any new entry point) |

### Updated Daily Update routine (Step 4 — attention) and Weekly Update

ALL robot writes now go through `cockpit_robot_write.update_card`, NOT direct
edits to `kanban_data.js`. After a daily/weekly run completes:

```powershell
cd '{{WORKDIR}}'
python cockpit_build.py
```

This regenerates `kanban_data.js` from the markdown tree and the view picks
it up on next refresh. The `intel_scan.py` daily script must call
`crw.update_card(card_path, yaml_patch={"attention": {...}, "lastScan": "..."}, body_marker_patches={"UPDATES": <rendered>})` rather than mutating the JS directly.

### Backup

Pre-migration snapshot lives at `kanban_data.pre_md_migration.js` — never
deleted; used as the round-trip baseline.

### Migration verification (28-Apr-2026)

- 62 cards across 36 customer folders + 6 columns.
- Round-trip parity: `meta` ✓, `kpis` ✓, **0 field-level diffs** vs the
  pre-migration `kanban_data.js`.
- Phase 5 checks all pass: view layer references intact, validator catches
  corrupted YAML, robot writes preserve human Notes byte-for-byte.

### V2.0 changelog

| Area | Change |
|---|---|
| Architecture | `kanban_data.js` demoted to build artifact; markdown tree under `cockpit-cards/` is now the source of truth. |
| Hermetic boundary | New 7-rule contract — robot/human field ownership, marker-bounded body sections, atomic writes, signature-based conflict detection, validator-first workflow. |
| Toolchain | New scripts: `js_to_markdown.py`, `cockpit_validate.py`, `cockpit_build.py`, `cockpit_robot_write.py`. |
| Edit workflow | Edit `cockpit-cards/<CUSTOMER>/<id>.md` → run `python cockpit_build.py` → refresh `kanban_view.html`. View layer unchanged. |
| Robot integration | All daily/weekly writers (`intel_scan.py`, future enrichment agents) MUST use `cockpit_robot_write.update_card` — direct JS edits are forbidden. |
| Backup | `kanban_data.pre_md_migration.js` preserved as the parity baseline. |

## 18. V1.2.1 patch (06-May-2026)

| Area | Change |
|---|---|
| Fresh-frame persistence | Disabled `bumpAllFreshSeen()` — the 1.5-s post-render auto-acknowledge that was clearing the pulsing red frame on the next refresh. Frames now persist across refreshes until the user EITHER clicks the card (acknowledge via `markAttentionSeen` in `openCardDetail`) OR hits the × dismiss. Rationale: the auto-bump fought the "what changed since yesterday?" workflow — frames vanished after the first peek and the user had to re-run `tpmResetAttnSeen()` every time. Now the lifecycle is fully user-driven. |
| View-layer rules update | The "fresh-alert red frame" rule in § "View-layer rules (locked-in 24-Apr-2026)" is amended: clear case (2) "next page refresh" is REMOVED. Only case (1) "user expands the card by clicking it" remains. Brand-new signals still re-trigger the frame automatically when `attention.since` advances past the seen value. |
| Version marker | `COCKPIT_VERSION = 'v1.2.1'`. |
| Reset path | `tpmResetAttnSeen()` is still useful as a one-time wipe when migrating to V1.2.1 (clears any seen entries previously written by `bumpAllFreshSeen`), but is no longer required as a daily hygiene step. |

