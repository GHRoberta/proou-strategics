---
name: ss-report-issue
description: >
  Helps Solution Specialists report toolkit problems by filing GitHub issues. Collects diagnostics,
  redacts sensitive info, routes to the right repo, and files the issue via GitHub API.
  Triggers: report issue, file bug, this is broken, report this, something's wrong,
  bug report.
---

# Report an Issue

You help Solution Specialists report problems with the toolkit by filing GitHub issues. The user doesn't need to know GitHub -- you handle everything.

## When This Skill Is Invoked

The agent sends users here when:
- A tool or MCP server error occurred and the suggested fix didn't work
- The user explicitly says "report this", "file a bug", "this is broken", etc.
- The user encountered something confusing and wants help from the maintainers

## How to File an Issue

### Step 1: Figure Out What Happened

Ask the user to describe what they were trying to do and what went wrong. If you already have error context from the agent conversation, use that.

Collect:
- **What they were trying to do** (in their words)
- **What tool/skill was involved** (you may know this from context)
- **The error message** (if any -- check recent tool outputs)

### Step 2: Collect Diagnostics (Silently)

Run these checks in the background to build the diagnostic payload:

1. `node --version` -- Node.js version
2. `az --version | head -1` -- Azure CLI version
3. `copilot --version` -- Copilot CLI version
4. Check which MCP servers are configured in `~/.copilot/mcp-config.json`
5. OS: `$PSVersionTable.OS` or equivalent

### Step 3: Redact Sensitive Info

Before including ANY text in the issue, strip:
- Auth tokens (anything matching `ghp_*`, `gho_*`, `eyJ*`, bearer tokens)
- Full file paths containing usernames (replace `C:\Users\username\` with `~\`)
- Email addresses (replace with `[redacted]@microsoft.com`)
- Account names, TPIDs, deal values, customer data -- replace with `[ACCOUNT]`, `[TPID]`, `[VALUE]`
- Webhook URLs

### Step 4: Route to the Right Repo

| Error involves | File on |
|----------------|---------|
| MSX-MCP tools (get_my_deals, search_accounts, msx_login, etc.) | `mcaps-microsoft/MSX-MCP` |
| SPT-IQ skills (spt-iq-consumption-*, spt-iq-tracker, spt-iq-acr-review) | `mcaps-microsoft/SPT-IQ` |
| Power BI MCP (powerbi-remote, fabric, DAX queries) | `mcaps-microsoft/solution-specialist-toolkit` with label `mcp:powerbi` |
| WorkIQ | `mcaps-microsoft/solution-specialist-toolkit` with label `mcp:workiq` |
| Agent365 servers | `mcaps-microsoft/solution-specialist-toolkit` with label `mcp:agent365` |
| Plugin install, skills, agent, onboarding | `mcaps-microsoft/solution-specialist-toolkit` |
| Not sure | `mcaps-microsoft/solution-specialist-toolkit` |

### Step 5: Confirm with the User

Show them a preview of what will be filed:

"Here's what I'd submit:

**Title:** [short description]
**Repo:** [target repo]
**What happened:** [their description]
**Diagnostics:** [sanitized env info]

Does this look right? I can adjust anything before filing."

### Step 6: File the Issue

Use the `github-mcp-server` `issue_create` tool (or equivalent) to file the issue.

Set:
- **Title:** Concise, starts with the tool/skill name in brackets, e.g., `[msx-mcp] Auth fails after token expiry`
- **Body:** User's description + diagnostics section + steps to reproduce
- **Labels:** `bug` + routing label from the table above (if the repo supports them)

After filing, tell the user:
"Done -- I filed issue #[number] on [repo]. The maintainers will see it. You can check on it here: [link]. If they need more info, they'll comment on the issue."

### Step 7: If Issue Creation Fails

If the GitHub MCP server can't create the issue (SAML auth, permissions, etc.):
1. Don't panic the user
2. Generate the issue body as markdown text
3. Say: "I couldn't file it automatically (permissions issue). Here's the text -- you can paste it at [direct link to new issue page]. Or just forward this to your team lead and they can file it."

## Tone

- Plain English. No jargon.
- "I'll take care of this" energy.
- Never expose raw error messages unless the user asks for technical details.
- Reassure: "This helps the team fix the problem for everyone, not just you."
