---
name: learning-trail-pptx
description: >
  Cria um plano/trilha de capacitação como deck PowerPoint (.pptx)
  profissional, didático e compartilhável, organizando o conteúdo por
  módulos e citando 3 recursos por módulo (Microsoft Support PT-BR,
  guia complementar, vídeo do canal oficial). SEMPRE valida cada
  hyperlink via HTTP antes de entregar — nada de URLs inventadas.
  Use quando o usuário pedir "trilha de aprendizado", "plano de
  capacitação", "learning path em slide", "deck de treinamento para
  cliente", "monta uma trilha de [tópico]", "PPT com plano de estudo".
  Triggers: trilha, learning trail, learning path, plano de capacitação,
  plano de estudo, plano de treinamento, deck de treinamento, PPT
  capacitação, slide trilha, capacitação cliente, jornada de aprendizado.
---

# Learning Trail PPTX — Trilha de Capacitação em PowerPoint

Gera um deck `.pptx` widescreen (16:9) com cobertura completa de uma
trilha de aprendizado: capa, visão geral em grid, slides de módulo
com 3 cards de recurso cada, e slide final de "como usar". **Todos
os links são validados via HTTP antes da entrega.**

## Pré-requisitos

- `python-pptx` (instalar com `pip install python-pptx` se faltar):
  `python -c "import pptx; print(pptx.__version__)"`
- Acesso à internet para validação de URLs
- Tópicos da trilha já definidos (vindos de email do cliente, screenshot,
  ou conversa)

## Workflow

### 1. Confirmar contexto antes de gerar

**Pergunte ao usuário**:
- Para quem é (nome + empresa/conta)?
- Tema central (Excel básico, PowerPoint, Copilot, Power BI…)?
- Tópicos específicos a cobrir (lista, captura de email, etc.)?
- Formato confirmado: `.pptx` (este skill é só PPTX — para Word use
  o approach genérico com python-docx)

### 2. Estrutura do deck (11 slides padrão)

| # | Slide | Conteúdo |
|---|-------|----------|
| 1 | Capa | Título, subtítulo, destinatário, data, branding Microsoft |
| 2 | Visão geral | Grid 4×2 de 8 cards de módulo |
| 3-10 | Módulos | 1 slide por módulo, formato 3-card (ver §4) |
| 11 | Como usar | 4 passos numerados + CTA para próximo treinamento |

### 3. Identidade visual (Microsoft brand)

```python
MS_BLUE      = RGBColor(0x00, 0x78, 0xD4)   # links, accents
MS_DARK_BLUE = RGBColor(0x00, 0x3A, 0x70)   # títulos, faixa rodapé
MS_LIGHT_BG  = RGBColor(0xF3, 0xF2, 0xF1)   # fundos suaves
MS_GREEN     = RGBColor(0x10, 0x7C, 0x10)   # módulos de fórmulas/dados
MS_RED       = RGBColor(0xD8, 0x3B, 0x01)   # bônus/Copilot
MS_PURPLE    = RGBColor(0x5C, 0x2D, 0x91)   # produtividade
MS_ORANGE    = RGBColor(0xCA, 0x50, 0x10)   # visualização
MS_GRAY      = RGBColor(0x60, 0x5E, 0x5C)   # subtítulos
```

Fonte: **Segoe UI** sempre. Slide widescreen: 13.333" × 7.5".
Faixa superior fina (0.18"); rodapé escuro com paginação à direita.

### 4. Anatomia de um slide de módulo

```
┌─ faixa cor do módulo (0.18") ──────────────────────────────────┐
│                                                                 │
│ [Módulo N]   Título do módulo                                   │
│              Subtítulo curto                                    │
│                                                                 │
│ ┌─ 🎯 Tópicos cobertos ─┐  ┌─ 📘 MICROSOFT SUPPORT (PT-BR) ─┐  │
│ │ • Tópico 1            │  │ Título do artigo               │  │
│ │ • Tópico 2            │  │ url-validado-200               │  │
│ │ • Tópico 3            │  └────────────────────────────────┘  │
│ │ • Tópico 4            │  ┌─ 📖 GUIA COMPLEMENTAR (PT-BR) ─┐  │
│ │ • Tópico 5            │  │ ...                            │  │
│ │ • Tópico 6            │  └────────────────────────────────┘  │
│ └───────────────────────┘  ┌─ 🎬 CANAL OFICIAL MS 365 ──────┐  │
│                            │ Busca/playlist YouTube          │  │
│                            └────────────────────────────────┘  │
│ ─ rodapé ──────────────────────────────────── N / Total ──────│
└─────────────────────────────────────────────────────────────────┘
```

Cada card de recurso tem **borda colorida à esquerda** (accent
strip de 0.18" de largura), label em caixa-alta pequena, título da
referência em bold dark-blue, e URL clicável em azul Microsoft.

### 5. ⚠️ Validação de URLs (PASSO OBRIGATÓRIO)

**NÃO entregue o pptx antes de validar todos os links.** Em sessões
anteriores, GUIDs de URLs do `support.microsoft.com` foram inventados
e retornavam 404. Fluxo correto:

#### 5a. Antes de gerar — montar lista candidata

Use as duas ferramentas em paralelo para descobrir URLs reais:

```
microsoft-learn-docs-microsoft_docs_search(query="...")
web_search(query="site:support.microsoft.com pt-br <topic>")
```

Sempre prefira artigos do `support.microsoft.com/pt-br/office/...`
(end-user) sobre `learn.microsoft.com/...` (developer) para temas
de produtividade.

#### 5b. Pós-geração — auditar TODAS as URLs do .pptx

Script padrão (`_audit_links.py`):

```python
import zipfile, re, urllib.request, urllib.error, concurrent.futures

PPTX = r"<caminho>.pptx"
urls = set()
with zipfile.ZipFile(PPTX) as z:
    for name in z.namelist():
        if name.endswith((".xml", ".rels")):
            for m in re.findall(r'https?://[^\s"<>\']+',
                                z.read(name).decode("utf-8", errors="ignore")):
                urls.add(m.rstrip(",.;)"))

def check(u):
    try:
        req = urllib.request.Request(u, method="GET",
                headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return (u, r.status, r.geturl())
    except urllib.error.HTTPError as e:  return (u, e.code, "")
    except Exception as e:               return (u, "ERR", str(e)[:80])

with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
    for u, code, final in sorted(ex.map(check, sorted(urls))):
        print(("✅" if code == 200 else "❌"), code, u,
              ("→ " + final) if final and final != u else "")
```

#### 5c. Filtros — ignore "falsos negativos"

URIs de **namespace XML** aparecem na auditoria e dão 404/ERR.
**NÃO são hyperlinks navegáveis** — são identificadores de schema
do formato OOXML. Padrões a ignorar:

```
http://schemas.openxmlformats.org/...
http://schemas.microsoft.com/office/...
http://purl.org/dc/...
http://www.w3.org/...
```

**Apenas hyperlinks reais** (`support.microsoft.com`, `learn.microsoft.com`,
`youtube.com`, `microsoft.com/...`) precisam retornar 200.

#### 5d. URLs verificadas (cache de pontos de partida)

| Recurso | URL |
|---------|-----|
| Excel hub PT-BR | `https://support.microsoft.com/pt-br/excel` |
| Word hub PT-BR  | `https://support.microsoft.com/pt-br/word` |
| Canal Microsoft 365 (busca) | `https://www.youtube.com/@Microsoft365/search?query=<term>` ✅ retorna 200 (redireciona para `/user/officevideos/showcase`) |
| Copilot Excel — Boas-vindas | `https://support.microsoft.com/pt-br/office/bem-vindo-ao-copilot-no-excel-d7110502-0334-4b4f-a175-a73abdfc118a` |
| Copilot Excel — Gerar fórmulas | `https://support.microsoft.com/pt-br/office/gerar-f%C3%B3rmulas-de-coluna-com-o-copilot-no-excel-d866d926-9791-4e5f-be2a-c6dd9e587a47` |
| MS Learn — Uncover insights AI | `https://learn.microsoft.com/training/modules/uncover-new-data-insights-ai/` |

Não existe `youtube.com/@MicrosoftBrasil` (404). Use `@Microsoft365`.

### 6. Geração do .pptx — funções utilitárias

```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]

def add_rect(slide, x, y, w, h, fill, line=None): ...
def add_text(slide, x, y, w, h, text, size=18, bold=False,
             color=BLACK, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, font="Segoe UI"): ...
def add_bullets(slide, x, y, w, h, items, size=14): ...
```

Para hyperlink clicável dentro do textbox:

```python
tb = s.shapes.add_textbox(x, y, w, h)
p  = tb.text_frame.paragraphs[0]
r  = p.add_run(); r.text = url
r.font.color.rgb = MS_BLUE
r.hyperlink.address = url
```

### 7. ⚠️ Não abra o .pptx no PowerPoint antes de patchear

Se o usuário (ou um `Start-Process`) abrir o arquivo no PowerPoint
e o assistente tentar editar o ZIP em seguida, o arquivo fica
corrompido (PowerPoint troca para formato OLE legacy).

**Workflow seguro**:
1. Gerar o .pptx
2. Auditar links com o script da §5b (não abre o arquivo)
3. Se algum link falhou → **regerar** do zero (não tentar patchear ZIP
   após PowerPoint ter aberto)
4. Só então `Start-Process` para abrir no Office

Se for necessário fechar PowerPoint via script:
```powershell
$p = Get-Process POWERPNT -ErrorAction SilentlyContinue
if ($p) { Stop-Process -Id $p.Id -Force; Start-Sleep 2 }
```
> ⚠️ Esta sessão não permite `Stop-Process -Name`/`taskkill /IM` —
> sempre via `-Id`.

### 8. Cobertura mínima por módulo

| Recurso | Tipo | Exigência |
|---------|------|-----------|
| 📘 Microsoft Support / Learn | Artigo conceitual PT-BR | Obrigatório |
| 📖 Guia complementar | Tutorial / artigo aprofundado PT-BR | Obrigatório |
| 🎬 Vídeo oficial | Canal Microsoft 365 (busca específica) | Obrigatório |
| 🎓 Live OE class | Cross-ref `oe-schedule` se houver curso correspondente | Opcional |

Se uma trilha tiver bônus de **Copilot**, sempre adicione um módulo
final dedicado (cor `MS_RED`).

### 9. Cleanup

Após confirmação do usuário, apague scripts (`_build_*.py`,
`_audit_links.py`, `_check_links.py`). Mantenha o `.pptx`.

## Histórico

- **Excel Básico — [CLIENTE] (Cleisiane), Abr/2026** — 11 slides, 8 módulos
  + bônus Copilot, 24 hyperlinks reais, todos validados HTTP 200.
  Primeira versão tinha 4 URLs 404 (GUIDs inventados); corrigidos via
  busca + auditoria antes da entrega.

## Cross-reference

- **`oe-schedule`** — para incluir turmas OE como recurso 🎓 nos módulos
- **`oe-grade-email`** — para enviar a grade isolada por email (não
  requer trilha completa)
- **`training-slas`** — para validar prazos se a trilha sugerir
  treinamentos PD/OE específicos
