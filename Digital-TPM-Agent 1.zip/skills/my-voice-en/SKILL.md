---
name: my-voice-en
description: >
  English-language companion to `my-voice`. Source of truth for the user's
  ENGLISH writing voice — signatures, openers/closers, and tone for internal
  Microsoft / global audiences. Load `voice-profile-en.md` from this folder when
  drafting in English. Triggers: my voice english, english voice profile, write
  as me in english, escreva em inglês no meu tom, my-voice-en.
---

# My Voice — English Profile (TEMPLATE)

> ⚠️ **PERSONALIZE.** `voice-profile-en.md` is a generic template. Fill it with
> your own English signatures and tone (see `PERSONALIZE.md`).

Passive data. Other skills load [`voice-profile-en.md`](voice-profile-en.md)
when the target language is English. For PT-BR and the shared rules, see the
sibling `my-voice` skill.

```text
view: {{COPILOT_HOME}}\skills\my-voice-en\voice-profile-en.md
```
