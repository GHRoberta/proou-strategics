# Voice Profile — English (TEMPLATE)

> Load before drafting English output. **Replace every `{{PLACEHOLDER}}`.**
> For shared identity/routing rules, see `../my-voice/voice-profile.md`.

## 1. Identity (EN)
| Field | Value |
|---|---|
| Common name (signature) | {{USER_NAME}} |
| Title (EN) | {{USER_TITLE_EN}} |
| Email | {{USER_UPN}} |

## 2. Signature (EN)
```
{{USER_NAME}}
{{USER_TITLE_EN}} — Microsoft Brazil
```

## 3. Tone for English audiences
- Audience is usually **internal Microsoft / global**: direct, concise,
  outcome-first. Lead with the ask or the decision.
- Keep sentences short and scannable; bullets for multi-part asks.
- Mirror the thread's register (peer vs. exec).
- Fill with your own openers/closers:
  - Opener (peer): {{OPENER_PEER_EN}}
  - Opener (exec): {{OPENER_EXEC_EN}}
  - Closer: {{CLOSER_EN}}

## 4. Standard phrases (EN)
Capture your reused English phrases: "Following up on…", "Quick ask:", "Net-net:",
"Let me know if…", "Thanks in advance," — replace with the ones you actually use.
