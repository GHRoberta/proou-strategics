---
name: training-slas
description: >
  Authoritative reference for FY26 Organizational Skilling SLAs — minimum lead
  times, submission deadlines, Delivery Operations turnaround, AER approval
  timing, and credit-back rules for every training delivery type (Open
  Enrollment, Multi-Account Private Delivery, Private Delivery, Virtual Training
  Day, TSPc, Video Recording Review). Use whenever the user asks about lead
  times, prazos, AER submission deadlines, dispatch SLAs, cancellation /
  credit-back rules, exception requests, or whether a delivery fits the SLA.
  ALWAYS consult this skill before quoting any SLA number — never improvise from
  memory.
---

# Training SLAs — FY26 Organizational Skilling

## When to use this skill

Use this skill WHENEVER the user asks about:
- "Posso agendar uma turma para X?" / "Quanto tempo de antecedência?"
- "Qual o SLA do/da [PD | TSPc | OE | VTD | MA-D]?"
- "Quando preciso submeter o AER?" / "Prazo de submissão"
- "Posso cancelar?" / "Crédito de volta?" / "Credit-back"
- "Cabe no SLA?" / "Vai ser rejeitado?" / "Preciso de exceção?"
- "Quantos dias úteis para [aprovação | dispatch | publicação]?"
- "Deadline de forecast" / "Próxima janela de submissão VTD"
- Any reschedule / rejection / exception question tied to timing.

If the user asks something not covered here, say so explicitly and direct them
to FY26 SLAs.pptx.

**Triggers:** SLA, SLAs, lead time, antecedência, prazo, submission deadline,
AER deadline, T-5, T-10, T-12, exception request, ERT, credit back,
cancelamento, crédito de volta, dispatch, scheduler assigned, ready for
scheduling, ready for dispatch, del ops, delivery operations, forecast
template, MASH, VTD forecast, scheduling SLA, business days, dias úteis,
pickup, execution SLA, trainer assignment.

---

> **Source of truth:** [FY26 SLAs.pptx](https://microsoft.sharepoint.com/teams/WWL/_layouts/15/Doc.aspx?sourcedoc=%7BBD943A9C-6891-4518-ACF2-72ED6ABD4144%7D&file=FY26%20SLAs.pptx)
> (CSNG Ops site, last updated 13-Feb-2026, owner Natalia Manidis)
>
> 🔒 **Exclusive source rule:** When the user asks about lead times, deadlines,
> SLAs, or any time-bound rule for training delivery, this skill is the
> ONLY authorized source. Do not quote SLAs from memory, kanban, email
> threads, or other docs. If a question goes beyond what is documented
> here, say "not in the FY26 SLA deck — check FY26 SLAs.pptx" rather
> than guess.

---

## Quick Lookup — Minimum Lead Times to Schedule

| Delivery Type | Minimum lead time (request → start date) | Hard rule? |
|---|---|---|
| **Open Enrollment (OE)** / **MA-D (bulk)** | **12 weeks** before Official Start Date | Hard SLA |
| **OE / MA-D top-up** (use excess MTT capacity) | **30 days** before Official Start Date | SPOC-driven |
| **Private Delivery (PD)** / **TPM-requested MA-D** | **5 weeks min** / **10 weeks max** before Official Start Date | Auto-rejected outside window |
| **Virtual Training Day (VTD)** | **30 calendar days** before event start | Forecast on the **20th** of month for delivery 2 months later |
| **Video Recording Review** | **12 weeks** before request date (status `Ready for Scheduling`) | Hard SLA |
| **TSPc** (Training Service Partner Credits) | **No customer lead time** — internal SLA: **2 business days** total (1 BD AER submission + 1 BD execution after ALL approval) | TPC team SLA |

---

## 1 · Open Enrollment (OE) & Multi-Account Private Delivery (MA-D)

### Submission
- **Bulk deliveries** → submit to Delivery Operations **no later than 12 weeks** from Official Start Date.
- **Top-ups** (use excess MTT capacity) → SPOC may request **no later than 30 days** from Official Start Date.

### Delivery Operations turnaround (Trainer Assignment & Dispatch)
| Step | Time |
|---|---|
| Pick-up (`Ready for Scheduling` → `Scheduler Assigned`) | **1 business day** |
| Execution (`Scheduler Assigned` → `Ready for Dispatch`) | **2–4 business days** |
| Auto-flow `Ready for Dispatch` → `Del Ops Assigned` | **10 min – 2 hours** |
| Reg Page Check + LxP Publication (`Del Ops Assigned` → `Delivery Published/Promoted`) | **1 business day** |
| **Total** | **4–6 business days** |
| Skillable Labs provisioning | **2 business days before Class Start** |

---

## 2 · Private Delivery (PD) & TPM-Requested MA-D

### Submission window
- AER must be in `Pending Approval` between **T-10 weeks and T-5 weeks** from Official Start Date.
- **Outside window → automatically rejected by Del Ops.**
- For exceptions (>T-10 or <T-5) → submit via **Exception Request Tool (ERT)**. Only approved exceptions are assigned to Del Ops.

### Delivery Operations turnaround
| Step | Time |
|---|---|
| Pick-up (`Ready for Scheduling`) | **1 business day** |
| Execution — **Classic / SBILT** | **2 business days** |
| Execution — **Blended** | **5 business days** |
| Auto-flow `Ready for Dispatch` → `Del Ops Assigned` | **10 min – 2 hours** |
| Reg Page Check + Publication | **1 business day** |
| **Total** | **4–7 business days** |
| Skillable Labs provisioning | **2 business days before Class Start** |

---

## 3 · Virtual Training Day (VTD)

### Forecast / Submission
- Forecast template due **no later than 30 calendar days** before event start.
- **Area forecasts due on the 20th of each month** for deliveries **2 months later** (e.g., **Jan 20 → March deliveries**).
- Requests **<30 calendar days** out → must go through **exception process**.
- Event teams: must check the **WWL report within 24 hours** of the confirmation email.

### Delivery Operations turnaround
| Step | Time |
|---|---|
| Delivery Record Creation (`Draft` → `Ready for Scheduling`) | **2 business days** from forecast |
| Pick-up (`Ready for Scheduling` → `Scheduler Assigned`) | **1 business day** |
| Execution (`Scheduler Assigned` → `Ready for Dispatch`) | **4 business days** |
| Auto-flow → `Del Ops Assigned` | **10 min – 2 hours** |
| Pick-up + execution (`Del Ops Assigned` → `Delivery Published/Promoted`) | **1 business day** |
| **Total** | **8 business days** |

⚠️ If registration details are not ready in **MASH**, the delivery moves to status `DelOps ON HOLD`.

---

## 4 · TSPc (Training Service Partner Credits)

### TPC team SLA (after TPM request)
| Step | Time |
|---|---|
| AER Submission (TPM request → AER in DynaMight, sent for ALL approval) | **1 business day** |
| Execution post-approval (activate Add-on Offer + send TSPc token to TSP) | **1 business day** |
| Edits & credit-back actions in DynaMight | **1 business day** per request |
| **Total** | **2 business days** (excludes ALL approval time) |

### Hard rules
- **Increases** to requested quantity **after AER submitted** → require a **brand-new AER**. The original cannot be amended upward.
- **TSPc token credit-back** requires **TSP confirmation on token usage** before credits return to the pool.
- "Total estimated time" = pick-up + execution; **does not include ALL approval latency** (out of TPC team's hands).

---

## 5 · Video Recording Review

### Submission
- Request must reach status `Ready for Scheduling` **no later than 12 weeks** from request date.

### Delivery Operations turnaround
| Step | Time |
|---|---|
| Pick-up (`Ready for Scheduling` → `Scheduler Assigned`) | **1 business day** |
| Execution (`Scheduler Assigned` → `Ready for Dispatch`) | **2 business days** |
| **Total** | **3 business days** |

---

## Decision Tree — "Can I schedule this on date X?"

1. **What delivery type?** (PD / OE / MA-D / TSPc / VTD / Video Review)
2. **Compute days between today and the requested Official Start Date.**
3. **Compare to the submission window:**
   - PD/MA-D: must be **35–70 days** out → otherwise ERT exception.
   - OE bulk: must be ≥**84 days** out (12 wks).
   - VTD: must be ≥**30 calendar days** + must align with the 20th-of-month forecast cadence.
   - Video Review: must be ≥**84 days** out.
   - TSPc: no customer lead time, but expect **2 BDs internal + ALL approval time**.
4. **Add Del Ops turnaround** (4–8 BDs depending on type) before the class can be `Delivery Published/Promoted`.
5. **Add 2 BDs** for Skillable Labs provisioning (if applicable).

If the math doesn't fit → **trigger Exception Request Tool (ERT)** and tell the user the request will only proceed if approved.

---

## Status / Stage Glossary

| Status | Meaning |
|---|---|
| `Draft` | Initial record creation, not yet routed |
| `Ready for Scheduling` | Hand-off to Del Ops; pick-up clock starts |
| `Scheduler Assigned` | Scheduler owns it; execution clock starts |
| `Ready for Dispatch` | Trainer assigned; auto-routes to Del Ops in 10 min – 2 hr |
| `Del Ops Assigned` | Del Ops owns publication; 1 BD to publish |
| `Delivery Published/Promoted` | Live on LxP; visible to learners |
| `DelOps ON HOLD` | Blocked (typically MASH registration data missing) |
| `Pending Approval` | AER awaiting ALL/approver decision |

---

## Common Q&A Patterns

| User asks | Answer pattern |
|---|---|
| "Posso agendar PD para [data]?" | Compute (date − today) in calendar days. **Must be 35–70 days**. If <35 or >70 → ERT exception. After approval, +4–7 BDs Del Ops + 2 BDs labs. |
| "Qual o SLA da TSPc?" | TPC team: **2 BDs total** (1 AER submit + 1 execution post-approval). ALL approval time is separate. |
| "Quando o forecast VTD de [mês] vence?" | **Day 20** of the month **2 months prior**. Ex: forecast for July deliveries due **May 20**. |
| "Posso aumentar a quantidade do AER já submetido?" | **Não — para TSPc, aumentos exigem novo AER.** O original não pode ser editado para cima. |
| "Como faço credit-back de TSPc?" | TPM solicita → TPC executa em **1 BD** em DynaMight, **mas só após o TSP confirmar não-uso do token**. |
| "Posso cancelar uma PD?" | Não está documentado timing de cancelamento neste deck. **Direcionar usuário ao FY26 SLAs.pptx ou Del Ops.** |

---

## Conventions

- **"Business days" = MS business days** (US calendar at minimum; LATAM follows local holidays where applicable).
- **"Calendar days" only used for VTD's 30-day rule**; everything else is BDs.
- **"Official Start Date"** = the date the class is scheduled to begin (not the registration open date).
- **All lead times are MINIMUMS.** Adding buffer is always wise — Del Ops SLAs are *targets*, not guarantees.

---

## Source & Refresh

- **File:** `FY26 SLAs.pptx`
- **Location:** SharePoint > WWL > CSNG Ops
- **Last updated in deck:** 13-Feb-2026
- **Skill last refreshed from deck:** 22-Apr-2026 (via Copilot extraction; conversation `01291295-7e88-4702-b4cc-18b5fec57120`)

If the user reports an SLA discrepancy or new version of the deck:
1. Re-fetch via Copilot (`agent365-copilot-search-copilot_chat` with the file URI).
2. Diff against this skill.
3. Update verbatim values + bump "last refreshed" date above.

## Post-Run Reflection

After answering an SLA question, briefly note in your reply: which SLA was
checked, the date math performed, and whether an ERT exception is needed.
This makes the audit trail visible to the user.
