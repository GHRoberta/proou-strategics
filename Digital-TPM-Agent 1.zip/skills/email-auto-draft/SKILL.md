---
name: email-auto-draft
description: >
  Automated email draft generator. Scans Outlook inbox for recent emails where the user
  is in the TO line, generates contextual draft replies using the agent's voice/tone,
  and saves them as Outlook drafts for review. Designed for headless scheduled execution.
  Triggers: auto draft, email drafts, draft replies, scheduled email, scan inbox,
  gerar rascunhos, rascunho automático.
---

# Email Auto-Draft — Scheduled Inbox Response Skill

> **Note:** `%WORK_BASE%` defaults to `{{WORKDIR_LOCAL}}\` but can be configured during setup.

## Purpose

Automatically scan the Outlook inbox for recent unreplied emails addressed directly
to the user (TO line), generate intelligent draft replies using the calling agent's
tone and style, and save them as Outlook drafts for human review before sending.

**This skill NEVER sends emails.** It only creates drafts.

## When to Use

- Scheduled execution via `schtasks` + `copilot -p` (primary use case)
- Manual invocation: "scan my inbox and draft replies"
- Triggered by automation wanting to pre-process email responses

## Prerequisites

1. **Outlook desktop must be running** (COM automation)
2. **PowerShell 5.1** (`powershell.exe`) for COM interop
3. **WorkIQ** available for email context enrichment (optional but recommended)
4. State file at `%WORK_BASE%\email-auto-draft\processed.json` tracks already-handled emails

---

## Execution Flow

### Step 1 — Initialize State

Load the processed emails tracker to avoid re-drafting:

```powershell
powershell.exe -Command "& {
    $stateDir  = Join-Path $env:WORK_BASE 'email-auto-draft'
    if (-not $stateDir) { $stateDir = '{{WORKDIR_LOCAL}}\email-auto-draft' }
    $stateFile = Join-Path $stateDir 'processed.json'

    if (-not (Test-Path $stateDir)) {
        New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
    }

    if (Test-Path $stateFile) {
        $processed = Get-Content $stateFile -Raw | ConvertFrom-Json
    } else {
        $processed = @{ entries = @() }
    }

    # Prune entries older than 7 days to keep file small
    $cutoff = (Get-Date).AddDays(-7).ToString('o')
    $processed.entries = @($processed.entries | Where-Object { $_.timestamp -gt $cutoff })

    $processed | ConvertTo-Json -Depth 5 | Set-Content $stateFile -Encoding UTF8
    Write-Host 'State initialized. Previously processed:' $processed.entries.Count 'entries'
}"
```

### Step 2 — Scan Inbox for Unreplied Emails (TO line only)

Find emails from the last 15 minutes where the user is a direct recipient (TO),
excluding already-processed EntryIDs:

```powershell
powershell.exe -Command "& {
    $ol    = New-Object -ComObject Outlook.Application
    $ns    = $ol.GetNamespace('MAPI')
    $inbox = $ns.GetDefaultFolder(6)  # olFolderInbox

    # Time window: last 20 minutes (5 min buffer for clock drift)
    $since = (Get-Date).AddMinutes(-20).ToString('MM/dd/yyyy HH:mm')

    $filter = ""[ReceivedTime] >= '$since'""
    $items  = $inbox.Items.Restrict($filter)
    $items.Sort('[ReceivedTime]', $true)

    # Load processed state
    $stateDir  = if ($env:WORK_BASE) { $env:WORK_BASE } else { '{{WORKDIR_LOCAL}}' }
    $stateFile = Join-Path $stateDir 'email-auto-draft\processed.json'
    $processed = @()
    if (Test-Path $stateFile) {
        $state = Get-Content $stateFile -Raw | ConvertFrom-Json
        $processed = @($state.entries | ForEach-Object { $_.entryId })
    }

    # Get user's email address
    $userEmail = $ns.CurrentUser.AddressEntry.GetExchangeUser().PrimarySmtpAddress

    $candidates = @()
    foreach ($item in $items) {
        if ($item.Class -ne 43) { continue }  # only MailItems

        # Skip already processed
        if ($processed -contains $item.EntryID) { continue }

        # Check if user is in TO line (not just CC/BCC)
        $toField = $item.To
        $isDirectRecipient = $false
        foreach ($recip in $item.Recipients) {
            if ($recip.Type -eq 1) {  # 1 = olTo
                $addr = $recip.AddressEntry.GetExchangeUser()
                if ($addr -and $addr.PrimarySmtpAddress -eq $userEmail) {
                    $isDirectRecipient = $true
                    break
                }
            }
        }

        if (-not $isDirectRecipient) { continue }

        # Skip if already replied (check PR_ flag)
        $PR_LAST_VERB = 0x10810003
        try {
            $lastVerb = $item.PropertyAccessor.GetProperty(""http://schemas.microsoft.com/mapi/proptag/$('0x{0:X8}' -f $PR_LAST_VERB)"")
            if ($lastVerb -eq 102 -or $lastVerb -eq 103) { continue }  # 102=Reply, 103=ReplyAll
        } catch {
            # Property not set = not replied, continue
        }

        $candidates += [PSCustomObject]@{
            EntryID    = $item.EntryID
            Subject    = $item.Subject
            From       = $item.SenderName
            FromEmail  = $item.SenderEmailAddress
            ReceivedAt = $item.ReceivedTime.ToString('yyyy-MM-dd HH:mm')
            BodyPreview = $item.Body.Substring(0, [Math]::Min(500, $item.Body.Length))
            To         = $item.To
            CC         = $item.CC
            HasAttach  = $item.Attachments.Count -gt 0
        }
    }

    if ($candidates.Count -eq 0) {
        Write-Host 'NO_NEW_EMAILS'
    } else {
        Write-Host ""FOUND $($candidates.Count) email(s) needing draft replies:""
        $candidates | ConvertTo-Json -Depth 3
    }
}"
```

**If output is `NO_NEW_EMAILS`, stop here. No further action needed.**

### Step 2b — Filter Newsletters and Bulk Mail

The scan script automatically filters out newsletters, automated notifications, and bulk
senders. The following patterns in `SenderEmailAddress` or `SenderName` are blocked:

```
noreply, no-reply, donotreply, do-not-reply, newsletter, academy,
notifications@, alerts@, mailer-daemon, postmaster, bounce, unsubscribe,
marketing@, news@, info@, support@, mcapsacademy, microsoftlearning,
msonlineservicesteam, microsoft365, office365, sharepointonline,
MicrosoftExchange, O365, Teams@
```

To add custom blocked senders, append patterns to the `$bulkPatterns` array in the scan script.
Blocked emails appear in the summary as `Skipped (bulk/newsletter)`.

### Step 3 — Generate Draft Reply Content

For EACH candidate email from Step 2, **load the user's voice profile**
and use it to compose a reply in their authentic voice:

```text
view: {{COPILOT_HOME}}\skills\my-voice\voice-profile.md
```

The profile (if present) is the source of truth for tone, signature,
openers/closers, and language routing. The agent should:

1. **Read the email body** carefully to understand the ask
2. **Match the sender to an Audience Mode** in `voice-profile.md` §4:
   - External `.com.br`/`.gov.br` → Mode A (PT-BR formal-warm)
   - Internal MS peer → Mode B (EN warm-direct)
   - TPC [CONTATO] → Mode C
   - Exec / VP → Mode D
   - Quick ack → Mode F
   - Use the §3 Language Routing table to confirm PT vs EN
3. **Draft a concise, actionable reply** using:
   - Opener phrase from the matched mode (§4)
   - Voice markers from §5 (e.g., "Conforme alinhado", "fico à disposição",
     "Hi [CONTATO], how are you?")
   - Closer + sign-off from the matched mode
4. **Format as clean HTML** using the channel rules in §6 (Aptos/Calibri
   11pt, Microsoft palette, PT-BR HTML entity encoding for accents under
   PS 5.1 COM)
5. **Skip signature injection** — Outlook auto-appends the user's default
   signature when the draft is created (§6 channel note)

If the profile is missing, fall back to generic guidance (PT for BR
contacts, EN otherwise) and **flag** in the run summary that the profile
was not found.

### Step 4 — Create Draft in Outlook

For each drafted reply, create an Outlook draft (NEVER send):

```powershell
powershell.exe -Command "& {
    param([string]$EntryID, [string]$ReplyBody, [string]$IsReplyAll)

    $ol   = New-Object -ComObject Outlook.Application
    $ns   = $ol.GetNamespace('MAPI')
    $msg  = $ns.GetItemFromID($EntryID)

    if ($IsReplyAll -eq 'true') {
        $reply = $msg.ReplyAll()
    } else {
        $reply = $msg.Reply()
    }

    # Prepend draft body before original message
    $reply.HTMLBody = $ReplyBody + $reply.HTMLBody

    # Save as draft (do NOT display in headless mode, do NOT send)
    $reply.Save()

    Write-Host ""Draft saved for: [$($msg.Subject)] from $($msg.SenderName)""
}" -EntryID '<entry-id>' -ReplyBody '<div style=""font-family:Calibri,sans-serif;font-size:11pt""><p>Draft content here</p></div><hr/>' -IsReplyAll 'false'
```

**Key:** Use `$reply.Save()` (not `Display()`) for headless execution.
Use `$reply.Display()` only when running interactively and user wants to see drafts.

### Step 5 — Update Processed State

After successfully creating each draft, record the EntryID:

```powershell
powershell.exe -Command "& {
    param([string]$EntryID, [string]$Subject, [string]$From)

    $stateDir  = if ($env:WORK_BASE) { $env:WORK_BASE } else { '{{WORKDIR_LOCAL}}' }
    $stateFile = Join-Path $stateDir 'email-auto-draft\processed.json'
    $state = Get-Content $stateFile -Raw | ConvertFrom-Json

    $newEntry = @{
        entryId   = $EntryID
        subject   = $Subject
        from      = $From
        timestamp = (Get-Date).ToString('o')
        action    = 'draft_created'
    }

    $state.entries += $newEntry
    $state | ConvertTo-Json -Depth 5 | Set-Content $stateFile -Encoding UTF8

    Write-Host ""Recorded: $Subject from $From""
}" -EntryID '<entry-id>' -Subject 'Email subject' -From 'Sender Name'
```

### Step 6 — Summary Output

At the end of execution, output a summary:

```
=== Email Auto-Draft Summary ===
Scanned: 15 min window
Found: 3 unreplied emails in TO line
Drafted: 3 replies saved to Outlook Drafts
Skipped: 0 (already processed)
Next run: ~15 minutes
================================
```

---

## Reply Guidelines for the Agent

When generating draft content, follow these rules:

1. **Never fabricate information.** If unsure about a detail, draft a reply that acknowledges and asks for clarification.
2. **Keep it short.** 2-4 sentences for routine emails. Longer only if complexity demands.
3. **Match urgency.** If the email has `!` (high importance), prioritize and reflect urgency in the draft.
4. **Preserve threads.** Always use Reply/ReplyAll — never compose a new email to respond.
5. **ReplyAll logic:** Use ReplyAll when CC recipients exist and the topic involves them. Use Reply for 1:1 or when the CC is purely informational.
6. **No signatures needed.** Outlook appends the user's default signature automatically.
7. **Flag uncertainty.** If the draft requires the user to fill in details, use `[TODO: ...]` placeholders.
8. **CRITICAL — Use HTML entities for accented characters.** PS 5.1 COM saves HTMLBody as Latin-1, corrupting UTF-8 accents. Always encode:
   - `á` → `&#225;`  `à` → `&#224;`  `ã` → `&#227;`  `â` → `&#226;`
   - `é` → `&#233;`  `ê` → `&#234;`
   - `í` → `&#237;`
   - `ó` → `&#243;`  `õ` → `&#245;`  `ô` → `&#244;`
   - `ú` → `&#250;`
   - `ç` → `&#231;`
   - `Á` → `&#193;`  `É` → `&#201;`  `Í` → `&#205;`  `Ó` → `&#211;`  `Ú` → `&#218;`
   - `Ã` → `&#195;`  `Õ` → `&#213;`  `Ç` → `&#199;`
9. **HTML template:**

```html
<div style="font-family: Calibri, sans-serif; font-size: 11pt;">
    <p>{{greeting}}</p>
    <p>{{body}}</p>
    <p>{{closing}}<br/>{{USER_FIRST_NAME}}</p>
</div>
<hr/>
```

---

## Scheduled Task Setup

To run every 15 minutes via Windows Task Scheduler:

```powershell
$action  = New-ScheduledTaskAction -Execute "copilot" -Argument "-p 'Load the email-auto-draft skill and execute the full flow: scan inbox for unreplied emails in my TO line from the last 15 minutes, draft contextual replies in my voice, and save as Outlook drafts. Output summary when done.' --agent ss-sales-manager --allow-all-tools --no-ask-user -s"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 15) -RepetitionDuration ([System.TimeSpan]::MaxValue)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

Register-ScheduledTask -TaskName "CopilotEmailAutoDraft" -Action $action -Trigger $trigger -Settings $settings -Description "Copilot: auto-draft email replies every 15 min"
```

To remove:
```powershell
Unregister-ScheduledTask -TaskName "CopilotEmailAutoDraft" -Confirm:$false
```

---

## Logging

All runs are logged to `%WORK_BASE%\email-auto-draft\runs.log`:

```powershell
$stateDir = if ($env:WORK_BASE) { $env:WORK_BASE } else { '{{WORKDIR_LOCAL}}' }
$logEntry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Found: $count | Drafted: $drafted | Skipped: $skipped"
Add-Content -Path (Join-Path $stateDir 'email-auto-draft\runs.log') -Value $logEntry
```

---

## Common Pitfalls

| Pitfall | Solution |
|---------|----------|
| Outlook not running (headless) | Ensure Outlook starts at login; COM will fail without it |
| COM hangs in scheduled task | Set task timeout to 5 minutes; kill zombie OUTLOOK.EXE if needed |
| Duplicate drafts | State file tracks processed EntryIDs — always update after drafting |
| PS7 vs PS 5.1 | All COM scripts MUST use `powershell.exe`, not `pwsh` |
| WorkIQ auth in scheduled context | WorkIQ uses WAM/SSO — works if user session is active (not locked screen with no session) |
| Clock drift between runs | Use 20-min scan window (5-min overlap buffer) for 15-min schedule |
| Large email bodies | Truncate BodyPreview to 500 chars for agent context; read full body only when drafting |
