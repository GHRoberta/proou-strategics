---
name: tpm-welcome-email
description: >
  Gera o e-mail-rascunho de boas-vindas / onboarding enviado a um
  cliente entrando no programa Capacitação Organizational Microsoft
  (antigo ESI). Diferente do capacitacao-kickoff-email (pós-reunião,
  consome transcrição), este produz o pacote introdutório padronizado:
  apresenta o programa, explica os portais LxP (aluno) e CxP
  (administrador), descreve o papel do administrador, anexa os 4
  materiais padrão (LxP, agendamento de prova com desconto, relatórios
  ESI e a Matriz de Capacidades) e fecha destacando a matriz como
  próximo passo (preenchimento pelo cliente). Cria rascunho no Outlook
  para contatos do cliente + virtual team Microsoft.
  Triggers: welcome ESI, boas-vindas ESI, onboarding ESI, kit de
  boas-vindas capacitação, apresentar Capacitação Organizational,
  primeiro email ESI sem reunião, material introdutório capacitação,
  matriz para preenchimento, LxP CxP admin onboarding, cliente novo no
  programa.
---

# Capacitação Welcome Email — Boas-vindas / Onboarding ao programa ESI

Gera o **e-mail-rascunho de boas-vindas** que enviamos a um cliente
quando ele está entrando no programa **Capacitação Organizational
Microsoft** (antigo ESI). É o pacote introdutório padrão: apresenta o
programa, explica os dois portais (LxP e CxP), define o papel do
administrador, anexa os 4 materiais de apoio e formaliza o próximo
passo (preenchimento da Matriz de Capacidades).

Modelo de referência: `Capacitação Organizational Microsoft (ESI) — Boas-vindas, materiais e próximos passos | <Cliente>`.

## Quando usar (vs. outros skills)

| Cenário | Skill |
|---------|-------|
| **Cliente novo entrando no programa, sem reunião específica como gatilho** | **este skill** |
| **Pós-reunião de descoberta** (consome transcrição + próximos passos literais da call) | `capacitacao-kickoff-email` |
| Apenas divulgar a grade OE (para TPC interna ou área de Comunicação do cliente) | `oe-grade-email` |
| Plano de capacitação completo em PPTX (trilha didática) | `learning-trail-pptx` |
| Email genérico para cliente externo | `secure-email-drafter` |

> **Regra de ouro:** se houve uma reunião e o cliente espera um
> follow-up dela, use o `capacitacao-kickoff-email`. Este skill aqui é
> o pacote padronizado, idêntico de cliente para cliente, sem
> dependência de reunião — útil para o primeiro contato formal pós
> apresentação inicial / vendas / handoff.

## Pré-requisitos

- 4 arquivos padrão disponíveis localmente:
  - `{{WORKDIR}}\Portal de Experiencia do Aluno - LxP.pdf` (~2.0 MB) — passo a passo do LxP
  - `{{WORKDIR}}\Agendamento da prova com desconto.pdf` (~1.85 MB) — passo a passo do desconto de 50% em provas
  - `{{WORKDIR}}\Passo a passo Relatorios ESI.pdf` (~815 KB) — passo a passo dos relatórios do CxP
  - `{{WORKDIR}}\Capacitacao_Organizational_Kit\Capacitacao_Organizational_Capability_Matrix_v1.xlsx` (~160 KB) — a Matriz de Capacidades
- Template HTML do email já versionado em:
  `{{WORKDIR}}\Capacitacao_Organizational_Kit\Email_Capacitacao_Organizational_template.html`
- Subject template em:
  `{{WORKDIR}}\Capacitacao_Organizational_Kit\Email_Capacitacao_Organizational_subject.txt`
- Manifest de versão em:
  `{{WORKDIR}}\Capacitacao_Organizational_Kit\manifest.json`
- VPN + `az login` se for criar o draft via Graph (ou Outlook desktop logado para via COM).

## Estrutura padrão do e-mail (NÃO pular seções)

Ordem fixa — facilita a leitura do cliente e mantém o padrão entre contas:

1. **Cabeçalho Microsoft** — barra azul `#0078D4` + logo de 4 quadrados (Microsoft palette) + título do programa + subtítulo "antigo Enterprise Skills Initiative (ESI) · Boas-vindas ao programa".
2. **Saudação + abertura** — `Olá [Nome], tudo bem?` (Mode A) seguido de `Em primeiro lugar, muito obrigado pelo engajamento e pela parceria...` (voice marker §5.1) e parágrafo curto explicitando que este e-mail é o pacote de boas-vindas.
3. **O programa Capacitação Organizational Microsoft** — `<u>` no título + 1 parágrafo de definição + bullets fixos dos 7 benefícios:
   - TPM dedicado
   - Turmas abertas em PT-BR
   - Treinamentos dedicados (PD)
   - Formato escalável (SWM)
   - 50% off em certificações
   - Plano de capacitação personalizado (ancorado na matriz)
   - Painel de métricas e relatórios
4. **Os dois portais (LxP e CxP)** — `<u>` no título + parágrafo de transição + tabela 2 linhas × 2 colunas com cor de fundo `#F3F2F1` no rótulo:
   - LxP — Learner eXperience Portal · "Portal de experiência do aluno"
   - CxP — Customer eXperience Portal · "Portal do administrador da [Cliente]"
5. **A figura do Administrador do programa** — `<u>` no título + parágrafo introdutório + 3 bullets de capacidades fixos:
   - Inclusão e promoção de usuários
   - Gerenciamento de domínios
   - Relatórios de usuários e consumo
   + recomendação fixa: "pelo menos dois administradores (um titular e um backup)".
6. **Materiais anexos** — `<u>` no título + lista numerada batendo 1:1 com a ordem dos 4 anexos. Sempre nessa ordem:
   1. Portal de Experiencia do Aluno - LxP.pdf
   2. Agendamento da prova com desconto.pdf
   3. Passo a passo Relatorios ESI.pdf
   4. Capacitacao_Organizational_Capability_Matrix_v1.xlsx
7. **Callout amarelo #1 — política de no-show** — `background-color:#FFF4CE` + `border-left:4px solid #D83B01` — 3 faltas seguidas sem cancelar = bloqueio.
8. **Callout amarelo #2 — material restrito** — mesmo estilo — material destinado apenas aos destinatários; CxP/relatórios apenas aos administradores indicados.
9. **Próximo passo: a Matriz de Capacidades** — `<u>` no título — seção de fechamento que afirma a matriz como instrumento central + 3 passos do caminho de trabalho:
   1. Cliente preenche papéis (time, # pessoas, papel/função)
   2. Cliente marca de 2 a 5 capacidades por papel
   3. Microsoft cruza com o catálogo e devolve plano por experiência de aprendizado
   + sugestão fixa: `Sugiro agendarmos uma sessão de trabalho de 60 minutos...` (voice marker §5.3).
10. **Despedida + assinatura** — `Aguardo retorno e fico à disposição` + `Atenciosamente,` + assinatura **vinda do `my-voice` §2.3 Full** (não hardcode).
11. **Rodapé cinza** (`background:#F3F2F1`, `color:#605E5C`) — nota curta de privacidade Microsoft + [Cliente].

### Snippets HTML reutilizáveis

```html
<!-- Cabeçalho Microsoft (4 quadrados + título do programa) -->
<div style="background:#0078D4;color:#fff;padding:22px 26px">
  <table role="presentation" cellspacing="0" cellpadding="0" style="margin-bottom:10px"><tr>
    <td style="width:12px;height:12px;background:#F25022"></td><td style="width:2px"></td><td style="width:12px;height:12px;background:#7FBA00"></td>
    <td rowspan="3" style="padding-left:10px;color:#fff;font-size:13pt;font-weight:600">Microsoft</td>
  </tr><tr><td colspan="3" style="height:2px"></td></tr><tr>
    <td style="width:12px;height:12px;background:#00A4EF"></td><td style="width:2px"></td><td style="width:12px;height:12px;background:#FFB900"></td>
  </tr></table>
  <div style="font-size:21pt;font-weight:600;line-height:1.15">Capacitação Organizational Microsoft</div>
  <div style="font-size:10.5pt;opacity:.95;margin-top:4px">antigo Enterprise Skills Initiative (ESI) · Boas-vindas ao programa</div>
</div>

<!-- Header de seção -->
<p style="margin:22px 0 6px"><b><u>Título da seção</u></b></p>

<!-- Tabela LxP/CxP -->
<table role="presentation" cellspacing="0" cellpadding="0" style="border-collapse:collapse;width:100%;margin-top:8px">
  <tr style="background:#F3F2F1">
    <td style="border:1px solid #E1DFDD;padding:10px 12px;width:35%;vertical-align:top">
      <b style="color:#003A70">Rótulo</b><br>
      <span style="color:#605E5C;font-size:10pt">Subtítulo</span>
    </td>
    <td style="border:1px solid #E1DFDD;padding:10px 12px;vertical-align:top">Conteúdo</td>
  </tr>
</table>

<!-- Callout amarelo / borda vermelha -->
<p style="background-color:#FFF4CE;padding:12px 14px;border-left:4px solid #D83B01;margin:18px 0">
  <b>IMPORTANTE</b> — texto do alerta.
</p>

<!-- Rodapé -->
<div style="background:#F3F2F1;color:#605E5C;padding:12px 26px;font-size:9pt;border-top:1px solid #E1DFDD">
  Microsoft Brasil — Programa Capacitação Organizational (ex-ESI). [...]
</div>

<!-- Assinatura: SEMPRE carregue do profile my-voice (não hardcode aqui) -->
<!-- Variante a usar: 2.3 Full (primeiro contato formal externo) -->
```

⚠️ **NÃO hardcode a assinatura neste skill.** Antes de montar o body,
carregue [`my-voice/voice-profile.md`](../my-voice/voice-profile.md) e
use a **variante 2.3 Full** (primeiro contato formal externo).

```text
view: {{COPILOT_HOME}}\skills\my-voice\voice-profile.md
# Use seção §2.3 Full HTML signature
```

Wrap o body inteiro em:

```html
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body dir="ltr" style="font-family:Aptos,Calibri,sans-serif;font-size:11pt;color:#000;background:#fff;margin:0;padding:0">
... conteúdo ...
</body></html>
```

## Recipientes

- **TO**: contatos indicados pelo usuário (mínimo 1 contato do
  domínio do cliente). Resolver via
  `agent365-user-GetMultipleUsersDetails` se só tiver display name.
- **CC**: virtual team Microsoft da conta. Padrão LASA mínimo:
  `{{EMAIL}}`, `{{EMAIL}}`. Para
  outras contas, verificar account team via
  `msx-mcp-get_account_overview` → seção `team`.
- **From**: usuário ({{USER_FIRSTNAME}}).

> Se o usuário não passar contatos do cliente, **pergunte** — não
> invente nomes. O CC com a virtual team pode ser confirmado por
> default ("manter a virtual team padrão LASA?").

## Workflow

### Passo 1 — Confirmar destinatários e contexto

Antes de gerar:

- Cliente (substitui `[Cliente]` no subject e body)
- Lista de TO (UPNs do cliente — mínimo 1)
- Lista de CC (virtual team MS — confirmar padrão LASA ou ajustar)
- Saudação personalizada (substitui `[Nome]`) — se forem múltiplos
  destinatários, usar `Olá [Nome1] e [Nome2], tudo bem?` (até 3 nomes)
  ou `Prezados, tudo bem?` (4+).

Se faltar qualquer item, **pergunte ao usuário antes de gerar.**

### Passo 2 — Gerar o body a partir do template

```python
import re
from pathlib import Path

KIT = Path(r"{{WORKDIR}}\Capacitacao_Organizational_Kit")
template = (KIT / "Email_Capacitacao_Organizational_template.html").read_text(encoding="utf-8")
subject_tmpl = (KIT / "Email_Capacitacao_Organizational_subject.txt").read_text(encoding="utf-8").strip()

cliente = "Banco Acme"
nome    = "Maria"   # ou "Maria e João"
body = template.replace("[Cliente]", cliente).replace("[Nome]", nome)
subject = subject_tmpl.replace("[Cliente]", cliente)
```

> **Não substitua placeholders à mão dentro do HTML** — sempre
> consuma o template para que correções no template propaguem
> automaticamente para os próximos envios.

### Passo 3 — Atribuir os 4 anexos via OneDrive URI

A rota OneDrive bypassa o limite de tamanho de base64 em args do
Graph:

```
1. Confirmar os 4 arquivos no diretório de trabalho (sync OneDrive completo)
2. Aguardar 5–8s para sync completar
3. Para cada arquivo: agent365-sharepoint-getFileOrFolderMetadataByUrl → coletar webUrl
4. agent365-mail-AddDraftAttachments com a lista dos 4 URIs (na ORDEM da seção 6 do email)
```

Caminhos canônicos (driveId
`b!z7dMnTHGRUOUJ_BLCOylyCQ2OiT9CXtNnT8VNsMdm67_lMnBMPr-SJ0Xi573e4W6`):

```
https://microsoft-my.sharepoint.com/personal/{{USER_SP}}/Documents/ghcli-working/Portal de Experiencia do Aluno - LxP.pdf
https://microsoft-my.sharepoint.com/personal/{{USER_SP}}/Documents/ghcli-working/Agendamento da prova com desconto.pdf
https://microsoft-my.sharepoint.com/personal/{{USER_SP}}/Documents/ghcli-working/Passo a passo Relatorios ESI.pdf
https://microsoft-my.sharepoint.com/personal/{{USER_SP}}/Documents/ghcli-working/Capacitacao_Organizational_Kit/Capacitacao_Organizational_Capability_Matrix_v1.xlsx
```

> **Atenção à matriz** — antes de anexar, confirmar com o usuário:
> manda a matriz **template** (em branco) ou **pré-preenchida** para o
> cliente? Se pré-preencher, delegar ao skill
> `tpm-capability-matrix` (se existir) ou pedir ao usuário a
> versão pronta. Em geral, o cliente novo recebe a matriz em branco.

### Passo 4 — Gerar o draft como `.eml` local (MANDATE M1)

Monte um `.eml` (RFC-822/MIME) e **abra-o** — **NÃO** use
`agent365-mail-CreateDraftMessage` nem Outlook COM (proibidos; entopem a pasta
Rascunhos). Snippet canônico em `my-voice/voice-profile.md` §6.

```
Subject:  "Capacitação Organizational Microsoft (ESI) — Boas-vindas, materiais e próximos passos | <Cliente>"
From:     {{USER_NAME}} <{{EMAIL}}>
To:       [contatos_cliente]
Cc:       [virtual_team_microsoft]
X-Unsent: 1
Body:     <html completo gerado no Passo 2>  (set_content + add_alternative)
Anexos:   os 4 arquivos embutidos DIRETO dos arquivos locais (caminhos acima) — MIME
Salvar:   {{WORKDIR_LOCAL}}\drafts\Capacitacao_OrgKit_<Cliente>.eml
Abrir:    subprocess.Popen(['cmd','/c','start','', str(eml)], shell=False)
```

**Nunca envie** — o `.eml` abre no new Outlook pronto para revisão e envio humano.

### Passo 5 — Verificar e reportar

Confirmar que o `.eml` em `{{WORKDIR_LOCAL}}\drafts\` abriu e contém os 4 anexos
presentes (LxP / Agendamento / Relatórios / Matriz) e devolver ao usuário o
**caminho do arquivo**.

## Erros e recuperação

| Erro | Causa | Solução |
|------|-------|---------|
| Anexo grande não entra no `.eml` | base64 estoura args MCP | Embuta do arquivo LOCAL com `msg.add_attachment(path.read_bytes(), ...)` — nunca via args MCP |
| `.eml` não abre / abre no app errado | handler default trocado | `subprocess.Popen(['cmd','/c','start','', str(eml)])`; confirmar que é o new Outlook |
| Body sem espaços / quebrado no Outlook | Template salvo com encoding errado (CP1252 vs UTF-8) | Reler o template **explicitamente** com `encoding="utf-8"` |
| Anexo de matriz duplicado | `.eml` montado 2x no mesmo arquivo | Regerar o `.eml` do zero (sobrescreve) em vez de re-anexar |
| Cliente reporta que LxP/CxP não está claro | Provavelmente o admin ainda não foi indicado | Reforçar no e-mail seguinte; sugerir uma call de 30 min |

## Checklist final antes de devolver ao usuário

- [ ] Subject substituído (`[Cliente]` → nome real)
- [ ] Body substituído (`[Cliente]` e `[Nome]` em todas as ocorrências — usar regex global, não match-a-match)
- [ ] TO contém pelo menos 1 contato do domínio do cliente
- [ ] CC contém o virtual team Microsoft (mínimo ATU + AE — ou padrão LASA)
- [ ] 4 anexos na ordem: LxP / Agendamento / Relatórios / Matriz
- [ ] Cabeçalho Microsoft renderizado (4 quadrados visíveis)
- [ ] Tabela LxP/CxP visível
- [ ] Seção do Administrador com 3 bullets
- [ ] 2 callouts amarelos (no-show + restrição)
- [ ] Seção final da Matriz com 3 passos + sugestão de call de 60 min
- [ ] Assinatura 2.3 Full ({{USER_NAME}} Neto + linha cinza com título + telefone + email + LinkedIn)
- [ ] **Draft criado, NÃO enviado** — devolver `webLink` ao usuário

## Cross-reference

- **`my-voice/voice-profile.md`** §2.3 Full (assinatura) · §4 Mode A
  (External Client) · §5.1/§5.3 (voice markers) · §6 (Email channel)
- **`capacitacao-kickoff-email/SKILL.md`** — variante pós-reunião,
  com transcrição
- **`tpm-capability-matrix/SKILL.md`** *(se criado)* — para
  pré-preencher / customizar a matriz antes de anexar
- **`secure-email-drafter`** — fallback para qualquer email externo
  com anexos quando este template específico não se aplicar
- **`oe-grade-email`** — quando precisar atualizar a grade OE em
  separado (não anexada por padrão neste e-mail de boas-vindas)
- **`account-agent`** — para confirmar virtual team da conta + buscar
  contatos do cliente quando o usuário não passar a lista
