---
name: mcp-reference
description: >
  Full MCP server catalog, configuration, auth patterns, health checks, and
  troubleshooting for all 14+ MCP servers used in the Work Hub. Load this skill
  when debugging MCP connectivity, adding new servers, checking auth status,
  or looking up server config details. Triggers: MCP, server, agent365,
  powerbi, markitdown, msx, servicetree, enghub, mcp-config, health check,
  fallback, outage, copilot-search, TPID, tool registration.
---

# MCP Server Reference

## Quick Server Table

| Name | Type | What It Does | Auth |
|------|------|-------------|------|
| `workiq` | Local | M365 data (email, Teams, calendar, transcripts, SP, people) | MSAL + WAM |
| `msx-mcp` | Local | MSX Dataverse (deals, pipeline, accounts, territories) | Azure CLI / `msx_login` |
| `powerbi-remote` | Remote | Power BI DAX queries against published datasets | Entra ID (copilotTokenAuth) |
| `agent365-mail` | Remote | Outlook email CRUD, search, attachments | Entra ID |
| `agent365-calendar` | Remote | Calendar CRUD, availability, rooms | Entra ID |
| `agent365-teams` | Remote | Teams chats, channels, messages, members | Entra ID |
| `agent365-copilot-search` | Remote | Search ALL M365 content (docs, emails, OneNote) | Entra ID |
| `agent365-user` | Remote | User profiles, manager, direct reports, org | Entra ID |
| `agent365-sharepoint` | Remote | OneDrive/SharePoint file operations | Entra ID |
| `agent365-word` | Remote | Word doc create/read/comment | Entra ID |
| `microsoft-learn-docs` | Remote | Azure/M365 product documentation search | None |
| `markitdown` | Local | Convert PPTX/PDF/DOCX/XLSX to Markdown | None |
| `enghub` | Stdio | eng.ms docs, ServiceTree browsing, TSG lookup | WAM |
| `servicetree` | Remote | Service Tree metadata, ownership, compliance | MISE auth |

**Plus built-in:** GitHub MCP (`github-mcp-server`) -- built into VS Code Copilot extension.

## Config Files

- **VS Code workspace:** `.vscode/mcp.json` (uses `"servers"` key)
- **Copilot CLI global:** `~/.copilot/mcp-config.json` (uses `"mcpServers"` key)
- **OpenCode:** `opencode.json` (project root)

## Common Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| MSX queries fail | VPN disconnected or token expired | Run `msx_auth_status`, then `msx_login` if needed |
| Power BI "unauthorized" | Token broker needs refresh | In VS Code: MCP: List Servers -> powerbi-remote -> Start. In CLI: restart session. |
| Teams tools fail | Used UPN instead of GUID | Call `agent365-user` `GetMyDetails` first to get user GUID |
| Copilot Search bad results | Wrong timezone format | Use IANA format: `America/Chicago`, not `Central Standard Time` |
| Tools missing after config change | CLI caches tools at startup | Restart CLI session (`/exit` then re-launch) |
| "invalid session" errors | MCP connection state expired | Restart CLI session |

## Detailed Server Documentation

For full per-server config, auth details, gotchas, and fallback patterns, see:
`References/playbook/mcp-servers.md` (383 lines, comprehensive reference)

Load that file only when you need specific server configuration details -- this skill provides the routing and troubleshooting layer.
