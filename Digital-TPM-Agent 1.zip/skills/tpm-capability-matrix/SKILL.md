---
name: tpm-capability-matrix
description: >
  Ciclo de vida da Matriz de Capacidades do programa Capacitação
  Organizational Microsoft (antigo ESI): (1) provisionar nova matriz
  para uma conta via template canônico; (2) renomear/refinar
  capacidades em massa via JSON map (sincroniza 3 abas: Matriz,
  Dicionário, Capacidade x Curso); (3) refresh do catálogo via
  Dynamight; (4) pré-preencher matriz com base em insights da conta;
  (5) validar matriz devolvida pelo cliente; (6) gerar plano de
  capacitação por papel a partir da matriz. Edição via Excel COM (a
  planilha tem sensitivity label/IRM, que quebra openpyxl); scripts
  idempotentes com retry/backoff para RPC_E_CALL_REJECTED.
  Triggers: matriz de capacidades, capability matrix, skilling matrix,
  nova matriz ESI, provisionar matriz, renomear capacidade, refresh
  catálogo matriz, pré-preencher matriz, validar matriz cliente, plano
  de capacitação a partir da matriz, ESI matrix lifecycle.
---

# Capacitação Capability Matrix — ciclo de vida da matriz do programa

Gerencia o ciclo de vida completo da **Matriz de Capacidades** do
programa Capacitação Organizational Microsoft (ex-ESI). É a planilha
que o cliente usa para identificar quais capacidades cada papel/área
da organização precisa desenvolver, e que a Microsoft consome para
montar o plano de capacitação por experiência de aprendizado (turmas
abertas, treinamentos dedicados, formato em escala, autoguiado,
certificações).

> **Identidade do artefato canônico:**
> `Capacitacao_Organizational_Capability_Matrix_v1.xlsx` — versionado em
> `{{WORKDIR}}\Capacitacao_Organizational_Kit\`.
> Estrutura: 25 capacidades em 8 domínios, 3 abas operacionais
> (Matriz, Dicionário, Capacidade x Curso) + 1 de auditoria.

## Quando usar (vs. outros skills)

| Cenário | Skill |
|---------|-------|
| **Operar a matriz** (provisionar, renomear, refresh, validar, gerar plano) | **este skill** |
| Anexar a matriz no e-mail de boas-vindas para o cliente | `tpm-welcome-email` |
| Gerar plano de capacitação **em PPTX didático** a partir do plano que sai daqui | `learning-trail-pptx` |
| Refresh do catálogo de cursos no Dynamight (origem de "Capacidade x Curso") | `dynamight` |
| Insights sobre uma conta (para pré-preencher) | `account-agent` |

## Pré-requisitos

- **Excel desktop instalado e logado** (não usamos openpyxl — a planilha
  tem sensitivity label / IRM, openpyxl falha com `BadZipFile: File is
  not a zip file`).
- Template canônico disponível em
  `{{WORKDIR}}\Capacitacao_Organizational_Kit\Capacitacao_Organizational_Capability_Matrix_v1.xlsx`.
- OneDrive sync ativo (para que o `ReparsePoint` se resolva em arquivo
  real antes da abertura — se necessário, o skill força download).
- VPN + `az login` se a operação consultar o Dynamight (capability 3).

## Estrutura da matriz (referência rápida)

| Aba | Conteúdo | Range principal |
|-----|----------|-----------------|
| **Matriz** | Cabeçalho com 25 capacidades + linhas de papéis + legenda dos 8 domínios + instruções | `D4:AB4` header capacidades · `A18:B25` legenda · `A2` subtítulo cliente/data/versão |
| **Dicionário** | 25 linhas com Código (Cxx), Domínio, Capacidade, Definição, Cursos âncora, Público típico | `A1:F26` |
| **Capacidade x Curso** | Cruzamento N:N (uma capacidade pode ter N cursos) com código, título, duração, capacidade da turma, observação | `A1:H77` |
| **Auditoria** | Cobertura do catálogo (mapeados / excluídos / sem mapeamento) | `A1:D97` |

> **Identificadores estáveis:** os códigos `C01`–`C25` na coluna A do
> Dicionário e da Capacidade x Curso são o **ID interno** das
> capacidades — sobrevivem a renomeações de exibição. Use-os como
> chave em joins, mappings e validações.

## Capabilities (6 operações do ciclo de vida)

### 1. Provisionar nova matriz para uma conta

**Quando:** novo cliente entrando no programa precisa receber a matriz
em branco.

**Entrada:**
- Nome da conta (ex.: `Banco Acme`)
- Pasta destino (default: `{{USERPROFILE}}\OneDrive - Microsoft\FY26\<Conta>\`)
- Versão alvo (default: copiar a versão mais recente do template
  canônico — atualmente `v2` com nomes de mercado)

**Saída:**
- Arquivo `Capacitacao_Organizational_Capability_Matrix_<Conta>_v1.xlsx`
  na pasta destino, com `A2` preenchido (`Cliente: <Conta> · Data: <hoje>`)

**Script:** `scripts/provision_matrix.ps1` (ver seção Scripts abaixo)

### 2. Renomear / refinar capacidades em massa

**Quando:** novos termos de mercado, ajustes de naming, reorganização
de domínios. Sincroniza 3 abas em uma única passada.

**Entrada:**
- JSON map em `templates/rename_map_v2_market.json` (estrutura abaixo)
- Caminho da planilha alvo (template ou instância de cliente)

**Saída:**
- Planilha com nomes atualizados em **3 abas em sincronia**:
  - `Matriz` header `D4:AB4` (sem prefixos `Cxx`)
  - `Matriz` legenda `B18:B25` (nome curto sem letra)
  - `Dicionário` colunas `B` (Domínio) e `C` (Capacidade)
  - `Capacidade x Curso` colunas `B` (Capacidade) e `C` (Domínio)
- Comentários (notas) atualizados em cada cell do header com descrição
  rica (objetivo + público + resultado de negócio)
- Subtítulo `A2` da Matriz com bump de versão (`v1` → `v2`)

**Estrutura do JSON map:**

```json
{
  "domain_renames": { "A. AI no dia a dia": "A. IA no dia a dia", ... },
  "domain_legend_renames": { "AI no dia a dia": "IA no dia a dia", ... },
  "capabilities": [
    {
      "code": "C01",
      "old": "Produtividade com Copilot Chat",
      "new": "Produtividade pessoal com IA generativa",
      "note": "Uso diário de IA assistente para tarefas pessoais e profissionais — redação, resumos, brainstorm, análise rápida de documentos. Cobre fundamentos de prompt-engineering e literacia em IA. Público: TODOS os colaboradores expostos a um assistente de IA gratuito (sem licença premium). Resultado: ganho de tempo individual em tarefas cognitivas do dia a dia."
    },
    ...
  ]
}
```

**Princípios das notas de capacidade** (cada cell do header):
- 1 frase: o que a capacidade habilita (objetivo de negócio)
- 1 frase: público típico
- 1 frase: resultado / outcome
- ~250-350 chars total
- PT-BR, jargão de mercado (não Microsoft)
- Sem nomes de produto

**Script:** `scripts/apply_renames.ps1` (idempotente — detecta valor já
renomeado e só atualiza nota; tem retry com backoff para
`RPC_E_CALL_REJECTED`).

### 3. Refresh do catálogo de cursos (Dynamight)

**Quando:** novos cursos entraram no portfólio Dynamight, ou cursos
foram aposentados/marcados como `retired`/`retiring within 60 days`.

**Entrada:**
- Conexão Dynamight (skill `dynamight` disponível)
- Caminho da planilha alvo
- Mapping `código de curso → código de capacidade` (mantido em
  `templates/course_to_capability_map.json` — extensível)

**Saída:**
- Aba `Capacidade x Curso` reescrita com cursos ativos atualizados
- Cursos sem mapeamento → seção `Auditoria` com flag para revisão
  humana
- `Dicionário` coluna E (`Cursos âncora`) refrescada

**Workflow:**

```text
1. Pull do catálogo Dynamight (skill dynamight)
2. Filtrar cursos ativos / private-capable (excluir retired,
   retiring<60d, removed-from-Learn-catalog)
3. Para cada curso, lookup no course_to_capability_map.json
4. Cursos sem mapping → flag para revisão (NÃO inserir
   automaticamente em capacidade arbitrária)
5. Reescrever aba Capacidade x Curso (preservar coluna H Observação)
6. Atualizar aba Auditoria com counts (mapeados / excluídos / sem
   mapeamento)
```

> **Não invente mapping** — se um curso novo não está no JSON, abrir
> uma pergunta para o usuário antes de inserir.

### 4. Pré-preencher matriz com base em insights da conta

**Quando:** sabemos coisas sobre a conta (perfis técnicos, foco de
investimento, prioridades) e queremos enviar uma matriz com
**sugestões iniciais** de marcação para reduzir o esforço do cliente.

**Entrada:**
- Nome da conta
- Insights estruturados (do `account-agent` ou passados pelo usuário):
  - Lista de papéis/áreas conhecidos
  - Capacidades prioritárias (códigos `Cxx`)
  - Anti-priorities (capacidades que **não** se aplicam)

**Saída:**
- Planilha pré-marcada com `x` nas células sugeridas
- **Sempre** com confirmação humana antes de enviar — gerar relatório
  resumo das marcações para revisão

**Workflow:**

```text
1. Consultar account-agent para a conta (perfil técnico, deals
   recentes, MSX activity, conversas no WorkIQ)
2. Mapear insights → códigos Cxx de capacidades
3. Para cada papel/área proposto:
   a. Adicionar linha em Matriz (Time, # pessoas, Papel)
   b. Marcar 'x' nas capacidades Cxx mapeadas (max 5 por papel)
4. Gerar relatório resumo:
   - "Para o papel X, sugerimos as capacidades Y, Z, W porque [motivo]"
5. Apresentar relatório para confirmação humana
6. Se confirmado → salvar; se não → reverter
```

> **Regra de ouro:** matriz pré-preenchida é sugestão. O cliente é o
> dono da decisão final. Sempre comunicar isso explicitamente no
> e-mail de envio.

### 5. Validar matriz devolvida pelo cliente

**Quando:** cliente devolveu a matriz preenchida e queremos validar
antes de gerar o plano.

**Entrada:**
- Caminho da matriz devolvida pelo cliente
- (Opcional) regras de validação custom

**Saída:**
- Relatório de validação com classificação:
  - ✅ **OK** — papéis bem definidos (2-5 marcações)
  - ⚠️ **Atenção** — papéis com 0 marcações (não sabemos o que precisa)
    ou >5 marcações (papel mal definido)
  - ⚠️ **Atenção** — capacidades órfãs (marcadas em todas as linhas →
    indica que talvez não seja diferenciador)
  - ❌ **Erro** — linhas sem `# pessoas` ou sem `Papel/Função`

**Regras de validação fixas:**

```text
- Toda linha com Papel/Função deve ter # pessoas > 0
- Cada papel deve ter entre 2 e 5 capacidades marcadas (3 é o ideal)
- Soma total de pessoas × capacidades = "demanda bruta de assentos"
  (input para o plano)
- Capacidades sem nenhuma marcação na matriz inteira = candidatas a
  remoção do escopo do plano para esse cliente
- Capacidades marcadas em >70% das linhas = candidatas a investigação
  ("é capacidade fundacional pra todo mundo, ou está sendo marcada
  como default sem critério?")
```

### 6. Gerar plano a partir da matriz preenchida

**Quando:** matriz validada → precisa virar plano de capacitação por
experiência de aprendizado, pronto para apresentar ao cliente.

**Entrada:**
- Matriz preenchida e validada (capability 5 OK)
- Catálogo atualizado (capability 3 OK)

**Saída:**
- Estrutura de plano por papel:
  ```
  Papel: Dev. SharePoint Júnior (10 pessoas)
  Capacidades a desenvolver:
    1. C01 - Produtividade pessoal com IA generativa
       → Cursos sugeridos:
         - MS-4023 (Exploração do Microsoft 365 Copilot Chat) — 1.5h, OE
         - MS-4018.S01 (Introdução ao Microsoft 365 Copilot) — 1h, OE
       → Modalidade recomendada: turmas abertas (OE)
    2. C20 - Desenvolvimento de software assistido por IA
       → Cursos sugeridos:
         - GH-300 (Copilot for productive code) — 4h, OE
       → Modalidade recomendada: turmas abertas (OE) ou dedicada
  ```
- Resumo agregado:
  - Demanda total por curso (soma de # pessoas × cursos sugeridos)
  - Sugestão de modalidade por curso (OE / dedicada / SWM) baseado em
    capacidade da turma e demanda
  - Cronograma macro sugerido (3-6 meses tipicamente)

> O resultado deste capability alimenta diretamente o
> `learning-trail-pptx` (deck didático para o cliente) e o
> `tpm-welcome-email` (próxima conversa pós-validação).

## Scripts

Scripts em `scripts/`:

| Script | Capability | Descrição |
|--------|-----------|-----------|
| `apply_renames.ps1` | 2 | Idempotente; aplica `templates/rename_map_v2_market.json` na planilha; sincroniza 3 abas; com retry/backoff para COM busy |
| `provision_matrix.ps1` | 1 | *(criar conforme demanda)* Copia template, preenche A2 com cliente/data |
| `refresh_catalog.ps1` | 3 | *(criar conforme demanda)* Pull Dynamight + reescreve Capacidade x Curso |
| `validate_matrix.ps1` | 5 | *(criar conforme demanda)* Roda regras de validação + gera relatório |
| `generate_plan.ps1` | 6 | *(criar conforme demanda)* Cruza matriz × catálogo → plano por papel |

> Os 4 scripts marcados *(criar conforme demanda)* são esqueletos: o
> `apply_renames.ps1` é o único entregue completo (validado em
> produção). Os outros usam o mesmo padrão — Excel COM com retry,
> backup antes de mexer, idempotência.

### Padrão obrigatório dos scripts

Todo script que mexe na planilha deve:

1. **Backup primeiro** — copiar para `{{WORKDIR_LOCAL}}\skilling-matrix\backup_<timestamp>.xlsx`
2. **Kill leftover Excel** antes de abrir (evita conflito com sessões
   anteriores)
3. **Excel COM** com `Visible=$false`, `DisplayAlerts=$false`,
   `ScreenUpdating=$false`, `EnableEvents=$false`
4. **Retry helper** com backoff exponencial para chamadas COM
   (RPC_E_CALL_REJECTED é normal sob carga)
5. **Try/finally** que sempre faz `Quit()` + `ReleaseComObject` +
   `[GC]::Collect()` + `WaitForPendingFinalizers()`
6. **Logar mudanças** em uma lista `$changes` e devolver no final
7. **Idempotência** — re-rodar deve produzir 0 mudanças se nada mudou

Ver `scripts/apply_renames.ps1` como referência canônica.

## Templates

Em `templates/`:

| Template | Uso |
|----------|-----|
| `rename_map_v2_market.json` | Mapping atual de v2 (nomes de mercado, sem produtos Microsoft, com notas de cell) |
| `course_to_capability_map.json` | *(a criar)* Mapping `código de curso Dynamight` → `código de capacidade Cxx` |
| `validation_rules.json` | *(a criar)* Regras configuráveis de validação (capability 5) |

## Erros e recuperação

Ver [`references/GOTCHAS_EXCEL_COM.md`](references/GOTCHAS_EXCEL_COM.md)
para o catálogo completo de armadilhas. Resumo dos top 5:

| Erro | Causa | Solução |
|------|-------|---------|
| `BadZipFile: File is not a zip file` ao abrir com openpyxl | Planilha tem sensitivity label / IRM (wrapper OLE `D0 CF 11 E0`) | Usar Excel COM, não openpyxl. Sem exceção. |
| `PermissionError: [Errno 13]` ao copiar/abrir | Arquivo aberto em outro processo (Excel desktop, sync OneDrive) | `Get-Process EXCEL` + `Stop-Process -Id` antes de mexer |
| `Call was rejected by callee. (0x80010001)` | Excel COM busy / sob carga | Retry com backoff (200ms × tentativa) — ver `Invoke-WithRetry` em `apply_renames.ps1` |
| `AutoSize property cannot be found on this object` (Comment) | API do `Comment.Shape.TextFrame` muda entre versões | Não usar AutoSize; setar `Width`/`Height` direto, com `try{}catch{}` |
| Arquivo modificado mesmo com erro no script | `Quit()` salvou silenciosamente apesar de `DisplayAlerts=false` | Sempre `wb.Close($false)` explícito antes do `Quit` (no try **e** no catch) |

## Checklist final antes de devolver ao usuário

- [ ] Backup criado em `{{WORKDIR_LOCAL}}\skilling-matrix\backup_<ts>.xlsx`
- [ ] Script rodou sem erro (verifica `$LASTEXITCODE` ou via try/catch)
- [ ] Mudanças listadas explicitamente (não devolver "executou")
- [ ] Sensitivity label preservado (verificar via Excel COM:
  `wb.Permission.Enabled = $true`)
- [ ] OneDrive sync esperou completar (5-10s pós-save) antes de
  apontar usuário para o arquivo no SharePoint
- [ ] Versão do arquivo bumped quando muda significativamente (v1 → v2)
- [ ] Manifest atualizado se for kit completo
  (`Capacitacao_Organizational_Kit/manifest.json`)

## Cross-reference

- **`tpm-welcome-email`** — consome a matriz como anexo no
  e-mail de boas-vindas
- **`capacitacao-kickoff-email`** — pode anexar matriz pré-preenchida
  pós-reunião
- **`learning-trail-pptx`** — consome o output do capability 6 (plano)
  para gerar deck didático
- **`dynamight`** — fonte do refresh do catálogo (capability 3)
- **`account-agent`** — fonte de insights para pré-preencher
  (capability 4)
- **`organizational-skilling-slides`** — visual system aplicado a
  qualquer deck derivado deste plano
- **`my-voice/voice-profile.md`** — para qualquer comunicação sobre a
  matriz com o cliente, seguir Mode A (External Client)

## Pós-execução

Após qualquer operação, lembrar de:
- Sincronizar OneDrive (esperar `🔄` ficar `✅` no overlay)
- Confirmar com o usuário que o arquivo no SharePoint reflete a versão
  local (URL: `https://microsoft-my.sharepoint.com/:x:/p/{{USER_ALIAS}}/...`)
- Se o usuário tiver a planilha aberta em Excel desktop ou web → pedir
  para fechar e reabrir antes de validar visualmente (cache do cliente
  pode estar stale)
