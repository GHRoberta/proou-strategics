# provision_matrix.ps1
# ====================
# Capability 1: Provisionar nova matriz para uma conta.
#
# Copia o template canônico para a pasta da conta,
# preenche A2 com cliente + data + versão, e renomeia o arquivo
# para o padrão da conta. Preserva sensitivity label.

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$ClientName,

    [Parameter(Mandatory=$false)]
    [string]$DestinationFolder = "",

    [Parameter(Mandatory=$false)]
    [string]$TemplatePath = "{{WORKDIR}}\Capacitacao_Organizational_Kit\Capacitacao_Organizational_Capability_Matrix_v1.xlsx",

    [Parameter(Mandatory=$false)]
    [string]$Version = "v1"
)

$ErrorActionPreference = "Stop"

# Default destination: FY26\<Conta>\
if ([string]::IsNullOrWhiteSpace($DestinationFolder)) {
    $DestinationFolder = "{{USERPROFILE}}\OneDrive - Microsoft\FY26\$ClientName"
}

if (-not (Test-Path $TemplatePath)) {
    throw "Template não encontrado: $TemplatePath"
}

if (-not (Test-Path $DestinationFolder)) {
    New-Item -ItemType Directory -Path $DestinationFolder -Force | Out-Null
    Write-Host "Pasta criada: $DestinationFolder" -ForegroundColor Green
}

# ASCII-safe filename token (sem acentos / espaços / caracteres especiais)
$clientToken = ($ClientName -replace '[^\w\d-]+','_').Trim('_')
$destFileName = "Capacitacao_Organizational_Capability_Matrix_${clientToken}_${Version}.xlsx"
$destPath = Join-Path $DestinationFolder $destFileName

if (Test-Path $destPath) {
    throw "Arquivo destino já existe: $destPath  -- escolha outra versão ou remova o anterior"
}

Write-Host "Copiando template..." -ForegroundColor Cyan
Write-Host "  De:    $TemplatePath"
Write-Host "  Para:  $destPath"
Copy-Item -Path $TemplatePath -Destination $destPath -Force

# Kill leftover Excel
Get-Process -Name EXCEL -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.Id -Force }
Start-Sleep -Seconds 2

# Open via Excel COM and stamp A2 with client + date
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false
$excel.ScreenUpdating = $false
$excel.EnableEvents = $false

$wb = $null
try {
    $wb = $excel.Workbooks.Open($destPath, 0, $false)
    $ws = $wb.Worksheets.Item("Matriz")
    $today = Get-Date -Format "dd/MM/yyyy"
    $newSubtitle = "Cliente: $ClientName  ·  Data: $today  ·  $Version (25 capacidades em 8 domínios)"
    $ws.Cells.Item(2, 1).Value2 = $newSubtitle

    Write-Host "`nA2 atualizado: $newSubtitle" -ForegroundColor Green

    $wb.Save()
    $wb.Close($false)
    $wb = $null
} catch {
    Write-Host "ERRO: $_" -ForegroundColor Red
    if ($wb -ne $null) {
        try { $wb.Close($false) } catch {}
    }
    throw
} finally {
    try { $excel.ScreenUpdating = $true } catch {}
    try { $excel.EnableEvents = $true } catch {}
    try { $excel.Quit() } catch {}
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
}

Start-Sleep -Seconds 1
Write-Host "`n=== PROVISIONADO ===" -ForegroundColor Cyan
$info = Get-Item $destPath
Write-Host "Arquivo: $($info.FullName)"
Write-Host "Tamanho: $($info.Length) bytes"
Write-Host "Data:    $($info.LastWriteTime)"
Write-Host "`nPróximos passos sugeridos:"
Write-Host "  1. Abrir o arquivo no Excel para revisão visual"
Write-Host "  2. Se necessário, pré-preencher via Capability 4 (account-agent insights)"
Write-Host "  3. Anexar no e-mail de boas-vindas via skill tpm-welcome-email"
