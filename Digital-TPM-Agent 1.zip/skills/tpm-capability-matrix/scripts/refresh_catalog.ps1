# refresh_catalog.ps1
# ===================
# Capability 3: Refresh do catálogo de cursos a partir do Dynamight.
#
# Esqueleto — implementar conforme Capability 3 do SKILL.md.

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$MatrixPath,

    [Parameter(Mandatory=$false)]
    [string]$CourseToCapMapPath = "$PSScriptRoot\..\templates\course_to_capability_map.json"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $MatrixPath)) {
    throw "Matriz não encontrada: $MatrixPath"
}

# TODO — implementar:
#   1. Pull do catalogo Dynamight (usar skill dynamight via subagent ou
#      MCP tool quando disponivel; fallback: ler dynamight_catalog_status.json
#      do diretorio de trabalho mais recente)
#   2. Filtrar cursos:
#      - status == "active" OR "private-capable"
#      - excluir retired, retiring within 60d, removed-from-Learn-catalog
#   3. Carregar $CourseToCapMapPath -> hashtable [course_code] -> [capability_code Cxx]
#   4. Para cada curso:
#      Se está no map -> adicionar/atualizar linha em "Capacidade x Curso"
#      Senão -> flag para revisão (NÃO inserir automaticamente)
#   5. Reescrever aba "Capacidade x Curso" preservando coluna H (Observação)
#   6. Atualizar "Dicionário" coluna E (Cursos âncora) com cursos novos
#   7. Atualizar "Auditoria":
#      - Total catalogo / mapeados / excluidos / sem mapeamento
#   8. Salvar via wb.Save() preservando sensitivity label

throw "TODO: implementar refresh_catalog per SKILL.md Capability 3. Dependência: skill dynamight ativa."
