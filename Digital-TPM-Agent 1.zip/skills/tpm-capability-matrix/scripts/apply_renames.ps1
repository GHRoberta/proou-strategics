# Idempotent rename script with COM retry logic.

param(
    [string]$SourcePath = "{{WORKDIR}}\Capacitacao_Organizational_Kit\Capacitacao_Organizational_Capability_Matrix_v1.xlsx",
    [string]$MapPath    = "{{WORKDIR_LOCAL}}\skilling-matrix\rename_map.json"
)

$ErrorActionPreference = "Stop"
$map = Get-Content $MapPath -Raw -Encoding UTF8 | ConvertFrom-Json

# Build lookups
$capByOld  = @{}
$capByNew  = @{}
$capByCode = @{}
foreach ($cap in $map.capabilities) {
    $capByOld[$cap.old]   = $cap
    $capByNew[$cap.new]   = $cap
    $capByCode[$cap.code] = $cap
}

# Domain hashtables (PSCustomObject -> hashtable)
$domFull = @{}
$map.domain_renames.PSObject.Properties | ForEach-Object { $domFull[$_.Name] = $_.Value }
$domLegend = @{}
$map.domain_legend_renames.PSObject.Properties | ForEach-Object { $domLegend[$_.Name] = $_.Value }

Write-Host "Loaded $($map.capabilities.Count) capability renames" -ForegroundColor Cyan
Write-Host "Loaded $($domFull.Count) domain (full) renames" -ForegroundColor Cyan
Write-Host "Loaded $($domLegend.Count) domain (legend) renames" -ForegroundColor Cyan

# COM retry helper
function Invoke-WithRetry {
    param([scriptblock]$Script, [int]$MaxAttempts = 5)
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        try { return & $Script }
        catch {
            if ($i -eq $MaxAttempts -or $_.Exception.Message -notmatch 'rejected|busy|0x80010001') { throw }
            Start-Sleep -Milliseconds (200 * $i)
        }
    }
}

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false
$excel.ScreenUpdating = $false
$excel.EnableEvents = $false

$changes = @()
$wb = $null
try {
    $wb = $excel.Workbooks.Open($SourcePath, 0, $false)

    # ==========================================
    # 1) MATRIZ HEADER (D4:AB4) — idempotent
    # ==========================================
    $ws = $wb.Worksheets.Item("Matriz")
    Write-Host "`n--- Sheet: Matriz (header D4:AB4) ---" -ForegroundColor Yellow
    for ($c = 4; $c -le 28; $c++) {
        $cell = $ws.Cells.Item(4, $c)
        $val = [string]$cell.Value2
        if ([string]::IsNullOrWhiteSpace($val)) { continue }
        $valTrim = $val.Trim()

        $cap = $null
        # Pattern A: "C01 · Old Name"
        if ($valTrim -match '^(C\d{2})\s*[·\.\-]\s*(.+)$') {
            $code = $matches[1]
            $cap = $capByCode[$code]
        }
        # Pattern B: already a known new name
        elseif ($capByNew.ContainsKey($valTrim)) {
            $cap = $capByNew[$valTrim]
        }
        # Pattern C: a known old name without code prefix
        elseif ($capByOld.ContainsKey($valTrim)) {
            $cap = $capByOld[$valTrim]
        }

        if ($cap -ne $null) {
            if ($valTrim -ne $cap.new) {
                Invoke-WithRetry { $cell.Value2 = $cap.new }
                $changes += "Matriz!$($cell.Address()): '$valTrim' -> '$($cap.new)'"
            }
            # Refresh comment
            Invoke-WithRetry {
                if ($cell.Comment -ne $null) { $cell.Comment.Delete() }
            }
            $cmt = Invoke-WithRetry { $cell.AddComment($cap.note) }
            Invoke-WithRetry {
                try { $cmt.Shape.Width = 320 } catch {}
                try { $cmt.Shape.Height = 200 } catch {}
                $cmt.Visible = $false
            }
            $changes += "Matriz!$($cell.Address()): note refreshed ($($cap.code))"
        } else {
            Write-Warning "  Could not resolve header at $($cell.Address()): $valTrim"
        }
    }

    # ==========================================
    # 2) MATRIZ LEGEND (B18:B25)
    # ==========================================
    Write-Host "`n--- Sheet: Matriz (legend B18:B25) ---" -ForegroundColor Yellow
    for ($r = 18; $r -le 25; $r++) {
        $cell = $ws.Cells.Item($r, 2)
        $val = [string]$cell.Value2
        if ([string]::IsNullOrWhiteSpace($val)) { continue }
        $valTrim = $val.Trim()
        if ($domLegend.ContainsKey($valTrim)) {
            $newVal = $domLegend[$valTrim]
            if ($newVal -ne $valTrim) {
                Invoke-WithRetry { $cell.Value2 = $newVal }
                $changes += "Matriz!$($cell.Address()): '$valTrim' -> '$newVal'"
            }
        } elseif ($domLegend.Values -contains $valTrim) {
            # Already renamed — skip
        } else {
            Write-Warning "  Unmapped legend at $($cell.Address()): $valTrim"
        }
    }

    # ==========================================
    # 3) DICIONARIO sheet (B = Domínio full, C = Capacidade)
    # ==========================================
    $wsD = $wb.Worksheets.Item("Dicionário")
    Write-Host "`n--- Sheet: Dicionário (B2:C26) ---" -ForegroundColor Yellow
    $rowsD = $wsD.UsedRange.Rows.Count
    for ($r = 2; $r -le $rowsD; $r++) {
        $domCell = $wsD.Cells.Item($r, 2)
        $domVal = [string]$domCell.Value2
        if (-not [string]::IsNullOrWhiteSpace($domVal)) {
            $domTrim = $domVal.Trim()
            if ($domFull.ContainsKey($domTrim)) {
                $newDom = $domFull[$domTrim]
                if ($newDom -ne $domTrim) {
                    Invoke-WithRetry { $domCell.Value2 = $newDom }
                    $changes += "Dicionário!$($domCell.Address()): '$domTrim' -> '$newDom'"
                }
            } elseif ($domFull.Values -notcontains $domTrim) {
                Write-Warning "  Unmapped domain at $($domCell.Address()): $domTrim"
            }
        }
        $capCell = $wsD.Cells.Item($r, 3)
        $capVal = [string]$capCell.Value2
        if (-not [string]::IsNullOrWhiteSpace($capVal)) {
            $capTrim = $capVal.Trim()
            $cap = $null
            if ($capByOld.ContainsKey($capTrim)) { $cap = $capByOld[$capTrim] }
            elseif ($capByNew.ContainsKey($capTrim)) { $cap = $capByNew[$capTrim] }
            if ($cap -ne $null -and $capTrim -ne $cap.new) {
                Invoke-WithRetry { $capCell.Value2 = $cap.new }
                $changes += "Dicionário!$($capCell.Address()): '$capTrim' -> '$($cap.new)'"
            } elseif ($cap -eq $null) {
                Write-Warning "  Unmapped capability at $($capCell.Address()): $capTrim"
            }
        }
    }

    # ==========================================
    # 4) "Capacidade x Curso" sheet (B = Capacidade, C = Domínio)
    # ==========================================
    $wsCxC = $wb.Worksheets.Item("Capacidade x Curso")
    Write-Host "`n--- Sheet: Capacidade x Curso ---" -ForegroundColor Yellow
    $rowsCxC = $wsCxC.UsedRange.Rows.Count
    $cxcCount = 0
    for ($r = 2; $r -le $rowsCxC; $r++) {
        $capCell = $wsCxC.Cells.Item($r, 2)
        $capVal = [string]$capCell.Value2
        if (-not [string]::IsNullOrWhiteSpace($capVal)) {
            $capTrim = $capVal.Trim()
            $cap = $null
            if ($capByOld.ContainsKey($capTrim)) { $cap = $capByOld[$capTrim] }
            elseif ($capByNew.ContainsKey($capTrim)) { $cap = $capByNew[$capTrim] }
            if ($cap -ne $null -and $capTrim -ne $cap.new) {
                Invoke-WithRetry { $capCell.Value2 = $cap.new }
                $cxcCount++
            }
        }
        $domCell = $wsCxC.Cells.Item($r, 3)
        $domVal = [string]$domCell.Value2
        if (-not [string]::IsNullOrWhiteSpace($domVal)) {
            $domTrim = $domVal.Trim()
            if ($domFull.ContainsKey($domTrim)) {
                $newDom = $domFull[$domTrim]
                if ($newDom -ne $domTrim) {
                    Invoke-WithRetry { $domCell.Value2 = $newDom }
                    $cxcCount++
                }
            }
        }
    }
    $changes += "Capacidade x Curso: $cxcCount cell updates"

    # ==========================================
    # 5) v1 -> v2 marker
    # ==========================================
    $sub = [string]$ws.Cells.Item(2, 1).Value2
    if ($sub -match '\bv1\b') {
        Invoke-WithRetry { $ws.Cells.Item(2, 1).Value2 = ($sub -replace '\bv1\b', 'v2') }
        $changes += "Matriz!A2: bumped v1 -> v2"
    }

    # SAVE
    Write-Host "`nSaving..." -ForegroundColor Cyan
    Invoke-WithRetry { $wb.Save() }
    $wb.Close($false)
    $wb = $null
    Write-Host "Saved." -ForegroundColor Green
} catch {
    Write-Host "ERROR: $_" -ForegroundColor Red
    if ($wb -ne $null) {
        try { $wb.Close($false) } catch {}
    }
    throw
} finally {
    try { $excel.EnableEvents = $true } catch {}
    try { $excel.ScreenUpdating = $true } catch {}
    try { $excel.Quit() } catch {}
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

Write-Host "`n=== CHANGE LOG ($($changes.Count) changes) ===" -ForegroundColor Cyan
$changes | ForEach-Object { Write-Host "  $_" }
