# generate_plan.ps1
# =================
# Capability 6: Gerar plano a partir da matriz preenchida.
#
# Esqueleto — implementar conforme Capability 6 do SKILL.md.

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$MatrixPath,

    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "$([System.IO.Path]::GetDirectoryName($MatrixPath))\Plano_Capacitacao.json"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $MatrixPath)) {
    throw "Matriz não encontrada: $MatrixPath"
}

# TODO — implementar:
#   1. Validar matriz primeiro (chamar validate_matrix.ps1; abortar se ERRO)
#   2. Abrir via Excel COM
#   3. Ler aba 'Capacidade x Curso' inteira -> hashtable [capacidade] -> [cursos]
#   4. Ler aba 'Matriz' D5:AB?, mapear (papel + #pessoas) -> [capacidades marcadas]
#   5. Para cada papel:
#      Para cada capacidade marcada:
#        Pegar lista de cursos âncora
#        Estimar modalidade recomendada (OE / dedicada / SWM):
#           - Se demanda (#pessoas) >= 50 e curso suporta SWM -> SWM
#           - Senão se #pessoas >= 15 -> dedicada
#           - Senão -> OE
#   6. Agregar demanda por curso (soma de #pessoas para todas as ocorrencias)
#   7. Gerar cronograma macro sugerido (3-6 meses)
#   8. Salvar JSON em $OutputPath
#   9. Devolver objeto PowerShell para uso programatico (alimenta learning-trail-pptx)

throw "TODO: implementar generate_plan per SKILL.md Capability 6. Considerar dependência: chamar validate_matrix antes."
