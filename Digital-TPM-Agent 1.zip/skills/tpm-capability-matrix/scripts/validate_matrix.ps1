# validate_matrix.ps1
# ===================
# Capability 5: Validar matriz devolvida pelo cliente.
#
# Esqueleto — implementar conforme regras da seção Capability 5 do SKILL.md.

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$MatrixPath,

    [Parameter(Mandatory=$false)]
    [string]$RulesPath = "$PSScriptRoot\..\templates\validation_rules.json",

    [Parameter(Mandatory=$false)]
    [int]$MinMarksPerRole = 2,

    [Parameter(Mandatory=$false)]
    [int]$MaxMarksPerRole = 5
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $MatrixPath)) {
    throw "Matriz não encontrada: $MatrixPath"
}

# TODO — implementar:
#   1. Abrir via Excel COM (preserva sensitivity label)
#   2. Ler aba 'Matriz' D5:AB? para mapear (papel) -> [capacidades marcadas]
#      a. Linha de papel = A:Time, B:#Pessoas, C:Papel/Funcao
#      b. Marcacao = 'x' / 'X' em qualquer cell de D em diante
#   3. Aplicar regras:
#      - Toda linha com Papel deve ter # pessoas > 0
#      - Cada papel: $MinMarksPerRole <= count <= $MaxMarksPerRole
#      - Capacidades sem nenhuma marcação = candidatas a remover
#      - Capacidades marcadas em > 70% das linhas = revisar
#   4. Gerar relatorio classificado: OK / WARN / ERRO
#      - Salvar em $MatrixPath.validation.txt
#      - Retornar object PowerShell para uso programatico

throw "TODO: implementar validate_matrix per SKILL.md Capability 5. Use scripts/apply_renames.ps1 como referência de padrão Excel COM."
