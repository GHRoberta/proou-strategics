# Excel COM Gotchas — Capacitação Capability Matrix

Catálogo de armadilhas técnicas descobertas em produção ao operar a
matriz via PowerShell + Excel COM. Lê obrigatoriamente antes de
escrever qualquer script novo.

---

## 1. Sensitivity label / IRM faz openpyxl falhar

### Sintoma

```
zipfile.BadZipFile: File is not a zip file
```

…ao tentar abrir a matriz com `openpyxl.load_workbook()`.

### Causa

A planilha tem **sensitivity label** aplicado (Microsoft Information
Protection). Quando isso acontece, o `.xlsx` é encapsulado em um
container OLE compound document (magic bytes `D0 CF 11 E0`), em vez do
ZIP nativo `.xlsx` (magic `50 4B`). Bibliotecas como openpyxl,
`pandas.read_excel(engine='openpyxl')`, `xlrd` e similares **não
lidam** com esse wrapper.

### Solução

**Excel COM. Sem exceção.** Não tem workaround com biblioteca pura
Python. Mesmo `Workbook.SaveAs(format=51)` (xlOpenXMLWorkbook) salva
de volta com wrapper OLE se o label estiver preservado — o que é o
comportamento desejado.

```powershell
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false
$wb = $excel.Workbooks.Open($path)
# manipular $wb.Worksheets...
$wb.Save()
$wb.Close($false)
$excel.Quit()
```

### Como detectar

```powershell
$bytes = [System.IO.File]::ReadAllBytes($path)[0..3]
$magic = ($bytes | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
# "50 4B 03 04" = ZIP nativo (sem label)
# "D0 CF 11 E0" = OLE wrapper (com label)
```

---

## 2. OneDrive ReparsePoint causa o mesmo erro

### Sintoma

```
PermissionError: [Errno 13] Permission denied
```

…ou o `BadZipFile` mesmo após copiar o arquivo, em pastas
sincronizadas pelo OneDrive.

### Causa

O OneDrive marca arquivos cloud-only com `ReparsePoint` attribute. O
arquivo "existe" no filesystem, mas o conteúdo está apenas no cloud.
Algumas bibliotecas leem o reparse point header em vez de baixar o
arquivo real.

### Solução

```powershell
# 1. Verificar se é reparse point
$attrs = (Get-Item $path).Attributes
if ($attrs -match 'ReparsePoint') {
    # 2. Forçar download via Get-Content (lê 1 byte para acionar download)
    Get-Content $path -TotalCount 1 -Encoding Byte | Out-Null
    Start-Sleep -Seconds 3
}
# 3. Verificar de novo
$attrs2 = (Get-Item $path).Attributes
# Deve ter perdido o ReparsePoint
```

Ou, mais robusto, copiar para fora da pasta sincronizada antes de
manipular:

```powershell
$tempPath = "{{WORKDIR_LOCAL}}\skilling-matrix\working_$(Get-Date -Format 'yyyyMMddHHmmss').xlsx"
Copy-Item -Path $sourcePath -Destination $tempPath -Force
# manipular $tempPath
# depois: Copy-Item $tempPath $sourcePath -Force
```

---

## 3. RPC_E_CALL_REJECTED ao chamar Excel COM em sequência rápida

### Sintoma

```
Call was rejected by callee. (0x80010001 (RPC_E_CALL_REJECTED))
```

…aparece aleatoriamente após várias chamadas COM consecutivas, mesmo
sem erro lógico no código.

### Causa

Excel COM é **single-threaded** internamente. Quando o automation
client (PowerShell) emite chamadas mais rápido do que o server
(EXCEL.EXE) consegue processar, o server rejeita a chamada com esse
HRESULT em vez de enfileirar.

### Solução

Wrapper de retry com backoff exponencial:

```powershell
function Invoke-WithRetry {
    param([scriptblock]$Script, [int]$MaxAttempts = 5)
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        try { return & $Script }
        catch {
            if ($i -eq $MaxAttempts -or $_.Exception.Message -notmatch 'rejected|busy|0x80010001') {
                throw
            }
            Start-Sleep -Milliseconds (200 * $i)
        }
    }
}

# Uso
Invoke-WithRetry { $cell.Value2 = $newValue }
Invoke-WithRetry { $wb.Save() }
```

Outras boas práticas que reduzem a frequência:

```powershell
$excel.ScreenUpdating = $false
$excel.EnableEvents = $false
$excel.DisplayAlerts = $false
$excel.AutomationSecurity = 3  # msoAutomationSecurityForceDisable (macros bloqueadas)
```

---

## 4. Comment.Shape.TextFrame.AutoSize não existe

### Sintoma

```
The property 'AutoSize' cannot be found on this object.
```

…ao tentar configurar o tamanho do balão de comentário.

### Causa

A API do `Comment.Shape.TextFrame` mudou entre versões do Excel. Em
algumas versões, `AutoSize` está em `TextFrame2` (não `TextFrame`); em
outras, foi removido.

### Solução

Não usar `AutoSize`. Setar `Width` / `Height` diretamente no `Shape`,
com `try{}catch{}` defensivo:

```powershell
$cmt = $cell.AddComment($noteText)
try { $cmt.Shape.Width = 320 } catch {}
try { $cmt.Shape.Height = 200 } catch {}
$cmt.Visible = $false
```

---

## 5. Quit() salva silenciosamente após erro

### Sintoma

Script falha no meio com exception → workbook é fechado mas o **arquivo
no disco mostra mudanças parciais** (mesmo com `DisplayAlerts=$false`).

### Causa

Quando `Workbook` está modificado e `Application.Quit()` é chamado,
algumas versões do Excel salvam silenciosamente apesar do
`DisplayAlerts=$false`. O comportamento varia por versão e por se há
sensitivity label aplicado.

### Solução

Sempre fechar o workbook **explicitamente** antes do Quit, em ambos os
caminhos (try **e** catch):

```powershell
$wb = $null
try {
    $wb = $excel.Workbooks.Open($path, 0, $false)
    # ... manipulação ...
    $wb.Save()
    $wb.Close($false)
    $wb = $null
}
catch {
    if ($wb -ne $null) {
        try { $wb.Close($false) } catch {}  # discard changes
    }
    throw
}
finally {
    try { $excel.Quit() } catch {}
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
```

`Close($false)` = "discard changes". Esse é o comportamento que
queremos no catch — manter o arquivo no estado anterior.

---

## 6. File handle persiste após Quit (próxima Open falha)

### Sintoma

```
Permission denied
```

…na próxima tentativa de abrir o arquivo, mesmo após Quit no script
anterior.

### Causa

O processo `EXCEL.EXE` foi finalizado, mas o file handle ainda não foi
liberado pelo Windows. O .NET COM Runtime mantém o handle até a próxima
GC.

### Solução

Forçar GC + finalizers + pequeno wait:

```powershell
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
[GC]::Collect()
[GC]::WaitForPendingFinalizers()
[GC]::Collect()  # segunda passada para os objetos com finalizer
Start-Sleep -Seconds 1
```

Se ainda assim persistir, verificar `Get-Process -Name EXCEL` —
processos órfãos podem precisar de `Stop-Process -Id <pid>`.

---

## 7. Workbook.FileFormat = 51 não garante .xlsx puro

### Sintoma

```powershell
$wb.SaveAs($path, 51)  # 51 = xlOpenXMLWorkbook
# arquivo salvo ainda tem magic bytes D0 CF 11 E0 (OLE)
```

### Causa

Quando o workbook tem sensitivity label / IRM, o Excel **sempre**
salva no wrapper OLE, independentemente do FileFormat solicitado. É by
design (o label requer encryption, que requer o wrapper).

### Solução

Aceitar o wrapper OLE quando o label estiver presente. Não tentar
"corrigir" — você quebraria a proteção do conteúdo.

Para confirmar se tem label aplicado:

```powershell
Write-Host "Permission.Enabled: $($wb.Permission.Enabled)"
Write-Host "HasPassword: $($wb.HasPassword)"
$label = $wb.SensitivityLabel.GetLabel()
Write-Host "Label name: $($label.Name)"
Write-Host "Label id: $($label.LabelId)"
Write-Host "IsEncrypted: $($label.IsEncrypted)"
```

---

## 8. Range.Item indexing é 1-based, não 0-based

### Sintoma

Off-by-one em loops:

```powershell
for ($r = 0; $r -lt $ws.UsedRange.Rows.Count; $r++) {
    $val = $ws.Cells.Item($r, 1).Value2  # ERRO: $r=0 é inválido
}
```

### Causa

Excel COM herda da convenção VBA: índices começam em 1, não em 0.

### Solução

Sempre comece em 1:

```powershell
$rows = $ws.UsedRange.Rows.Count
for ($r = 1; $r -le $rows; $r++) {
    $val = $ws.Cells.Item($r, 1).Value2
}
```

---

## 9. PSCustomObject.PSObject.Properties.Count tem comportamento confuso

### Sintoma

```powershell
$json = ConvertFrom-Json $jsonString
Write-Host $json.domain_renames.PSObject.Properties.Count
# Output: "1 1 1 1 1 1 1 1" (8x "1")
```

…em vez do count real (8).

### Causa

`PSCustomObject` não tem `.Count` direto na lista de Properties. Cada
Property tem `.Count = 1`, e a saída encadeia.

### Solução

Converter para hashtable primeiro:

```powershell
$ht = @{}
$json.domain_renames.PSObject.Properties | ForEach-Object { $ht[$_.Name] = $_.Value }
Write-Host $ht.Count  # 8 ✓
```

---

## 10. Cells com merged formatação herdam Value2 só da top-left

### Sintoma

`Cells.Item($r, $c).Value2` retorna `$null` para uma cell visualmente
preenchida.

### Causa

A cell faz parte de um merged range. Apenas a top-left tem o Value2;
as outras retornam `$null`.

### Solução

Se a planilha usa merged cells em headers, sempre testar via
`MergeCells` antes:

```powershell
$cell = $ws.Cells.Item($r, $c)
if ($cell.MergeCells) {
    $val = $cell.MergeArea.Cells.Item(1, 1).Value2  # top-left do merge
} else {
    $val = $cell.Value2
}
```

A matriz canônica **não usa merged cells nas áreas operacionais** —
apenas em A1 (título) e A2 (subtítulo). Mas vale a guarda defensiva.

---

## Referência rápida — arquivo modelo

Ver `scripts/apply_renames.ps1` para um exemplo completo aplicando
todos os padrões acima:
- COM com flags de performance
- Retry com backoff
- Backup-aware
- Try/catch/finally robustos
- Idempotência
- GC explícito ao final
