# MSXI 2.0 — Microsoft Copilot End to End Reporting

**Report ID:** `b2e20794-a0bf-436e-ae98-e73b05ad365b`
**Base URL:** `https://msxinsights.microsoft.com/User/report/b2e20794-a0bf-436e-ae98-e73b05ad365b`
**Mapped:** 2026-05-05 (3 of 10 tabs visually captured before MSXI auth expired)

This is the canonical SME&C dashboard for **Microsoft Copilot End to End** intelligence: covers Copilot Chat + Agents, M365 Copilot pipeline / usage / scrum / NPSA, Copilot Studio (E2E / Consumption / Billed / Usage), and the SME&C Fast & Focused motion.

Default landing fiscal period: **FY26**. Confidential\Internal Only.

---

## How it's built

- Hosted in **MSX Insights 2.0** portal (`msxinsights.microsoft.com`) — outer SPA controls layout, filters, tabs.
- Each tab embeds a **Power BI** report inside an `<iframe>`.
- Tab navigation uses `button[role="tab"]` elements; the URL updates with `?reportTab=<slug>` per tab — so tabs are **deeplinkable**.
- A persistent **Global Filter Panel** (top of page) cascades filters across the active tab.
- A right-edge "Filtros" rail lets you pin/edit applied filters.
- Every tab header has: **Release Notes** | **Data Dictionary** | **Refresh Date** icons (top-right) and a **Reset Slicers** button (right of filters).
- Auth: requires Microsoft corporate sign-in. Sessions time out → a Portuguese **"Entrada exigida / Entrar"** modal appears → click "Entrar" to refresh.

---

## Tabs

| # | Tab name | Purpose |
|---|----------|---------|
| 1 | **Copilot Chat + Agents + Copilot Studio E2E** | E2E executive summary across all Copilot motions |
| 2 | **M365 Copilot** | M365 Copilot pipeline / acceleration |
| 3 | **M365 Copilot Usage** | Active users, usage trends, benchmarks |
| 4 | **M365 Copilot Scrum** | Scrum / forecast recommendation / qualified pipeline view |
| 5 | **M365 Copilot NPSA** | Net New Paid Seats Added (NPSA) tracking |
| 6 | **Copilot Studio End to End Pipeline** | Full Studio funnel |
| 7 | **Copilot Studio Consumption Pipeline** | Consumption-only Studio deals |
| 8 | **Copilot Studio Billed Pipeline** | Billed pipeline snapshot |
| 9 | **Copilot Studio Usage** | Studio adoption / consumption metrics |
| 10 | **SME&C Copilot Fast & Focused** | F&F sprint/play tracking for SME&C |

**Deeplink pattern:** `https://msxinsights.microsoft.com/User/report/b2e20794-a0bf-436e-ae98-e73b05ad365b?reportTab=<slug>` — slugs captured per tab when mapping (see `dashboard_map.json`). Tab 4 (Scrum) slug observed: `41dc11e00b0295043473`.

---

## Tab 1 — Copilot Chat + Agents + Copilot Studio E2E

**Layout:** 6 KPI columns (cards stacked vertically per motion):

| Wall To Wall | Copilot Chat All Up | M365 Copilot | Copilot Chat Unpaid | Agent | Copilot Studio All Up |
|---|---|---|---|---|---|
| Wall to Wall (count) | MAU | Actual Seats | MAU | MAU | Credit Pack Utilization% |
| Penetration % | Penetration % | IW Penetration % | Penetration % | Agent Allup MAU% | MAL Penetration % |
| W2W MoM (count) | MAU MoM (count) | Seats MoM % | MAU MoM% | MAU MoM% | Customers Growth MoM% |
| W2W MoM% | MAU MoM% | QP Seats | Chat QP Users | Agent QP Users | Copilot Studio QP$ |

**Sample values (mapped 2026-05-05, no filters applied):** Wall to Wall 3.1 Mi · 27.2% pen · MoM −46.12 Mil (−1.4%) | Chat All Up MAU 3.0 Mi · 26.4% · −50.1 Mil (−1.6%) | M365 Copilot 354.1 Mil seats · 4.7% IW pen · +5.8% MoM · QP 553.1 Mil | Chat Unpaid MAU 2.8 Mi · 24.1% · −2.3% · QP 1.2 Mi | Agent MAU 141.9 Mil · 4.6% · +13% · 108.8 Mil QP | Studio Util 16.9% · MAL Pen 28.1% · −2% · QP $4.9 Mi.

**Cross-link:** "Link to Copilot Chat & Agent Pipeline" → drill into pipeline view.

**Filters (22 slicers):** Fiscal Period · TZ Area · Market Area · MSA Area · Field Segment · ATU · Sales Territory · AE · AI WF SSP · Customer Cohort · Customer Targeting · BusinessType · BusinessType (Pipeline) · MAL Flag · HQ/DS Flag · Is EDU · Pricing Level · Engagement Milestone Category · Milestone Status · Milestone Status Reason · M365 Copilot Product · Q4 Accelerator.

---

## Tab 2 — M365 Copilot

**Section: M365 Copilot Pipeline Acceleration** with toggles:
- **To Budget** ↔ **To CFO Forecast** (target benchmark)
- **Select Metrics Group** dropdown (Default / etc.)
- Group-by buttons: **TimeZone | Market | MSA | Segment | ATU | SalesTerritory**
- Note: "EOP Seat Ambition Target & NPSA Ambition Target are sliced to Fiscal Quarter only."

**Filters (16):** Fiscal Period (default FY26) · TZ Area · Market Area · MSA Area · ATU · Field Segment · Is Edu · MAL Flag (default Yes) · HQ/DS flag · Major Expiration · BusinessType · BusinessType (Pipeline) · Customer Targeting · ISD Flag · M365 Copilot Product · Q4 Accelerator.

---

## Tab 3 — M365 Copilot Usage

**Main visual: Hierarchical usage table** (drillable: TZ → Market → Industry):

| Column | Meaning |
|---|---|
| #Account | Number of accounts |
| Actual Seats (Closed Month) | Seats sold by close of last month |
| *Actual Seats (Current Month) | Live seat count (asterisk = in-flight) |
| PAU (from Usage Data) | Paid Active Users (telemetry-based) |
| Enabled Users | Users with license enabled |
| Enabled % | Enabled / Seats |
| MAU | Monthly Active Users |
| MAU % (vs Enabled) | MAU as share of Enabled |
| MAU % (vs PAU) | MAU as share of PAU |
| WAU | Weekly Active Users |
| WAU % (vs Enabled) | WAU / Enabled |
| WAU % (vs PAU) | WAU / PAU |
| Qualified Pipe$ | Qualified pipeline $ |
| UnQualified Open $ | Open unqualified $ |
| All Pipe (Open) | Total open pipe $ |

**Sample row (Americas, FY26, no filters):** 3,790 accts · 253,527 seats CM · 244,232 enabled (96%) · 225,537 MAU (92% vs Enabled / 89% vs PAU) · 193,696 WAU (79%/76%) · Qualified Pipe $58.361 Mi.
**BRA row:** 579 accts · 147,715 seats · 139,390 enabled (94%) · 127,635 MAU (92%/86%) · 107,636 WAU (77%/73%) · QP $31.696 Mi · All Open Pipe $31.702 Mi.

**Group-by buttons:** TimeZone | Market | MSA | Segment | Industry.
**Color coding:** Cyan-highlighted % cells flag values inside benchmark range.
**Filters (12):** Fiscal Period · TZ · Market · MSA · ATU · Field Segment · EDU (default No) · MAL Flag (default Yes) · HQ/DS Flag · Major Expiration · Customer Targeting · ISD Flag · Q4 Accelerator. Plus an "Indicador" KPI selector and "Benchmark selector".

---

## Tab 4 — M365 Copilot Scrum (filters captured)

**Filters:** Fiscal Period · TZ · Market · MSA · Field Segment · ATU Group · Is Edu · MAL Flag · HQ/DS Flag · **MSX Status** · **Forecast Recommendation** · BusinessType · **Qualified Pipeline Flag** · ISD Flag · Q4 Accelerator. Adds an "Indicador" KPI selector and Customer Targeting.

The Scrum-specific slicers (MSX Status / Forecast Recommendation / Qualified Pipeline Flag) make this the right tab for **forecast scrub conversations** — which deals are committed, which need de-risking, which have stale forecast.

---

## Tabs 5–10 — Mapping pending

NPSA, Studio E2E / Consumption / Billed / Usage, and SME&C F&F structure not yet captured (initial mapping run had auth expire mid-pass). To complete: re-auth in Edge → run `python scripts/map_dashboard.py` → updates `dashboard_map.json`.

---

## Common filter slicers (Global Filter Panel)

Most tabs share these slicers (varies slightly per tab):

- **Time:** Fiscal Period (defaults to FY26)
- **Geo:** TZ / Area, Market / Area, MSA / Area, ATU (Area Territory Unit) / ATU Group, Sales Territory
- **People:** AE (Account Executive), AI WF SSP
- **Segmentation:** Field Segment, Customer Cohort, Customer Targeting, BusinessType, BusinessType (Pipeline)
- **Flags:** MAL Flag (defaults Yes), Is EDU, ISD Flag, HQ / DS Flag, Q4 Accelerator, Major Expiration
- **Pricing / Stage:** Pricing Level, Engagement Milestone Category, MSX Status, Forecast Recommendation, Qualified Pipeline Flag
- **Product (M365 Copilot tab):** M365 Copilot Product
- **Usage tabs:** Indicador (KPI selector), Benchmark selector

---

## Navigation patterns (when scripting)

The dashboard renders **two tab bars** — one hidden (preload) and one visible. Always click the **last** matching `button[role="tab"]`:

```js
const els = [...document.querySelectorAll('button[role="tab"]')]
  .filter(e => e.getAttribute('name') === TAB_NAME);
els[els.length - 1].click();
```

Visuals live inside the iframe — find the right frame by querying `visual-container-modern, .visualContainer`:

```python
for f in page.frames:
    cnt = await f.evaluate("document.querySelectorAll('visual-container-modern, .visualContainer').length")
    if cnt > 0: pbi_frame = f; break
```

After clicking a tab, **wait ~8s** for Power BI to re-render before extracting data.

---

## Reusable scripts (in this skill)

- `scripts/map_dashboard.py` — clicks each tab, captures slug + visuals → writes `dashboard_map.json`. Supports `--tab "<name>"` for single-tab runs.
- `scripts/state_check.py` — quick health check (auth state, modal detection, screenshot)

**Run prerequisite:** Edge must be running with CDP on port 9222 AND the dashboard tab must be open and signed in.

```powershell
python ~/.copilot/skills/msxi-copilot-e2e/scripts/map_dashboard.py
```

---

## Known gotchas

1. **Two tab bars** in DOM — one hidden, one visible. Pick the last match.
2. **Background page throttling** — Edge throttles inactive tabs; always `bring_to_front()` before evaluating scripts.
3. **Auth expiration** — `Entrada exigida` modal silently replaces the report. Detect with `document.querySelector('[role="dialog"]')` or check tab count == 0.
4. **Iframe is not powerbi.com** — MSXI proxies the embed; match by `visualContainer` count, not by URL host.
5. **First load is slow** — initial PBI render can take 30-60s. Subsequent tab switches: ~7-9s.
6. **Visual aria-labels are localized** — many show as "Imagem" / "Navegação na página" in PT-BR. Use the `text` field (innerText) for actual KPI values.
7. **Persistent banner**: "Having trouble loading this report or its data? Use **MSXI Assist** to quickly troubleshoot." appears at top — safe to dismiss.

---

## Sample questions this dashboard answers

- "What's BRA's M365 Copilot WAU% vs Enabled this month?" → Tab 3, group by Market → BRA row.
- "How is Copilot Studio Credit Pack utilization trending?" → Tab 1, Studio All Up column.
- "Which deals does the forecast recommend re-scoring?" → Tab 4, filter by Forecast Recommendation.
- "What's our M365 Copilot pipeline gap to CFO Forecast for Brazil?" → Tab 2, toggle "To CFO Forecast", group by Market = BRA.
- "How many Net New Paid Seats added in FY26 Q3?" → Tab 5 (NPSA).
- "What's the Copilot Studio billed pipeline by ATU?" → Tab 8, group by ATU.

---

## Run notes / automation TODOs

- 2026-06-08: TPID slicer search in dropdown did not respond to normal Playwright `fill()`/typing; setting `input.searchInput.value` and dispatching `input`/`keyup`/`change` exposed `[TPID] - [CLIENTE]`. After selecting it on the Scrum page, MSXI/Power Apps auth expired (`Entrada exigida`, then `chrome-error://chromewebdata/` at `login.microsoftonline.com`). Future automation should recover/re-open MSXI before continuing and avoid clicking embedded Power Apps surfaces while selecting slicers.
