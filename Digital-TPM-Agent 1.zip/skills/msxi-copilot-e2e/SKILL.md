---
name: msxi-copilot-e2e
description: >
  Navigates the MSXI 2.0 "Microsoft Copilot End to End Reporting" dashboard
  (msxinsights.microsoft.com) via Edge CDP automation. Answers questions
  about M365 Copilot pipeline, usage, scrum/forecast, NPSA, Copilot Chat +
  Agents, and Copilot Studio (E2E / Consumption / Billed / Usage) at
  TZ/Market/MSA/ATU/Industry grain. Captures KPIs, applies filters,
  switches tabs, exports visual data. Use whenever the user asks about the
  Copilot E2E dashboard, MSXI Copilot reporting, M365 Copilot
  usage/MAU/WAU/PAU, NPSA, Copilot Studio billed/consumption pipeline,
  forecast scrum, Wall to Wall, IW/MAL penetration, qualified pipe for
  Copilot, or wants numbers from the MSXI Copilot dashboard. Triggers:
  MSXI dashboard, Copilot dashboard, Copilot E2E, M365 Copilot usage, MAU
  WAU PAU, NPSA, Copilot Studio pipeline, Wall to Wall, Copilot scrum,
  forecast scrum Copilot, qualified pipe Copilot, dashboard MSXI Copilot,
  navegar dashboard Copilot, número do dashboard Copilot.
---

# MSXI 2.0 — Microsoft Copilot End to End Reporting

Operates the MSXI Copilot E2E dashboard via Edge CDP + Playwright. The full structural reference (10 tabs, KPIs per tab, filter slicers, gotchas) lives in [references/DASHBOARD_GUIDE.md](references/DASHBOARD_GUIDE.md) — load it on demand when answering structural questions or planning a multi-tab pull.

**Report ID:** `b2e20794-a0bf-436e-ae98-e73b05ad365b`
**Base URL:** `https://msxinsights.microsoft.com/User/report/b2e20794-a0bf-436e-ae98-e73b05ad365b`
**Default landing:** Fiscal Period FY26. Confidential\Internal Only.

## Capabilities

| Capability | Description |
|---|---|
| **Tab navigation** | Switch between the 10 dashboard tabs and capture per-tab KPI structure |
| **State / health check** | Detect MSXI auth modal ("Entrada exigida"), iframe count, current tab slug |
| **Visual extraction** | Pull titles, aria-labels, inner text and positions from every Power BI visual on the active tab |
| **Filter inspection** | Read the active Global Filter Panel slicers (Fiscal Period, TZ/Market/MSA/ATU, Field Segment, MAL Flag, etc.) |
| **Screenshots** | Capture per-tab PNGs for embedding in briefings/digests |
| **Deeplink lookup** | Map tab name → `?reportTab=<slug>` for direct sharing |

## Prerequisites

- **Microsoft Edge** running with `--remote-debugging-port=9222` (`msedge.exe --remote-debugging-port=9222`)
- **Dashboard tab open and signed in** at the base URL above
- **Python 3.10+** with `playwright` (`pip install playwright && playwright install chromium`)
- Scripts at: `~/.copilot/skills/msxi-copilot-e2e/scripts/`

If Edge is not on CDP or auth has expired (modal "Entrada exigida"), stop and ask the user to fix it before retrying — see Error Handling below.

## The 10 tabs

1. **Copilot Chat + Agents + Copilot Studio E2E** — executive 6-column summary (Wall To Wall · Chat All Up · M365 Copilot · Chat Unpaid · Agent · Studio All Up)
2. **M365 Copilot** — pipeline acceleration (To Budget vs To CFO Forecast)
3. **M365 Copilot Usage** — hierarchical Seats/Enabled/MAU/WAU/PAU/Pipe$ table
4. **M365 Copilot Scrum** — forecast scrub (MSX Status · Forecast Recommendation · Qualified Pipeline Flag)
5. **M365 Copilot NPSA** — Net New Paid Seats Added
6. **Copilot Studio End to End Pipeline**
7. **Copilot Studio Consumption Pipeline**
8. **Copilot Studio Billed Pipeline**
9. **Copilot Studio Usage**
10. **SME&C Copilot Fast & Focused**

Full per-tab KPI definitions, sample values, and filter slicers in [references/DASHBOARD_GUIDE.md § Tabs](references/DASHBOARD_GUIDE.md#tabs).

## Workflow: answer a question from the dashboard

### Step 1 — Pick the right tab

Use the routing table in [references/DASHBOARD_GUIDE.md § Question routing](references/DASHBOARD_GUIDE.md#sample-questions-this-dashboard-answers). Quick rules:

| User asks about… | Tab |
|---|---|
| Wall to Wall, Chat MAU, Agent MAU, Studio Credit Pack | 1 (E2E summary) |
| M365 Copilot pipeline gap to budget/CFO forecast | 2 |
| MAU%, WAU%, PAU, Enabled %, by Market/MSA | 3 (Usage) |
| Forecast recommendation, qualified pipe flag | 4 (Scrum) |
| NPSA, Net New Paid Seats Added | 5 |
| Copilot Studio pipeline by stage / consumption / billed | 6, 7, 8 |
| Studio adoption metrics | 9 |
| F&F sprint progress | 10 |

### Step 2 — Health check before automation

```bash
python ~/.copilot/skills/msxi-copilot-e2e/scripts/state_check.py
```

Outputs current URL, tab count, iframe count, auth modal text (if any), and a screenshot at `state_now.png`. **If `tabs == 0` or modal text contains "Entrada exigida" → stop and ask the user to sign in.**

### Step 3 — Run the mapper / extractor

To capture **all 10 tabs** at once (writes `dashboard_map.json`):

```bash
python ~/.copilot/skills/msxi-copilot-e2e/scripts/map_dashboard.py
```

To capture **a single tab** (faster, no nav round-trips):

```bash
python ~/.copilot/skills/msxi-copilot-e2e/scripts/map_dashboard.py --tab "M365 Copilot Usage"
```

Output JSON shape: `{ tab_name: { slug, visuals: [{title, aria, text, x, y, w, h}] } }`. Use `text` (innerText) for actual KPI values — `aria-label` is localized to PT-BR ("Imagem", "Navegação na página") and rarely useful.

### Step 4 — Read & report

- Pick visuals by `title` first, fall back to `aria` or `text` substring match.
- Sort by `(y, x)` for reading order (already done by the script).
- For tabular visuals (Tab 3 Usage table), the entire table sits in one `text` field — split on whitespace patterns or take a screenshot.
- When citing numbers, include the **filter context** active at extraction time (Fiscal Period, Market, MAL Flag, etc.) — defaults are FY26 / MAL=Yes / EDU=No.

## Filters (Global Filter Panel)

The 22 common slicers and which tabs use which subsets are documented in [references/DASHBOARD_GUIDE.md § Common filter slicers](references/DASHBOARD_GUIDE.md#common-filter-slicers-global-filter-panel).

**Defaults (no user filters applied):** Fiscal Period = FY26 · MAL Flag = Yes · EDU = No.

To programmatically apply a filter, the cleanest path today is to **navigate by URL with the captured `reportTab` slug + ask the user to set the filter in UI**, then re-run the extractor. Direct URL-encoded filter injection is not yet implemented (Power BI hash routing is opaque from outside the iframe).

## Error Handling

| Symptom | Likely cause | Action |
|---|---|---|
| `tabs: 0` and modal text "Entrada exigida" | MSXI session expired | Tell user to click "Entrar" in the Edge modal, then retry |
| `iframeCount: 0` | Page redirected away from dashboard | Re-navigate Edge to the base URL |
| `tab not found` for a known tab name | Wrong tab bar (preload vs visible) | Already handled — script picks `els[els.length - 1]` |
| Visual `text` empty | Power BI still rendering | Increase wait from 8s to 15s in `map_dashboard.py` |
| Screenshot timeout | Heavy fonts / slow render | Use viewport-only screenshot (`full_page=False` is default) |
| Cannot find PBI iframe | Outer SPA loaded but iframe blocked | Reload the page in Edge, wait 60s for first render |

Detailed gotchas in [references/DASHBOARD_GUIDE.md § Known gotchas](references/DASHBOARD_GUIDE.md#known-gotchas).

## Output Format

When answering a question, structure the reply as:

```
**Source:** MSXI 2.0 — Microsoft Copilot E2E · Tab N (<Tab name>) · slug=<short>
**Filters active:** Fiscal Period=FY26, MAL Flag=Yes, [other if changed]
**Captured:** <YYYY-MM-DD HH:MM>

<key numbers, formatted as plain text or compact table>

**Cross-checks / caveats:** <if any — e.g. "this excludes EDU; MAL filter on">
```

For multi-tab answers (e.g., a Copilot business review), produce one section per tab in this same format.

## Examples

| User prompt | Action |
|---|---|
| "Qual o WAU% do Brasil em M365 Copilot?" | state_check → if OK → `map_dashboard.py --tab "M365 Copilot Usage"` → grep BRA row in returned text → cite WAU% (vs Enabled) and (vs PAU) |
| "Como está nossa penetração Wall to Wall?" | Tab 1 → cite Wall to Wall count + Penetration % + MoM% |
| "Qual nosso gap pro CFO Forecast em M365 Copilot?" | Tell user to toggle "To CFO Forecast" in Tab 2 UI → screenshot → narrate |
| "Quais deals o forecast recomenda re-scoring?" | Tab 4 → user filters by Forecast Recommendation in UI → extract table |
| "Resume o dashboard Copilot pra reunião amanhã" | Run full `map_dashboard.py` → produce one paragraph per tab using the Output Format above |

## References

- [DASHBOARD_GUIDE.md](references/DASHBOARD_GUIDE.md) — full per-tab structure, KPIs, sample values, filter slicers, gotchas
- Scripts: `scripts/map_dashboard.py`, `scripts/state_check.py`

## Post-Run Reflection

After each invocation, briefly note (in your working response, not the user-facing answer):

1. **Trigger fit** — did the user phrase match this skill's triggers? If not, what new trigger phrase to add?
2. **Auth state** — did MSXI auth hold for the whole session, or expire mid-run?
3. **Coverage gaps** — was a tab needed that isn't yet structurally documented in DASHBOARD_GUIDE.md (Tabs 5–10 are placeholders)? If yes, run a one-shot capture and update the guide.
4. **Filter friction** — did the user need a filter we couldn't apply programmatically? Note for future automation work.

If any of #2–#4 surfaced, append a short note to `~/.copilot/skills/msxi-copilot-e2e/references/DASHBOARD_GUIDE.md` (or open a TODO) so the next invocation is better.
