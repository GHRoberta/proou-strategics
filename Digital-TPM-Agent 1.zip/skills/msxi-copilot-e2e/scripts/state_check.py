"""MSXI Copilot E2E health check.

Verifies that:
  - Edge is on CDP port 9222
  - The dashboard tab is open
  - There's no auth modal blocking
  - The Power BI iframe is rendering visuals

Outputs JSON to stdout and writes a screenshot to state_now.png in the script dir.
"""
import asyncio
import json
import sys
from pathlib import Path

from playwright.async_api import async_playwright

REPORT_ID = "b2e20794-a0bf-436e-ae98-e73b05ad365b"


async def main():
    out = {"ok": False, "checks": {}}
    try:
        async with async_playwright() as p:
            browser = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
            out["checks"]["cdp"] = "ok"
            ctx = browser.contexts[0]
            page = next(
                (pg for pg in ctx.pages
                 if "msxinsights.microsoft.com" in pg.url and REPORT_ID in pg.url),
                None,
            )
            if not page:
                out["checks"]["dashboard_tab"] = "missing"
                print(json.dumps(out, indent=2))
                sys.exit(1)
            out["checks"]["dashboard_tab"] = "ok"
            await page.bring_to_front()
            await asyncio.sleep(2)

            info = await page.evaluate(
                """() => ({
                  url: location.href,
                  title: document.title,
                  tabCount: document.querySelectorAll('button[role="tab"]').length,
                  iframeCount: document.querySelectorAll('iframe').length,
                  modals: [...document.querySelectorAll('[role="dialog"], .ms-Dialog, .ms-Modal')]
                            .map(m => (m.innerText || '').substring(0, 200)),
                })"""
            )
            out["url"] = info["url"]
            out["title"] = info["title"]
            out["checks"]["tabs"] = info["tabCount"]
            out["checks"]["iframes"] = info["iframeCount"]
            out["checks"]["modals"] = info["modals"]

            # Auth state
            modal_text = " ".join(info["modals"]).lower()
            if "entrada exigida" in modal_text or "sign in" in modal_text or "entrar" in modal_text:
                out["checks"]["auth"] = "EXPIRED — sign in via Edge modal"
            elif info["tabCount"] == 0:
                out["checks"]["auth"] = "UNKNOWN — no tabs, possibly auth or load issue"
            else:
                out["checks"]["auth"] = "ok"

            # Iframe with visuals
            visual_count = 0
            for f in page.frames:
                try:
                    c = await f.evaluate(
                        "document.querySelectorAll('visual-container-modern, .visualContainer').length"
                    )
                    visual_count = max(visual_count, c)
                except Exception:
                    pass
            out["checks"]["visuals_in_iframe"] = visual_count

            png_path = Path(__file__).parent / "state_now.png"
            try:
                await page.screenshot(path=str(png_path), timeout=20000)
                out["screenshot"] = str(png_path)
            except Exception as e:
                out["screenshot_error"] = str(e)

            out["ok"] = (
                out["checks"]["auth"] == "ok"
                and out["checks"]["tabs"] > 0
                and visual_count > 0
            )
            await browser.close()
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
    print(json.dumps(out, indent=2, ensure_ascii=False))
    sys.exit(0 if out["ok"] else 1)


if __name__ == "__main__":
    asyncio.run(main())
