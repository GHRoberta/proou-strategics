"""MSXI Copilot E2E dashboard mapper.

Connects to Edge over CDP (port 9222), navigates the 10 tabs of the MSXI 2.0
Microsoft Copilot End to End Reporting dashboard, and extracts visual structure
+ sample text from the active Power BI iframe per tab.

Usage:
  python map_dashboard.py                       # map all 10 tabs
  python map_dashboard.py --tab "M365 Copilot"  # single tab
  python map_dashboard.py --out C:/path.json    # custom output

Prereqs:
  - Edge running with --remote-debugging-port=9222
  - The MSXI dashboard tab open and signed in
"""
import argparse
import asyncio
import json
import sys
from pathlib import Path

from playwright.async_api import async_playwright

REPORT_ID = "b2e20794-a0bf-436e-ae98-e73b05ad365b"
BASE_URL = f"https://msxinsights.microsoft.com/User/report/{REPORT_ID}"

TABS = [
    "Copilot Chat + Agents + Copilot Studio E2E",
    "M365 Copilot",
    "M365 Copilot Usage",
    "M365 Copilot Scrum",
    "M365 Copilot NPSA",
    "Copilot Studio End to End Pipeline",
    "Copilot Studio Consumption Pipeline",
    "Copilot Studio Billed Pipeline",
    "Copilot Studio Usage",
    "SME&C Copilot Fast & Focused",
]


async def get_pbi_frame(page, retries=6, delay=2.0):
    for _ in range(retries):
        for f in page.frames:
            try:
                cnt = await f.evaluate(
                    "document.querySelectorAll('visual-container-modern, .visualContainer').length"
                )
                if cnt > 0:
                    return f
            except Exception:
                pass
        await asyncio.sleep(delay)
    return None


async def extract_visuals(frame):
    return await frame.evaluate(
        """
        () => {
          const out = [];
          document.querySelectorAll('visual-container-modern, .visualContainer').forEach(el => {
            const r = el.getBoundingClientRect();
            const titleEl = el.querySelector('.preTextWithEllipsis, .titleTextDefault, [class*="title"] text');
            const title = titleEl ? (titleEl.innerText || titleEl.textContent || '').trim() : '';
            const text = (el.innerText || '').replace(/\\s+/g, ' ').trim().substring(0, 800);
            const aria = (el.getAttribute('aria-label') || '').substring(0, 250);
            out.push({
              title, aria, text,
              x: Math.round(r.x), y: Math.round(r.y),
              w: Math.round(r.width), h: Math.round(r.height),
            });
          });
          out.sort((a, b) => (Math.floor(a.y / 40) - Math.floor(b.y / 40)) || (a.x - b.x));
          return out;
        }
        """
    )


async def click_tab(page, name):
    try:
        ok = await page.evaluate(
            """(name) => {
              const els = [...document.querySelectorAll('button[role=\"tab\"]')]
                .filter(e => (e.getAttribute('name') || '').trim() === name
                          || (e.getAttribute('data-content') || '').trim() === name);
              if (!els.length) return false;
              const m = els[els.length - 1];
              m.scrollIntoView({block: 'center'});
              m.click();
              return true;
            }""",
            name,
        )
        if ok:
            return True
    except Exception as e:
        print(f"  eval err: {e}")
    try:
        await page.locator(f'button[role="tab"][name="{name}"]').last.click(force=True, timeout=8000)
        return True
    except Exception as e:
        print(f"  loc err: {e}")
    return False


async def main(only_tab: str | None, out_path: Path):
    targets = [t for t in TABS if (only_tab is None or t == only_tab)]
    if only_tab and not targets:
        print(f"Unknown tab: {only_tab}\nKnown: {TABS}", file=sys.stderr)
        sys.exit(2)

    async with async_playwright() as p:
        browser = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = browser.contexts[0]
        page = next(
            (pg for pg in ctx.pages
             if "msxinsights.microsoft.com" in pg.url and REPORT_ID in pg.url),
            None,
        )
        if not page:
            print("Open the dashboard in Edge first:", BASE_URL, file=sys.stderr)
            sys.exit(1)
        await page.bring_to_front()
        await asyncio.sleep(2)

        results = {}
        for i, tab in enumerate(targets, 1):
            print(f"\n[{i}/{len(targets)}] {tab}")
            await page.bring_to_front()
            if not await click_tab(page, tab):
                print("  click failed (auth modal? page redirected?)")
                continue
            await asyncio.sleep(9)
            slug = page.url.split("reportTab=")[-1] if "reportTab=" in page.url else ""
            frame = await get_pbi_frame(page)
            if not frame:
                print("  no PBI iframe")
                results[tab] = {"slug": slug, "visuals": []}
                continue
            visuals = await extract_visuals(frame)
            results[tab] = {"slug": slug, "visuals": visuals}
            print(f"  slug={slug}  visuals={len(visuals)}")
            for v in visuals[:6]:
                t = v["title"] or v["aria"] or v["text"][:80]
                print(f"    • {t[:140]}")

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\nWrote {out_path} ({sum(len(v['visuals']) for v in results.values())} total visuals)")
        await browser.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--tab", help='Single tab name (exact match), e.g. "M365 Copilot Usage"')
    ap.add_argument(
        "--out",
        default=str(Path(__file__).parent.parent / "dashboard_map.json"),
        help="Output JSON path",
    )
    args = ap.parse_args()
    asyncio.run(main(args.tab, Path(args.out)))
