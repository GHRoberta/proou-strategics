---
name: private-deliveries
description: >
  Query and analyze Private Delivery (PD) and TSPc (Training Services Partner credits)
  requests in Dynamight (ESI Admin Dataverse). Use whenever the user mentions PD,
  Private Delivery, TSPc, AER, Area Empowerment Request, training credits, delivery
  request, pedido de PD/TSPc, créditos de treinamento, or asks how many credits X
  consumed, what PDs are open for customer Y, AERs by TPM Z, course/module info on a
  request, learners per delivery, or budget consumption. Also for requested vs
  approved vs consumed credits, pending approvals, deliveries by month, or full
  course/modality/learner breakdown.
---

# Private Deliveries — PD & TSPc Requests in Dynamight

## When to use this skill

**Triggers:** PD, PDs, private delivery, TSPc, AER, AER-XXXXXX, area empowerment,
pedido de PD, pedido de TSPc, créditos consumidos, créditos aprovados, delivery
request, training request, módulos do pedido, learners por entrega, eficiência de
créditos, participantes por crédito, custo de treinamento, catálogo Dynamight,
rate card, sessões realizadas, custo por sessão.

**ALWAYS use this skill** (do not improvise queries) whenever the user asks to
calculate credits, costs, efficiency, or seats/participants tied to training
sessions or catalog courses — even if the request looks like a generic
"how many credits / how many participants" question.

> 🔒 **EXCLUSIVE SOURCE RULE (user directive, 22-Apr-2026):**
> Whenever a request involves **credits, efficiency, cost per session, or
> training catalog data**, this skill is the **ONLY** authorized source.
> Do **not** consult kanban data, Power BI dashboards, WorkIQ, MSX, web
> search, or any cached/inferred values. Always re-query Dynamight live
> via the patterns below. If Dynamight is unreachable, say so — do not
> fall back to other sources.

Query Private Delivery (PD), TSPc, and Open Enrollment requests stored as
**Area Empowerment Requests (AERs)** in the ESI Admin Dataverse
(`esiadmin.crm.dynamics.com`). Each AER has 1+ product line items that hold
the actual course/module/credit/learner breakdown.

## Critical Distinction: PD vs TSPc

Both budgets are denominated in **credits**, but they come from **separate
pools** and the **credit cost per training is calculated by different rate
cards**. Never conflate them or sum them as a single number.

| Aspect | **PDc** (Private Delivery credits) | **TSPc** (TSP credits) |
|---|---|---|
| **Delivered by** | **MTT** — Microsoft Technical Trainer (Microsoft FTE/v-) in a class **exclusive to one customer** | **TSP** — Training Service Provider (external partner: Green, Fast Lane, ALLYIS, etc.) using credits Microsoft grants the TSP |
| **Capacity unit** | **Credits** | **Credits** |
| **Budget pool** | PDc credits budget | TSPc credits budget |
| **How credit cost is determined** | **PDc Rate Card / Catalog** — each catalog item (course code) has a fixed credit value driven by delivery duration / modality (Standard, Scale, SWM, CIE, exception). | **TPC Rate Card** (inside the **TSPc Training Deck**) — credit cost per course defined by TPC, varies by course family/duration. |
| **Source of truth (rate card)** | `FY26 PDc Rate Card.pptx` (Training Program Manager SP site, updated 1‑Apr‑2026) | `TSPc Training Deck.pptx` / `TSPc Training Deck v2.pptx` (Training Program Manager SP site) |
| **Lifecycle states** | **Committed → Allocated → Utilized** (see PDc FAQ for cancellation / credit-back rules) | Submitted → Approved → Consumed (TSP delivers and reports completion) |
| **`esi_productcategory`** | `Private Delivery` (859270000) | `TSPc` (859270002) |
| **Partner field** | `_esi_trainingservicepartner_value` empty (Microsoft delivers) | `_esi_trainingservicepartner_value` populated (Green, Fast Lane, etc.) |
| **AER header detail** | Often sparse — real data in line items (`esi_areaempowermentrequestproducts`); see `esi_creditvalue` per session | Usually populated (course, learners, month) |
| **Typical use** | Bespoke onboarding, deep-dive workshops, exec briefings, customer-specific deliveries | Scaled enablement via partner ecosystem, multi-class programs |

> ⚠️ **Two-credit-pool rule:** Always state which pool you are reporting on
> (PDc vs TSPc). Never present a combined credit total without explicitly
> noting it is a sum of two distinct budgets.

When the user asks "how many credits…" without qualifying, default to:
1. Show **both** breakdowns side-by-side (PDc and TSPc), or
2. Ask which pool they mean.

### Cost Calculation Rules

When asked **"how many credits will training X cost?"**:

- **For PD (MTT-delivered)** → look up the catalog item / course code in the
  **PDc Rate Card** (`FY26 PDc Rate Card.pptx`). Cost depends on:
  - Catalog item (e.g., AI-103, MS-4023)
  - Delivery duration (1‑day, 2‑day, etc.)
  - Variant: **Standard / Scale / SWM (Scaled Workshop Model) / CIE / exception**
  - The AER stores the resolved cost in `esi_creditvalue` per line item and
    `esi_totalcredits` at the header.

- **For TSPc (TSP-delivered)** → look up the course in the **TPC Rate Card**
  inside the **TSPc Training Deck**. Cost depends on:
  - Course family (MS-4xxx, AZ-xxx, AI-xxx, etc.)
  - Course duration (modules × hours)
  - The AER stores the resolved cost in `esi_requestedtspvqty` and
    `esi_totalcredits` at the header (TSPc requests usually populate header).

**If the rate card is not loaded into context**, do not invent a credit cost.
Say so explicitly and either (a) ask the user to share the relevant rate card,
or (b) read the value from the AER itself if the request already exists in
Dynamight (`esi_totalcredits` / line-item `esi_creditvalue`).

### Authoritative References

| Document | Purpose |
|---|---|
| **TSPc Training Deck (v2)** | TPC Rate Card for TSPc cost per course; TSPc process & lifecycle |
| **FY26 PDc Rate Card.pptx** | PDc cost per catalog item (Standard / Scale / SWM / CIE) |
| **PDc FAQ.docx** | PDc credit lifecycle (Committed → Allocated → Utilized), cancellations, credit-back rules |
| **FY26 Scale Deliveries Guidance.pptx** | Consolidated TSPc + PDc scale delivery rules |

All hosted on the *Training Program Manager* SharePoint site. Use WorkIQ to
fetch on demand if cost lookup is needed and the rate card is not in context.

> Note: `Open Enrollment (OE)` is a third category — public classes. Distinct
> from both PDc and TSPc, but generally out of scope for this skill unless
> explicitly requested.

### TSPc High-Volume / Scale rules (verified FY26 — {{USER_FIRSTNAME}}, 22-Jun-2026)

Use these when sizing/pricing any TSPc request (especially requests to the TPC, [CONTATO]):

- **Class size is SOLELY the TSP's decision.** Per the *TSPc High-Volume Guidance*
  there is **no program limit on learners per turma** ("no program limit;
  TSP-dependent"). **Never question, cap, or flag the people-per-turma** (e.g.,
  500, 1,000) in a request or draft — it is the partner's call. (Reminder: do not
  re-introduce a "confirm feasibility of N/turma" caveat.)
- **Credit cost:** **6 TSPc credits per 4-hour scale session per instructor**;
  a **co-instructor (required for 50+ learners) = 12 credits/session (6 + 6)**.
  **1 modality = 4 contiguous hours.** Source: TSPc Training Deck v2 rate card +
  the Apr-2026 [CLIENTE] request ("6 credits per session per instructor — with
  co-instructor = 12 credits per class"). This is why the May [CLIENTE] batch
  (AER-137526) = 6 courses × 12 = 72 credits.
- **High-volume eligibility varies by course** (confirm via the catalog, not by
  assuming):
  - **High-volume (scale to 500+):** MS-4018 (`.S` up to 500), MS-4023 (up to 600),
    AI-3025 (`.S` 500–600), MS-4019 (`.S`).
  - **NOT high-volume:** **GH-300** (GitHub Copilot — `GH-300.S` caps at ~200),
    **MS-4004** (only use-case variants `.1`–`.10`, small classes).
  - **AI-3018 is NOT a valid ESI catalog code** (no deliveries/line items). When a
    partner lists "Copilot Foundations", the likely real code is **MS-4019**
    (*Get Started with M365 Copilot and Agents*), or MS-4018.S01 / CEUT-4004.
- **Do not invent credit costs.** If a course's tier/eligibility isn't confirmed,
  read it from the catalog/deliveries — or **ask {{USER_FIRSTNAME}}** (per MANDATE M6).

### TSPc Rate Card — Regional (🇧🇷 Brazil = Region 4) (verified FY26 — {{USER_FIRSTNAME}}, 24-Jun-2026)

The **TSPc Rate Card is regional** (5 regions). **Brazil = Region 4.** For a
**standard 1-day private VILT class (10–20 learners) in Brazil the cost is
18 TSPc credits/turma** — NOT 28. (Earlier drafts that used "28/turma" or a
"Tier 3" label were wrong; **18** is the authoritative number for Brazil.)

| Region 4 — 🇧🇷 Brazil · modality | TSPc credits |
|---|---|
| **Per-class 1-day (10–20 learners)** | **18 / turma** |
| Per-class ARB (10–20 learners) | 60 / turma |
| Per-class Copilot (High-Volume / scale) | 6 / session / instructor (×2 w/ co-instructor for ≥50 = 12) |
| Per-learner 1-day | 2 / learner |
| Per-learner ARB | 6 / learner |
| Online Platform | 1 / unit · 18 per customer (10–100 HVS) |

Full 5-region table + scale nuances: see **`swm-hvs-scale-rules` § 5b**. Always
re-open the latest **TSPc Training Deck** rate card before quoting (golden rule)
and record the version/date in the AER comments.

## When to Use

Load this skill when the user wants to:

- **Find** PD or TSPc requests by customer, TPM, TPC, status, month, or AER ID
- **Inspect** a specific AER (AER-XXXXXX) — courses, modules, credits, learners, modality
- **Summarize** how many credits/seats are committed/approved/consumed by customer or by the user
- **Compare** requested vs approved vs consumed credits
- **List** pending approvals or recently submitted requests
- **Cross-reference** between TPM workload and budget allocation

**Do NOT use** for:
- Account-level info (TPID, segment, territory) → use **dynamight** skill
- MSX opportunity data → use **msx-mcp** tools
- Submitting/creating new AERs (this skill is read-only)

## Prerequisites

- **Azure CLI** signed in: `az login` (use `@microsoft.com`)
- **Corporate VPN** connected (required for `esiadmin.crm.dynamics.com`)
- ESI Admin security role ({{USER_FIRSTNAME}} already has it as TPM)

> ⚠️ **Always check VPN first.** Test with:
> `Test-NetConnection esiadmin.crm.dynamics.com -Port 443 -InformationLevel Quiet`
> If `False`, ask the user to connect VPN before running queries.

## Core Entities

| Entity Set | Purpose | Key Fields |
|---|---|---|
| `esi_areaempowermentrequests` | The request header (one per AER) | `esi_aerequestid`, `esi_productcategory`, `esi_areaempowermentstatus`, `esi_quantity`, `esi_totalcredits` |
| `esi_areaempowermentrequestproducts` | Line items (course/modality/credits per session) | `_esi_catalogitem_value`, `_esi_modality_value`, `esi_creditvalue`, `esi_expectednumberoflearners`, `esi_deliverymonth` |
| `esi_trainingentitlements` | Active credit/seat balances (DCS, etc.) | `esi_entitlementid`, `esi_entitlementtype`, `esi_committedqty`, `esi_remainingqty`, `esi_completedqty` |

## Option Set Reference

**`esi_productcategory`** (request type):
| Code | Label |
|---|---|
| 859270000 | Private Delivery |
| 859270001 | Open Enrollment |
| 859270002 | TSPc |

**`esi_areaempowermentstatus`** (lifecycle):
| Code | Label |
|---|---|
| 859270000 | Draft |
| 859270001 | Submitted |
| 859270002 | Approved |
| 859270003 | Rejected |
| 859270004 | Canceled |
| 859270005 | Needs Review |

> Always include `Prefer: odata.include-annotations="OData.Community.Display.V1.FormattedValue"`
> in headers to read labels (e.g., "Private Delivery") instead of raw codes.

## Auth Pattern

```powershell
$token = (az account get-access-token --resource "https://esiadmin.crm.dynamics.com/" --query accessToken -o tsv 2>$null)
$headers = @{
    Authorization     = "Bearer $token"
    Accept            = "application/json"
    "OData-MaxVersion"= "4.0"
    "OData-Version"   = "4.0"
    "Prefer"          = 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
}
$base = "https://esiadmin.crm.dynamics.com/api/data/v9.2"
```

## Resolving "Me" (Current User)

Use the `WhoAmI` function — no email lookup required:

```powershell
$me = (Invoke-RestMethod -Uri "$base/WhoAmI" -Headers $headers -Method Get).UserId
```

Result is the `systemuserid` GUID used to filter as TPM/TPC.

## Workflows

### 1. List My AERs (as TPM)

```powershell
$myid = (Invoke-RestMethod -Uri "$base/WhoAmI" -Headers $headers).UserId
$select = "esi_aerequestid,esi_productcategory,esi_areaempowermentstatus,esi_quantity,esi_totalcredits,esi_approvedcredits,esi_consumedcredits,esi_displaycourses,esi_deliverymonth,createdon"
$expand = "esi_account(`$select=name,esi_tpid)"
$url = "$base/esi_areaempowermentrequests?`$filter=_esi_accounttpm_value eq $myid&`$select=$select&`$expand=$expand&`$orderby=createdon desc&`$top=50"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
$resp.value
```

Filter variants:
- **By TPC instead of TPM:** `_esi_accounttpc_value eq $myid`
- **Open only (not canceled/rejected):** add ` and statecode eq 0`
- **Approved only:** add ` and esi_areaempowermentstatus eq 859270002`
- **PD only:** add ` and esi_productcategory eq 859270000`
- **TSPc only:** add ` and esi_productcategory eq 859270002`
- **Created in last 90 days:** add ` and createdon ge ` + ISO timestamp

### 2. Find AERs by Customer Name

Resolve account first (preferred — exact match), then query:

```powershell
$acct = Invoke-RestMethod -Uri "$base/accounts?`$filter=contains(name,'[CLIENTE]')&`$select=accountid,name,esi_tpid&`$top=5" -Headers $headers
$acctid = $acct.value[0].accountid

$url = "$base/esi_areaempowermentrequests?`$filter=_esi_account_value eq $acctid&`$select=esi_aerequestid,esi_productcategory,esi_areaempowermentstatus,esi_quantity,esi_totalcredits,esi_consumedcredits,esi_displaycourses,esi_deliverymonth&`$orderby=createdon desc&`$top=20"
Invoke-RestMethod -Uri $url -Headers $headers
```

Or single-pass with `$expand` filter (less efficient, but one call):

```powershell
$url = "$base/esi_areaempowermentrequests?`$filter=esi_account/name eq 'BANCO [CLIENTE] SA'&...&`$expand=esi_account(`$select=name)"
```

### 3. Get a Specific AER by ID (Full Detail + Line Items)

```powershell
$aer = "AER-136172"
# 1. Header
$hdr = (Invoke-RestMethod -Uri "$base/esi_areaempowermentrequests?`$filter=esi_aerequestid eq '$aer'&`$expand=esi_account(`$select=name,esi_tpid)&`$top=1" -Headers $headers).value[0]
$aerid = $hdr.esi_areaempowermentrequestid

# 2. Line items (courses/modules)
$items = (Invoke-RestMethod -Uri "$base/esi_areaempowermentrequestproducts?`$filter=_esi_areaempowermentrequest_value eq $aerid" -Headers $headers).value
```

Each line item has FormattedValue annotations for lookups, e.g.:
- `_esi_catalogitem_value@OData.Community.Display.V1.FormattedValue` → `"AI-103"`
- `_esi_modality_value@OData.Community.Display.V1.FormattedValue` → `"VILT"`
- `_esi_primarylanguage_value@OData.Community.Display.V1.FormattedValue` → `"Portuguese"`
- `esi_creditvalue` → credits per session
- `esi_expectednumberoflearners` → learners per session
- `esi_deliverymonth` → e.g., `"May"`

### 4. List AERs by Status (e.g., Pending Approvals)

```powershell
# Submitted but not yet approved (status 859270001 = Submitted)
$url = "$base/esi_areaempowermentrequests?`$filter=esi_areaempowermentstatus eq 859270001 and _esi_accounttpm_value eq $myid&`$select=esi_aerequestid,esi_totalcredits,createdon&`$expand=esi_account(`$select=name)&`$orderby=createdon desc"
```

### 5. Roll Up Credit Consumption (TSPc + PD) for a Period

**⚠️ Use different fields per pool — they don't share columns:**

| Pool | "Credits requested/granted" field | "Credit-back" field |
|---|---|---|
| **TSPc** | `esi_tspvcredits` (primary) or `esi_requestedtspvqty` | `esi_creditbackqty` |
| **PDc** | `esi_totalcredits` / `esi_approvedcredits` / `esi_consumedcredits` | `esi_creditbackqty` |

**Always filter to `Approved` status** (`esi_areaempowermentstatus eq 859270002`)
when computing "consumed" — Rejected and Canceled AERs do not count against
the budget.

**FY26 period:** filter on `_esi_period_value eq <FY26 GUID>`. Resolve once via
`GET esi_periods?$filter=esi_name eq 'FY26'&$select=esi_periodid`.

```powershell
$myid = (Invoke-RestMethod -Uri "$base/WhoAmI" -Headers $headers).UserId
$fy26 = (Invoke-RestMethod -Uri "$base/esi_periods?`$filter=esi_name eq 'FY26'&`$select=esi_periodid" -Headers $headers).value[0].esi_periodid

# TSPc-only, FY26, my AERs, Approved
$filter = "_esi_accounttpm_value eq $myid and esi_productcategory eq 859270002 and _esi_period_value eq $fy26 and esi_areaempowermentstatus eq 859270002"
$select = "esi_aerequestid,esi_tspvcredits,esi_creditbackqty,esi_deliverymonth"
$rows = (Invoke-RestMethod -Uri "$base/esi_areaempowermentrequests?`$filter=$filter&`$select=$select&`$top=200" -Headers $headers).value

$rows | Group-Object 'esi_deliverymonth@OData.Community.Display.V1.FormattedValue' | ForEach-Object {
    [PSCustomObject]@{
        Month   = $_.Name
        AERs    = $_.Count
        Credits = ($_.Group | ForEach-Object { [double]($_.esi_tspvcredits ?? 0) } | Measure-Object -Sum).Sum
    }
}
```

For **PDc roll-ups**, swap `esi_productcategory eq 859270000` and aggregate
`esi_totalcredits` (or `esi_consumedcredits` for actuals).

#### ⚠️ PD requires line-item-driven aggregation (header is sparse)

Validated against FY26 PD data (Apr 2026): **the PD AER header has neither
`esi_deliverymonth` nor `esi_dateutilized` populated.** All meaningful PD
roll-ups must be done from `esi_areaempowermentrequestproducts` (line items).

**PD per-line fields that ARE populated and authoritative:**
| Field | Meaning | Source |
|---|---|---|
| `esi_creditvalue` | Credit cost **per session** — already resolved from the **Dynamight catalog (PDc Rate Card)** at line creation. No external lookup needed. | catalog → AER line |
| `esi_expectednumberoflearners` | Planned seats per session | request |
| `esi_deliverymonth` (option set) | Month each individual session is scheduled in | request |
| `esi_areaempowermentproductstatus` | Per-line lifecycle (Approved / Canceled / Draft) — different lines in same AER can have different statuses | request |

**PD utilization** (no `esi_dateutilized` in header) — apply header completion
ratio uniformly to its lines:
```
compRatio  = esi_consumedcredits / esi_totalcredits   # header-level
util_cred  = line.esi_creditvalue          * compRatio
util_seats = line.esi_expectednumberoflearners * compRatio
```

**PD monthly aggregation pattern** (validated FY26 totals: 80 sessions, 58.0
credits booked, 48.25 utilized, 39 430 planned seats, 29 100 realized):
```powershell
foreach ($a in $pdAers) {
  $li = (Invoke-RestMethod -Uri "$base/esi_areaempowermentrequestproducts?%24filter=_esi_areaempowermentrequest_value eq $($a.esi_areaempowermentrequestid)" -Headers $headers).value
  $tot  = [double]($a.esi_totalcredits ?? 0)
  $cons = [double]($a.esi_consumedcredits ?? 0)
  $cr   = if ($tot -gt 0) { $cons/$tot } else { 0 }
  foreach ($l in $li) {
    $month  = $l.'esi_deliverymonth@OData.Community.Display.V1.FormattedValue'
    $status = $l.'esi_areaempowermentproductstatus@OData.Community.Display.V1.FormattedValue'
    # bucket by $month, sum esi_creditvalue (booked), creditvalue*$cr (used),
    # expectednumberoflearners (plan), expectednumberoflearners*$cr (realized)
  }
}
```

> Do **not** apply the Carlos Q4 carry-over rule to PD. That rule is TSPc-only
> (TSPc has `esi_dateutilized`); PD has no equivalent timestamp at the header.

### 5b. Realized Efficiency — Participants per Credit

Use this for any "how efficient was X" / "participants per credit" / "custo
por aluno" request.

**Methodology (validated against the user's FY26 numbers):**

```
sessions_done       = sessions × (consumed / booked)
seats_per_session   = expected_learners / sessions
realized_learners   = sessions_done × seats_per_session
                    = expected_learners × (consumed / booked)
part_per_credit     = realized_learners / consumed_credits
part_per_session    = realized_learners / sessions_done
```

For **PD**: apply header `consumed/total` ratio at the line level
(see § 5 PD pattern). For **TSPc**: use `esi_completedcredits / esi_tspvcredits`.

**TPM role limitation (confirmed 403):** `esi_classes`, `esi_classparticipants`,
`esi_deliverylearners`, `esi_bookingrequests` are **inaccessible** to the
standard TPM role. The proportional proxy above is one estimate, but **prefer
the engagement entity for actuals** (see next paragraph).

**✅ AUTHORITATIVE actuals source (TSPc only — confirmed 23-Apr-2026):**
`esi_learningpartnerengagements.esi_reportedlearnerscount` is **accessible
to TPM role** and contains the **official reported learners** for each TSPc
AER (matches the FY26 TPM Learner Attainment Power BI report). One engagement
record per AER, FK = `_esi_areaempowermentrequest_value`.

```powershell
# Per-AER reported learners (TSPc)
$ids = $aers | ForEach-Object { "_esi_areaempowermentrequest_value eq $($_.esi_areaempowermentrequestid)" }
$filter = $ids -join ' or '
$engs = (Invoke-RestMethod -Uri "$base/esi_learningpartnerengagements?`$filter=$filter&`$select=_esi_areaempowermentrequest_value,esi_reportedlearnerscount,esi_approvedlearnerscount,esi_completedseats" -Headers $headers).value
# Sum esi_reportedlearnerscount per AER GUID for the official actual.
```

**✅ AUTHORITATIVE actuals source (PD only — confirmed 23-Apr-2026):**
For Private Deliveries, the per-class delivery record is stored as a
**Field Service Work Order** (`msdyn_workorder`, entity set `msdyn_workorders`,
displayed in the UI as "Delivery"). One work order per scheduled class.
**Accessible to TPM role.** Each line item on the AER references its delivery
via `esi_areaempowermentrequestproduct._esi_deliveryid_value` →
`msdyn_workorder.msdyn_workorderid`.

| UI label | Field on `msdyn_workorder` |
|---|---|
| Registration count | `esi_registrationcount` |
| **Check-in count** (= official Trained Learners) | **`esi_attendancecount`** |
| No-Show Count | `esi_noshowcount` |
| Max enrollment | `esi_maxenrollmentcount` |
| Delivery number (UI ID, e.g. 96985) | `msdyn_name` |
| Linked AER | `_esi_areaempowermentrequest_value` |
| Class title | `esi_catalogitemtitle` |
| Class start | `esi_officialstartdatetime` |

```powershell
# Per-AER PD trained learners — sum esi_attendancecount across all work orders
foreach ($a in $pdAers) {
  $wos = (Invoke-RestMethod -Uri "$base/msdyn_workorders?`$filter=_esi_areaempowermentrequest_value eq $($a.esi_areaempowermentrequestid)&`$select=msdyn_name,esi_attendancecount,esi_registrationcount,esi_noshowcount" -Headers $headers).value
  $trained = ($wos | Measure-Object esi_attendancecount -Sum).Sum
  $registered = ($wos | Measure-Object esi_registrationcount -Sum).Sum
  # registered = booked seats (target proxy); trained = actual check-ins
}
```

Validated FY26: [CLIENTE] AER-131056 = 10 deliveries / 331 reg / **256 checked-in**;
[CLIENTE] AER-132923 = 5 deliveries / 353 reg / **251 checked-in**.

**High-volume seat overrides** — ⚠️ **DEPRECATED for the TPM Cockpit dashboard
(user directive 23-Apr-2026).** The cockpit now uses two clean fields:

- `projectedLearners` — planned reach taken from AER `esi_estimatedlearners`
  (header) or `esi_expectednumberoflearners` (line) **as-is, no overrides**.
- `trainedLearners` — official actuals from the FY26 TPM Learner Attainment
  Power BI report, populated only when a card moves to **Done**.

The override table below is retained **only** for offline Q-rollup reconciliation
against Carlos Pardo's LATAM TSP Credits report, where the underlying delivery
counts genuinely require seat assumptions. **Never apply these to the cockpit
or to any cockpit-related calculation.**

| Pattern (Q-rollup only — NOT cockpit) | Default seats per session |
|---|---|
| Scale / high-volume event, no explicit number | 500–1000 |
| [CLIENTE] SP scaled deliveries | 500/session, capped at 80 000 total |
| [CLIENTE] scaled deliveries | 1000/session |
| [CLIENTE], [CLIENTE], [CLIENTE] virtual events ≥ 500 expected | trust line value |
| PD small-group ([CLIENTE], [CLIENTE] enterprise PD) | trust line value (typically 25) |

If used in a Q-rollup, always print the override applied as a footnote.

#### ⚠️ Pending seats (Assentos Solicitados) — canonical source

For **"total potential seats in approved-but-not-yet-realized requests"** (a.k.a.
"Assentos Solicitados"), **use the AER header field `esi_estimatedlearners`
directly**. Do NOT count line items × override — TSPc AERs typically have only
**1 line item per AER** (a single high-volume offer row with
`esi_expectednumberoflearners=0`), and `esi_quantity` on the header is NULL.

The header field `esi_estimatedlearners` is what the TPM submitted as the
expected total reach (e.g., [CLIENTE] AER-136360 = 48 000, [CLIENTE] AER-135547 = 15 000,
[CLIENTE] AER-134787 = 6 000). It is the trustworthy "potential" value.

```powershell
# TSPc pending seats (FY26)
$select = "esi_aerequestid,esi_productcategory,esi_estimatedlearners,esi_tspvcredits,esi_creditbackqty,esi_deliverymonth"
$url = "$base/esi_areaempowermentrequests?`$filter=_esi_accounttpm_value eq $myid and createdon ge 2025-07-01T00:00:00Z and esi_areaempowermentstatus eq 859270002&`$select=$select&`$top=200"
$approved = (Invoke-RestMethod -Uri $url -Headers $headers).value

# TSPc: future delivery month AND not fully credit-backed
$futureMonths = @(192350003,192350004,192350005)  # Apr/May/Jun FY26 Q4
$tspcSeats = ($approved | Where-Object {
  $_.'esi_productcategory@OData.Community.Display.V1.FormattedValue' -eq 'TSPc' `
  -and $_.esi_deliverymonth -in $futureMonths `
  -and -not ([double]$_.esi_tspvcredits -gt 0 -and [double]$_.esi_creditbackqty -ge [double]$_.esi_tspvcredits)
} | Measure-Object esi_estimatedlearners -Sum).Sum
```

For **PD**, `esi_estimatedlearners` is also populated on the header (e.g., [CLIENTE]
AER-135132 = 10 800, [CLIENTE] AER-135125 = 8 400, [CLIENTE] AER-136149 = 5 400). Same rule
applies — prefer the header field; only fall back to summing line item
`esi_expectednumberoflearners` when the header is empty.

#### ⚠️ Quarterly roll-up rule (matches Carlos Pardo's LATAM TSP Credits report)

A simple `esi_deliverymonth IN (Apr, May, Jun)` filter **undercounts Q4**
because it misses **carry-over** — AERs from prior months that were
*utilized* in Q4 still consume Q4 budget.

The correct rule (verified end-to-end against the manager's Q4 report,
matched 2,244 credits exactly):

> An Approved AER counts toward **quarter Q** if **either**:
> - `esi_deliverymonth` ∈ months of Q **OR**
> - `esi_dateutilized` ∈ date range of Q (≥ Q-start, ≤ Q-end)

```powershell
$qStart = [datetime]'2026-04-01'           # Q4 FY26 start
$qEnd   = [datetime]'2026-06-30T23:59:59'  # Q4 FY26 end
$qMonths = @('April','May','June')

$qCounted = $rows | Where-Object {
    $delQ  = $_.'esi_deliverymonth@OData.Community.Display.V1.FormattedValue' -in $qMonths
    $utilQ = $_.esi_dateutilized -and `
             ([datetime]$_.esi_dateutilized -ge $qStart) -and `
             ([datetime]$_.esi_dateutilized -le $qEnd)
    $delQ -or $utilQ
}
$credits = ($qCounted | ForEach-Object { [double]($_.esi_tspvcredits ?? 0) } | Measure-Object -Sum).Sum
```

Excluded from the rule: AERs with `esi_deliverymonth` outside Q **and**
no `esi_dateutilized` set — those are still pipeline against the original
quarter and have not consumed Q's budget.

FY26 fiscal quarter month map (Microsoft FY = Jul→Jun):
| Quarter | Months |
|---|---|
| Q1 | July, August, September |
| Q2 | October, November, December |
| Q3 | January, February, March |
| Q4 | April, May, June |

**Sort by FY-month order** (Jul → Jun) using a hashtable map:

```powershell
$fyOrder = @{ July=1; August=2; September=3; October=4; November=5; December=6;
              January=7; February=8; March=9; April=10; May=11; June=12 }
```

### 6. Active Training Entitlements (Credit Balances)

```powershell
$url = "$base/esi_trainingentitlements?`$filter=statecode eq 0&`$select=esi_entitlementid,esi_entitlementtype,esi_committedqty,esi_allocatedqty,esi_completedqty,esi_remainingqty,esi_entitlementexpirationdate&`$expand=esi_customer(`$select=name)&`$top=50"
```

## Output Format

For lists, present as a table with key fields:

```
| AER | Customer | Type | Status | Credits (Total/Approved/Consumed) | Month |
|-----|----------|------|--------|-----------------------------------|-------|
| AER-136172 | BANCO [CLIENTE] SA | Private Delivery | Approved | 8 / 8 / 8 | May  |
| AER-136360 | [CLIENTE] SP          | TSPc             | Approved | 960 / 960 / 0 | May  |
```

For a single AER detail, use sections:
- **Header** — AER ID, customer (TPID), TPM, TPC, type, status, total credits
- **Line items** — table of course code, modality, language, credits, learners, month
- **Totals** — sum of credits across line items, sum of learners

## Common Field Reference

### `esi_areaempowermentrequest` (request header)

| Field | Meaning |
|---|---|
| `esi_aerequestid` | Public ID (e.g., `AER-136172`) |
| `esi_areaempowermentrequestid` | Internal GUID (use for line item lookup) |
| `esi_productcategory` | PD / TSPc / OE (option set) |
| `esi_areaempowermentstatus` | Draft / Submitted / Approved / Rejected / Canceled / Needs Review |
| `esi_statusstage` | Free-text stage (e.g., "Draft") |
| `esi_quantity` | Number of sessions/modules requested (**PD only** — populated for Private Delivery) |
| `esi_totalcredits` | Total credits the request will cost (**PD**; usually 0/null for TSPc) |
| `esi_approvedcredits` | Credits approved (**PD**; usually 0/null for TSPc) |
| `esi_consumedcredits` | Credits already consumed by completed deliveries (**PD**; usually 0/null for TSPc) |
| `esi_completedcredits` | Credits from completed deliveries (**PD**) |
| `esi_tspvcredits` | **TSPc credits granted by this request** — primary "credits consumed" field for TSPc rollups |
| `esi_requestedtspvqty` | TSPc credits requested (TSPc only; mirrors `esi_tspvcredits` in most cases) |
| `esi_tspvquantity` | TSPc sessions/units (count, not credits) |
| `esi_creditbackqty` | Credits returned (cancellations / partial credit-back) — applies to both pools |
| `esi_displaycourses` | Display string of courses (often empty for PD; see line items) |
| `esi_deliverymonth` | Target delivery month (option set: Jan, Feb, …) |
| `esi_estimatedlearners` | Total learners across all sessions (TSPc; for PD see line items) |
| `esi_requestedtspvqty` | TSPc credits requested (TSPc only) |
| `esi_requestedpdqty` | PD seats requested |
| `esi_requesteddcsqty` | DCS quantity |
| `esi_requestedohqty` | OH quantity |
| `esi_requestorcomments` | Requestor comments |
| `esi_approvercomments` | Approver comments |
| `esi_requestsubmitteddate` | Submission timestamp |
| `_esi_account_value` | Customer account (lookup → `accounts`) |
| `_esi_accounttpm_value` | TPM (lookup → `systemusers`) |
| `_esi_accounttpc_value` | TPC (lookup → `systemusers`) |
| `_esi_solutionarea_value` | Solution area |
| `_esi_modality_value` | Modality (header-level) |
| `_esi_period_value` | Fiscal period (e.g., FY26) |
| `_esi_areabudgetallocation_value` | Budget allocation bucket |
| `_esi_trainingservicepartner_value` | Delivery partner (Green, Fast Lane, etc.) |
| `_esi_offer_value` | Linked offer |
| `_esi_coursecode_value` | Primary course code (when single-course) |
| `_esi_reviewedby_value` | Approver |
| `_esi_allapprover_value` | Final approver |
| `esi_tpid` | TPID (denormalized) |
| `statecode` / `statuscode` | Active=0 / Inactive=1 |

### `esi_areaempowermentrequestproduct` (line items)

| Field | Meaning |
|---|---|
| `_esi_areaempowermentrequest_value` | Parent AER (filter on this) |
| `_esi_catalogitem_value` | Course/Module catalog item (e.g., AI-103, MS-4023) |
| `_esi_product_value` | Product label (e.g., "Private Delivery Credits") |
| `_esi_modality_value` | VILT / ILT / On-Demand |
| `_esi_country_value` | Delivery country |
| `_esi_primarylanguage_value` | Language |
| `_esi_timezone_value` | Time zone |
| `_esi_deliveryid_value` | Delivery ID (links to class) |
| `esi_creditvalue` | Credits per session |
| `esi_expectednumberoflearners` | Learners per session |
| `esi_deliverymonth` | Month for this line item |
| `esi_areaempowermentproductstatus` | Per-line-item status |
| `esi_name` | Display name |

### `esi_trainingentitlement` (credit pool)

| Field | Meaning |
|---|---|
| `esi_entitlementid` | Public ID (e.g., `ENT-59939`) |
| `esi_entitlementtype` | DCS, etc. |
| `esi_committedqty` | Credits/seats committed |
| `esi_allocatedqty` | Credits/seats allocated |
| `esi_completedqty` | Completed |
| `esi_scheduledqty` | Scheduled (in flight) |
| `esi_remainingqty` | Remaining balance |
| `esi_entitlementexpirationdate` | Expiry date |
| `_esi_customer_value` | Customer account |
| `_esi_offerid_value` | Source offer |

## Error Handling

| Error | Cause | Recovery |
|---|---|---|
| Token acquisition fails | Not signed in | `az login` |
| Connection timeout | VPN not connected | Pause and ask user to connect VPN |
| `401 Unauthorized` | Token expired | Re-acquire token |
| `403 Forbidden` on `esi_class` / `esi_bookingrequest` | Standard TPM role lacks privilege | Use AER + line items instead — they cover most needs |
| `Syntax error … contains` on metadata | `contains()` not allowed on EntityDefinitions | Pull full list, filter in PowerShell |
| Empty result for "my AERs" | Logged-in account isn't TPM on any AER | Try `_esi_accounttpc_value` (TPC) instead |
| Lookup field returns GUID only | Missing `Prefer` header for FormattedValues | Add the `Prefer` header |

## Tips

- **Performance:** the `esi_areaempowermentrequests` table is large. Always filter
  by TPM/TPC/account, and use `$select` to limit fields. Default `$top=50`.
- **Lookups:** to display a lookup label, either use `$expand` on the navigation
  property (e.g., `esi_account($select=name)`) or read the
  `_<field>_value@OData.Community.Display.V1.FormattedValue` annotation.
- **Date filters:** use ISO 8601 with `Z` suffix:
  `createdon ge 2026-01-01T00:00:00Z`
- **Counting:** Dataverse caps `$top` at 5000 per page. Use `@odata.nextLink`
  to paginate when totals matter.
- **PD vs TSPc differences:** They are **different delivery models, different
  budgets, different units** — see the "Critical Distinction" section at the
  top of this skill. PD = Microsoft MTT delivers exclusively to one customer
  (seats). TSPc = credits granted to a TSP partner (Green, Fast Lane, etc.) to
  deliver. Never sum them. PD requests often leave `esi_displaycourses`,
  `esi_requestedtspvqty`, and `esi_estimatedlearners` empty — the real data is
  in `esi_areaempowermentrequestproducts` (line items). TSPc requests usually
  populate header-level fields and have `_esi_trainingservicepartner_value` set.
- **Cross-reference with Kanban:** AER IDs from this skill can be matched against
  cards in `kanban_data.js` (e.g., MS-4018, MS-4023) to enrich the dashboard.
- **Catalog credit lookup:** the user's catalog (`esi_products`, `esi_areaproducts`,
  `esi_catalogitems`) is **403 for the TPM role**. Do **NOT** try to JOIN the
  catalog directly — the credit cost is already materialized into the AER line
  item as `esi_creditvalue` when the request is created (it is the rate-card
  value resolved against the catalog at that moment). This is the authoritative
  per-session cost for both PD (PDc Rate Card) and the AER snapshot.
- **PD vs TSPc credit-field cheat sheet:**
  | Concept       | TSPc field                   | PD field                                  |
  |---|---|---|
  | Requested     | `esi_requestedtspvqty`       | sum of line `esi_creditvalue` (any status) |
  | Approved/Booked | `esi_tspvcredits`           | `esi_totalcredits` (header) = sum of approved-line `esi_creditvalue` |
  | Utilized      | `esi_completedcredits`       | `esi_consumedcredits` (header)             |
  | Sessions      | `esi_tspvquantity`           | `esi_quantity` (header) = count of lines   |
  | Seats         | `esi_estimatedlearners` (hdr)| `esi_expectednumberoflearners` (per line)  |
  | Delivery month| `esi_deliverymonth` (hdr)    | `esi_deliverymonth` (per line, **not** hdr)|
  | Util date     | `esi_dateutilized` (hdr)     | **not populated** — use `consumed/total` ratio |

## Post-Run Reflection

After completing a workflow, follow the
[core § 5 Post-Run Reflection](../core/SKILL.md#5-post-run-reflection-continuous-improvement)
protocol — note query patterns that worked, fields that surprised you, and any
new entities discovered.
