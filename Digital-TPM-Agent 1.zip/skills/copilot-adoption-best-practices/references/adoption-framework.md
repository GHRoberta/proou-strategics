# Adoption Framework — combined Microsoft + curated proposta da casa

This file combines three layers of framework:

1. **Microsoft Success Kit 4-phase model** (Get Ready → Onboard & Engage
   → Deliver Impact → Extend & Optimize) — official
2. **Microsoft 3-tier skilling progression** (Foundational →
   Departmental → Advanced) — official, from User Enablement Guide
3. **5-level proficiency funnel** (Capacitado → Amplificado →
   Multiplicador → Construtor → Especialista) — **proposta da casa**
   tailored for Brazilian institutional customers (esp. government)

All three are mutually reinforcing — the Brazilian funnel maps cleanly
onto the official Microsoft layers.

---

## 1. Microsoft Success Kit — 4-phase model

Source: Microsoft 365 Copilot Success Kit, *User Enablement Guide*
(`copilot-success-kit/_cache/extracted/3_UserEnablementGuide_Microsoft365Copilot.pptx`)

| Phase | Primary outcome | Time horizon |
|---|---|---|
| **1. Get ready** | Foundation: governance, sponsorship, scenarios identified, success measures defined, comms plan, license allocation, Champions identified | Pre-launch (T-30 to T-0) |
| **2. Onboard & engage** | Activation: launch comms, kickoff training, first wins, community ignited, leadership modeling | Launch (D0 to W+4) |
| **3. Deliver impact** | Outcomes: power users mature, scenarios scale, KPIs measured, second wave trained, departmental templates | M+1 to M+6 |
| **4. Extend & optimize** | Steady state + innovation: agents built, business processes redesigned, advanced skilling, cross-org sharing, continuous measurement | M+6 onwards |

These phases run **per wave** of users — and large rollouts overlap
phases across waves (e.g., Wave 1 in Phase 3 while Wave 2 in Phase 1).

---

## 2. Microsoft 3-tier skilling progression

Source: Success Kit User Enablement Guide slide 48.

| Tier | Skill focus | Value accrues to | Typical time investment |
|---|---|---|---|
| **Foundational** | Top 10 prompts; daily-use scenarios; build the habit; bookend the day | **Individual** | 2-8 h |
| **Departmental** | Role-specific multi-step scenarios (e.g., "Sales: pre-meeting brief from CRM + Outlook"; "HR: candidate evaluation summary") | **Department** | +6-12 h |
| **Advanced** | Cross-business automation: build agents in Copilot Studio, declarative agents in M365, custom Power Automate flows, prompt libraries shared org-wide | **Organization** | +16-40 h |

Each tier **assumes the prior tier is solid**. Skipping Foundational and
jumping to Advanced is the #1 failure pattern in real implementations.

---

## 3. Champions / Multiplicadores program

Source: Success Kit User Enablement Guide slides 31-64.

### Why Champions

Champions (called **User Enablement Specialists** in official Microsoft
branding) are the single biggest predictor of sustainable adoption.
Microsoft data consistently shows organizations with a structured
champion program reach 2-3x higher monthly active usage than those
without.

### Selection criteria (from Microsoft)

1. **Motivated by helping others**, not by the technology itself
2. **Formally trained** for depth + breadth
3. **Empowered** by leadership to teach peers
4. **Need consistent positive reinforcement** — celebrate publicly
5. **Need a clear execution plan** — not "go figure it out"
6. **Day-to-day duties alongside core job** — Champion is NOT a
   full-time role (typically 10-20% time allocation)
7. **Representation from across the organization** — every business
   unit, geography, persona

### 5 steps to develop the community

1. **Set context** — leadership defines why
2. **Align to organizational objectives** — Champion goals tied to
   business outcomes (not "use Copilot more")
3. **Identify and get buy-in** — both the Champion and their manager
4. **Build the plan, skill them first and often** — Champions get
   trained 4-8 weeks before general user wave
5. **Execute and share feedback** — Champion forum (Viva Engage /
   Teams), monthly debriefs, surfacing scenarios for reuse

### Champion duties (typical mix)

- Run monthly office hours for their org/team
- Maintain a shared prompt library
- Onboard new hires in the org to Copilot
- Surface scenarios / blockers to central program team
- Pilot new Copilot features before general rollout
- Recognize and celebrate peer wins

### Community structure

- **Channel**: Viva Engage community OR Teams group chat (typically
  both — Viva for async knowledge, Teams for real-time help)
- **Cadence**:
  - Monthly Champion all-hands (45-60 min)
  - Weekly office hours per region/persona
  - Quarterly executive-sponsored "wins showcase"
- **Recognition**: badges, intranet spotlight, executive notes —
  recognition matters more than monetary incentives

---

## 4. Brazilian 5-level proficiency funnel — proposta da casa

Standardized vocabulary for Brazilian (esp. government) customers.
Replaces anglicisms (Power User, Champion, Maker, Builder) with
institutional Portuguese.

| Nível | Nome | % população | Investimento (acumulado) | Equivalente Microsoft |
|---|---|---|---|---|
| 1 | **Capacitado** | 100% | 8 h | Foundational / Novice→Explorer |
| 2 | **Amplificado** | 30% | 14 h | Departmental / Explorer |
| 3 | **Multiplicador** | 10% | 22 h | Champion (User Enablement Specialist) |
| 4 | **Construtor** | 5% | 38 h | Maker (Copilot Studio author) |
| 5 | **Especialista** | 1% | 78 h | Advanced (Agent engineer, full-stack) |

> Percentages are **suggested defaults** for a 5.000-license rollout.
> Adjust by customer maturity and BU mix.

### Mapping to Microsoft tiers

```
Microsoft tier      Funil PT-BR
─────────────────   ──────────────────────────────
Foundational        Capacitado
Departmental        Amplificado
Champion program    Multiplicador  ← official Microsoft framework
Advanced (Maker)    Construtor
Advanced (Builder)  Especialista
```

### Outcome statement per level

- **Capacitado** — usa Copilot todo dia em pelo menos 3 cenários
  pessoais (resumir email, gerar resumo de reunião, redigir um
  documento). Já internalizou o "bookend the day".
- **Amplificado** — domina cenários do seu departamento; ensina pares
  informalmente; já experimentou Copilot em Excel/PowerPoint/Outlook
  além do Chat. Time savings >30 min/dia.
- **Multiplicador** — é referência reconhecida na sua área; conduz
  office hours; mantém biblioteca de prompts compartilhada; surface
  scenarios + blockers ao programa central. Formalizado como
  Multiplicador no comitê de IA.
- **Construtor** — constrói agentes declarativos em M365 / Copilot
  Studio; entende limites e governança de dados; entrega pelo menos
  1 agente em produção para sua área.
- **Especialista** — full-stack: Copilot Studio + Power Automate + APIs;
  governança e segurança avançada (Purview, Defender for Cloud Apps);
  entrega agentes complexos cross-business; orienta arquitetura. Pode
  representar a organização em conselhos / fóruns externos.

### Wave design pattern

A typical waved rollout for 5.000 licenses:

```
Onda 0 — Fundação (governança, AI Council, identificação de 30-50 Multiplicadores
        candidatos, sponsorship)
Onda 1 — Multiplicadores capacitados (treinar nível 3 ANTES dos demais,
        T-4 semanas vs general user wave)
Onda 2 — Capacitado geral (100% dos 5k, em ~4 semanas, por departamento)
Onda 3 — Amplificado por departamento (escolha de 30% dos capacitados, 4-6 semanas)
Onda 4 — Construtor (vol baixo, cuidadosamente selecionado, com sponsor)
Onda 5 — Especialista (curadoria, mentoria 1:1, projetos reais)
```

Note: **Onda 1 (Multiplicadores) PRECEDE Onda 2 (Capacitado)** — esse é
um pattern oficial Microsoft. Sem Multiplicadores prontos, a Onda 2 vira
"firehose de treinamento sem suporte" e a adoção esfria após 30 dias.

---

## 5. Communications plan — 4 streams

Adapted from the Success Kit *User Enablement Guide* (slides 21-30) +
*Implementation Summary Guide for Leaders*.

| Stream | Owner | Purpose | Cadence |
|---|---|---|---|
| **Awareness** | Comms team | "Why we are doing this; what's in it for you" | Pre-launch + monthly reminders |
| **Engagement** | Champions + central program | "Here's how to start; here's a scenario for your role; share your win" | Weekly during launch, biweekly steady-state |
| **Measurement** | Program lead | "Here's what we are seeing; here's what's next" | Monthly executive note + quarterly review |
| **Management** | Sponsor | "Leadership uses Copilot in public; here's why" | Continuous — modeling behavior on town halls etc. |

### Minimum viable comms calendar

- **T-30 days** — Awareness: announcement from sponsor; sign-up for
  Multiplicadores wave
- **T-15** — Awareness: licença confirmada, conta como acessar,
  expectation setting
- **T-7** — Engagement: scenario kit by persona, first prompts cheat
  sheet
- **D0 (launch)** — Engagement: live kickoff; first office hours
  scheduled
- **W+1** — Measurement: first usage snapshot to leadership
- **W+4** — Engagement: first Champion debrief, scenario showcase
- **M+3** — Measurement: executive review of outcomes; expand or
  pivot decision
