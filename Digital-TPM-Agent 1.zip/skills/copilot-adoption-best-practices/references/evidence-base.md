# Evidence Base — Microsoft 365 Copilot at Scale

> Use these numbers on customer-facing slides / proposals. **Always
> cite the source URL** on the slide footer.

## 1. AI at work is here — Work Trend Index 2024

**Source:** Microsoft & LinkedIn — Work Trend Index Annual Report,
*"AI at Work Is Here. Now Comes the Hard Part"*, May 2024.
URL: <https://www.microsoft.com/en-us/worklab/work-trend-index/ai-at-work-is-here-now-comes-the-hard-part>

### Adoption is mainstream
- **75%** of knowledge workers now use AI at work
- **46%** of AI users started less than 6 months ago
- AI use **nearly doubled** in the last 6 months of the study

### Self-reported outcomes (general AI users)
- **90%** say AI helps them save time
- **85%** say AI helps them focus on the most important work
- **84%** say AI helps them be more creative
- **83%** say AI helps them enjoy their work more

### Power Users — the disproportionate value pool
"Power Users" = use AI multiple times per week and save 30+ minutes/day.

- **92%** say AI makes their workload more manageable
- **92%** say AI boosts their creativity
- **93%** say AI helps them focus
- **91%** say they feel more motivated
- **91%** say they enjoy work more
- Save **>30 min/day** vs ~10 min/day for average users
- **68%** more likely to experiment with AI than average users
- Behavior signature: **bookend the day with AI** (start AND end of day)

### Skills demand from leaders
- **66%** of leaders say they would **not hire** someone without AI skills
- **71%** say they'd rather hire a **less-experienced** candidate with AI
  skills than a more-experienced one without
- **79%** of leaders agree their company needs to adopt AI to stay
  competitive
- **76%** of professionals say they need AI skills to remain competitive

### Heaviest Teams users — concrete time-saving
- In one month measured, heaviest Teams users summarized **8 hours of
  meetings** with Copilot (≈ 1 full workday recovered)

---

## 2. Functional ROI snapshots (use cautiously, link primary)

### IDC — The Business Opportunity of AI
- IDC reports Microsoft customers see **3.7x average ROI** on Microsoft
  AI investments
- Source: IDC Info Snapshot, sponsored by Microsoft, Nov 2023.
  Search for: "The Business Opportunity of AI — IDC + Microsoft"
- ⚠️ Verify current URL before citation — it has moved.

### Forrester TEI (Total Economic Impact)
- Forrester Consulting commissioned by Microsoft has published a TEI for
  Microsoft 365 Copilot. Commonly cited composite metric: **132% ROI
  over 3 years**, payback < 14 months.
- ⚠️ The TEI URL on adoption.microsoft.com moves; check
  <https://adoption.microsoft.com/en-us/copilot/business-value/> for the
  current download.

### Internal Microsoft case studies
- Use customer stories from
  <https://www.microsoft.com/en-us/customers/?products=Microsoft-365-Copilot>
- High-signal Brazilian examples to cite when available: [CLIENTE],
  Vivo, Stefanini (TBD — log in `customer-examples.md` when verified).

---

## 3. Adoption maturity curve — user typology

From the Work Trend Index 2024, four user types emerge along the
adoption journey:

| Type | Behavior | % of population (approx) |
|---|---|---|
| **Skeptic** | Rarely or never uses AI; doubts value | 25-30% |
| **Novice** | Tried AI once or twice; no habit | 25-30% |
| **Explorer** | Uses AI regularly but only for specific tasks | 25-30% |
| **Power User** | Uses AI multiple times per week across tasks; saves >30 min/day | 10-15% |

> **Adoption insight:** the gap between Novice and Power User is **not
> talent or role** — it is **habit + permission**. The fastest way to
> move someone up the curve is to (a) give them daily-use scenarios
> they care about, (b) bookend their day with AI prompts, and (c) put
> them in a peer group with at least one existing Power User.

---

## 4. Path to Power User — habit design

Microsoft research identified five behaviors that distinguish Power
Users:

1. **Bookend the day** — first 30 min and last 30 min of the day with
   Copilot (catch up / prepare for tomorrow)
2. **Experiment relentlessly** — Power Users are 68% more likely to
   try Copilot for tasks they haven't used it for before
3. **Apply across job functions** — not siloed to email or chat
4. **Make it personal** — invest time in personalizing prompts /
   templates / Copilot Pages
5. **Reflect and share** — talk with colleagues about wins / failures

Use this as the foundation for **Champion behavioral expectations** and
the **promotion-criteria heuristics** between Amplificado and Multiplicador.

---

## 5. Microsoft 365 Copilot — product evidence

(Refreshed periodically — values below from late 2024 / early 2025
public statements.)

- **70%** of Fortune 500 are using Copilot (announced at multiple
  earnings calls)
- Customers report writing-time savings of **30-50%** for document
  creation tasks (Microsoft customer case studies)
- Meeting prep time reduction: **30-40%** with Copilot Recap +
  Intelligent Recap (multiple case studies)

> ⚠️ These figures are public-statement quotes, not laboratory data.
> Always re-verify on adoption.microsoft.com or the Microsoft 365 blog
> before citing in a customer proposal.

---

## 6. Where to find fresh evidence

| Source | Cadence | URL |
|---|---|---|
| Work Trend Index | Annual (May) | <https://www.microsoft.com/worklab/work-trend-index> |
| Customer Stories | Weekly | <https://www.microsoft.com/en-us/customers/?products=Microsoft-365-Copilot> |
| Adoption Hub | Continuous | <https://adoption.microsoft.com/en-us/copilot/> |
| Business Value page | Continuous | <https://adoption.microsoft.com/en-us/copilot/business-value/> |
| Forrester TEI (M365 Copilot) | One-off + refresh | linked from Business Value page above |
| IDC Info Snapshot | One-off + refresh | search "IDC Microsoft AI ROI" |
| MSW Newsroom Brazil | Continuous | <https://news.microsoft.com/source/latin-america/> |

When refreshing this file, run a quick check on each link, update the
"as of" stamps, and add new bullet points under the relevant section
rather than overwriting older points (so we keep a history).
