# Catálogo de Treinamentos M365 Copilot — vigente

> Living catalog. **Do not edit by hand** — re-run `helpers\refresh-catalog.ps1` to refresh.
> Last refresh: **2026-05-29 09:25**
> ESI fetch: 2026-05-29 09:24 — 103 active items (of 114 total)
> Microsoft Learn fetch: 05/29/2026 09:18:55 — 15 LPs · 60 modules · 11 Applied Skills · 9 certifications · 2 exams · 52 courses

## Mapeamento sugerido por nível do funil

> Padrão sugerido. Cada cliente refina pelo perfil real. Para o detalhe das fontes, ver `adoption-framework.md`.

| Nível | ESI primário | ESI complementar | Microsoft Learn (opcional) |
|---|---|---|---|
| **1 · Capacitado** | `MS-4018.S` (4h) ou `CEUT-4019` (1h) | `MS-4023` Copilot Chat (1.5h), `DW-0370` (3x2h sessões) | LP: *Get started with Microsoft 365 Copilot* · Applied Skill: *Configure Copilot for everyday work* |
| **2 · Amplificado** | `MS-4018` full (8h) + `MS-4019.S` (1.5h) | `MS-4004.*` por persona (1h cada), `MS-4021` CIE (6x1.5h) | LP: *Plan and execute a Microsoft 365 Copilot rollout* |
| **3 · Multiplicador** | `MS-4007` Copilot User Enablement Specialist¹ | `MS-4019` full (8h), `DW-101` (3x4h) | Applied Skill: *Build a foundation to extend M365 Copilot* · AI-900 entry cert |
| **4 · Construtor** | `MS-4022` (3h) + `MS-4014.S` (3h) | `PL-7008` (8h), `MS-4017` (8h), `DW-102` (3x4h) | Applied Skill: *Enhance agents with autonomous capabilities* |
| **5 · Especialista** | `MS-4014` full (8h) + `AB-100` (3x8h) | `DW-104` (2x4h), `DW-107` (4h), `DW-112` (3x4h) | Applied Skill: *Protect information in M365 Copilot with Purview* · AI-900 cert |

¹ ⚠️ MS-4007 retired 03/31/2026 — quando esse arquivo for refrescado após essa data, o helper deve buscar o sucessor (ver bloco *Avisos de retirement*).

---

## ESI Catalog (Dynamight) — ativos, agrupados por família

Convenções de sufixos comuns:
- `.S` = Short version (3-4h em vez de 8h)
- `.PE/.PF/.PO` e `.01-.13` = customizações por persona (Executive, Finance, Operations, IT, Legal, etc.)
- `.OE` = OE Only (Open Enrollment, não disponível como PD)
- `-PE` no fim = Practice Exam (não é treinamento, é simulado)
- `T00` = Trainer-led variant

### AB — Agentic AI for Business — 5 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `AB-100` | Architecting agentic AI business solutions | 3 - 8 hour sessions | MOC Courseware | OE and Private | This course is intended for experienced technology professionals who are responsible for planning, designing, and guiding AI-powered business solutions using Microsoft platforms. This course assumes f… |
| `AB-730` | Transform business workflows with generative AI | 8 hours | MOC Courseware | OE and Private | This course is designed for professionals from a wide range of business functions, such as marketing, sales, operations, product management, customer success, human resources, and finance. The course … |
| `AB-730.S` | Transform business workflows with generative AI | 3 hours | MOC Courseware | Private Only | This course is designed for professionals from a wide range of business functions, such as marketing, sales, operations, product management, customer success, human resources, and finance. The course … |
| `AB-900-PE` | Microsoft Official Practice Assessment for AB-900: Microsoft 365 Copilot and Agent Administration Fundamentals |  | Practice Exam |  | — |
| `AB-CUSTOM-COPILOT.S` | Copilot - Custom Learning Course. | 3 hours | MOC Courseware | Private Only | — |

### AI — AI for Business Users — 3 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `AI-3025` | Work smarter with AI | 3 hours | MOC Courseware | OE and Private | Business Users |
| `AI-3025.S` | Work smarter with Copilot and no-code agents | 1.5 hours | MOC Courseware | Private Only | Business Users |
| `AI-CUSTOM-COPILOT.S` | Copilot - Custom Learning Course. | 3 hours | MOC Courseware | Private Only | — |

### AZ — Azure (Copilot context) — 2 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `AZ-2007` | Get started with AI-assisted development | 8 hours | MOC Courseware | OE and Private | Experienced developers who are interested in using the GitHub Copilot extensions for Visual Studio Code to accelerate their development process and improve their code. |
| `AZ-2007.S` | Accelerate app development by using GitHub Copilot | 3 hours | MOC Courseware | Private Only | Experienced developers who are interested in using the GitHub Copilot extensions for Visual Studio Code to accelerate their development process and improve their code. |

### CEUT — Curated End User Training — 11 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `CEUT-4004` | Get started with Microsoft 365 Copilot | 1 hour | MOC Courseware |  | — |
| `CEUT-4004.01` | Microsoft 365 Copilot Training for Executives | 1 hour | MOC Courseware |  | This is targeted towards business users who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.02` | Microsoft 365 Copilot Training for Sales | 1 hour | MOC Courseware |  | This is targeted towards business users who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.03` | Microsoft 365 Copilot Training for IT | 1 hour | MOC Courseware |  | This is targeted towards business users and IT professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.04` | Microsoft 365 Copilot Training for Marketing | 1 hour | MOC Courseware |  | This is targeted towards business users and Marketing professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.05` | Microsoft 365 Copilot Training for Finance | 1 hour | MOC Courseware |  | This is targeted towards business users and Finance professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.06` | Microsoft 365 Copilot Training for HR | 1 hour | MOC Courseware |  | This is targeted towards business users and HR professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.07` | Microsoft 365 Copilot Training for Operations | 1 hour | MOC Courseware |  | This is targeted towards business users and Operations professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `CEUT-4004.10` | Microsoft 365 Copilot for Legal | 1 hour | MOC Courseware |  | — |
| `CEUT-4019` | Microsoft 365 Copilot Training: Get Started with Microsoft 365 Copilot and Agents | 1 hour | MOC Courseware |  | This course is targeted to Microsoft 365 business users. |
| `CEUT-4023` | Microsoft 365 Copilot Training: Explore Microsoft 365 Copilot Chat | 1 hours | MOC Courseware | Private Only | The Business User, specifically those who interact with Microsoft 365 Copilot to enhance their daily work and productivity. This audience profile focuses on users who apply Copilot’s built-in capabili… |

### DP — Data / Fabric Copilot — 1 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `DP-3029` | Work smarter with Copilot in Microsoft Fabric | 8 hours | MOC Courseware | OE and Private | This course is for data analysts and data engineers who are familiar with basic data concepts and terminology. People taking this course should already have a basic understanding of Microsoft Fabric a… |

### DW — Discovery Workshops — 18 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `DW-0039` | Accelerate data insights with Copilot in Power BI | 2 - 4 hour sessions | MOC Courseware | OE and Private | — |
| `DW-0370` | Elevate user productivity with Microsoft 365 Copilot (End user training) | 3 - 2 hour sessions | MOC Courseware | OE and Private | — |
| `DW-0802` | Accelerate your AI transformation with Microsoft 365 Copilot + Agents | 1.5 hours | MOC Courseware | OE and Private | — |
| `DW-0821` | Win Developers with GitHub Copilot | 1.5 hours | MOC Courseware | OE and Private | — |
| `DW-0955` | Modernize your SOC with Microsoft Sentinel | 1 - 1.5 hour session | MOC Courseware | OE and Private | — |
| `DW-101` | Implement with impact-Next-Gen Productivity: Copilot + Agents for the Modern Enterprise | 3 - 4 hour sessions | MOC Courseware | OE and Private | Technical |
| `DW-1012` | Becoming Frontier: Framing the AI Opportunity Through Strategic Conversations | 3 - 1.5 hour sessions | MOC Courseware | OE and Private | — |
| `DW-102` | Build enterprise ready agents with Copilot Studio | 3 - 4 hour sessions | MOC Courseware | OE and Private | Technical, Developers |
| `DW-103` | Pre-sales: Specialize Data Security Consultation with Microsoft Purview in the era of AI | 6 hours | MOC Courseware | OE and Private | Presales, Technical​​ |
| `DW-104` | Build and Extend Agents with Pro‑Code in Microsoft 365 and Copilot | 2 - 4 hour sessions | MOC Courseware | OE and Private | Technical |
| `DW-107` | Pre-sales Build, Orchestrate, and Govern AI Agents with Copilot Studio | 4 hours | MOC Courseware | OE and Private | — |
| `DW-112` | Implement Agent 365 to observe, govern, and secure Al apps, Copilot & Agents | 3 - 4 hours sessions | MOC Courseware | OE and Private | Technical |
| `DW-200` | Accelerate Agentic AI | 3 - 5 hour sessions | MOC Courseware | OE and Private | Technical, Developers |
| `DW-240` | Pre-sales: Unify your Data Platform with Microsoft Fabric | 4 hours | MOC Courseware | OE and Private | Technical, Developers |
| `DW-300` | Implement, Govern and Scale Data Security with Microsoft Purview in the era of AI | 3 - 4 hour sessions | MOC Courseware | OE and Private | Technical |
| `DW-330` | Implement Threat Protection with Microsoft Defender XDR solutions | 3 - 4 hour sessions | MOC Courseware | OE and Private | Technical |
| `DW-360` | Threat Protection and Incident response with Microsoft Sentinel within Unified Platform | 2 - 4 hour sessions | MOC Courseware | OE and Private | Technical |
| `DW-370` | Implement Security Copilot across MS Security workloads | 3 - 4 hour sessions | MOC Courseware | OE and Private | Technical |

### GH — GitHub Copilot — 3 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `GH-300` | GitHub Copilot | 8 hours | MOC Courseware | OE and Private | AI Developers and Engineers: Professionals involved in creating and deploying AI systems who need to understand the ethical implications and governance frameworks. Data Scientists and Analysts: Indivi… |
| `GH-300-PE` | Practice Assessment for GH-300: GitHub Copilot |  | Practice Exam |  | — |
| `GH-300.S` | GitHub Copilot | 3 hours | MOC Courseware | Private Only | AI Developers and Engineers: Professionals involved in creating and deploying AI systems who need to understand the ethical implications and governance frameworks. Data Scientists and Analysts: Indivi… |

### MD — Modern Workplace devices — 1 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `MD-4011` | Enhance endpoint security with Microsoft Intune and Microsoft Security Copilot | 8 hours | MOC Courseware | OE and Private | This course is designed for Endpoint Administrators and Security Analysts proficient in basic device management and security operations. |

### MS-40xx — M365 Copilot core — 51 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `MS-4002` | Prepare security and compliance to support Microsoft 365 Copilot | 8 hours | MOC Courseware | OE and Private | This course is designed for administrators, Microsoft 365 administrators, or persons aspiring to the Microsoft 365 Administrator role who have completed at least one of the Microsoft 365 role-based ad… |
| `MS-4004` | Empower your workforce with Microsoft 365 Copilot Use Cases | 8 hours | MOC Courseware |  | This course is targeted towards business users who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.1` | Empower your workforce with Microsoft 365 Copilot: Executives Use Case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.10` | Empower your workforce with Microsoft 365 Copilot: Legal Use Case | 1 hour | MOC Courseware | Private Only | — |
| `MS-4004.2` | Empower your workforce with Microsoft 365 Copilot: Sales use case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.3` | Empower your workforce with Microsoft 365 Copilot: IT Use Case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users and IT professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.4` | Empower your workforce with Microsoft 365 Copilot: Marketing Use Case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users and Marketing professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.5` | Empower your workforce with Microsoft 365 Copilot: Finance Use Case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users and Finance professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.6` | Empower your workforce with Microsoft 365 Copilot: HR Use Case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users and HR professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.7` | Empower your workforce with Microsoft 365 Copilot: Operations use case | 1 hour | MOC Courseware | Private Only | This is targeted towards business users and Operations professionals who want to enhance their prompting skills in Copilot for Microsoft 365. |
| `MS-4004.8` | Empower your workforce with Microsoft 365 Copilot: Communications Use Case | 1 hour | MOC Courseware | Private Only | — |
| `MS-4004.9` | Empower your workforce with Microsoft 365 Copilot: Customer Service Use Case | 1 hour | MOC Courseware | Private Only | — |
| `MS-4014` | Build a foundation to build AI agents and extend Microsoft 365 Copilot | 8 hours | MOC Courseware | OE and Private | Developers and IT professionals interested in extending Microsoft 365 Copilot and/or building agents or generative AI applications using Microsoft 365, Copilot Studio, and/or Azure AI services. |
| `MS-4014.S` | Build a foundation to build AI agents and extend Microsoft 365 Copilot | 3 hours | MOC Courseware | Private Only | Developers and IT professionals interested in extending Microsoft 365 Copilot and/or building agents or generative AI applications using Microsoft 365, Copilot Studio, and/or Azure AI services. |
| `MS-4017` | Manage and extend Microsoft 365 Copilot | 8 hours | MOC Courseware | OE and Private | This course is designed for administrators, Microsoft 365 administrators, and IT professionals who are interested in learning how to manage and extend Microsoft 365 Copilot. |
| `MS-4017.S` | Manage and extend Microsoft 365 Copilot | 3 hours | MOC Courseware | Private Only | This course is designed for administrators, Microsoft 365 administrators, and IT professionals who are interested in learning how to manage and extend Microsoft 365 Copilot. |
| `MS-4018` | Draft, analyze, and present with Microsoft 365 Copilot | 8 hours | MOC Courseware | OE and Private | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S` | Draft, analyze, and present with Microsoft 365 Copilot | 4 hours | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S01` | Draft, analyze, and present with Microsoft 365 Copilot: Introduction to Microsoft 365 Copilot | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S02` | Draft, analyze, and present with Microsoft 365 Copilot: Build effective presentations with AI | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S03` | Draft, analyze, and present with Microsoft 365 Copilot: Draft impactful documents using AI | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S04` | Draft, analyze, and present with Microsoft 365 Copilot: Make your meetings more productive with AI | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S05` | Draft, analyze, and present with Microsoft 365 Copilot: Uncover new data insights with AI | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S06` | Microsoft 365 Copilot: From inbox to impact: Improve your email workflows with AI | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4018.S07` | Microsoft 365 Copilot: Unlock productivity and unleash creativity with AI powered chat | 1 hour | MOC Courseware | Private Only | This course is designed for business users who want to leverage Microsoft 365 Copilot to enhance their productivity and efficiency. These users typically have a foundational understanding of Microsoft… |
| `MS-4019` | Transform your everyday business processes with agents | 8 hours | MOC Courseware | OE and Private | This course is targeted to Microsoft 365 business users. |
| `MS-4019.1` | Get started with agents | 1 hour | MOC Courseware |  | This course is targeted to everyday Microsoft 365 business users. No programming experience is required to create Microsoft 365 Copilot Chat agents and SharePoint agents. |
| `MS-4019.2` | Explore prebuilt Microsoft 365 Copilot agents | 1 hour | MOC Courseware |  | This course is targeted to everyday Microsoft 365 business users. No programming experience is required to create Microsoft 365 Copilot Chat agents and SharePoint agents. |
| `MS-4019.3` | Build and manage an agent | 1 hour | MOC Courseware |  | This course is targeted to everyday Microsoft 365 business users. No programming experience is required to create Microsoft 365 Copilot Chat agents and SharePoint agents. |
| `MS-4019.4` | Share and use agents | 1 hour | MOC Courseware |  | This course is targeted to everyday Microsoft 365 business users. No programming experience is required to create Microsoft 365 Copilot Chat agents and SharePoint agents. |
| `MS-4019.PE` | Transform everyday process with agents - Executive | 1 hour | MOC Courseware | Private Only | This course is targeted to Microsoft 365 business users. |
| `MS-4019.PF` | Transform everyday processes with agents - Finance | 1 hour | MOC Courseware | Private Only | This course is targeted to Microsoft 365 business users. |
| `MS-4019.PO` | Transform everyday processes with agents - Operations | 1 hour | MOC Courseware | Private Only | This course is targeted to Microsoft 365 business users. |
| `MS-4019.S` | Get Started with Microsoft 365 Copilot and Agents | 1.5 hours | MOC Courseware | OE and Private | This course is targeted to Microsoft 365 business users. |
| `MS-4021` | Copilot Immersion Experience (CIE) for Microsoft 365 | 6 - 1.5 hour sessions | MOC Courseware | Private Only | This experience is designed for organizations that have deployed Microsoft 365 Copilot and specifically aimed at Executives, business leaders, and end users who are interested in advancing their strat… |
| `MS-4021.01` | Copilot Immersion Experience (CIE) for Microsoft 365: Executive | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.02` | Copilot Immersion Experience (CIE) for Microsoft 365: Executive Assistants | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.03` | Copilot Immersion Experience (CIE) for Microsoft 365: Business Managers | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.04` | Copilot Immersion Experience (CIE) for Microsoft 365: Communications | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.05` | Copilot Immersion Experience (CIE) for Microsoft 365: Finance | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.06` | Copilot Immersion Experience (CIE) for Microsoft 365: HR Managers | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.07` | Copilot Immersion Experience (CIE) for Microsoft 365: IT | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.08` | Copilot Immersion Experience (CIE) for Microsoft 365: Legal | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.09` | Copilot Immersion Experience (CIE) for Microsoft 365: Marketing Managers | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.10` | Copilot Immersion Experience (CIE) for Microsoft 365: Operations | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.11` | Copilot Immersion Experience (CIE) for Microsoft 365: Sales | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.12` | Copilot Immersion Experience (CIE) for Microsoft 365: Agents for Business | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4021.13` | Copilot Immersion Experience (CIE) for Microsoft 365: Agents for Executives | 1.5 hours | MOC Courseware | Private Only | — |
| `MS-4022` | Extend Microsoft 365 Copilot in Copilot Studio | 3 hours | MOC Courseware | OE and Private | This course targets low-code developers interested in using Copilot Studio to build agents. Learners should be familiar with Microsoft 365 Copilot. |
| `MS-4023` | Transform ideas into action with Copilot Chat | 1.5 hours | MOC Courseware | Private Only | The Business User, specifically those who interact with Microsoft 365 Copilot to enhance their daily work and productivity. This audience profile focuses on users who apply Copilot’s built-in capabili… |
| `MS-4023.OE` | Transform ideas into action with Copilot Chat | 1.5 hours | MOC Courseware | OE Only | The Business User, specifically those who interact with Microsoft 365 Copilot to enhance their daily work and productivity. This audience profile focuses on users who apply Copilot’s built-in capabili… |

### PL — Power Platform — 1 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `PL-7008` | Create agents in Microsoft Copilot Studio | 8 hours | MOC Courseware | OE and Private | Participants use Microsoft Copilot Studio to solve business problems with copilots. They are familiar with the capabilities and limitations of Copilot Studio and are self-directed and solution focused… |

### SB — Subscriptions (3rd-party / Microsoft) — 4 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `SB-Brainstorm` | M365 Copilot, Copilot Chat & M365 Learning Experiences |  | EdTech Subscription |  | — |
| `SB-Coursera` | Coursera for Microsoft Copilot, AI, Azure and Security |  | EdTech Subscription |  | — |
| `SB-edX` | Microsoft Skills Subscription with edX |  | EdTech Subscription |  | — |
| `SB-Sulava` | Copilot Essential |  | EdTech Subscription |  | — |

### VTD — Virtual Training Days — 3 itens

| ID | Title | Duration | Type | Delivery | Audience (resumo) |
|---|---|---|---|---|---|
| `VTD-7008` | Microsoft Virtual Training Day: Create Agents in Microsoft Copilot Studio | 2 - 8 hour sessions | Event |  | Fundamental Skills |
| `VTD-9901` | Microsoft Virtual Training Day: Introduction to Microsoft 365, Copilot, and Agents | 8 hours | Event |  | — |
| `VTD-9902` | Microsoft Virtual Training Day: Secure and administer Microsoft 365 Copilot and Agents | 8 hours | Event |  | — |

---

## Microsoft Learn — conteúdo M365 Copilot

### Learning Paths (15)

| Title | Min | Level(s) | Pop | URL |
|---|---|---|---|---|
| Secure AI interactions and environments with Microsoft Purview | 210 | intermediate | 0.46 | [link](https://learn.microsoft.com/en-us/training/paths/purview-protect-ai/?WT.mc_id=api_CatalogApi) |
| Build a foundation to build AI agents and extend Microsoft 365 Copilot | 104 | beginner | 0.44 | [link](https://learn.microsoft.com/en-us/training/paths/build-foundation-extend-microsoft-365-copilot/?WT.mc_id=api_CatalogApi) |
| Extend Microsoft 365 Copilot in Copilot Studio | 182 | intermediate | 0.4 | [link](https://learn.microsoft.com/en-us/training/paths/extend-microsoft-365-copilot-studio/?WT.mc_id=api_CatalogApi) |
| Windows 11 Pro Accreditation 2026 | 114 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/windows-11-pro-accreditation-2026/?WT.mc_id=api_CatalogApi) |
| Architect AI solutions for business productivity | 684 | advanced | 0 | [link](https://learn.microsoft.com/en-us/training/paths/architect-agentic-ai-business-solutions/?WT.mc_id=api_CatalogApi) |
| AI in special education | 120 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/ai-in-special-education/?WT.mc_id=api_CatalogApi) |
| Protect information in a Microsoft 365 Copilot environment using Microsoft Purview | 175 | intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/paths/purview-protect-microsoft-365-copilot-environment/?WT.mc_id=api_CatalogApi) |
| Discover AI for leaders in nonprofit | 192 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/discover-ai-leaders-nonprofit/?WT.mc_id=api_CatalogApi) |
| Microsoft Education Accreditation 2026 | 108 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/microsoft-education-accreditation-2026/?WT.mc_id=api_CatalogApi) |
| Explore Microsoft 365 Copilot and agent administration | 199 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/explore-microsoft-365-copilot-agent-administration/?WT.mc_id=api_CatalogApi) |
| Explore the business value of generative AI solutions | 62 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/explore-business-value-generative-ai-solutions/?WT.mc_id=api_CatalogApi) |
| Explore role-based AI agent skills for business users | 100 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/explore-role-based-ai-agent-skills-business-users/?WT.mc_id=api_CatalogApi) |
| Discover new Outlook for Windows | 139 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/discover-new-outlook-windows/?WT.mc_id=api_CatalogApi) |
| Drive business value with AI solutions | 68 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/drive-value-generative-ai-solutions/?WT.mc_id=api_CatalogApi) |
| Enhance your productivity with prebuilt Microsoft 365 Copilot agents | 72 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/paths/enhance-productivity-prebuilt-agents/?WT.mc_id=api_CatalogApi) |

### Applied Skills (11)

| Title | Level | Min | URL |
|---|---|---|---|
| Microsoft Applied Skills: Accelerate AI-assisted development by using GitHub Copilot | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/accelerate-app-development-by-using-github-copilot/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Create agents in Microsoft Copilot Studio | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/create-agents-in-microsoft-copilot-studio/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Create an AI agent | beginner |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/create-an-ai-agent/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Enhance agents with autonomous capabilities | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/enhance-agents-with-autonomous-capabilities/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Generate reports with AI research agents | beginner |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/generate-reports-with-ai-research-agents/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Get started developing agents in Microsoft Foundry | beginner |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/get-started-developing-agents-in-microsoft-foundry/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Integrate model context protocol tools with agents in Microsoft Foundry | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/integrate-model-context-protocol-tools-with-agents-in-microsoft-foundry/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Prepare security and compliance to support Microsoft 365 Copilot | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/prepare-security-and-compliance-to-support-microsoft-365-copilot/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Protect information in Microsoft 365 Copilot by using Microsoft Purview | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/protect-information-in-microsoft-365-copilot-by-using-microsoft-purview/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Resolve GitHub issues by using GitHub Copilot | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/resolve-github-issues-by-using-github-copilot/?WT.mc_id=api_CatalogApi) |
| Microsoft Applied Skills: Streamline business workflows with AI chat | beginner |  | [link](https://learn.microsoft.com/en-us/credentials/applied-skills/streamline-business-workflows-with-ai-chat/?WT.mc_id=api_CatalogApi) |

### Certifications (9)

| Title | Level | Exams | URL |
|---|---|---|---|
| GitHub Certified: Agentic AI Developer (beta) | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/agentic-ai-developer/?WT.mc_id=api_CatalogApi) |
| GitHub Copilot | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/github-copilot/?WT.mc_id=api_CatalogApi) |
| Microsoft 365 Certified: Copilot and Agent Administration Fundamentals | beginner |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/copilot-and-agent-administration-fundamentals/?WT.mc_id=api_CatalogApi) |
| Microsoft Certified: Agentic AI Business Solutions Architect | advanced |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/agentic-ai-business-solutions-architect/?WT.mc_id=api_CatalogApi) |
| Microsoft Certified: AI Agent Builder Associate (beta) | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/ai-agent-builder-associate/?WT.mc_id=api_CatalogApi) |
| Microsoft Certified: Azure AI Apps and Agents Developer Associate (beta) | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/azure-ai-apps-and-agents-developer-associate/?WT.mc_id=api_CatalogApi) |
| Microsoft Certified: Azure AI Engineer Associate | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/azure-ai-engineer/?WT.mc_id=api_CatalogApi) |
| Microsoft Certified: Azure AI Fundamentals | beginner | exam.ai-900, exam.ai-901 | [link](https://learn.microsoft.com/en-us/credentials/certifications/azure-ai-fundamentals/?WT.mc_id=api_CatalogApi) |
| Microsoft Certified: Dynamics 365 Contact Center AI Engineer Associate (beta) | intermediate |  | [link](https://learn.microsoft.com/en-us/credentials/certifications/d365-contact-center-ai-engineer-associate/?WT.mc_id=api_CatalogApi) |

### Exams (Copilot / Agent / AI-fundamentals) (2)

| Title | UID | URL |
|---|---|---|
| Microsoft Azure AI Fundamentals | `exam.ai-900` | [link](https://learn.microsoft.com/en-us/credentials/certifications/exams/ai-900/?WT.mc_id=api_CatalogApi) |
| Microsoft Azure AI Fundamentals (beta) | `exam.ai-901` | [link](https://learn.microsoft.com/en-us/credentials/certifications/exams/ai-901/?WT.mc_id=api_CatalogApi) |

### Modules (60) — top 30 por popularidade

| Title | Min | Level | Pop | URL |
|---|---|---|---|---|
| Leverage AI tools and resources for your business | 42 | beginner | 0.61 | [link](https://learn.microsoft.com/en-us/training/modules/leverage-ai-tools/?WT.mc_id=api_CatalogApi) |
| Challenge project - Build a declarative agent to chat with your external data ingested to Microsoft 365 | 70 | intermediate | 0.48 | [link](https://learn.microsoft.com/en-us/training/modules/copilot-declarative-agent-challenge-chat-with-external-data/?WT.mc_id=api_CatalogApi) |
| Introduction to tools for declarative agents in Copilot Studio | 23 | intermediate | 0.46 | [link](https://learn.microsoft.com/en-us/training/modules/introduction-copilot-studio-actions/?WT.mc_id=api_CatalogApi) |
| Challenge project - Build a declarative agent to chat with your docs | 53 | intermediate | 0.45 | [link](https://learn.microsoft.com/en-us/training/modules/copilot-declarative-agent-challenge-chat-with-docs/?WT.mc_id=api_CatalogApi) |
| Challenge project - Build a declarative agent to chat with your data | 93 | intermediate | 0.45 | [link](https://learn.microsoft.com/en-us/training/modules/copilot-declarative-agent-challenge-chat-with-data/?WT.mc_id=api_CatalogApi) |
| Extend declarative agents with connector tools in Copilot Studio | 38 | intermediate | 0.44 | [link](https://learn.microsoft.com/en-us/training/modules/extend-declarative-agents-connector-actions-copilot-studio/?WT.mc_id=api_CatalogApi) |
| Extend declarative agents with prompt tools in Copilot Studio | 35 | intermediate | 0.44 | [link](https://learn.microsoft.com/en-us/training/modules/extend-declarative-agents-prompt-actions-copilot-studio/?WT.mc_id=api_CatalogApi) |
| Build your first declarative agent for Microsoft 365 Copilot by using Copilot Studio | 67 | intermediate | 0.44 | [link](https://learn.microsoft.com/en-us/training/modules/build-your-first-agent-microsoft-365-copilot-use-copilot-studio/?WT.mc_id=api_CatalogApi) |
| Turn information into decisions with AI agents | 90 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/turn-info-into-decisions-ai-agents/?WT.mc_id=api_CatalogApi) |
| Evaluate costs and benefits of AI solutions | 34 | advanced | 0 | [link](https://learn.microsoft.com/en-us/training/modules/evaluate-costs-benefits-ai-powered-business-solution/?WT.mc_id=api_CatalogApi) |
| Explore Microsoft 365 Copilot and agents | 74 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/explore-microsoft-365-copilot-agents/?WT.mc_id=api_CatalogApi) |
| Integrate your agent with Microsoft 365 | 74 | intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/modules/integrate-foundry-agent-with-m365/?WT.mc_id=api_CatalogApi) |
| Introduction to agentic AI business solutions | 24 | advanced | 0 | [link](https://learn.microsoft.com/en-us/training/modules/introduction-agentic-ai-business-solution-architecture/?WT.mc_id=api_CatalogApi) |
| Apply AI tools in special education environments | 15 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/introduction-ai-special-education/?WT.mc_id=api_CatalogApi) |
| Introduction to developing AI agents | 18 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/introduction-develop-ai-agents/?WT.mc_id=api_CatalogApi) |
| Introduction to Microsoft AI agent solutions | 27 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-ai-agent-solutions/?WT.mc_id=api_CatalogApi) |
| Manage People in new Outlook for Windows | 19 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/manage-people-new-outlook-windows/?WT.mc_id=api_CatalogApi) |
| Drive business value with Microsoft Copilot solutions | 38 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/business-value-microsoft-copilot-solutions/?WT.mc_id=api_CatalogApi) |
| Manage testing AI-powered business solutions | 35 | advanced | 0 | [link](https://learn.microsoft.com/en-us/training/modules/manage-testing-ai-powered-business-solutions/?WT.mc_id=api_CatalogApi) |
| Monitor and maintain Microsoft 365 Copilot connectors | 56 | beginner,intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/modules/monitor-maintain-microsoft-365-copilot-connectors/?WT.mc_id=api_CatalogApi) |
| Orchestrate configuration of prebuilt agents and apps | 57 | intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/modules/orchestrate-configuration-prebuilt-agents-apps/?WT.mc_id=api_CatalogApi) |
| Organize your inbox in new Outlook for Windows | 28 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/organize-your-inbox-new-outlook-windows/?WT.mc_id=api_CatalogApi) |
| Perform basic administrative tasks for Microsoft 365 Copilot | 55 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/perform-admin-tasks-microsoft-365-copilot/?WT.mc_id=api_CatalogApi) |
| Protect and govern Microsoft 365 data | 62 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/protect-govern-data-microsoft-365/?WT.mc_id=api_CatalogApi) |
| Secure Microsoft 365 Copilot interactions with Microsoft Purview | 54 | intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/modules/purview-ai-secure-copilot/?WT.mc_id=api_CatalogApi) |
| Scale how you work by creating AI agents | 20 | intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/modules/scale-work-creating-ai-agents/?WT.mc_id=api_CatalogApi) |
| Streamline administrative tasks with AI tools | 21 | intermediate | 0 | [link](https://learn.microsoft.com/en-us/training/modules/streamline-administrative-tasks-ai/?WT.mc_id=api_CatalogApi) |
| Support multilingual and accessible family communication | 21 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/support-multilingual-accessible-family-communication/?WT.mc_id=api_CatalogApi) |
| Understand the foundations of generative AI for business leaders | 34 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/understand-foundations-generative-ai-business-leaders/?WT.mc_id=api_CatalogApi) |
| Manage your calendar in new Outlook for Windows | 36 | beginner | 0 | [link](https://learn.microsoft.com/en-us/training/modules/manage-calendar-new-outlook-windows/?WT.mc_id=api_CatalogApi) |

> Lista completa de módulos no arquivo `_cache/mslearn_copilot_catalog.json`.

### Courses (ILT/MOC catalog) — relacionados a Copilot/Agent (52)

| Title | UID | Hours | URL |
|---|---|---|---|
| Accelerate sales pipelines with AI in Dynamics 365 | `course.ab-210t00` | 72 | [link](https://learn.microsoft.com/en-us/training/courses/ab-210t00/?WT.mc_id=api_CatalogApi) |
| AI for educators | `course.edu.ai-education` | 4 | [link](https://learn.microsoft.com/en-us/training/courses/ai-education/?WT.mc_id=api_CatalogApi) |
| Architecting agentic AI business solutions | `course.ab-100t00` | 72 | [link](https://learn.microsoft.com/en-us/training/courses/ab-100t00/?WT.mc_id=api_CatalogApi) |
| Augment advance level Supply Chain Management solutions with Microsoft Dynamics 365 | `course.mb-335t00` | 120 | [link](https://learn.microsoft.com/en-us/training/courses/mb-335t00/?WT.mc_id=api_CatalogApi) |
| Build a foundation to build AI agents and extend Microsoft 365 Copilot | `course.ms-4014` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4014/?WT.mc_id=api_CatalogApi) |
| Build custom engine agents with the Microsoft 365 Agents SDK | `course.ms-4015` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4015/?WT.mc_id=api_CatalogApi) |
| Conceptualize Supply Chain Management in Microsoft Dynamics 365 | `course.mb-330t00` | 120 | [link](https://learn.microsoft.com/en-us/training/courses/mb-330t00/?WT.mc_id=api_CatalogApi) |
| Copilot Immersion Experience | `course.ms-4021` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4021/?WT.mc_id=api_CatalogApi) |
| Create instructional materials with Teach in Microsoft 365 Copilot | `course.edu.create-instructional-materials-teach-microsoft-365-copilot` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/create-instructional-materials-teach-microsoft-365-copilot/?WT.mc_id=api_CatalogApi) |
| Defend against cyberthreats with Microsoft's security operations platform | `course.sc-200t00` | 96 | [link](https://learn.microsoft.com/en-us/training/courses/sc-200t00/?WT.mc_id=api_CatalogApi) |
| Design and build integrated AI agent solutions in Copilot Studio | `course.ab-620t00` | 72 | [link](https://learn.microsoft.com/en-us/training/courses/ab-620t00/?WT.mc_id=api_CatalogApi) |
| Develop AI agents on Azure | `course.ai-3026` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ai-3026/?WT.mc_id=api_CatalogApi) |
| Develop AI apps and agents on Azure | `course.ai-103t00` | 96 | [link](https://learn.microsoft.com/en-us/training/courses/ai-103t00/?WT.mc_id=api_CatalogApi) |
| Develop AI cloud solutions on Azure | `course.ai-200t00` | 120 | [link](https://learn.microsoft.com/en-us/training/courses/ai-200t00/?WT.mc_id=api_CatalogApi) |
| Develop AI-enabled database solutions | `course.dp-800t00` | 72 | [link](https://learn.microsoft.com/en-us/training/courses/dp-800t00/?WT.mc_id=api_CatalogApi) |
| Draft, analyze, and present with Microsoft 365 Copilot | `course.ms-4018` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4018/?WT.mc_id=api_CatalogApi) |
| Drive AI transformation in your organization | `course.ab-731t00` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ab-731t00/?WT.mc_id=api_CatalogApi) |
| Embark on your AI journey with free AI tools from Microsoft (1-hour) | `course.edu.embark-ai-journey-free-ai-tools-microsoft-education-1hr` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/embark-ai-journey-free-ai-tools-microsoft-education-1hr/?WT.mc_id=api_CatalogApi) |
| Embark on your AI journey with free AI tools from Microsoft (3-hour) | `course.edu.embark-ai-journey-free-ai-tools-microsoft-education-3hr` | 3 | [link](https://learn.microsoft.com/en-us/training/courses/embark-ai-journey-free-ai-tools-microsoft-education-3hr/?WT.mc_id=api_CatalogApi) |
| Empower your workforce with Microsoft 365 Copilot Use Cases | `course.ms-4004` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4004/?WT.mc_id=api_CatalogApi) |
| Enhance endpoint security with Microsoft Intune and Microsoft Security Copilot | `course.md-4011` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/md-4011/?WT.mc_id=api_CatalogApi) |
| Enhance security operations by using Microsoft Security Copilot | `course.sc-5006` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/sc-5006/?WT.mc_id=api_CatalogApi) |
| Enhance teaching and learning with Microsoft Copilot | `course.edu.enhance-teaching-learning-bing-chat` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/enhance-teaching-learning-microsoft-copilot/?WT.mc_id=api_CatalogApi) |
| Equip and support learners with AI tools from Microsoft | `course.edu.equip-support-learners-ai-tools-microsoft` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/equip-support-learners-ai-tools-microsoft/?WT.mc_id=api_CatalogApi) |
| Extend Microsoft 365 Copilot in Copilot Studio | `course.ms-4022` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4022/?WT.mc_id=api_CatalogApi) |
| Get started with Microsoft 365 Copilot (1-hour) | `course.edu.get-started-microsoft-365-copilot-1hr` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/get-started-microsoft-365-copilot-1hr/?WT.mc_id=api_CatalogApi) |
| Get started with Microsoft 365 Copilot (3-hour) | `course.edu.get-started-microsoft-365-copilot-3hr` | 3 | [link](https://learn.microsoft.com/en-us/training/courses/get-started-microsoft-365-copilot-3hr/?WT.mc_id=api_CatalogApi) |
| GitHub Copilot | `course.gh-300t00` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/gh-300t00/?WT.mc_id=api_CatalogApi) |
| Implement a data science and machine learning solution for AI with Microsoft Fabric | `course.dp-604t00` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/dp-604t00/?WT.mc_id=api_CatalogApi) |
| Implement end‑to‑end security controls for cloud and AI workloads | `course.sc-500t00` | 96 | [link](https://learn.microsoft.com/en-us/training/courses/sc-500t00/?WT.mc_id=api_CatalogApi) |
| Implement Generative AI engineering with Azure Databricks | `course.dp-3028` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/dp-3028/?WT.mc_id=api_CatalogApi) |
| Introduction to AI in Azure | `course.ai-901t00` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ai-901t00/?WT.mc_id=api_CatalogApi) |
| Introduction to Microsoft 365 and AI administration | `course.ab-900t00` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ab-900t00/?WT.mc_id=api_CatalogApi) |
| Introduction to supply chain management in Dynamics 365 | `course.ab-6005` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ab-6005/?WT.mc_id=api_CatalogApi) |
| Manage and extend Microsoft 365 Copilot | `course.ms-4017` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4017/?WT.mc_id=api_CatalogApi) |
| Microsoft AI Bootcamp for Educators – Azure AI Fundamentals | `course.msle-ai-bootcamp-fun` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/msle-ai-bootcamp-fun/?WT.mc_id=api_CatalogApi) |
| Microsoft Copilot Prompt-a-thon Workshop for School Leaders | `course.microsoft-copilot-prompt-a-thon-workshop-for-school-leaders` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/microsoft-copilot-prompt-a-thon-workshop-for-school-leaders/?WT.mc_id=api_CatalogApi) |
| Microsoft Learn for Educators (MSLE) Foundational AI Bootcamp | `course.msle-cybersecurity-and-ai-bootcamp` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/msle-cybersecurity-and-ai-bootcamp/?WT.mc_id=api_CatalogApi) |
| Microsoft Learn for Educators (MSLE) Generative AI for Teaching Bootcamp | `course.msle-generative-ai-for-teaching-bootcamp` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/msle-generative-ai-for-teaching-bootcamp/?WT.mc_id=api_CatalogApi) |
| Minecraft Trainer Academy: Train educators to teach with Minecraft Education in the classroom | `course.edu.minecraft-trainer-academy-minecraft-education-classroom` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/minecraft-trainer-academy-minecraft-education-classroom/?WT.mc_id=api_CatalogApi) |
| Operationalize machine learning and generative AI solutions | `course.ai-300t00` | 96 | [link](https://learn.microsoft.com/en-us/training/courses/ai-300t00/?WT.mc_id=api_CatalogApi) |
| Protect sensitive information with Microsoft Purview in the AI era | `course.sc-401t00` | 96 | [link](https://learn.microsoft.com/en-us/training/courses/sc-401t00/?WT.mc_id=api_CatalogApi) |
| Secure AI solutions in the cloud using Microsoft Defender for Cloud and Microsoft Entra | `course.sc-5009` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/sc-5009/?WT.mc_id=api_CatalogApi) |
| Secure and Govern your AI agent workforce | `course.ab-6007` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ab-6007/?WT.mc_id=api_CatalogApi) |
| Transform business workflows with generative AI | `course.ab-730t00` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ab-730t00/?WT.mc_id=api_CatalogApi) |
| Transform contact center experiences with AI in Dynamics 365 | `course.ab-250t00` | 72 | [link](https://learn.microsoft.com/en-us/training/courses/ab-250t00/?WT.mc_id=api_CatalogApi) |
| Transform Ideas into Action with Copilot Chat | `course.ms-4023` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4023/?WT.mc_id=api_CatalogApi) |
| Transform your everyday business processes with agents | `course.ms-4019` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ms-4019/?WT.mc_id=api_CatalogApi) |
| Unlock the power of Microsoft agents (1-hour) | `course.edu.unlock-power-microsoft-agents-1hr` | 1 | [link](https://learn.microsoft.com/en-us/training/courses/unlock-power-microsoft-agents-1-hour/?WT.mc_id=api_CatalogApi) |
| Unlock the power of Microsoft agents (3-hour) | `course.edu.unlock-power-microsoft-agents-3hr` | 3 | [link](https://learn.microsoft.com/en-us/training/courses/unlock-power-microsoft-agents-3-hour/?WT.mc_id=api_CatalogApi) |
| Work smarter with AI | `course.ai-3025` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/ai-3025/?WT.mc_id=api_CatalogApi) |
| Work smarter with Copilot in Microsoft Fabric | `course.dp-3029` | 24 | [link](https://learn.microsoft.com/en-us/training/courses/dp-3029/?WT.mc_id=api_CatalogApi) |

---

## Como re-executar

```powershell
cd $env:USERPROFILE\.copilot\skills\copilot-adoption-best-practices
.\helpers\refresh-catalog.ps1
# Opções:
#   -SkipDynamight  → não tenta Dynamight (útil sem VPN)
#   -SkipMSLearn    → não atualiza bloco MSLearn
```

