# Customer Examples — Brazilian Copilot adoption case library

> Institutional memory of plans we have proposed or delivered. Append
> after every customer engagement. Keep entries factual and short.
> This is **not** marketing prose — it is so the next plan can re-use
> what worked and avoid what didn't.

## Template

```markdown
### {Customer} — {YYYY-MM}
- **Scale:** {N licenses available} · {N actively trained per tier}
- **Industry/Context:** {sector, regulatory notes}
- **Approach:** {1-2 sentences on the funnel/wave design}
- **Trainings used (ESI codes):** {list}
- **Outcomes (if measured):** {KPIs}
- **What worked:** {patterns to reuse}
- **What we'd change:** {anti-patterns to avoid}
- **Source artifacts:** {OneDrive paths / deck file names}
- **Owner:** {Microsoft contact}
```

---

## Cases

### [CLIENTE] — 2026-06 (proposta, FY27)
- **Scale:** ~5.000 licenças M365 Copilot · 5.000 Capacitados · 1.500
  Amplificados · 500 Multiplicadores · 250 Construtores · 50 Especialistas
- **Industry/Context:** Empresa pública federal de TI; basicamente todas
  as áreas são "IT"; conta prioritária; FY27 budget cycle
- **Approach:** Funil 5 níveis (Capacitado → Amplificado → Multiplicador
  → Construtor → Especialista). Onda 0 de fundação imediata em 1/jul/2026.
  Multiplicadores treinados ANTES da onda geral. 100% via ESI.
- **Trainings used (ESI codes):** Em desenho — espinha dorsal MS-4018.S
  (Capacitado), MS-4019.S + MS-4023 (Amplificado), MS-4007/sucessor +
  MS-4021 CIE (Multiplicador), PL-7008 + MS-4022 (Construtor), MS-4014 +
  AB-100 (Especialista)
- **Outcomes:** TBD (proposta)
- **What worked:** Vocabulário PT-BR institucional (Multiplicador em vez
  de Champion) ressoou imediatamente; critério "Multiplicadores antes do
  general user" foi aceito sem fricção.
- **What we'd change:** TBD
- **Source artifacts:** session-state checkpoint 002, deck
  `SERPRO_PlanoCopilotM365_v1_SV1.pptx` (em construção)
- **Owner:** {{USER_NAME}} (TPM)

### [CLIENTE] DAF — 2026-XX (proposta concluída)
- **Scale:** TBD (DAF — Diretoria Administrativa-Financeira) · escopo
  inicial focado em jurídico / finanças / RH
- **Industry/Context:** Estatal SP, escopo departamental específico
- **Approach:** Deck de proposta focado em área DAF; treinamentos por
  persona (legal / finance / HR use cases)
- **Trainings used (ESI codes):** MS-4004.5 (Finance use case), MS-4004.6
  (HR), MS-4004.10 (Legal)
- **Outcomes:** TBD
- **What worked:** Recorte por área permitiu encaixar treinamentos
  customizados existentes (MS-4004.*) sem necessidade de customização
  adicional
- **Source artifacts:** session-state checkpoint 001
- **Owner:** {{USER_NAME}} (TPM)

### [CLIENTE] — 2026-XX (precedente de deck)
- **Scale:** TBD
- **Industry/Context:** Varejo
- **Approach:** Workflow 3 do Success Kit — usado como pattern para usar
  slides oficiais Microsoft + capas SV1 PT-BR
- **What worked:** Combinação de slides Microsoft (frameworks
  autorizativos) + slides custom SV1 PT-BR; preservou animações via
  PowerPoint COM
- **Source artifacts:** referenciado no `copilot-success-kit` SKILL.md
- **Owner:** {{USER_NAME}} (TPM)

---

## Patterns observed across cases (rolling notes)

> Update este bloco quando você notar um pattern repetido em 3+ cases.
> É o "tacit knowledge" do programa.

- **PT-BR institutional vocabulary** funciona muito melhor que
  anglicismos em órgãos de governo + estatais. Reduz ruído ao apresentar
  o plano para sponsor / TI / RH.
- **Onda 0 dedicada à governança** evita 80% dos problemas de adoção
  observados em programas que vão direto pro user-wave.
- **Multiplicadores antes do general user** é o pattern mais
  determinante para sustentação após dia 30. Sem isso, adoção cai ~50%
  no segundo mês.
- **Critério de promoção transparente** desde o lançamento gera
  participação voluntária 3-5x maior que programa "convite por seleção
  da liderança".

---

## Anti-patterns (what NOT to do)

- ❌ **Treinar 100% de uma vez em 1 mês.** Funciona como awareness, mas
  destrói o suporte pós-treinamento. Sem Multiplicadores no chão, o
  uso esfria.
- ❌ **Exigir cert para promoção entre níveis baixos.** Filtra
  Multiplicadores naturais que não fazem exames.
- ❌ **Treinar Construtor antes do Multiplicador maduro.** O
  Construtor vira ilhado, sem comunidade que entenda o que ele
  construiu.
- ❌ **Sponsor que não usa Copilot publicamente.** Modeling behavior
  importa mais que qualquer comunicação escrita.
- ❌ **Sem critério de promoção definido.** Vira hierarquia política
  em vez de meritocracia de uso.
