# Promotion Criteria — gates between proficiency levels

> Suggested criteria for promoting a person from one level of the 5-level
> funnel to the next. Combines **usage telemetry** (Copilot Dashboard +
> Viva Insights), **self-nomination + manager approval** (institutional
> gate, important for government customers), **optional certification**
> (Microsoft Learn — acelerador, não obrigatório), and **portfolio /
> peer recommendation** (for senior levels).

## Design principles

1. **Multi-signal, not single-signal.** Usage alone misses Champions
   who teach more than they consume; cert alone misses doers without a
   badge. Combine signals.
2. **Voluntary, not coercive.** Self-nomination preserves motivation.
   Forced promotion creates Champions on paper but not in practice.
3. **Manager-endorsed.** A line manager confirming "this person has the
   bandwidth and the right" prevents burnout and political conflict.
4. **Time-boxed re-evaluation.** Anyone passed-over has a clear next
   review date (quarterly).
5. **Certification is an accelerator, not a gate.** Required certs
   exclude high-performers who don't take exams; making them optional
   incentives ("fast-track to next level") works better in practice.

---

## Level 1 → 2 — Capacitado → Amplificado

**Default candidate volume:** 30% of the Capacitado population.

### Hard signals (usage telemetry from Copilot Dashboard)

- ≥ **5 consecutive weeks** of weekly Copilot active usage
- Used Copilot in ≥ **3 different M365 apps** (Chat + at least 2 of
  Word/Excel/PowerPoint/Outlook/Teams)
- Self-reported time saving ≥ **15 min/day** in a quick survey

### Soft signals

- Asked questions in the Multiplicadores office hours / Viva Engage
  community
- Completed at least one Copilot Academy badge (foundational)

### Institutional gate

- Self-inscrição via portal
- Manager approval (1-click form: "this person can dedicate ~6h in next
  quarter")

### Optional accelerator (waives usage gate if completed)

- Microsoft Applied Skill: *Configure Microsoft Copilot for everyday work*
- MS-4018.S (ESI — short version, 4h) ou equivalente Foundations

---

## Level 2 → 3 — Amplificado → Multiplicador

**Default candidate volume:** 1/3 of the Amplificado population.

### Hard signals

- ≥ **12 consecutive weeks** of weekly active usage
- Power User band on Copilot Dashboard (≥ 30 min/day saved)
- Used Copilot in ≥ **5 M365 apps** or built ≥ **1 prompt template**
  shared with peers

### Soft signals — these matter MORE at this level

- **Peer recommendation**: at least 2 colleagues recommend the person
  (1-click form in the community)
- **Teaching behavior**: shared at least 1 scenario / prompt / tip
  publicly in Viva Engage or office hours
- Volunteer attitude expressed in 1:1 with manager

### Institutional gate

- Self-nomination + **manager sponsor sign-off** ("I commit 10-20% of
  this person's time for next 6 months")
- Joining the Multiplicadores formal community

### Required (yes, required at this level)

- Complete **MS-4007 / MS-4007-successor** — *Microsoft 365 Copilot
  User Enablement Specialist* (official Microsoft Champion training)
- ⚠️ MS-4007 will be retired 03/31/2026 — check current SKU in
  `training-catalog.md` before citing externally.

### Optional accelerator

- Applied Skill: *Build a foundation to extend Microsoft 365 Copilot*
- Light cert path: AI-900 (foundational AI, helps general literacy)

---

## Level 3 → 4 — Multiplicador → Construtor

**Default candidate volume:** ~50% of the Multiplicador population.

> At this level the **portfolio gate** dominates. We are no longer
> measuring usage; we are measuring **building**.

### Hard signals

- Has delivered ≥ **1 declarative agent** in M365 Copilot OR ≥ 1 agent
  in Copilot Studio that is actually used by colleagues (not just a demo)
- Has documented the agent (purpose, data sources, governance review,
  feedback collected from users)

### Soft signals

- Active participation in the *Construtores* community (separate from
  the broader Multiplicadores community)
- Has paired with a Construtor existente on a small project

### Institutional gate

- Submit a **proposta de agente** (template: problema, dados, segurança,
  beneficiados, métrica de sucesso)
- AI Council reviews and approves the proposta
- Manager confirms 10% dedicated time

### Required training (in order)

- MS-4022 — *Extend Microsoft 365 Copilot in Copilot Studio* (3h)
- MS-4014 (or .S) — *Build a foundation to build AI agents and extend
  Microsoft 365 Copilot* (3-8h)
- PL-7008 — *Create agents in Microsoft Copilot Studio* (8h) **OR**
  MS-4017 — *Manage and extend Microsoft 365 Copilot* (depending on
  background)
- *Plus* the Applied Skill: *Enhance agents with autonomous capabilities*

---

## Level 4 → 5 — Construtor → Especialista

**Default candidate volume:** ~20% of the Construtor population.

> This is the **architect / advisor** tier. Selection is **curated** —
> not self-nomination at scale. The AI Council nominates candidates.

### Hard signals

- Has delivered ≥ **3 agents** of varying complexity, including at
  least 1 cross-departmental
- Has contributed to the **prompt + agent governance** framework
  (security, data classification, audit)
- Has mentored ≥ **1 Construtor** through their first agent

### Soft signals

- Speaks (internally or externally) about the program
- Co-authored a *scenario library* entry that another BU adopted

### Institutional gate

- **AI Council nomination** (curated, not self-service)
- Sponsorship by a director-level leader
- Time allocation **20-30%** formalized in the role description

### Required certification

- **AI-900** Azure AI Fundamentals (if not already done)
- Applied Skill: *Protect information in Microsoft 365 Copilot by using
  Microsoft Purview*
- (Strongly recommended) **AB-900 / agent-engineer cert** when available
- (Strongly recommended) **MB-820 / Copilot Studio cert** when available

---

## Demotion / step-back policy

Anyone at level 3+ who, over a quarter:

- Drops below weekly active usage for **8+ consecutive weeks** without
  a documented leave/role-change, OR
- Misses 3+ Champion / community commitments without notice

→ Returns to level 2 (Amplificado) with a clean re-entry path back to 3
in the next cycle. Frame this as **role rotation**, not punishment —
language matters a lot for retention.

---

## Telemetry sources

| Signal | Source | Refresh |
|---|---|---|
| Active usage by week / app | Microsoft Copilot Dashboard (Viva Insights) | Weekly |
| Time saved (self-report) | Quarterly survey via Forms | Quarterly |
| Peer recommendation | Forms in Viva Engage | On-demand |
| Manager sponsorship | Forms tied to HR org tree | On-demand |
| Cert completion | Microsoft Learn transcript (admin-pulled) | Monthly |
| Agent inventory | M365 admin center / Copilot Studio admin | Monthly |
| Office hour attendance | Teams attendance reports | Per session |

---

## Cycle cadence

- **Monthly** — Multiplicadores program team reviews pipeline of
  nominations and approvals
- **Quarterly** — AI Council reviews:
  - Level 3 → 4 nominations
  - Level 4 → 5 nominations (curated)
  - Step-back cases
  - Cohort health metrics

---

## Communication template (manager 1-click form)

> "I, [manager name], confirm that [employee name] can dedicate
> approximately [X%] of their time over the next [Y months] to act as a
> [level] in the Copilot adoption program. I commit to:
> - Supporting protected time in their calendar
> - Recognizing their contribution in performance review
> - Removing blockers when they surface
>
> I understand this is a [voluntary / role-rotation] commitment and the
> employee may step back at any time."

Keep the form to **3 fields** — simpler equals more participation.
