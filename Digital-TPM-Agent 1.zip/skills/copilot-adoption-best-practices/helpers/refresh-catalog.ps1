# Refresh ESI + Microsoft Learn catalogs for the
# copilot-adoption-best-practices skill, then re-render
# references/training-catalog.md.
#
# Run cadence: monthly, or after any Microsoft event that may have
# introduced new SKUs / retired old ones.
#
# Requirements:
#   - Azure CLI logged in as @microsoft.com (`az login`)
#   - Corporate VPN connected (for Dynamight reachability)
# If Dynamight is unreachable, the script still refreshes Microsoft
# Learn and reuses the cached ESI block, marking the catalog stale.

[CmdletBinding()]
param(
    [switch]$SkipDynamight,
    [switch]$SkipMSLearn
)

$ErrorActionPreference = 'Stop'
$root  = Split-Path $PSScriptRoot -Parent
$cache = Join-Path $root '_cache'
$refs  = Join-Path $root 'references'
New-Item -ItemType Directory -Path $cache -Force | Out-Null
New-Item -ItemType Directory -Path $refs  -Force | Out-Null

$now      = Get-Date
$nowStamp = $now.ToString('yyyy-MM-dd HH:mm')

function Log($msg) { Write-Host "[refresh-catalog] $msg" }

# ─────────────────────────────────────────────────────────────────────
# 1. ESI Catalog (Dynamight Dataverse OData)
# ─────────────────────────────────────────────────────────────────────
$esiOk   = $false
$esiPath = Join-Path $cache 'esi_copilot_catalog.json'

if (-not $SkipDynamight) {
    Log "Fetching ESI catalog from Dynamight..."
    try {
        $token = (az account get-access-token --resource "https://esiadmin.crm.dynamics.com/" --query accessToken -o tsv 2>$null)
        if (-not $token) { throw "No Azure CLI token — run 'az login'" }

        $headers = @{
            Authorization      = "Bearer $token"
            Accept             = "application/json"
            "OData-MaxVersion" = "4.0"
            "OData-Version"    = "4.0"
            "Prefer"           = 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
        }
        $base = "https://esiadmin.crm.dynamics.com/api/data/v9.2"

        $select = @(
            'msdyn_name','esi_title','msdyn_description','esi_courseprerequisites',
            'esi_audienceprofile','esi_standardduration','esi_catalogitemtype',
            'esi_deliverytypessupported','esi_deliveredby','esi_mslearnurl',
            'esi_externalurl','esi_itemtype','esi_creditvalue','esi_language',
            'esi_activedate','statuscode','esi_retirementdate','esi_sku','esi_tier'
        ) -join ','
        $filter = "statecode eq 0 and (contains(esi_title,'Copilot') or contains(msdyn_name,'Copilot') or contains(msdyn_description,'Copilot'))"
        $url    = "$base/msdyn_incidenttypes?`$filter=$filter&`$select=$select&`$orderby=msdyn_name&`$top=500"

        $resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -TimeoutSec 60
        $items = $resp.value
        Log "  -> $($items.Count) total Copilot-related ESI items"

        # Save with metadata
        @{
            fetchedAt = $nowStamp
            count     = $items.Count
            items     = $items
        } | ConvertTo-Json -Depth 8 | Out-File $esiPath -Encoding UTF8
        $esiOk = $true
    } catch {
        Log "  ⚠ ESI fetch failed: $_"
        Log "  Reusing cached ESI block if available."
    }
}

# ─────────────────────────────────────────────────────────────────────
# 2. Microsoft Learn Catalog API (no auth)
# ─────────────────────────────────────────────────────────────────────
$lrnOk   = $false
$lrnPath = Join-Path $cache 'mslearn_copilot_catalog.json'

if (-not $SkipMSLearn) {
    Log "Fetching Microsoft Learn catalog..."
    try {
        $wc = New-Object System.Net.WebClient
        $wc.Headers.Add("Accept","application/json")
        $apiBase = 'https://learn.microsoft.com/api/catalog'

        function FetchCatalog($url) {
            for ($i=0; $i -lt 3; $i++) {
                try {
                    return ($wc.DownloadString($url) | ConvertFrom-Json)
                } catch {
                    Start-Sleep -Seconds (3 * ($i + 1))
                }
            }
            return $null
        }

        $lp  = FetchCatalog "$apiBase/?type=learningPaths&product=microsoft-365-copilot&locale=en-us"
        Start-Sleep -Seconds 2
        $mod = FetchCatalog "$apiBase/?type=modules&product=microsoft-365-copilot&locale=en-us"
        Start-Sleep -Seconds 2
        $as  = FetchCatalog "$apiBase/?type=appliedSkills&locale=en-us"
        Start-Sleep -Seconds 2
        $certs = FetchCatalog "$apiBase/?type=certifications&locale=en-us"
        Start-Sleep -Seconds 2
        $exams = FetchCatalog "$apiBase/?type=exams&locale=en-us"
        Start-Sleep -Seconds 2
        $courses = FetchCatalog "$apiBase/?type=courses&locale=en-us"

        $asCopilot = @($as.appliedSkills | Where-Object {
            ($_.products -contains 'microsoft-365-copilot') -or
            ($_.products -contains 'copilot-studio') -or
            ($_.title -match 'Copilot|Agent')
        })
        $certsCopilot = @($certs.certifications | Where-Object {
            ($_.products -contains 'microsoft-365-copilot') -or
            ($_.products -contains 'copilot-studio') -or
            ($_.title -match 'Copilot|Agent') -or
            ($_.uid -match 'ai-fundamentals|ai-engineer|ai-900')
        })
        $examsCopilot = @($exams.exams | Where-Object {
            $_.title -match 'Copilot|Agent|AI-?900|MS-?900|AI-?102|AB-900|GH-900|PL-900' -or
            $_.uid -match 'ms-900|ai-900|ai-102|ab-900|gh-900|pl-900'
        })
        $coursesCopilot = @($courses.courses | Where-Object {
            $_.title -match 'Copilot|Agent'
        })

        @{
            fetchedAt      = $nowStamp
            learningPaths  = @($lp.learningPaths)
            modules        = @($mod.modules)
            appliedSkills  = $asCopilot
            certifications = $certsCopilot
            exams          = $examsCopilot
            courses        = $coursesCopilot
        } | ConvertTo-Json -Depth 8 | Out-File $lrnPath -Encoding UTF8

        Log "  -> LPs=$($lp.learningPaths.Count) Mods=$($mod.modules.Count) AS=$($asCopilot.Count) Certs=$($certsCopilot.Count) Exams=$($examsCopilot.Count) Courses=$($coursesCopilot.Count)"
        $wc.Dispose()
        $lrnOk = $true
    } catch {
        Log "  ⚠ Microsoft Learn fetch failed: $_"
        Log "  Reusing cached Learn block if available."
    }
}

# ─────────────────────────────────────────────────────────────────────
# 3. Render references/training-catalog.md
# ─────────────────────────────────────────────────────────────────────
$esi = if (Test-Path $esiPath) { Get-Content $esiPath -Raw | ConvertFrom-Json } else { $null }
$lrn = if (Test-Path $lrnPath) { Get-Content $lrnPath -Raw | ConvertFrom-Json } else { $null }

if (-not $esi -and -not $lrn) {
    throw "No cached data available — refresh aborted."
}

$esiItems = @()
if ($esi) {
    $esiItems = $esi.items | Where-Object {
        $_.'statuscode@OData.Community.Display.V1.FormattedValue' -eq 'Active'
    }
}

function Family($name) {
    if ($name -match '^MS-40')        { return 'MS-40xx — M365 Copilot core' }
    if ($name -match '^MS-')          { return 'MS-other' }
    if ($name -match '^AB-')          { return 'AB — Agentic AI for Business' }
    if ($name -match '^AI-')          { return 'AI — AI for Business Users' }
    if ($name -match '^AZ-')          { return 'AZ — Azure (Copilot context)' }
    if ($name -match '^CEUT-')        { return 'CEUT — Curated End User Training' }
    if ($name -match '^DP-')          { return 'DP — Data / Fabric Copilot' }
    if ($name -match '^DW-')          { return 'DW — Discovery Workshops' }
    if ($name -match '^GH-')          { return 'GH — GitHub Copilot' }
    if ($name -match '^MD-')          { return 'MD — Modern Workplace devices' }
    if ($name -match '^PL-')          { return 'PL — Power Platform' }
    if ($name -match '^SC-')          { return 'SC — Security Copilot' }
    if ($name -match '^SB-')          { return 'SB — Subscriptions (3rd-party / Microsoft)' }
    if ($name -match '^VTD-')         { return 'VTD — Virtual Training Days' }
    if ($name -match '^FY')           { return 'FYxx — Legacy VTDs' }
    return 'Other'
}

function CleanText($s) {
    if (-not $s) { return '' }
    $t = $s -replace '\r?\n',' ' -replace '<[^>]+>','' -replace '\s+',' '
    return $t.Trim()
}

function Trim200($s) {
    $s = CleanText $s
    if ($s.Length -gt 200) { return $s.Substring(0,200) + '…' }
    return $s
}

$staleNote = ""
if (-not $esiOk -and -not $SkipDynamight) {
    $staleNote += "`n> ⚠️ **ESI block is STALE** — Dynamight was unreachable during the last refresh. Last successful fetch was $($esi.fetchedAt). Re-run with VPN connected.`n"
}
if (-not $lrnOk -and -not $SkipMSLearn) {
    $staleNote += "`n> ⚠️ **Microsoft Learn block is STALE** — API unreachable during the last refresh. Last successful fetch was $($lrn.fetchedAt).`n"
}

$sb = New-Object System.Text.StringBuilder

[void]$sb.AppendLine("# Catálogo de Treinamentos M365 Copilot — vigente")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("> Living catalog. **Do not edit by hand** — re-run ``helpers\refresh-catalog.ps1`` to refresh.")
[void]$sb.AppendLine("> Last refresh: **$nowStamp**")
[void]$sb.AppendLine("> ESI fetch: $($esi.fetchedAt) — $($esiItems.Count) active items (of $($esi.count) total)")
[void]$sb.AppendLine("> Microsoft Learn fetch: $($lrn.fetchedAt) — $($lrn.learningPaths.Count) LPs · $($lrn.modules.Count) modules · $($lrn.appliedSkills.Count) Applied Skills · $($lrn.certifications.Count) certifications · $($lrn.exams.Count) exams · $($lrn.courses.Count) courses")
if ($staleNote) { [void]$sb.AppendLine($staleNote) }
[void]$sb.AppendLine("")

# Retirement warnings — items with retirementdate in next 12 months
$soon = $esi.items | Where-Object {
    $_.esi_retirementdate -and ([datetime]$_.esi_retirementdate) -gt $now -and
    ([datetime]$_.esi_retirementdate) -lt $now.AddMonths(12)
} | Sort-Object esi_retirementdate
if ($soon) {
    [void]$sb.AppendLine("## ⚠️ Avisos de retirement (próximos 12 meses)")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("| ID | Title | Retirement date |")
    [void]$sb.AppendLine("|---|---|---|")
    foreach ($it in $soon) {
        $d = ([datetime]$it.esi_retirementdate).ToString('yyyy-MM-dd')
        [void]$sb.AppendLine("| ``$($it.msdyn_name)`` | $(CleanText $it.esi_title) | **$d** |")
    }
    [void]$sb.AppendLine("")
}

# Suggested mapping by level (curated — manual, will need re-tuning over time)
[void]$sb.AppendLine("## Mapeamento sugerido por nível do funil")
[void]$sb.AppendLine("")
[void]$sb.AppendLine('> Padrão sugerido. Cada cliente refina pelo perfil real. Para o detalhe das fontes, ver `adoption-framework.md`.')
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Nível | ESI primário | ESI complementar | Microsoft Learn (opcional) |")
[void]$sb.AppendLine("|---|---|---|---|")
[void]$sb.AppendLine("| **1 · Capacitado** | ``MS-4018.S`` (4h) ou ``CEUT-4019`` (1h) | ``MS-4023`` Copilot Chat (1.5h), ``DW-0370`` (3x2h sessões) | LP: *Get started with Microsoft 365 Copilot* · Applied Skill: *Configure Copilot for everyday work* |")
[void]$sb.AppendLine("| **2 · Amplificado** | ``MS-4018`` full (8h) + ``MS-4019.S`` (1.5h) | ``MS-4004.*`` por persona (1h cada), ``MS-4021`` CIE (6x1.5h) | LP: *Plan and execute a Microsoft 365 Copilot rollout* |")
[void]$sb.AppendLine("| **3 · Multiplicador** | ``MS-4007`` Copilot User Enablement Specialist¹ | ``MS-4019`` full (8h), ``DW-101`` (3x4h) | Applied Skill: *Build a foundation to extend M365 Copilot* · AI-900 entry cert |")
[void]$sb.AppendLine("| **4 · Construtor** | ``MS-4022`` (3h) + ``MS-4014.S`` (3h) | ``PL-7008`` (8h), ``MS-4017`` (8h), ``DW-102`` (3x4h) | Applied Skill: *Enhance agents with autonomous capabilities* |")
[void]$sb.AppendLine("| **5 · Especialista** | ``MS-4014`` full (8h) + ``AB-100`` (3x8h) | ``DW-104`` (2x4h), ``DW-107`` (4h), ``DW-112`` (3x4h) | Applied Skill: *Protect information in M365 Copilot with Purview* · AI-900 cert |")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("¹ ⚠️ MS-4007 retired 03/31/2026 — quando esse arquivo for refrescado após essa data, o helper deve buscar o sucessor (ver bloco *Avisos de retirement*).")
[void]$sb.AppendLine("")

# ─── ESI Catalog by family ───
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## ESI Catalog (Dynamight) — ativos, agrupados por família")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("Convenções de sufixos comuns:")
[void]$sb.AppendLine("- ``.S`` = Short version (3-4h em vez de 8h)")
[void]$sb.AppendLine("- ``.PE/.PF/.PO`` e ``.01-.13`` = customizações por persona (Executive, Finance, Operations, IT, Legal, etc.)")
[void]$sb.AppendLine("- ``.OE`` = OE Only (Open Enrollment, não disponível como PD)")
[void]$sb.AppendLine("- ``-PE`` no fim = Practice Exam (não é treinamento, é simulado)")
[void]$sb.AppendLine("- ``T00`` = Trainer-led variant")
[void]$sb.AppendLine("")

$grouped = $esiItems | Group-Object { Family $_.msdyn_name } | Sort-Object Name
foreach ($g in $grouped) {
    [void]$sb.AppendLine("### $($g.Name) — $($g.Count) itens")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("| ID | Title | Duration | Type | Delivery | Audience (resumo) |")
    [void]$sb.AppendLine("|---|---|---|---|---|---|")
    foreach ($it in ($g.Group | Sort-Object msdyn_name)) {
        $id    = $it.msdyn_name
        $title = CleanText $it.esi_title
        $dur   = $it.esi_standardduration
        $type  = $it.'esi_catalogitemtype@OData.Community.Display.V1.FormattedValue'
        $del   = $it.'esi_deliverytypessupported@OData.Community.Display.V1.FormattedValue'
        $aud   = Trim200 $it.esi_audienceprofile
        if (-not $aud) { $aud = '—' }
        [void]$sb.AppendLine("| ``$id`` | $title | $dur | $type | $del | $aud |")
    }
    [void]$sb.AppendLine("")
}

# ─── Microsoft Learn block ───
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Microsoft Learn — conteúdo M365 Copilot")
[void]$sb.AppendLine("")

[void]$sb.AppendLine("### Learning Paths ($($lrn.learningPaths.Count))")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Title | Min | Level(s) | Pop | URL |")
[void]$sb.AppendLine("|---|---|---|---|---|")
foreach ($p in ($lrn.learningPaths | Sort-Object { -1 * $_.popularity })) {
    $lvl = ($p.levels -join ',')
    $pop = [math]::Round($p.popularity, 2)
    [void]$sb.AppendLine("| $(CleanText $p.title) | $($p.duration_in_minutes) | $lvl | $pop | [link]($($p.url)) |")
}
[void]$sb.AppendLine("")

[void]$sb.AppendLine("### Applied Skills ($($lrn.appliedSkills.Count))")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Title | Level | Min | URL |")
[void]$sb.AppendLine("|---|---|---|---|")
foreach ($a in ($lrn.appliedSkills | Sort-Object title)) {
    $lvl = ($a.levels -join ',')
    [void]$sb.AppendLine("| $(CleanText $a.title) | $lvl | $($a.duration_in_minutes) | [link]($($a.url)) |")
}
[void]$sb.AppendLine("")

[void]$sb.AppendLine("### Certifications ($($lrn.certifications.Count))")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Title | Level | Exams | URL |")
[void]$sb.AppendLine("|---|---|---|---|")
foreach ($c in ($lrn.certifications | Sort-Object title)) {
    $lvl = ($c.levels -join ',')
    $exams = ($c.exams -join ', ')
    [void]$sb.AppendLine("| $(CleanText $c.title) | $lvl | $exams | [link]($($c.url)) |")
}
[void]$sb.AppendLine("")

[void]$sb.AppendLine("### Exams (Copilot / Agent / AI-fundamentals) ($($lrn.exams.Count))")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Title | UID | URL |")
[void]$sb.AppendLine("|---|---|---|")
foreach ($e in ($lrn.exams | Sort-Object title)) {
    [void]$sb.AppendLine("| $(CleanText $e.title) | ``$($e.uid)`` | [link]($($e.url)) |")
}
[void]$sb.AppendLine("")

[void]$sb.AppendLine("### Modules ($($lrn.modules.Count)) — top 30 por popularidade")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Title | Min | Level | Pop | URL |")
[void]$sb.AppendLine("|---|---|---|---|---|")
$topMods = $lrn.modules | Sort-Object { -1 * $_.popularity } | Select-Object -First 30
foreach ($m in $topMods) {
    $lvl = ($m.levels -join ',')
    $pop = [math]::Round($m.popularity, 2)
    [void]$sb.AppendLine("| $(CleanText $m.title) | $($m.duration_in_minutes) | $lvl | $pop | [link]($($m.url)) |")
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("> Lista completa de módulos no arquivo ``_cache/mslearn_copilot_catalog.json``.")
[void]$sb.AppendLine("")

if ($lrn.courses -and $lrn.courses.Count -gt 0) {
    [void]$sb.AppendLine("### Courses (ILT/MOC catalog) — relacionados a Copilot/Agent ($($lrn.courses.Count))")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("| Title | UID | Hours | URL |")
    [void]$sb.AppendLine("|---|---|---|---|")
    foreach ($c in ($lrn.courses | Sort-Object title)) {
        [void]$sb.AppendLine("| $(CleanText $c.title) | ``$($c.uid)`` | $($c.duration_in_hours) | [link]($($c.url)) |")
    }
    [void]$sb.AppendLine("")
}

# Footer
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Como re-executar")
[void]$sb.AppendLine("")
[void]$sb.AppendLine('```powershell')
[void]$sb.AppendLine('cd $env:USERPROFILE\.copilot\skills\copilot-adoption-best-practices')
[void]$sb.AppendLine('.\helpers\refresh-catalog.ps1')
[void]$sb.AppendLine('# Opções:')
[void]$sb.AppendLine('#   -SkipDynamight  → não tenta Dynamight (útil sem VPN)')
[void]$sb.AppendLine('#   -SkipMSLearn    → não atualiza bloco MSLearn')
[void]$sb.AppendLine('```')
[void]$sb.AppendLine('')

$out = Join-Path $refs 'training-catalog.md'
$sb.ToString() | Out-File $out -Encoding UTF8 -NoNewline
Log "Wrote $out ($([math]::Round((Get-Item $out).Length / 1KB, 1)) KB)"

# ─────────────────────────────────────────────────────────────────────
# 4. Append CHANGELOG
# ─────────────────────────────────────────────────────────────────────
$logPath = Join-Path $cache 'CHANGELOG.md'
if (-not (Test-Path $logPath)) {
    "# Refresh Log`n`n" | Out-File $logPath -Encoding UTF8
}
$entry = "- **$nowStamp** — ESI: $($esiItems.Count) active (esiOk=$esiOk) · MSLearn: $($lrn.learningPaths.Count) LPs / $($lrn.modules.Count) modules / $($lrn.appliedSkills.Count) AS / $($lrn.certifications.Count) certs / $($lrn.exams.Count) exams (lrnOk=$lrnOk)"
Add-Content -Path $logPath -Value $entry -Encoding UTF8
Log "CHANGELOG updated"

Log "Done."
