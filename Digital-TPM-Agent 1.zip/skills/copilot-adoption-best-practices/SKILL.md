---
name: copilot-adoption-best-practices
description: >
  Living playbook for Microsoft 365 Copilot adoption at enterprise scale —
  evidence base (Work Trend Index, ROI), Champions program, 4-phase model,
  3-tier skill progression, 5-level proficiency funnel
  (Capacitado→Amplificado→Multiplicador→Construtor→Especialista) with
  promotion criteria, and the complete catalog of current Copilot trainings
  (ESI/Dynamight + Microsoft Learn paths, modules, applied skills,
  certifications, exams). Every Copilot adoption plan should anchor here.
  Use to plan/scale/sell a Copilot adoption, pull audience-tier mappings,
  promotion gates, skilling sequences, ESI SKUs, or MS Learn trails.
  Includes refresh helper for ESI + MSLearn catalogs. Triggers: copilot
  adoption, adoção copilot, plano de adoção copilot, copilot at scale,
  champion program, programa champions, multiplicadores copilot, funil
  proficiência copilot, copilot skilling, capacitação copilot, copilot
  training catalog, catálogo treinamentos, MS-4018, MS-4019, MS-4007,
  MS-4021, CEUT-4019, CIE, melhores práticas adoção copilot.
---

# Copilot Adoption Best Practices — Living Playbook

> **Purpose.** Single source of truth that every Copilot adoption plan
> (deck, proposal, training matrix) must reference. Combines official
> Microsoft frameworks, evidence from Microsoft research, and the
> complete catalog of M365 Copilot trainings we can actually deliver
> through ESI + MSLearn.

## When to use this skill

Load whenever the user is:

- Building or refining a **Copilot adoption plan** for any customer
  (e.g., [CLIENTE], [CLIENTE], [CLIENTE]) — small or enterprise scale
- Proposing a **proficiency funnel** (5-level model: Capacitado →
  Amplificado → Multiplicador → Construtor → Especialista) or any
  variant of "users → power users → champions → makers → builders"
- Designing a **Champions/Multiplicadores program** — selection
  criteria, duties, branding, community structure, comms cadence
- Selecting **specific trainings** by audience tier — needs a
  current-on-the-day list of ESI SKUs and MSLearn paths/applied skills
- Defining **promotion criteria** between levels — usage telemetry,
  cert gates, peer-recommendation, portfolio evidence
- Citing **evidence** (Work Trend Index numbers, Power User profile,
  ROI/TEI data) on a sales slide or executive briefing
- Mapping **certifications** as optional adoption stepping stones
  (MS-4007 → MS-4014 → AB-900 → Applied Skills, etc.)

## Companion skills

| Skill | Role |
|---|---|
| **copilot-success-kit** | Owns the 7 master decks (Implementation Summary, User Enablement Guide, Technical Readiness, etc.). Use to pull official Microsoft slides into a customer-facing deck. **This skill complements** it with custom frameworks + delivery catalog. |
| **training-catalog** | Generic catalog navigation (any product). This skill is the **Copilot-specific** vertical with curated mapping by adoption tier. |
| **organizational-skilling-slides** | SV1 visual system for building skilling decks. Use after this skill for layout/visual rules. |
| **business-value-study** | When evidence here is needed in a BVS — links to the value calculator KPIs. |
| **dynamight-esi-admin** | Source of truth for ESI Catalog Item entities. Refresh helper here uses its OData patterns. |
| **ms-learn** | Source of truth for Learn Catalog API. Refresh helper here uses its query patterns. |

## File map

```
copilot-adoption-best-practices/
├── SKILL.md                              ← this file
├── references/
│   ├── training-catalog.md               ← 🎯 living catalog (ESI + Learn) — refreshed by helper
│   ├── evidence-base.md                  ← Work Trend Index, ROI, hiring stats with sources
│   ├── adoption-framework.md             ← Champion program, 4-phase, 3-tier skill progression,
│   │                                       5-level Brazilian proficiency funnel (proposta da casa)
│   ├── promotion-criteria.md             ← gates between levels (usage + nomination + cert)
│   └── customer-examples.md              ← Brazilian case library (seed: [CLIENTE], [CLIENTE],
│                                           [CLIENTE]) — appended over time
├── helpers/
│   └── refresh-catalog.ps1               ← re-fetch ESI Dynamight + MSLearn API, re-render
│                                          references/training-catalog.md + _cache/*.json
└── _cache/
    ├── esi_copilot_catalog.json          ← raw ESI export (~100 active items)
    ├── mslearn_copilot_catalog.json      ← raw Learn export (paths, modules, applied skills, certs)
    └── CHANGELOG.md                      ← refresh log (date + counts + delta highlights)
```

## How to read the catalog

`references/training-catalog.md` is the **authoritative list of
trainings vigentes** for any Copilot adoption plan we propose. It is
organized in three layers:

1. **By proficiency level** (top of file) — quick "which trainings for
   which tier" answer. Use this when designing waves.
2. **By family** (ESI Catalog) — MS-40xx, CEUT-xxxx, AB-xxx, DW-xxx,
   GH-300, VTD-xxx, etc. Use this when validating SKU codes for a
   PD/OE/TSPc request.
3. **Microsoft Learn track** (paths, modules, applied skills,
   certifications) — use this when proposing self-paced or certification
   gates as promotion criteria.

Each ESI item carries: ID, title, type, duration, delivery modes
(OE/Private), language, audience profile, retirement date if any.

> ⚠️ **Always re-check `statuscode`** for any SKU you cite before
> sending to a customer — see training-catalog skill § Rule 1.
> The refresh helper here already filters out items with
> statuscode = "Retired", but a SKU may retire between refreshes.

## Refresh cadence

- **Mandatory** before any adoption plan PPT/proposal goes external
- **Monthly** as a hygiene baseline
- **After Microsoft events** — Ignite, Build, MTT Global Connect,
  major product GA announcements (any of these typically introduce new
  SKUs or retire old ones)
- **Manual ad-hoc** when a TPC mentions a new course code we don't
  recognize

To refresh:

```powershell
cd $env:USERPROFILE\.copilot\skills\copilot-adoption-best-practices
.\helpers\refresh-catalog.ps1
```

The helper will:
1. Hit Dynamight OData (requires `az login` + corporate VPN)
2. Hit `learn.microsoft.com/api/catalog` (no auth)
3. Save raw JSON to `_cache/`
4. Re-render `references/training-catalog.md`
5. Append a CHANGELOG entry with date, totals, and delta vs last run

If Dynamight access fails (no VPN), the helper still refreshes the
Microsoft Learn section and reuses the cached ESI block (with a stale
warning at the top of the catalog file).

## Voice & branding notes

- This skill produces **internal artifacts** (planning material) and
  **customer-facing evidence** (slide content). When citing numbers
  externally, always include the source (Microsoft Work Trend Index
  2024, etc.) — see `references/evidence-base.md`.
- For **government customers (PT-BR)** prefer institutional vocabulary:
  *capacitado, amplificado, multiplicador, construtor, especialista*
  (the standardized 5-level proficiency funnel) instead of anglicisms.

## Adding a new customer example

After delivering an adoption wave at a customer, append to
`references/customer-examples.md` a short entry:

```markdown
### {Customer} — {YYYY-MM}
- **Scale:** {N licenses} · {N trained per tier}
- **Approach:** {brief}
- **Outcomes:** {measured KPIs}
- **Lessons learned:** {what we'd change}
- **Source artifacts:** {OneDrive paths / deck file names}
```

Keep entries factual and short — this is institutional memory for
re-use, not marketing prose.
