---
name: copilot-success-kit
description: >
  Microsoft 365 Copilot Success Kit — official asset library from
  adoption.microsoft.com mirrored locally: 7 master decks + worksheets
  used to plan and execute Copilot adoption at enterprise scale. Use
  when building a customer Copilot adoption plan, change management
  story, exec briefing, technical readiness checklist, or training
  content map and you need authoritative Microsoft visuals (with
  animations) to anchor the narrative. Includes helpers to extract
  specific slides preserving animations via PowerPoint COM and to
  translate them in-place to pt-BR. Triggers: copilot success kit,
  success kit, adoption kit, copilot adoption plan, plano de adoção
  copilot, kit de sucesso copilot, implementation summary guide, user
  enablement guide, technical readiness guide, business results
  copilot, viva copilot, training content map, scenario library,
  license allocation guide, adoption planning checklist.
---

# Copilot Success Kit — Official Microsoft adoption asset library

Mirror of the **Microsoft 365 Copilot Success Kit** from
`https://adoption.microsoft.com/en-us/copilot/success-kit/`, cached
locally for offline use and reuse in customer-facing plans.

## When to use this skill

Load when the user asks you to:

- Build a **customer Copilot adoption plan** (PPTX) and wants Microsoft's
  official intro slides (framework, 3-essentials, readiness checklist,
  change management) as the front matter — "use os slides do adoption",
  "use os slides do success kit", "intro do success kit", "slides da
  Microsoft pra adoção".
- Reference a **specific guide**: Implementation Summary for Leaders,
  User Enablement Guide, Technical Readiness Guide, Delivering Business
  Results, Accelerate with Viva, Training Content Map, License
  Allocation Guide.
- Pull a **template asset** (Stakeholder Engagement worksheet, Adoption
  Planning Checklist, User Experience Strategy doc) for a customer.
- Need authoritative Microsoft visuals for executive briefings, change
  management decks, or technical readiness presentations.

> ⚠️ **License & branding rule.** These assets are Microsoft IP intended
> for partner/customer use. Always keep Microsoft attribution visible on
> slides reused verbatim. Translation is allowed; structural redesign of
> Microsoft-branded slides is not — if you need a different layout,
> build your own from scratch and cite the kit as inspiration.

## Kit inventory (cached locally)

Located at `_cache\extracted\`. Refresh from
`https://aka.ms/Copilot/SuccessKitDownload` if older than 90 days.

| File | Size | Slides | Purpose |
|---|---|---|---|
| `1_StartHere.pptx` | 24 MB | 2 | Welcome / kit overview |
| `2_ImplementationSummaryGuideForLeaders_Microsoft365Copilot.pptx` | 5 MB | 24 | **Executive overview** — framework, 3 essentials, sponsorship, AI Council, scenarios, change management, technical readiness, Copilot Studio, co-investment. **Best source for intro/framework slides.** |
| `3_UserEnablementGuide_Microsoft365Copilot.pptx` | 37 MB | many | User enablement deep-dive — onboarding, training paths, communications, champions network |
| `4_TechnicalReadinessGuide_Microsoft365Copilot.pptx` | 56 MB | many | Technical readiness — licensing, security, compliance, deployment phases |
| `5_DeliveringBusinessResultswithMicrosoft365Copilot.pptx` | 105 MB | many | Business value, scenarios by function, ROI framework, measurement |
| `6_AccelerateCopilotEnablementwithMicrosoftViva.pptx` | 56 MB | many | Viva integration for Copilot adoption |
| `7_TrainingContentMap.pptx` | 4 MB | small | Training catalog map (MS-40xx series, MS Learn paths) |
| `License_allocation_guidance.pptx` | 6 MB | small | License targeting framework (who gets Copilot first) |
| `AdoptionPlanningChecklist.xlsx` | 30 KB | — | Phased adoption checklist |
| `GetReady_StakeholderEngagementWorksheet.xlsx` | 50 KB | — | Stakeholder map worksheet |
| `GetReady_User-Experience-Strategy.docx` | 60 KB | — | UX strategy template |

### Index of key slides in Implementation Summary deck (#2)

(Validated reading 2026-05-19. Slide numbers are 1-indexed.)

| # | Title (EN) | Use case |
|---|---|---|
| 2 | Microsoft 365 Copilot implementation framework | **Hero intro slide** — front matter for any adoption plan |
| 3 | Copilot Control System | Govern Copilot + Agents at scale |
| 4 | 5 in 1 AI capabilities with Microsoft 365 Copilot | Capability overview |
| 5 | Where Copilot wows | Use case showcase |
| 6 | 3 essentials for Copilot success (Leadership) | Framing for leadership track |
| 7 | Microsoft 365 Copilot implementation (readiness checklist) | Implementation overview |
| 8 | 3 essentials for Copilot success (Technical readiness) | Framing for tech track |
| 9 | Secure exec sponsorship (ABCs) | Sponsorship motion |
| 10 | Clarify AI value drivers | Value driver framework |
| 11 | Create an AI Council | Governance recommendation |
| 12 | Identify initial high-value Copilot scenarios | Scenario discovery |
| 14 | 3 essentials for Copilot success (Leadership recap) | Section divider |
| 15 | Implementation executive summary (Human change) | Change mgmt intro |
| 16 | Drive human change with best practices | Change management playbook |
| 17 | Lay the foundation for continuous learning | **Skilling rationale** |
| 18 | Accelerate your AI workforce transformation | Communications + skilling |
| 19 | 3 essentials for Copilot success (User enablement) | Framing for skilling track |
| 21 | M365 Copilot Optimization Assessment | Get ready step |
| 22 | Extend & optimize | Drive value loop |
| 23 | Microsoft Copilot Studio | Build your own agents |
| 24 | Microsoft investments to accelerate time to value | Partner co-investment |

## Workflows

### Workflow 1 — Extract intro slides for a customer plan (preserving animations)

> **Rule:** PowerPoint COM is the ONLY way to preserve animations when
> cloning slides across decks. `python-pptx` will lose them.
>
> **Use `helpers\extract_slides_v2.ps1`** — it uses `Slides.InsertFromFile`
> which bypasses the clipboard race conditions of the older Copy/Paste
> pattern (kept as `extract_slides.ps1` for reference; do not use).

```powershell
# Example: pull slides 2, 6, 7, 17, 18 from Implementation Summary deck
.\helpers\extract_slides_v2.ps1 `
  -SourceDeck "$skill\_cache\extracted\2_ImplementationSummaryGuideForLeaders_Microsoft365Copilot.pptx" `
  -SlideNumbers 2,6,7,17,18 `
  -OutputDeck "C:\Temp\customer_intro_base.pptx"
```

The helper:
1. Opens source deck via `Powerpoint.Application` COM
2. Creates new deck with same dimensions, deletes default blank slide
3. For each requested slide: `Slides.InsertFromFile(file, index, n, n)`
   (animations, transitions, embedded media, theme — all preserved)
4. Saves with `FileFormat = 24` (`ppSaveAsOpenXMLPresentation` → real `.pptx`)
5. Closes PowerPoint, kills any orphan PIDs spawned by this run
6. Returns path to the new deck

> ⚠️ **Always pass `FileFormat = 24` to `SaveAs`.** Otherwise PowerPoint
> COM defaults to legacy OLE binary (`D0 CF 11 E0`) inside a `.pptx`
> extension — `python-pptx` cannot read it. The v2 helpers already handle
> this; if you write your own COM script, do not forget.
>
> ⚠️ **Write build artifacts to `C:\Temp\<job>\`, NOT directly to OneDrive.**
> OneDrive's background indexing/preview/sync process converts freshly
> written PPTX files into legacy OLE binary within ~1 minute, breaking
> python-pptx round-trips. Build everything locally, then **copy** the
> final artifact to OneDrive as a single transfer at the end.

### Workflow 2 — Translate slides in-place to pt-BR (or any language)

> **Rule:** Translation must preserve layout, fonts, animations, and
> imagery. Walk every text run, replace English text with the
> translation, save back. **Do not** delete or recreate shapes.

```powershell
.\helpers\translate_slides.ps1 `
  -DeckPath "C:\...\customer_intro_base.pptx" `
  -TargetLang "pt-BR" `
  -TranslationDict "$skill\helpers\translations_ptBR.json"
```

The helper:
1. Opens deck via COM
2. Iterates every slide → every shape → every paragraph → every run
3. Looks up the English run text in `translations_ptBR.json`
4. If found: replaces text, preserves font/size/color/bold
5. If not found: emits to console as `[MISSING] "english text"` for the
   user to add to the dictionary
6. Saves deck

### Workflow 3 — Compose a new customer adoption plan

End-to-end pattern (proven on [CLIENTE] 2026-05-19):

1. **Build directory**: create `C:\Temp\<customer>_build\` — do NOT
   build in OneDrive (sync will corrupt PPTX files mid-write).
2. **Extract Microsoft intro slides** via `extract_slides_v2.ps1`
   → `<build>\customer_intro_EN.pptx` (5 slides typical)
3. **Build custom plan slides** via `python-pptx` script
   → `<build>\customer_custom_PTBR.pptx` (20-25 slides typical)
4. **Merge** via `merge_decks_v2.ps1` (uses InsertFromFile, OOXML-safe)
   → `<build>\Plano_<Customer>.pptx` (final)
5. **Audit links** with `_audit_*.py` (HTTP 200 check on every hyperlink;
   ignore OOXML schema URIs per `learning-trail-pptx` §5c)
6. **Copy** final file to OneDrive as a SINGLE transfer
   → `{{WORKDIR}}\Plano_<Customer>.pptx`
7. Write a **NOTAS.md** alongside documenting assumptions, defaults,
   open items, and intro slides that still need translation
8. **Translate** intro slides in a second pass (see Workflow 2)

### Workflow 4 — Pull a specific worksheet/template

```powershell
Copy-Item "$skill\_cache\extracted\GetReady_StakeholderEngagementWorksheet.xlsx" `
          "{{USERPROFILE}}\OneDrive - Microsoft\Clientes\<Customer>\<file>"
```

The `.xlsx`/`.docx` assets are not localized — open them, the user
translates inline as needed.

## Refresh policy

- **Re-download** the kit if the last validated download is older than
  **90 days** OR the user explicitly asks to "refresh the success kit".
- Track last refresh in `_cache\_last_refresh.txt` (ISO date).
- Microsoft updates the kit frequently; quarterly refresh is safest.

## URL reference (validated)

| Asset | URL |
|---|---|
| Full kit (EN, 293 MB ZIP) | `https://aka.ms/Copilot/SuccessKitDownload` |
| Landing page (EN) | `https://adoption.microsoft.com/en-us/copilot/success-kit/` |
| Landing page (pt-BR) | `https://adoption.microsoft.com/pt-br/copilot/success-kit/` |
| Implementation Summary Guide | `https://aka.ms/Copilot/ImplementationSummaryGuide` |
| User Enablement Guide | `https://aka.ms/Copilot/UserEnablementGuide` |
| Technical Readiness Guide | `https://aka.ms/Copilot/TechnicalReadinessGuide` |
| Stakeholder Engagement Worksheet | `https://aka.ms/Copilot/StakeholderManagementWorksheet` |
| Adoption Planning Checklist | `https://aka.ms/Copilot/AdoptionPlanningChecklist` |
| License Allocation Guide | `https://aka.ms/Copilot/LicenseAllocationGuide` |
| Scenario Library | `https://aka.ms/Copilot/ScenarioLibrary` |
| Agents Get Started | `https://aka.ms/Copilot/AgentsGetStarted` |
| Quick Start Guide | `https://aka.ms/Copilot/QuickStartGuide` |
| Recommended Prompts | `https://adoption.microsoft.com/files/copilot/RecommendedPromptsForMicrosoft365Copilot.pptx` |
| Chat & Agent Starter Kit | `https://aka.ms/Copilot/ChatAgentStarterKit` |
| Agent Success Kit | `https://adoption.microsoft.com/agents/success-kit/` |
| Modern Management of M365 Apps | `https://aka.ms/ModernManagementofM365Apps` |
| Copilot Chat User Onboarding Templates | `https://aka.ms/Copilot/CopilotChatUserOnboardingTemplates` |
| Virtual Skilling Event Framework | `https://adoption.microsoft.com/copilot/user-engagement-tools-and-templates/virtual-skilling-event-framework/` |
| Copilot Prompt-a-thon | `https://aka.ms/Copilot/Promptathon` |

> ⚠️ **`aka.ms/...` localization caveat.** The `aka.ms` redirects do NOT
> serve a pt-BR variant — they all resolve to the English asset. The
> "9 additional languages" mentioned on the landing page are NOT
> downloadable via separate aka.ms links; translations are baked into
> the SuccessKitDownload ZIP only for some files (verify per file).
> When the user needs pt-BR, the practical path is **Workflow 2**:
> extract EN slides and translate in-place.

## Cross-reference

- **`learning-trail-pptx`** — for the link-audit script pattern and
  hyperlink validation rules
- **`treinamento-plan-designer`** — agent that orchestrates full
  capacitação plan creation (calls this skill for intro slides)
- **`private-deliveries`** — for PDc/TSPc credit cost / delivery rules
  that go into the "Investment" slide of an adoption plan
- **`swm-hvs-scale-rules`** — for course capacities (MS-4023, MS-4018.S,
  MS-4019.s, MS-4021) used in plan sizing
- **`oe-schedule`** — for pulling complementary OE class grids
- **`training-catalog`** — for course descriptions (ementas) in plan
  appendices

## History

- **2026-05-19** — Skill created. Cached kit v.2026-02-23 (293 MB).
  Inventoried 7 master decks + worksheets. Implementation Summary deck
  indexed slide-by-slide. Used to build [CLIENTE] Copilot
  adoption plan (28 slides: 5 EN intro + 23 pt-BR custom).
- **2026-05-19 (v2 helpers)** — Replaced the original `extract_slides.ps1`
  and `merge_decks.ps1` (which used `Slide.Copy()` + `Slides.Paste()`)
  with `_v2.ps1` variants that use `Slides.InsertFromFile`. The
  clipboard pattern failed with `Slides.Paste: Invalid request. Clipboard
  is empty` even with paste delays — InsertFromFile is reliable.
  Also added explicit `FileFormat = 24` to `SaveAs` calls — without it,
  COM saves as legacy OLE binary inside `.pptx` extension and python-pptx
  cannot read the result.
- **2026-05-19 (OneDrive gotcha)** — Empirically confirmed that OneDrive's
  background process converts freshly-written python-pptx files into
  legacy OLE format within ~1 minute. Documented in Workflow 3 + 1:
  always build in `C:\Temp\<job>\` and copy the final artifact to OneDrive
  as a single transfer.
