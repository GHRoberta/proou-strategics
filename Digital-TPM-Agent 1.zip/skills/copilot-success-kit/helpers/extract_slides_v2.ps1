# extract_slides_v2.ps1 — Robust slide extractor using Slides.InsertFromFile
# (bypasses clipboard race conditions of the Copy/Paste pattern).
#
# Usage:
#   .\extract_slides_v2.ps1 `
#     -SourceDeck "C:\path\to\source.pptx" `
#     -SlideNumbers 2,6,7,17,18 `
#     -OutputDeck "C:\path\to\output.pptx"
#
# Notes:
#   - InsertFromFile inserts one range at a time. We call it once per
#     requested slide so order is preserved exactly as requested.
#   - Theme/masters/animations come along automatically.

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)] [string]$SourceDeck,
  [Parameter(Mandatory=$true)] [int[]] $SlideNumbers,
  [Parameter(Mandatory=$true)] [string]$OutputDeck
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $SourceDeck)) { throw "Source deck not found: $SourceDeck" }
$SourceDeck = (Resolve-Path $SourceDeck).Path
$OutputDir = Split-Path $OutputDeck -Parent
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null }
$OutputDeck = [System.IO.Path]::GetFullPath($OutputDeck)

Write-Host "Source : $SourceDeck"
Write-Host "Slides : $($SlideNumbers -join ', ')"
Write-Host "Output : $OutputDeck"

$existing = Get-Process POWERPNT -ErrorAction SilentlyContinue

$pp = $null; $src = $null; $dst = $null
try {
  $pp = New-Object -ComObject PowerPoint.Application
  $pp.Visible = $true
  $pp.WindowState = 2  # minimized

  # Open source READ-ONLY just to read dims/slide count
  $src = $pp.Presentations.Open($SourceDeck, $true, $false, $false)
  $srcCount = $src.Slides.Count
  $srcW = $src.PageSetup.SlideWidth
  $srcH = $src.PageSetup.SlideHeight

  # Create target deck with same dimensions
  $dst = $pp.Presentations.Add($true)
  $dst.PageSetup.SlideWidth  = $srcW
  $dst.PageSetup.SlideHeight = $srcH
  if ($dst.Slides.Count -ge 1) { $dst.Slides[1].Delete() }

  # Close source — InsertFromFile reads from disk directly
  $src.Close()
  [System.Runtime.Interopservices.Marshal]::ReleaseComObject($src) | Out-Null
  $src = $null

  $inserted = 0
  foreach ($n in $SlideNumbers) {
    if ($n -lt 1 -or $n -gt $srcCount) {
      Write-Warning "Slide $n out of range (source has $srcCount slides). Skipping."
      continue
    }
    $insertAt = $dst.Slides.Count  # insert at end (0-based index for InsertFromFile)
    $beforeCount = $dst.Slides.Count
    # InsertFromFile(FileName, Index, SlideStart, SlideEnd)
    $count = $dst.Slides.InsertFromFile($SourceDeck, $insertAt, $n, $n)
    Start-Sleep -Milliseconds 200
    $afterCount = $dst.Slides.Count
    $delta = $afterCount - $beforeCount
    $inserted += $delta
    Write-Host "  Source slide $n -> output slide $afterCount  (inserted $delta)"
  }

  # ppSaveAsOpenXMLPresentation = 24 (.pptx OOXML)
  $dst.SaveAs($OutputDeck, 24)
  Write-Host "Saved (OOXML): $OutputDeck ($inserted slides)"
}
catch {
  Write-Error "Extract failed: $($_.Exception.Message)"
  throw
}
finally {
  try { if ($dst) { $dst.Close() } } catch {}
  try { if ($src) { $src.Close() } } catch {}
  try { if ($pp)  { $pp.Quit()   } } catch {}
  if ($dst) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($dst) | Out-Null }
  if ($src) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($src) | Out-Null }
  if ($pp)  { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($pp)  | Out-Null }
  [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()

  $orphans = Get-Process POWERPNT -ErrorAction SilentlyContinue |
             Where-Object { ($_.StartTime -gt (Get-Date).AddSeconds(-90)) -and (-not $existing -or $existing.Id -notcontains $_.Id) }
  foreach ($o in $orphans) {
    try { Stop-Process -Id $o.Id -Force; Write-Host "Killed orphan PowerPoint PID $($o.Id)" } catch {}
  }
}
