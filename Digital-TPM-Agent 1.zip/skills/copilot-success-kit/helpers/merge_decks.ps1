# merge_decks.ps1 — Append all slides from a "tail" deck onto a "head" deck.
# Preserves animations/transitions/embedded media via PowerPoint COM.
#
# Usage:
#   .\merge_decks.ps1 `
#     -HeadDeck "C:\path\to\head.pptx" `
#     -TailDeck "C:\path\to\tail.pptx" `
#     -OutputDeck "C:\path\to\final.pptx"

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)] [string]$HeadDeck,
  [Parameter(Mandatory=$true)] [string]$TailDeck,
  [Parameter(Mandatory=$true)] [string]$OutputDeck,
  [int]$PasteTimeoutMs = 1500
)

$ErrorActionPreference = 'Stop'
foreach ($p in @($HeadDeck, $TailDeck)) {
  if (-not (Test-Path $p)) { throw "Deck not found: $p" }
}
$HeadDeck = (Resolve-Path $HeadDeck).Path
$TailDeck = (Resolve-Path $TailDeck).Path
$OutputDir = Split-Path $OutputDeck -Parent
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null }
$OutputDeck = [System.IO.Path]::GetFullPath($OutputDeck)

Write-Host "Head   : $HeadDeck"
Write-Host "Tail   : $TailDeck"
Write-Host "Output : $OutputDeck"

$existing = Get-Process POWERPNT -ErrorAction SilentlyContinue

$pp = $null; $head = $null; $tail = $null
try {
  $pp = New-Object -ComObject PowerPoint.Application
  $pp.Visible = $true; $pp.WindowState = 2

  $head = $pp.Presentations.Open($HeadDeck, $false, $false, $false)
  $tail = $pp.Presentations.Open($TailDeck, $true,  $false, $false)

  $startCount = $head.Slides.Count
  $tailCount  = $tail.Slides.Count
  Write-Host "Head has $startCount slides; appending $tailCount from tail..."

  for ($i = 1; $i -le $tailCount; $i++) {
    $tail.Slides[$i].Copy() | Out-Null
    Start-Sleep -Milliseconds $PasteTimeoutMs
    $head.Slides.Paste() | Out-Null
    if ($i % 5 -eq 0 -or $i -eq $tailCount) { Write-Host "  Appended $i/$tailCount" }
  }

  $head.SaveAs($OutputDeck)
  Write-Host "Saved: $OutputDeck (total slides: $($head.Slides.Count))"
}
catch {
  Write-Error "Merge failed: $($_.Exception.Message)"
  throw
}
finally {
  try { if ($head) { $head.Close() } } catch {}
  try { if ($tail) { $tail.Close() } } catch {}
  try { if ($pp)   { $pp.Quit()    } } catch {}
  if ($head) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($head) | Out-Null }
  if ($tail) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($tail) | Out-Null }
  if ($pp)   { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($pp)   | Out-Null }
  [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()

  $orphans = Get-Process POWERPNT -ErrorAction SilentlyContinue |
             Where-Object { ($_.StartTime -gt (Get-Date).AddSeconds(-90)) -and (-not $existing -or $existing.Id -notcontains $_.Id) }
  foreach ($o in $orphans) {
    try { Stop-Process -Id $o.Id -Force; Write-Host "Killed orphan PowerPoint PID $($o.Id)" } catch {}
  }
}
