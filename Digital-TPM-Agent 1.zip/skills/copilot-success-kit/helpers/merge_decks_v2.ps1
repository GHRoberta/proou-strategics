# merge_decks_v2.ps1 — Robust deck merger via Slides.InsertFromFile.
# Bypasses clipboard race conditions of the Copy/Paste pattern.
#
# Usage:
#   .\merge_decks_v2.ps1 `
#     -HeadDeck "C:\path\to\head.pptx" `
#     -TailDeck "C:\path\to\tail.pptx" `
#     -OutputDeck "C:\path\to\final.pptx"

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)] [string]$HeadDeck,
  [Parameter(Mandatory=$true)] [string]$TailDeck,
  [Parameter(Mandatory=$true)] [string]$OutputDeck
)

$ErrorActionPreference = 'Stop'
foreach ($p in @($HeadDeck, $TailDeck)) {
  if (-not (Test-Path $p)) { throw "Deck not found: $p" }
}
$HeadDeck = (Resolve-Path $HeadDeck).Path
$TailDeck = (Resolve-Path $TailDeck).Path
$OutputDir = Split-Path $OutputDeck -Parent
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null }
$OutputDeck = [System.IO.Path]::GetFullPath($OutputDeck)

Write-Host "Head   : $HeadDeck"
Write-Host "Tail   : $TailDeck"
Write-Host "Output : $OutputDeck"

$existing = Get-Process POWERPNT -ErrorAction SilentlyContinue

$pp = $null; $head = $null
try {
  $pp = New-Object -ComObject PowerPoint.Application
  $pp.Visible = $true; $pp.WindowState = 2

  # Open HEAD as target (writable)
  $head = $pp.Presentations.Open($HeadDeck, $false, $false, $false)
  $headStart = $head.Slides.Count

  # InsertFromFile reads tail directly from disk (no need to open it)
  # Get tail slide count first by opening read-only briefly
  $tailRO = $pp.Presentations.Open($TailDeck, $true, $false, $false)
  $tailCount = $tailRO.Slides.Count
  $tailRO.Close()
  [System.Runtime.Interopservices.Marshal]::ReleaseComObject($tailRO) | Out-Null
  $tailRO = $null

  Write-Host "Head has $headStart slides; appending $tailCount from tail..."

  # Insert all tail slides at end in one call (Index=headStart appends after last)
  $head.Slides.InsertFromFile($TailDeck, $headStart, 1, $tailCount) | Out-Null
  Start-Sleep -Milliseconds 500

  $finalCount = $head.Slides.Count
  Write-Host "Final count: $finalCount slides"

  # ppSaveAsOpenXMLPresentation = 24 (.pptx OOXML, not legacy .ppt binary)
  $head.SaveAs($OutputDeck, 24)
  Write-Host "Saved (OOXML): $OutputDeck"
}
catch {
  Write-Error "Merge failed: $($_.Exception.Message)"
  throw
}
finally {
  try { if ($head) { $head.Close() } } catch {}
  try { if ($pp)   { $pp.Quit()    } } catch {}
  if ($head) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($head) | Out-Null }
  if ($pp)   { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($pp)   | Out-Null }
  [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()

  $orphans = Get-Process POWERPNT -ErrorAction SilentlyContinue |
             Where-Object { ($_.StartTime -gt (Get-Date).AddSeconds(-90)) -and (-not $existing -or $existing.Id -notcontains $_.Id) }
  foreach ($o in $orphans) {
    try { Stop-Process -Id $o.Id -Force; Write-Host "Killed orphan PowerPoint PID $($o.Id)" } catch {}
  }
}
