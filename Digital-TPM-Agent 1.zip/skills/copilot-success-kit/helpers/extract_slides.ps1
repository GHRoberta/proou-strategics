# extract_slides.ps1 — Copy specific slides from a source PPTX into a NEW deck
# Preserves animations, transitions, embedded media, theme via PowerPoint COM.
#
# Usage:
#   .\extract_slides.ps1 `
#     -SourceDeck "C:\path\to\source.pptx" `
#     -SlideNumbers 2,6,7,17,18 `
#     -OutputDeck "C:\path\to\output.pptx"

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)] [string]$SourceDeck,
  [Parameter(Mandatory=$true)] [int[]] $SlideNumbers,
  [Parameter(Mandatory=$true)] [string]$OutputDeck,
  [int]$PasteTimeoutMs = 2000
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $SourceDeck)) { throw "Source deck not found: $SourceDeck" }
$SourceDeck = (Resolve-Path $SourceDeck).Path
$OutputDir = Split-Path $OutputDeck -Parent
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null }
$OutputDeck = [System.IO.Path]::GetFullPath($OutputDeck)

Write-Host "Source : $SourceDeck"
Write-Host "Slides : $($SlideNumbers -join ', ')"
Write-Host "Output : $OutputDeck"

$existing = Get-Process POWERPNT -ErrorAction SilentlyContinue
if ($existing) { Write-Warning "PowerPoint already running (PIDs: $($existing.Id -join ',')). This may conflict with COM ops." }

$pp = $null; $src = $null; $dst = $null
try {
  $pp = New-Object -ComObject PowerPoint.Application
  $pp.Visible = $true
  $pp.WindowState = 2  # ppWindowMinimized

  $src = $pp.Presentations.Open($SourceDeck, $true, $false, $false)

  $dst = $pp.Presentations.Add($true)
  $dst.PageSetup.SlideWidth  = $src.PageSetup.SlideWidth
  $dst.PageSetup.SlideHeight = $src.PageSetup.SlideHeight

  if ($dst.Slides.Count -ge 1) { $dst.Slides[1].Delete() }

  $copied = 0
  foreach ($n in $SlideNumbers) {
    if ($n -lt 1 -or $n -gt $src.Slides.Count) {
      Write-Warning "Slide $n out of range (source has $($src.Slides.Count) slides). Skipping."
      continue
    }
    $src.Slides[$n].Copy() | Out-Null
    Start-Sleep -Milliseconds $PasteTimeoutMs
    $dst.Slides.Paste() | Out-Null
    $copied++
    Write-Host "  Copied source slide $n -> output slide $copied"
  }

  $dst.SaveAs($OutputDeck)
  Write-Host "Saved: $OutputDeck ($copied slides)"
}
catch {
  Write-Error "Extract failed: $($_.Exception.Message)"
  throw
}
finally {
  try { if ($dst) { $dst.Close() } } catch {}
  try { if ($src) { $src.Close() } } catch {}
  try { if ($pp)  { $pp.Quit()   } } catch {}
  if ($dst) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($dst) | Out-Null }
  if ($src) { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($src) | Out-Null }
  if ($pp)  { [System.Runtime.Interopservices.Marshal]::ReleaseComObject($pp)  | Out-Null }
  [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()

  $orphans = Get-Process POWERPNT -ErrorAction SilentlyContinue |
             Where-Object { ($_.StartTime -gt (Get-Date).AddSeconds(-60)) -and (-not $existing -or $existing.Id -notcontains $_.Id) }
  foreach ($o in $orphans) {
    try { Stop-Process -Id $o.Id -Force; Write-Host "Killed orphan PowerPoint PID $($o.Id)" } catch {}
  }
}
