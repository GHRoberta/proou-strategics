---
name: opendoc-bridge
description: Read and edit live Office documents (Word, Excel, PowerPoint, OneNote) from the Copilot CLI. The document must be open with the OpenDoc Bridge add-in loaded.
---

# OpenDoc Bridge

## When to Use

Load this skill when the user wants to interact with a **currently open** Office document. Trigger phrases include:

- "edit the document I have open"
- "update my PowerPoint"
- "read the spreadsheet"
- "add to my Word doc"
- "check my OneNote notes"
- "insert a slide", "replace text in my doc", "read cells from Excel"
- Any reference to modifying or reading a **live, open** Office file

**Do NOT use** for files on disk or SharePoint that aren't open in an Office app. Use agent365-sharepoint, agent365-word, or markitdown for those.

## Prerequisites

1. **Bridge server running** -- the OpenDoc Bridge MCP server must be active (check with MCP server list).
2. **Add-in loaded** -- the OpenDoc Bridge task pane add-in must be loaded in the target Office application (Word, Excel, PowerPoint, or OneNote).
3. **Document open** -- the target document must be open and active in the Office app.

## Available Tools (77 tools)

### Word (22 tools)

**Read:**
| Tool | Description |
|------|-------------|
| `get_document_overview` | Get document structure, metadata, and section list |
| `get_document_content` | Get full document content (body text, paragraphs) |
| `get_document_section` | Get content of a specific section by index or heading |
| `get_selection` | Get the current selection (rich object with formatting) |
| `get_selection_text` | Get plain text of current selection |
| `get_document_properties` | Read document metadata (title, author, etc.) |
| `get_paragraph_by_index` | Get a specific paragraph by its index |
| `list_content_controls` | List all content controls in the document |
| `get_headers_footers` | Get header and footer content |
| `list_comments` | List all comments in the document |

**Write:**
| Tool | Description |
|------|-------------|
| `set_document_content` | Write or replace document content |
| `insert_content_at_selection` | Insert text/HTML/OOXML at the cursor or selection |
| `find_and_replace` | Find and replace text throughout the document |
| `insert_table` | Insert a table at the current selection |
| `insert_paragraph` | Insert a paragraph at a specified location |
| `insert_page_break` | Insert a page break |
| `insert_image` | Insert an image into the document |
| `set_content_control` | Set the value of a content control |
| `add_comment` | Add a comment to the document |

**Format:**
| Tool | Description |
|------|-------------|
| `apply_style_to_selection` | Apply a named style to the current selection |
| `set_paragraph_formatting` | Set formatting properties on a paragraph |
| `apply_document_style` | Apply a document-level style |

### Excel (28 tools)

**Read:**
| Tool | Description |
|------|-------------|
| `get_workbook_overview` | Get workbook structure: sheets, named ranges, tables |
| `get_workbook_info` | Get workbook metadata (name, path, author) |
| `get_workbook_content` | Read cell values from a range (e.g., `Sheet1!A1:D10`) |
| `get_selected_range` | Get the currently selected range and its values |
| `get_table_data` | Read data from a named table |
| `get_cell_formulas` | Get formulas (not just values) from a range |
| `get_conditional_formats` | List conditional formatting rules on a range |
| `get_pivot_table_data` | Read pivot table data and configuration |
| `get_chart_info` | Get chart type, data source, and properties |

**Write:**
| Tool | Description |
|------|-------------|
| `set_workbook_content` | Write values to a range (auto-creates sheets if needed) |
| `set_selected_range` | Write values to the currently selected range |
| `find_and_replace_cells` | Find and replace values across the workbook |
| `insert_chart` | Insert a chart from a data range |
| `create_named_range` | Create a named range for a cell address |
| `add_worksheet` | Add a new worksheet to the workbook |
| `delete_worksheet` | Delete a worksheet from the workbook |
| `set_cell_formulas` | Write formulas to a range |
| `create_table` | Create a named table from a range |
| `add_table_row` | Add a row to an existing table |
| `delete_table_row` | Delete a row from a table |
| `sort_range` | Sort a range by column |
| `filter_table` | Apply filters to a table |
| `clear_range` | Clear contents from a range |
| `merge_cells` | Merge a range of cells |
| `insert_image` | Insert an image into the worksheet |

**Format:**
| Tool | Description |
|------|-------------|
| `apply_cell_formatting` | Apply formatting to a cell range |
| `autofit_worksheet` | Auto-fit column widths and row heights |
| `set_conditional_format` | Create a conditional formatting rule |

### PowerPoint (20 tools)

**Read:**
| Tool | Description |
|------|-------------|
| `get_presentation_overview` | Get slide count, layout info, and slide titles |
| `get_presentation_content` | Get content of all slides (shapes, text, images) |
| `get_slide_image` | Get a rendered image of a specific slide |
| `get_slide_notes` | Get speaker notes for a slide |
| `get_slide_shapes` | List all shapes on a slide with properties |
| `get_slide_layout` | Get the layout type and placeholders of a slide |
| `get_presentation_properties` | Get presentation metadata |

**Write:**
| Tool | Description |
|------|-------------|
| `set_presentation_content` | Update text content in slide shapes |
| `add_slide_from_code` | Add a new slide with layout and content |
| `clear_slide` | Remove all content from a slide |
| `update_slide_shape` | Update a specific shape's properties |
| `set_slide_notes` | Set speaker notes for a slide |
| `duplicate_slide` | Duplicate an existing slide |
| `add_slide` | Add a blank slide with a specified layout |
| `delete_slide` | Remove a slide by index |
| `insert_image_on_slide` | Insert an image onto a slide |
| `add_shape` | Add a shape (rectangle, oval, etc.) to a slide |
| `add_text_box` | Add a text box to a slide |
| `reorder_slides` | Move a slide from one position to another |

**Format:**
| Tool | Description |
|------|-------------|
| `set_slide_background` | Set the background color or image of a slide |

### OneNote (6 tools, COM API only)
| Tool | Description |
|------|-------------|
| `get_notebook_hierarchy` | List notebooks, section groups, and sections |
| `get_section_pages` | List pages in a section |
| `get_page_content` | Read the XML content of a page |
| `create_page` | Create a new page in a section |
| `update_page_content` | Update page content with new HTML/XML |
| `search_pages` | Search across pages by keyword |

### Shared (1 tool)
| Tool | Description |
|------|-------------|
| `web_fetch` | Fetch a URL (available across all hosts) |

## Usage Examples

### 1. Summarize an open QBR deck
> "Read the QBR deck I have open and summarize the key slides"

Call `ppt_getAllSlidesText` to extract all slide content, then summarize the key themes, metrics, and action items.

### 2. Add a slide to a presentation
> "Add a new slide to my presentation with these bullet points: ..."

Call `ppt_addSlide` to create a blank slide, then `ppt_addTextToSlide` to insert the formatted bullet points.

### 3. Find and replace in a Word document
> "Find and replace 'Q4 2025' with 'Q1 2026' in my Word document"

Call `word_replaceText` with the search and replacement strings. Returns the count of replacements made.

### 4. Read Excel data for analysis
> "Read cells A1:D10 from the Budget sheet in my Excel workbook"

Call `excel_setActiveSheet` to switch to "Budget", then `excel_readRange` with range "A1:D10" to retrieve the cell values.

## Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| Tools not available | Bridge MCP server not running | Check MCP server list; restart if needed |
| "No active host" error | Add-in not loaded in any Office app | Open the OpenDoc Bridge add-in from the Office app's Insert > Add-ins menu |
| Wrong document responding | Multiple Office apps open with add-in | Call `bridge_getActiveHost` to confirm which app is connected; reload add-in in the correct app |
| Stale content returned | Document changed since last read | Re-call the read tool to get fresh content |
| OneNote tools fail | OneNote desktop not supported | OneNote tools require OneNote for the web or OneNote on Windows (UWP) with add-in support |

## Architecture Note

OpenDoc Bridge tools execute via the **Office JS API** running in a task pane add-in's browser context. The bridge MCP server communicates with the add-in over a local WebSocket connection. All read/write operations happen against the **live in-memory document** -- changes appear immediately in the Office app and are subject to the app's normal save/autosave behavior.
