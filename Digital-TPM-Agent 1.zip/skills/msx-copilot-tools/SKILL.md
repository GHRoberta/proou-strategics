---
name: msx-copilot-tools
description: >
  MSX (Dynamics 365) opportunity management automation. Analyzes pipeline Excel exports,
  generates forecast comments using M365 intelligence (WorkIQ), inserts/edits/deletes
  comments directly in MSX via Playwright browser automation, discovers uncaptured
  opportunities from emails/meetings/Teams, and drafts email/Teams responses.
  Triggers: MSX, forecast, forecast comment, pipeline, oportunidade, opportunity,
  Dynamics 365, msx_updater, analise Excel, analyze Excel, update MSX, delete comment,
  new opportunities, draft response, rascunho, oportunidades novas.
---

# MSX Copilot Tools

Automação de gestão de oportunidades no MSX (Dynamics 365) via GitHub Copilot CLI.

> **Note:** `%WORK_BASE%` defaults to `{{WORKDIR_LOCAL}}\` but can be configured during setup.

## Capabilities

| Capability | Description |
|---|---|
| **Pipeline Analysis** | Reads MSX Excel exports, analyzes by account/stage/recommendation, converts currencies |
| **Forecast Comments** | Generates comments using M365 intelligence (WorkIQ) |
| **Browser Automation** | Inserts/edits/deletes forecast comments directly in MSX via Playwright + Edge |
| **Opportunity Discovery** | Finds uncaptured opportunities from emails/meetings/Teams (last 30-60 days) |
| **Draft Responses** | Generates email/Teams reply drafts based on pipeline context |

## Prerequisites

- Python 3.10+ with `playwright`, `openpyxl`, `pandas`
- Microsoft Edge running with `--remote-debugging-port=9222`
- MSX authenticated via SSO in Edge
- Scripts located at: `%WORK_BASE%\msx-copilot-tools\scripts\`

## MSX Browser Automation Commands

Run the script at `%WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py`:

```bash
python %WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py tabs                        # List open Edge tabs
python %WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py open <guid>                 # Open opportunity
python %WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py update <guid> <comment>      # Add forecast comment
python %WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py delete <guid> [index]        # Delete comment (0=newest)
python %WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py screenshot                  # Screenshot current page
python %WORK_BASE%\msx-copilot-tools\scripts\msx_updater.py explore                     # Explore page selectors
```

## Workflow: Update Forecast Comments

### Step 1: Load opportunities
- Read the Excel file exported from MSX (usually in Downloads)
- Parse columns: Topic, Est. Revenue, Forecast Comments, Account, Sales Stage, etc.
- The Excel "(Do Not Modify) Opportunity" column contains the GUIDs needed for automation

### Step 2: Gather intelligence
- Group opportunities by account
- For each account, query WorkIQ for recent emails, meetings, Teams messages, and transcripts (last 30-60 days)
- Focus on: deal status, blockers, next steps, partner updates, customer communications

### Step 3: Generate forecast comments
- Write new comments based on gathered intelligence
- DO NOT include the "MG - DD/Mon -" prefix — MSX adds this automatically on export
- Go straight to the content (e.g., "Brasoftware suspended all processes..." not "MG - 12/Mar - Brasoftware suspended...")
- Keep comments concise but informative: current status, blockers, next steps
- Reference specific dates and events from the intelligence

### Step 4: Update MSX (if requested)
- Use the msx_updater.py script to insert comments directly in MSX
- Edge must be running with `--remote-debugging-port=9222` and MSX authenticated
- Always confirm with the user before batch-updating all opportunities

## Workflow: Discover New Opportunities

### Step 1: Search broadly for signals
- Query WorkIQ for emails, Teams messages, meetings, and transcripts from the last 30-60 days
- Look for signals like: customer expressing interest, budget discussions, procurement starting, partner proposing new projects, requests for demos/PoCs, new use cases
- Search broadly — do NOT pre-filter by account list, since the user may own accounts that have no opportunities yet

### Step 2: Cross-reference with existing pipeline
- Compare signals found against the user's existing opportunities (from Excel)
- Separate into: (a) new initiatives within existing accounts, (b) signals from accounts not in the pipeline at all

### Step 3: Present ALL findings for user validation
- Group by account
- For each potential opportunity, include: account, solution area, signals found, suggested next steps
- Be explicit about confidence level (high/medium/low)
- ALWAYS let the user validate which accounts are theirs — the Excel only shows accounts WITH open opportunities, not the full territory
- The user may own child accounts, new accounts, or accounts with no active pipeline

### Common pitfalls
- The Excel export does NOT represent the full territory — many accounts have no opportunities yet
- Partner discussions (e.g., Brasoftware, Pentare) are usually operational, not new opportunities — but ask the user
- Internal Microsoft events/trainings are not customer opportunities
- Always present findings and let the user confirm ownership — never assume an account is or isn't theirs

## Workflow: Draft Email & Teams Responses

### Step 1: Find unanswered items
- Query WorkIQ for emails where user is in the TO line, not yet replied (last 24-48h)
- Query WorkIQ for Teams messages where user is @mentioned, not yet responded

### Step 2: Generate draft responses
- Use context from pipeline, accounts, and recent intelligence to draft appropriate responses
- Match the user's communication style (Portuguese for Brazilian contacts, English for others)
- Keep drafts concise and actionable

### Step 3: Present for review
- Show: original message summary + draft response
- User copies/pastes into Outlook/Teams manually
- Note: WorkIQ is read-only — cannot send emails or messages directly

## MSX Technical Details

### Forecast Comments Structure
- Located inside an iframe: `data-id="WebResource_ForecastComments-WebResource_ForecastComments"`
- Input field: `textarea#forecastCommentsInput` (class `WR_textarea`)
- Save button: `button#SubmitButton` (class `SaveButton`)
- Expand input: click `div#EnterCommentLabel`
- Delete icon: `span.delete > i.ms-Icon.ms-Icon--Delete` (per comment in `.CommentsDiv`)
- Edit icon: `span.edit > i.ms-Icon.ms-Icon--Edit`

### Delete Mechanism
The delete button calls `parent.Xrm.Navigation.openConfirmDialog()` (Dynamics 365 dialog, not browser native).
To automate, override it: `parent.Xrm.Navigation.openConfirmDialog = () => Promise.resolve({ confirmed: true })`

### MSX URL Pattern
```
https://microsoftsales.crm.dynamics.com/main.aspx?appid=fe0c3504-3700-e911-a849-000d3a10b7cc&forceUCI=1&pagetype=entityrecord&etn=opportunity&id={GUID}
```

### Currency Notes
- Opportunities in BRL show "R$" in the revenue field (e.g., "R$ 150.000,00")
- Opportunities in USD show only "$" (e.g., "$50,000.00")
- Always ask the user for the current BRL→USD exchange rate before converting

## Best Practices

### MSX Loading & Reliability
- Wait at least **15 seconds** after page.goto for Dynamics to fully render
- Use `domcontentloaded` (not `networkidle`) for page.goto — MSX never stops loading background requests
- On fresh Edge sessions, the first navigation may fail because MSX redirects for SSO — retry automatically
- If page title shows "Microsoft Dynamics 365" (generic) instead of the opportunity name, the page hasn't fully loaded — wait longer or retry
- Always take a screenshot after automation to verify changes

### Forecast Comments
- Comments are append-only in the feed — newest appears at top
- After deleting, wait 5 seconds for the async Dynamics operation to complete
- The "MG - DD/Mon -" prefix is added automatically on export — do NOT include it when inserting new comments

### Edge / Playwright
- Edge must be launched with `--remote-debugging-port=9222` BEFORE starting automation
- Use `launch_edge.ps1` to ensure proper setup (kills existing instances, relaunches with flag)
- If automation fails, check that MSX is authenticated in Edge — SSO may have expired
- The script connects via CDP (Chrome DevTools Protocol) on port 9222
