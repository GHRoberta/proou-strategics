# Data sources & gotchas — portfolio-analytics

All identifiers verified 2026-07-01/03. Constants live in `portfolio_config.py`;
this file is the human-readable provenance + the recipes that took the most effort
to discover.

## 1. MACC balances — MSX Insights portal (scrape)

- **Report:** "MACC Balances and Shortfall", `aka.ms/maccbalanceshortfall`
  → `https://msxinsights.microsoft.com/User/report/15b4d62d-805a-4ec9-ac6d-ca006ad4eeee`
- **Why scrape:** the AHR Power BI dashboards were **deprecated**; the report lives
  in the MSX Insights portal and is **NOT** queryable via the `powerbi-remote` MCP
  (report IDs return 404). The cube backend is UAR-gated. So the reliable path is
  browser export of the **Portfolio** tab's account table.
- **Columns used** (xlsx): `To Direct Top Parent ID`=TPID, `To Direct Top Parent Name`,
  `Consumption Commitment`=committed, `Decrement`=consumed, `Balance`,
  `End Date`=prazo, `% Commit Complete`, `% Months Complete`, `MACC Status`
  (filter to `Active`), `To Direct Sales Unit` (Brazil-HQ detection).
- **Export gotcha:** the PBI "Export data" dialog renders **inside the report
  iframe** — click the Export button in the *frame*, not the page. The table visual
  is found by element-handle text (`% Commit Complete` / `Consumption Commitment`+`Balance`),
  largest area, after hovering to reveal "More options".
- **Do NOT** use the "MACC Tracker" dataset (`factmacc`, artifact
  `6152fe7f-38df-4832-a430-dde5fd6b5b9c`) for committed — its `Signed` field is
  corrupted (Int32-max sentinels / negatives) and only refreshes monthly.

## 2. M365 Copilot paid seats — Power BI

- **Dataset:** "M365 Copilot Usage" `5c6c70ac-f04e-4809-8f6a-c53cb4354e6e`
  (workspace "Prod Publish - WW Field and Partner Programs"; IDEAs, daily refresh).
- **Measure:** `[Paid Available Units (M365 Copilot)]` — the **suffix is required**;
  `[Paid Available Units]` alone does not resolve.
- **Brazil filter:** `'Customer'[Field Region] = "BRA"`.
- **Access:** `INFO.MEASURES()` needs admin; get names via `GetSemanticModelSchema`.
  Query via REST `POST /v1.0/myorg/datasets/{id}/executeQueries` (endpoint **without**
  `/groups/`), token resource `https://analysis.windows.net/powerbi/api`.
- **Authority:** the `copilot-usage` plugin skill owns Copilot usage analytics
  (see its `references/DAX_REFERENCE.md`); `pull_seats.py` is only a BRA-by-TPID roll-up.

## 3. Core Account Team (AE/ATS/CSAM) — MSX Dataverse

- **Entity:** `msp_accountteam` (the "Core Account Team" tab in MSX; reachable in the
  UI via the record's "…" overflow → Core Account Team).
- **Roles:**
  - AE = `msp_rolename` == `ATU Account Executive` (also the account owner).
  - ATS = `msp_rolename` == `ATU Account Technology Strategist`.
  - CSAM = `msp_standardtitle` == `Customer Success Account Mgmt IC` (roletype CSU).
- **Where it hangs:** the **Top-parent** account (`msp_parentinglevelcode` = `861980000`),
  **except strategic accounts** (e.g., [CLIENTE], [CLIENTE]) where the core team sits on the
  operating account under a "Strategic …" title → `pull_team.py` probes Top first, then
  person-owned operating accounts.
- **CSAM disambiguation:** big groups roll up a shared WW CSU pool; pick the
  account-level IC (title `Customer Success Acct Manager`), FTE over vendor (`v-`).
- **Trap:** the `get_account_overview` MSX tool's `team` section returns only the
  **extended** team (CSU/STU/M&O) and omits these core ATU roles — use the entity.
- **Access:** OData GET against `https://microsoftsales.crm.dynamics.com/api/data/v9.2`,
  token resource `https://microsoftsales.crm.dynamics.com/`. Use `$top` (metadata
  `$filter` on `EntityDefinitions` is blocked; `INFO`/metadata needs admin).

## 4. Attainment (trained learners) — reference

The Carteira dashboard's "Treinados" column uses `attainment_summary.json` (export of
"FY26 TPM Learner Target Attainment"), summing `Trained Learners` per account
(includes PD + TSP/scale). Portfolio total ≈ 110,081 — do **not** use partial PD-only
counts.

## Scope / exclusions

- Study scope = **clients headquartered in Brazil**. Foreign accounts are dropped
  dynamically when `To Direct Sales Unit` is not a Brazil unit
  (`is_brazil_unit`) — e.g. Teléfonos de México (MX), SATRACK (CO), South Consulting /
  Serviex (CL).
- Manual exclusions in `EXCLUDE_TPIDS` (currently LG - Lugar de Gente, TPID 26717164,
  removed per user request 2026-07-03 though it is Brazil-HQ).

## Dashboard validation lesson

In standalone HTML, never declare `<script>` globals whose names collide with
`window` properties (`top`, `name`, `length`, `open`, `status`, …) — it silently
breaks the whole script in a browser but not in Node. Always validate with
**jsdom** (`validate_dashboard.js`), not `node --check`.

## Related skills (avoid duplication)

- `copilot-usage` (plugin) — Copilot seats/usage authority; extend it for deeper usage analytics.
- `acr` (plugin) — ACR/consumption + MACC **sizing** via DAX/AHR (`[Azure Consumed Revenue Baseline]`); complementary to our portal-scraped **balances**.
- `msxi-copilot-e2e` (user) — the Edge-CDP/Playwright MSX-Insights automation pattern (Copilot E2E report); we reuse the same mechanics for the MACC report.
- `account-explorer` / `account-agent` (plugin/user) — single-account briefings; consume our AE/ATS/CSAM + MACC + seats outputs.
