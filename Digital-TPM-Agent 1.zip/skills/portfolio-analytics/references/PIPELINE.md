# Pipeline — stages, I/O, dependency graph

Home: `{{WORKDIR}}\portfolio-analytics\`
Config: `portfolio_config.py` (paths, IDs, 30-account portfolio, roles, exclusions, `get_token`).

```
portfolio_config.py  ── imported by every stage ──┐
                                                   │
pull_macc.py ──(Edge scrape | reuse xlsx)──► macc_portfolio.xlsx ──► macc_all.json
pull_seats.py ──(PBI executeQueries REST)──────────────────────────► seats_by_tpid.json
                                                   │  (macc_all + seats)
pull_team.py ──uses build_top50.select_scope──► team_by_tpid.json
build_top50.py ──(macc_all + seats + team)──► top50_macc_seats.json
render_top50.py ──(top50_macc_seats.json)──► ../Top50_MACC_Copilot_Brasil.html
aggregate_macc.py ──(macc_portfolio.xlsx)──► macc_by_tpid.json ──► render_carteira.py ──► ../Carteira_FY27_Copilot_Dashboard.html (MACC block, in place)
validate_dashboard.js ──(jsdom)──► PASS/FAIL on both dashboards
```

| Stage | Script | Reads | Writes | Live? |
|---|---|---|---|---|
| 1 | `pull_macc.py [--refresh]` | (Edge) or cached xlsx | `macc_portfolio.xlsx`, `macc_all.json` | Edge (only with `--refresh`) |
| 2 | `pull_seats.py` | `macc_all.json` | `seats_by_tpid.json` | Power BI token |
| 3 | `pull_team.py` | `macc_all.json`, `seats_by_tpid.json` | `team_by_tpid.json` | Dataverse token |
| 4 | `build_top50.py` | `macc_all.json`, `seats_by_tpid.json`, `team_by_tpid.json` | `top50_macc_seats.json` | no |
| 5 | `render_top50.py` | `top50_macc_seats.json` | `../Top50_MACC_Copilot_Brasil.html` | no |
| 4b | `aggregate_macc.py` | `macc_portfolio.xlsx` | `macc_by_tpid.json` | no |
| 4c | `render_carteira.py` | `macc_by_tpid.json` | `../Carteira_FY27_Copilot_Dashboard.html` (MACC block) | no |
| — | `run_all.py` | orchestrates 1→5 + 4b + validate | | |
| test | `healthcheck.py` | everything (read-only) | — | tokens unless `--offline` |
| test | `validate_dashboard.js` | the two HTML dashboards | — | no |

Notes
- `build_top50.select_scope(macc, seats)` returns top-50-by-score ∪ carteira; `pull_team`
  imports it so team is fetched for exactly the rows that appear — no re-rank loop.
- The Carteira FY27 dashboard's non-MACC columns (licenses, pipeline, trained) come from
  pre-existing Work Hub inputs (`carteira_fy27_copilot.csv`, `pipeline_data.py`,
  `open_copilot_opps.json`, `seats_in_opps.json`, `attainment_summary.json`).
  `render_carteira.py` refreshes only its embedded `const MACC={…}` block in place (one-line
  regex replace; KPIs recompute in-browser). The Top-50 portal regenerates fully from stages 1–5.
