---
name: portfolio-analytics
description: >
  Builds and refreshes {{USER_FIRSTNAME}}'s portfolio analytics: per-account MACC (Azure
  consumption commitment) balances, M365 Copilot paid seats, and the MSX Core
  Account Team (AE/ATS/CSAM), combined into two self-contained HTML dashboards —
  the "Carteira FY27" managed-portfolio view and the "Top 20 Clientes Brasil ·
  MACC × Copilot" ranking (top 20 by combined score PLUS every carteira account),
  now with FY26 Copilot paid seats AND FY27 open M365 Copilot opportunity seats
  per account. Use whenever the user wants MACC committed/consumed/prazo per
  account, Copilot seats (FY26 paid or FY27 pipeline) per account, who the
  AE/ATS/CSAM are for an account, or wants to
  build/refresh either dashboard. It owns a scripted, testable pipeline (pull →
  build → render → validate) with a single portfolio_config.py source of truth.
  Triggers: portfolio analytics, análise da carteira, MACC por conta, MACC
  balances, MACC committed/consumido/prazo, aka.ms/maccbalanceshortfall, seats de
  Copilot por conta, Paid Available Units, top 50 clientes, top50 MACC x Copilot,
  carteira FY27 dashboard, quem é o AE/ATS/CSAM, core account team, AE ATS CSAM,
  refresh do dashboard, atualizar dashboard de MACC/Copilot.
---

# portfolio-analytics

Turns four internal-Microsoft data sources into two dashboards, via a scripted
pipeline that lives with its data at
`{{WORKDIR}}\portfolio-analytics\`
(the SKILL documents it; the code + outputs stay in the Work Hub, per the
tpm-cockpit convention). Everything is parameterized from **`portfolio_config.py`**
— edit a TPID, dataset ID, or the exclusion list in exactly one place.

## Capabilities

| # | Capability | Source | Script |
|---|---|---|---|
| 1 | **MACC balances** per account (committed / consumed / balance / end-date / risk) | MSX Insights portal report "MACC Balances and Shortfall" (`aka.ms/maccbalanceshortfall`) — **UI-only**, scraped via Edge+Playwright | `pull_macc.py`, `aggregate_macc.py` |
| 2 | **FY26 M365 Copilot paid seats** per account (Brazil) | Power BI "M365 Copilot Usage", measure `[Paid Available Units (M365 Copilot)]` | `pull_seats.py` |
| 3 | **FY27 open M365 Copilot opportunity seats** per account | PBI 'Opportunity Pipeline' (flag `Is M365 Copilot(Opportunity)`=Yes, incl. E7/ME7 bundles) joined to MSX Dataverse `opportunity._parentaccountid_value → account.msp_mstopparentid` (=TPID) | `pull_opp_seats.py` |
| 4 | **Core Account Team** AE / ATS / CSAM per account | MSX Dataverse entity `msp_accountteam` (OData REST) | `pull_team.py` |
| 5 | **FY26 Trained Learners** per account (PD + TSP) | PBI "FY26 TPM Learner Target Attainment" (Playwright export → `attainment_summary.json`, cached in Work Hub root) | `pbi_export_attainment.py` |
| 6 | **Two dashboards** (portfolio + top-20 ranking) | combines 1–5 | `build_top50.py`, `render_top50.py`, `render_carteira.py` |

Full provenance, IDs, DAX/OData recipes and gotchas: [references/DATA_SOURCES.md](references/DATA_SOURCES.md).
Overlap with existing skills (don't duplicate): [references/DATA_SOURCES.md#related-skills](references/DATA_SOURCES.md).

## Prerequisites

- `az login` (tokens for `https://microsoftsales.crm.dynamics.com/` and `https://analysis.windows.net/powerbi/api`).
- Python: `pandas`, `playwright` (Edge channel). Node: `jsdom` (installed in the Work Hub `node_modules`).
- A signed-in cached Edge profile at `..\.pbi_profile` (needed only for the MACC re-scrape).
- Run `python healthcheck.py` first — it verifies all of the above.

## Workflow

### Refresh everything (one command)
```powershell
cd "{{WORKDIR}}\portfolio-analytics"
python run_all.py                # reuse cached MACC xlsx; refresh seats+team; rebuild+render+validate
python run_all.py --refresh-macc # also re-scrape the MACC portal via Edge (headed; sign in if prompted)
python run_all.py --skip-team    # keep team_by_tpid.json (team pull is the slow ~2 min step)
```
Stages: `pull_macc → pull_seats → pull_opp_seats → pull_team → build_top50 → render_top50 → aggregate_macc → render_carteira → validate`.

### Run a single stage
Each script is standalone and prints a one-line summary. Order matters only in that
`pull_seats`/`pull_team`/`build_top50` read `macc_all.json`; `build_top50` reads
`opp_seats_by_tpid.json` + `team_by_tpid.json` if present. `pull_opp_seats` refreshes
the PBI Copilot-opp universe (`open_copilot_opps.json`) then joins opp→TPID via
Dataverse (scope = current `top50_macc_seats.json` ∪ carteira). `pull_team` scopes
itself to top-20 ∪ carteira via `build_top50.select_scope` (no chicken-and-egg).

### Outputs
- Data: `macc_all.json`, `seats_by_tpid.json`, `open_copilot_opps.json` (FY27 opp universe), `opp_seats_by_tpid.json` (FY27 opp seats/TPID), `team_by_tpid.json`, `macc_by_tpid.json`, `top50_macc_seats.json` (top-20 + carteira), `macc_portfolio.xlsx`. External (Work Hub root): `attainment_summary.json` (FY26 Trained Learners/TPID — refresh via `python pbi_export_attainment.py --headless`).
- Dashboards (Work Hub root): `Top50_MACC_Copilot_Brasil.html`, `Carteira_FY27_Copilot_Dashboard.html`.
- Open with `Start-Process msedge.exe "<path>"`; Ctrl+F5 if a stale tab is cached.

## Error handling

| Symptom | Cause | Fix |
|---|---|---|
| `no Power BI iframe rendered` | MSX Insights auth expired | sign in to Edge once; profile is cached in `.pbi_profile` |
| seats measure `could not be resolved` | dropped the suffix | measure is `[Paid Available Units (M365 Copilot)]` (suffix required) |
| team AE/ATS = None for a big account | core team on operating (not Top) account | already handled — `pull_team` probes Top then operating accounts |
| CSAM over-counts (shared US pool) | strategic-account rollup | already handled — `_pick_csam` prefers the account-level IC |
| `az token failed` | not logged in | `az login` |
| dashboard renders blank in browser but node --check passes | window-global collision in inline script | validate with `validate_dashboard.js` (jsdom), never node --check alone |

## Testing

- `python healthcheck.py` — read-only: config integrity, deps, tokens, artifact counts, dashboards-pass-jsdom (add `--offline` to skip live/token checks).
- `node validate_dashboard.js [file]` — jsdom-validates dashboards (0 script errors, table rows rendered, no `undefined`/`NaN` KPIs).

## Examples

| Prompt | Action |
|---|---|
| "atualiza o dashboard top 50" | `python run_all.py` → report the summary line, open the HTML |
| "puxa o MACC atualizado" | `python run_all.py --refresh-macc` (headed Edge) |
| "quem é o AE/ATS/CSAM da [CLIENTE]?" | read `team_by_tpid.json` (key = TPID); if stale, `python pull_team.py` |
| "MACC da [CLIENTE]" | read `macc_by_tpid.json`/`macc_all.json` (TPID [TPID]) |
| "quantos seats de Copilot a [CLIENTE] comprou?" | read `seats_by_tpid.json` (TPID [TPID]) |

## References

- [references/DATA_SOURCES.md](references/DATA_SOURCES.md) — provenance, dataset/report/entity IDs, DAX/OData recipes, exclusions, gotchas, related skills.
- [references/PIPELINE.md](references/PIPELINE.md) — per-stage inputs/outputs and the dependency graph.
- Cross-reference: `copilot-usage` (seats authority), `acr` (ACR/AHR consumption via DAX), `msxi-copilot-e2e` (Edge/Playwright MSX-Insights pattern), `account-agent`/`client-meeting-prep` (consume these outputs).

## Post-Run Reflection

After each run, note (in the working response, not the deliverable):
1. Did the source refresh cleanly, or did MACC auth / a token expire mid-run?
2. Team coverage (AE/ATS/CSAM present out of rows) — a drop signals an MSX org change worth a `pull_team` re-run.
3. New scope entrants/leavers vs. last run (top-50 churn) worth flagging to the user.
4. If a data source's schema shifted (column/measure/entity rename), update `portfolio_config.py` + `references/DATA_SOURCES.md`.
