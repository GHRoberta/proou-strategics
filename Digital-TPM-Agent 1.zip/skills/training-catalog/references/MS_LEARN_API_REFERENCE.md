# MS Learn Catalog API Reference

Complete API reference for querying the Microsoft Learn training catalog.

## Endpoint

```
GET https://learn.microsoft.com/api/catalog/
```

Returns JSON with up to 12 top-level arrays. **Always filter** — the full catalog is 15MB+.

## Query Parameters

All optional. Multiple parameters combine with AND.

| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| `locale` | string | Locale code for content language | `pt-br`, `en-us`, `es-es` |
| `type` | string | Comma-separated content types | `modules,learningPaths` |
| `uid` | string | Specific content UID(s) | `learn.azure.intro-to-azure-fundamentals` |
| `last_modified` | string | Date filter with operator | `gte 2025-01-01` |
| `popularity` | string | Popularity score filter (0-1) | `gte 0.7` |
| `level` | string | Comma-separated levels | `beginner,intermediate` |
| `role` | string | Comma-separated roles | `developer,administrator` |
| `product` | string | Comma-separated products | `azure,azure-openai` |
| `subject` | string | Comma-separated subjects | `security,cloud-computing` |

### Type Values

| Value | Returns |
|-------|---------|
| `modules` | Individual learning modules (most granular) |
| `units` | Units within modules |
| `learningPaths` | Curated sequences of modules |
| `appliedSkills` | Hands-on applied skills |
| `certifications` | Microsoft certifications |
| `mergedCertifications` | Certifications merged with exam data |
| `exams` | Individual certification exams |
| `courses` | Instructor-led training courses |
| `levels` | Taxonomy: available levels |
| `products` | Taxonomy: available products |
| `roles` | Taxonomy: available roles |
| `subjects` | Taxonomy: available subjects |

### Level Values

| Value | Description |
|-------|-------------|
| `beginner` | No prior experience needed |
| `intermediate` | Some experience required |
| `advanced` | Significant experience required |

### Common Role Values

| Value | Description |
|-------|-------------|
| `administrator` | IT admin roles |
| `ai-engineer` | AI/ML engineering |
| `business-analyst` | Business analysis |
| `data-analyst` | Data analysis |
| `data-engineer` | Data engineering |
| `data-scientist` | Data science |
| `developer` | Software development |
| `devops-engineer` | DevOps engineering |
| `network-engineer` | Network engineering |
| `security-engineer` | Security engineering |
| `solution-architect` | Solution architecture |
| `student` | Students and learners |

### Common Product Values

| Value | Product |
|-------|---------|
| `azure` | Microsoft Azure (broad) |
| `azure-openai` | Azure OpenAI Service |
| `azure-machine-learning` | Azure Machine Learning |
| `azure-cosmos-db` | Azure Cosmos DB |
| `azure-functions` | Azure Functions |
| `azure-kubernetes-service` | Azure Kubernetes Service |
| `azure-virtual-machines` | Azure Virtual Machines |
| `dynamics-365` | Dynamics 365 (broad) |
| `power-platform` | Power Platform (broad) |
| `power-bi` | Power BI |
| `power-apps` | Power Apps |
| `power-automate` | Power Automate |
| `m365` | Microsoft 365 |
| `microsoft-365-copilot` | Microsoft 365 Copilot |
| `microsoft-copilot-studio` | Copilot Studio |
| `microsoft-purview` | Microsoft Purview |
| `microsoft-sentinel` | Microsoft Sentinel |
| `microsoft-defender` | Microsoft Defender |
| `intune` | Microsoft Intune |
| `windows` | Windows |
| `dotnet` | .NET |
| `vs-code` | Visual Studio Code |
| `github` | GitHub |

### Common Subject Values

| Value | Subject |
|-------|---------|
| `artificial-intelligence` | AI & ML |
| `cloud-computing` | Cloud computing |
| `cloud-security` | Cloud security |
| `data-management` | Data management |
| `data-engineering` | Data engineering |
| `identity-access` | Identity & access |
| `machine-learning` | Machine learning |
| `networking` | Networking |
| `security` | Security |
| `app-development` | App development |
| `devops` | DevOps |
| `compliance` | Compliance |

## Response Schema

### Module Record

| Field | Type | Description |
|-------|------|-------------|
| `uid` | string | Unique identifier |
| `title` | string | Module title (localized) |
| `summary` | string | Short description |
| `type` | string | Always `"module"` |
| `levels` | string[] | Audience levels |
| `roles` | string[] | Target job roles |
| `products` | string[] | Related products |
| `subjects` | string[] | Subject tags |
| `duration_in_minutes` | int | Estimated completion time |
| `rating` | object | `{count, average}` — user ratings |
| `popularity` | float | Normalized 0-1 popularity score |
| `url` | string | Direct URL to module |
| `firstUnitUrl` | string | URL to first unit |
| `units` | string[] | UIDs of child units |
| `number_of_children` | int | Number of units |
| `last_modified` | date | Last major revision |
| `locale` | string | Content language |

### Learning Path Record

| Field | Type | Description |
|-------|------|-------------|
| `uid` | string | Unique identifier |
| `title` | string | Learning path title (localized) |
| `summary` | string | Short description |
| `type` | string | Always `"learningPath"` |
| `levels` | string[] | Audience levels |
| `roles` | string[] | Target job roles |
| `products` | string[] | Related products |
| `subjects` | string[] | Subject tags |
| `duration_in_minutes` | int | Total estimated time |
| `url` | string | Direct URL |
| `modules` | string[] | UIDs of child modules |
| `number_of_children` | int | Number of modules |

### Certification Record

| Field | Type | Description |
|-------|------|-------------|
| `uid` | string | Unique identifier |
| `title` | string | Certification name |
| `subtitle` | string | Short subtitle |
| `type` | string | Always `"certification"` |
| `certification_type` | string | `fundamentals`, `role-based`, `specialty` |
| `levels` | string[] | Audience levels |
| `roles` | string[] | Target roles |
| `products` | string[] | Related products |
| `url` | string | Direct URL to cert page |
| `exams` | string[] | UIDs of required exams |

### Exam Record

| Field | Type | Description |
|-------|------|-------------|
| `uid` | string | Unique identifier |
| `title` | string | Exam title |
| `type` | string | Always `"exam"` |
| `levels` | string[] | Audience levels |
| `roles` | string[] | Target roles |
| `products` | string[] | Related products |
| `url` | string | Direct URL to exam page |
| `courses` | string[] | UIDs of related courses |
| `certifications` | string[] | UIDs of certs this exam satisfies |
| `study_guide` | object | Study guide sections |

### Course Record (Instructor-Led)

| Field | Type | Description |
|-------|------|-------------|
| `uid` | string | Unique identifier |
| `title` | string | Course title |
| `type` | string | Always `"course"` |
| `course_number` | string | Official course ID (e.g., AZ-104T00) |
| `levels` | string[] | Audience levels |
| `roles` | string[] | Target roles |
| `products` | string[] | Related products |
| `duration_in_hours` | int | Instructor-led duration |
| `url` | string | Direct URL |
| `certification` | string | UID of associated cert |
| `exam` | string | UID of associated exam |
| `modules` | string[] | UIDs of related modules |

## Example Queries

| Use Case | URL |
|----------|-----|
| All Azure beginner modules | `?type=modules&product=azure&level=beginner` |
| Copilot certifications | `?type=certifications,exams&product=microsoft-365-copilot` |
| Popular AI learning paths | `?type=learningPaths&subject=artificial-intelligence&popularity=gte 0.7` |
| All Portuguese content | `?locale=pt-br&type=modules,learningPaths` |
| Security for admins | `?type=modules,learningPaths&product=microsoft-sentinel&role=administrator` |
| Updated in last 6 months | `?type=modules&last_modified=gte 2025-10-01` |
| Specific module by UID | `?uid=learn.azure.intro-to-azure-fundamentals` |
| All instructor-led courses | `?type=courses` |

## Notes

- Responses can be very large. Always filter by `type` + at least one dimension (product/role/level/subject).
- Not all content is localized. If `locale=pt-br` returns fewer results, also query `locale=en-us`.
- `popularity` is normalized 0-1; use `gte 0.5` for above-average, `gte 0.8` for top content.
- `last_modified` uses ISO 8601 dates. Operators: `lt`, `lte`, `eq`, `gt`, `gte`.
