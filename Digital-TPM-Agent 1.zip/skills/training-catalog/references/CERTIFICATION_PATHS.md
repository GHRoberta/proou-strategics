# Microsoft Certification Paths Reference

Common Microsoft certification tracks with prerequisite chains, associated exams, and recommended preparation.

## Certification Types

| Type | Description | Example |
|------|-------------|---------|
| **Fundamentals** | Entry-level, no prerequisites | AZ-900, AI-900, SC-900 |
| **Role-based** | Intermediate/Advanced, validates job role skills | AZ-104, AZ-204, AZ-305 |
| **Specialty** | Deep expertise in specific technology area | AZ-400, AI-102 |

## Azure Certification Tracks

### Cloud Fundamentals → Administrator → Architect

```
AZ-900 (Azure Fundamentals)
  └── AZ-104 (Azure Administrator Associate)
        └── AZ-305 (Azure Solutions Architect Expert)
```

### Cloud Fundamentals → Developer

```
AZ-900 (Azure Fundamentals)
  └── AZ-204 (Azure Developer Associate)
```

### AI Track

```
AI-900 (Azure AI Fundamentals)
  └── AI-102 (Azure AI Engineer Associate)
  └── AI-3018 (Implement a Copilot with Azure AI Foundry)
```

### Data Track

```
DP-900 (Azure Data Fundamentals)
  └── DP-203 (Azure Data Engineer Associate)
  └── DP-300 (Azure Database Administrator Associate)
  └── DP-600 (Fabric Analytics Engineer Associate)
  └── DP-700 (Fabric Data Engineer Associate)
```

### Security Track

```
SC-900 (Security, Compliance, and Identity Fundamentals)
  └── SC-200 (Security Operations Analyst Associate)
  └── SC-300 (Identity and Access Administrator Associate)
  └── SC-400 (Information Protection and Compliance Administrator)
  └── AZ-500 (Azure Security Engineer Associate)
```

### DevOps

```
AZ-900 (Azure Fundamentals) [recommended]
  └── AZ-400 (DevOps Engineer Expert)
        ↑ Requires: AZ-104 OR AZ-204
```

### Networking

```
AZ-900 (Azure Fundamentals) [recommended]
  └── AZ-700 (Azure Network Engineer Associate)
```

## Microsoft 365 & Copilot Certification Tracks

### M365 Fundamentals → Admin → Copilot

```
MS-900 (Microsoft 365 Fundamentals)
  └── MS-102 (Microsoft 365 Administrator Expert)
  └── MS-4004 (Empower your workforce with Copilot for Microsoft 365)
  └── MS-4005 (Craft effective prompts for Microsoft 365 Copilot)
```

### Teams

```
MS-900 (Microsoft 365 Fundamentals) [recommended]
  └── MS-700 (Managing Microsoft Teams)
  └── MS-721 (Collaboration Communications Systems Engineer)
```

## Dynamics 365 Certification Tracks

### Business Applications Fundamentals

```
MB-910 (Dynamics 365 Fundamentals: Customer Engagement)
MB-920 (Dynamics 365 Fundamentals: Finance and Operations)
```

### Functional Consultants

```
MB-210 (Dynamics 365 Sales Functional Consultant)
MB-220 (Dynamics 365 Customer Insights - Journeys)
MB-230 (Dynamics 365 Customer Service Functional Consultant)
MB-240 (Dynamics 365 Field Service Functional Consultant)
MB-300 (Dynamics 365 Finance and Operations Core)
  └── MB-310 (Dynamics 365 Finance Functional Consultant)
  └── MB-330 (Dynamics 365 Supply Chain Management)
  └── MB-335 (Dynamics 365 Supply Chain Management Expert)
```

## Power Platform Certification Tracks

```
PL-900 (Power Platform Fundamentals)
  └── PL-100 (Power Platform App Maker)
  └── PL-200 (Power Platform Functional Consultant)
  └── PL-300 (Power BI Data Analyst)
  └── PL-400 (Power Platform Developer)
  └── PL-500 (Power Automate RPA Developer)
  └── PL-600 (Power Platform Solution Architect Expert)
```

## Copilot & AI Business Certifications

```
AB-100 (Architecting Agentic AI Business Solutions)
AB-730 (Transform Business Workflows with Generative AI)
AI-050 (Develop Generative AI Solutions with Azure OpenAI Service)
AI-3016 (Develop Copilots with Microsoft Copilot Studio)
```

## Exam-to-ESI Course Mapping

Many exams have a corresponding ESI course with the same base number:

| Exam | ESI Course ID | ESI Title |
|------|--------------|-----------|
| AZ-104 | AZ-104T00 | Microsoft Azure Administrator |
| AZ-204 | AZ-204T00 | Developing Solutions for Microsoft Azure |
| AZ-305 | AZ-305T00 | Designing Microsoft Azure Infrastructure Solutions |
| AZ-400 | AZ-400T00 | Designing and Implementing Microsoft DevOps Solutions |
| AZ-500 | AZ-500T00 | Microsoft Azure Security Technologies |
| AZ-700 | AZ-700T00 | Designing and Implementing Microsoft Azure Networking |
| AI-102 | AI-102T00 | Designing and Implementing Azure AI Solutions |
| DP-203 | DP-203T00 | Data Engineering on Microsoft Azure |
| DP-300 | DP-300T00 | Administering Microsoft Azure SQL Solutions |
| SC-200 | SC-200T00 | Microsoft Security Operations Analyst |
| SC-300 | SC-300T00 | Microsoft Identity and Access Administrator |
| MS-102 | MS-102T00 | Microsoft 365 Administrator |

> **Pattern:** ESI course ID = Exam number + "T00" suffix (e.g., AZ-104 → AZ-104T00).
> Shortened versions may use ".S" suffix (e.g., AB-730.S for a 3-hour version).
> Practice exams use "-PE" suffix (e.g., AZ-104-PE).

## How to Use This Reference

1. **User asks "how to get certified in Azure"** → Show the Azure tracks, recommend starting with AZ-900
2. **User asks about a specific exam** → Find the track, show prerequisites, map to ESI course
3. **User wants a training plan for a cert** → Combine MS Learn paths + ESI courses + practice exams
4. **User asks "what certs are available for X product"** → Filter by product area in the tracks above
