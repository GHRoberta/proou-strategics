# ESI Catalog Queries — Dynamight OData Reference

Query patterns for the ESI course catalog at `esiadmin.crm.dynamics.com`.

## Entity

| Property | Value |
|----------|-------|
| Entity logical name | `msdyn_incidenttype` |
| Entity set | `msdyn_incidenttypes` |
| Display name | Catalog Item |
| Primary key | `msdyn_incidenttypeid` |
| Primary name | `msdyn_name` (Catalog ID, e.g., "AZ-104T00") |
| Active records (as of 2026-04) | ~301 |

## Authentication

Same Dynamight pattern — all queries use Azure CLI token:

```powershell
$token = (az account get-access-token --resource "https://esiadmin.crm.dynamics.com/" --query accessToken -o tsv 2>$null)
$headers = @{
    Authorization = "Bearer $token"
    Accept        = "application/json"
    "OData-MaxVersion" = "4.0"
    "OData-Version"    = "4.0"
    "Prefer"           = 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
}
$base = "https://esiadmin.crm.dynamics.com/api/data/v9.2"
```

> ⚠️ Always include the `Prefer` header to get formatted values for Picklist fields.

## Key Fields

| Field | Display Name | Type | Description |
|-------|-------------|------|-------------|
| `msdyn_name` | Catalog ID | String | Course identifier (e.g., "AZ-104T00", "AB-100") |
| `esi_title` | Title | String | Full course title |
| `msdyn_description` | Description | Memo | Course description |
| `esi_courseprerequisites` | Course Prerequisites | Memo | Prerequisite descriptions |
| `esi_audienceprofile` | Audience Profile | Memo | Target audience description |
| `esi_catalogitemtype` | Catalog Item Type | Picklist | Type of catalog entry |
| `esi_itemtype` | Item Type | Picklist | Delivery vs Non-Delivery |
| `esi_deliverytypessupported` | Delivery Types | Picklist | OE Only, Private Only, OE and Private |
| `esi_deliveredby` | Delivered By | Picklist | Microsoft, LinkedIn Learning, etc. |
| `esi_standardduration` | Standard Duration | String | e.g., "4 days", "8 hours" |
| `msdyn_estimatedduration` | Estimated Duration | Integer | Duration in minutes |
| `esi_mslearnurl` | MSLearn URL | String | Link to MS Learn content |
| `esi_externalurl` | External URL | String | Link to external content |
| `esi_sku` | SKU | String | Product SKU |
| `esi_tier` | Tier | String | Pricing/access tier |
| `esi_creditvalue` | Credit Value | Decimal | Training credit value |
| `esi_activedate` | Active Date | DateTime | When course became active |
| `esi_retirementdate` | Retirement Date | DateTime | Scheduled retirement |
| `esi_language` | Language | Picklist | Content language |
| `statecode` | Status | State | 0 = Active, 1 = Inactive |
| `statuscode` | Status Reason | Status | **Critical:** even when `statecode=0`, this can be "Retired". Always check via formatted value annotation. |
| `esi_catalogclassification` | Catalog Classification | Lookup | Classification category |
| `esi_catalogitemsolutionarea` | Solution Area | Lookup | Solution area mapping |
| `esi_microsoftcertification` | Microsoft Certification | Lookup | Linked cert |
| `esi_solutionplay` | Solution Play | Lookup | Linked solution play |

## OptionSet Values

### Catalog Item Type (`esi_catalogitemtype`)

| Value | Label |
|-------|-------|
| 859270000 | Event |
| 859270001 | LinkedIn Learning |
| 859270002 | Microsoft Cloud Workshop |
| 859270003 | MOC Courseware |
| 859270004 | MSLearn |
| 859270005 | Pluralsight |
| 859270006 | WorkshopPlus |
| 859270007 | LearnOnDemand-HOIL |
| 859270008 | OpenHack |
| 859270009 | Opsgility |
| 859270010 | Practice Exam |
| 859270011 | Gamified Experience |
| 859270012 | EdTech Subscription |
| 100000000 | GPS Depth Workshop |

### Delivery Types Supported (`esi_deliverytypessupported`)

| Value | Label |
|-------|-------|
| 859270000 | OE Only |
| 859270001 | Private Only |
| 859270002 | OE and Private |

### Item Type (`esi_itemtype`)

| Value | Label |
|-------|-------|
| 859270000 | Delivery |
| 859270001 | Non-Delivery |

### Delivered By (`esi_deliveredby`)

| Value | Label |
|-------|-------|
| 859270000 | LinkedIn Learning |
| 859270001 | Microsoft |
| 859270002 | PluralSight |
| 859270003 | Opsgility |

## Query Templates

### Q1: Search by Keyword

```powershell
$keyword = "Azure"
$url = "$base/msdyn_incidenttypes?`$filter=statecode eq 0 and (contains(esi_title,'$keyword') or contains(msdyn_name,'$keyword') or contains(msdyn_description,'$keyword'))&`$select=msdyn_name,esi_title,msdyn_description,esi_courseprerequisites,esi_standardduration,esi_catalogitemtype,esi_deliverytypessupported,esi_deliveredby,esi_mslearnurl,esi_itemtype,statuscode,esi_retirementdate&`$orderby=msdyn_name&`$top=50"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
```

> ⚠️ Always check `statuscode` formatted value — `statecode eq 0` alone does NOT filter out retired courses.

### Q2: Search by Catalog Item Type (e.g., MOC Courseware only)

```powershell
$url = "$base/msdyn_incidenttypes?`$filter=statecode eq 0 and esi_catalogitemtype eq 859270003&`$select=msdyn_name,esi_title,esi_standardduration,esi_deliverytypessupported,esi_deliveredby,esi_courseprerequisites,esi_mslearnurl,statuscode,esi_retirementdate&`$orderby=msdyn_name&`$top=100"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
```

### Q3: Search by Course ID

```powershell
$courseId = "AZ-104"
$url = "$base/msdyn_incidenttypes?`$filter=statecode eq 0 and contains(msdyn_name,'$courseId')&`$select=msdyn_name,esi_title,msdyn_description,esi_courseprerequisites,esi_standardduration,esi_catalogitemtype,esi_deliverytypessupported,esi_deliveredby,esi_mslearnurl,esi_audienceprofile,esi_creditvalue,statuscode,esi_retirementdate,esi_language,esi_activedate&`$orderby=msdyn_name"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
```

### Q4: List All Active Delivery Courses

```powershell
$url = "$base/msdyn_incidenttypes?`$filter=statecode eq 0 and esi_itemtype eq 859270000&`$select=msdyn_name,esi_title,esi_catalogitemtype,esi_standardduration,esi_deliverytypessupported,esi_deliveredby,statuscode,esi_retirementdate&`$orderby=msdyn_name&`$top=200"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
```

### Q5: Courses Retiring Soon

```powershell
$futureDate = (Get-Date).AddMonths(6).ToString("yyyy-MM-dd")
$url = "$base/msdyn_incidenttypes?`$filter=statecode eq 0 and esi_retirementdate ne null and esi_retirementdate le $futureDate&`$select=msdyn_name,esi_title,esi_retirementdate,esi_catalogitemtype&`$orderby=esi_retirementdate"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
```

### Q6: Expand Solution Area and Certification Lookups

```powershell
$url = "$base/msdyn_incidenttypes?`$filter=statecode eq 0 and contains(msdyn_name,'AZ-104')&`$select=msdyn_name,esi_title&`$expand=esi_catalogitemsolutionarea(`$select=msdyn_name),esi_microsoftcertification(`$select=msdyn_name)"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
```

### Q7: Pre-Request Retirement Check (Safeguard)

Use this query **before every PD/OE request** to validate that courses are
not retired. Returns `statuscode` formatted value which can be "Active" or
"Retired" even when `statecode eq 0`.

```powershell
# Check one or more courses by ID — pass comma-separated IDs
$courseIds = @("AI-102", "DP-100", "PL-300", "DP-700")
foreach ($id in $courseIds) {
    $url = "$base/msdyn_incidenttypes?`$filter=contains(msdyn_name,'$id')&`$select=msdyn_name,esi_title,statecode,statuscode,esi_retirementdate,esi_activedate,esi_creditvalue,esi_deliverytypessupported,esi_language&`$top=5"
    $resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
    foreach ($item in $resp.value) {
        $status = $item.'statuscode@OData.Community.Display.V1.FormattedValue'
        $delivery = $item.'esi_deliverytypessupported@OData.Community.Display.V1.FormattedValue'
        $lang = $item.'esi_language@OData.Community.Display.V1.FormattedValue'
        Write-Host "$($item.msdyn_name) | $($item.esi_title) | Status: $status | Retirement: $($item.esi_retirementdate) | Delivery: $delivery | Language: $lang | Credits: $($item.esi_creditvalue)"
    }
}
```

**Decision logic after Q7:**

| statuscode | Action |
|-----------|--------|
| Active | ✅ OK to include in request |
| Retired | ❌ BLOCK — alert user, search for successor (try next sequential ID: AI-102→AI-103, DP-100→AI-300), present replacement |

> ⚠️ **Critical:** This query is MANDATORY before any PD request. The
> [CLIENTE] Seguros incident (May 2026) showed that `statecode eq 0` alone
> missed retired courses (AI-102, DP-100 retired 4/30/2026), causing TPC
> rejection and rework. See SKILL.md § "Pre-Request Validation Checklist"
> for the full safeguard rules.

## Result Formatting

Parse each record and present formatted output:

```powershell
$resp.value | ForEach-Object {
    [PSCustomObject]@{
        CatalogID   = $_.msdyn_name
        Title       = $_.esi_title
        Status      = $_.'statuscode@OData.Community.Display.V1.FormattedValue'
        Type        = $_.'esi_catalogitemtype@OData.Community.Display.V1.FormattedValue'
        Delivery    = $_.'esi_deliverytypessupported@OData.Community.Display.V1.FormattedValue'
        DeliveredBy = $_.'esi_deliveredby@OData.Community.Display.V1.FormattedValue'
        Duration    = $_.esi_standardduration
        Retirement  = $_.esi_retirementdate
        MSLearnURL  = $_.esi_mslearnurl
    }
} | Format-Table -AutoSize
```

> ⚠️ Always include `Status` (from `statuscode` formatted value) in output. Flag any "Retired" entries prominently.

> ⚠️ Formatted values for Picklist fields use the `@OData.Community.Display.V1.FormattedValue` annotation.
> ⚠️ The `Prefer` header must include `odata.include-annotations="OData.Community.Display.V1.FormattedValue"`.
