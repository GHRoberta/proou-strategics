# YouTube Microsoft Learn — Search Patterns

Strategies for finding recorded Microsoft training content on YouTube.

## Primary Channel

| Property | Value |
|----------|-------|
| Channel | Microsoft Learn |
| URL | `https://www.youtube.com/@MicrosoftLearn` |
| Playlists | `https://www.youtube.com/@MicrosoftLearn/playlists` |
| Content | Technical sessions, certifications prep, product deep-dives, event recordings |

## Search Strategies

### Strategy 1: Web Search (Recommended)

Use `web_search` for targeted discovery:

```
web_search(query="site:youtube.com/@MicrosoftLearn {topic} playlist")
web_search(query="site:youtube.com Microsoft Learn {certification} exam prep")
web_search(query="site:youtube.com Microsoft Learn {product} training 2025 2026")
```

**Why web search over direct URL:** YouTube is a SPA (Single Page Application) — `web_fetch` returns JavaScript, not rendered content. Web search indexes the rendered pages and returns useful results.

### Strategy 2: Topic-Specific Search

For broad topics, search without the site restriction to include related channels:

```
web_search(query="Microsoft Learn YouTube {topic} training playlist")
web_search(query="Microsoft official {product} training recorded sessions")
```

### Strategy 3: Event Recordings

Microsoft events are often recorded and posted to YouTube:

```
web_search(query="site:youtube.com Microsoft Ignite {year} {topic} session")
web_search(query="site:youtube.com Microsoft Build {year} {topic}")
web_search(query="site:youtube.com Microsoft Learn AI Tour {year}")
```

## Known High-Value Playlists

These are well-known playlist series on the Microsoft Learn channel. Search for the latest versions:

| Series | Topics | Search Pattern |
|--------|--------|---------------|
| Azure Fundamentals (AZ-900) | Cloud concepts, Azure services | `Microsoft Learn AZ-900 playlist` |
| Azure Administrator (AZ-104) | VM, storage, networking, identity | `Microsoft Learn AZ-104 playlist` |
| Azure Developer (AZ-204) | App services, functions, Cosmos DB | `Microsoft Learn AZ-204 playlist` |
| Azure Architect (AZ-305) | Design patterns, governance | `Microsoft Learn AZ-305 playlist` |
| AI Fundamentals (AI-900) | AI concepts, Azure AI services | `Microsoft Learn AI-900 playlist` |
| Data Fundamentals (DP-900) | Data concepts, Azure data services | `Microsoft Learn DP-900 playlist` |
| Security Fundamentals (SC-900) | Security, compliance, identity | `Microsoft Learn SC-900 playlist` |
| Power Platform (PL-900) | Power Apps, Power Automate, Power BI | `Microsoft Learn PL-900 playlist` |
| Microsoft 365 (MS-900) | M365 services, licensing | `Microsoft Learn MS-900 playlist` |
| Copilot for Microsoft 365 | Copilot features, prompting | `Microsoft Learn Copilot Microsoft 365` |
| Azure OpenAI | GPT, DALL-E, embeddings | `Microsoft Learn Azure OpenAI playlist` |
| GitHub Copilot | AI pair programming | `Microsoft Learn GitHub Copilot` |
| Fabric Analytics | Data lakehouse, pipelines | `Microsoft Learn Fabric playlist` |

## Related YouTube Channels

| Channel | Focus | URL |
|---------|-------|-----|
| Microsoft Learn | Official training content | `@MicrosoftLearn` |
| Microsoft Developer | Dev tools, APIs, SDKs | `@MicrosoftDeveloper` |
| Microsoft Azure | Azure product updates | `@MicrosoftAzure` |
| Microsoft Mechanics | Product demos, deep-dives | `@MicrosoftMechanics` |
| Microsoft 365 | M365 productivity | `@Microsoft365` |
| Azure Power Platform | Power Platform content | `@MicrosoftPowerPlatform` |

## Result Formatting

Present YouTube findings as:

```
| # | Title | Type | Duration/Count | URL |
|---|-------|------|---------------|-----|
| 1 | AZ-900 Certification Course | Playlist (23 videos) | ~8 hours | [Watch](url) |
| 2 | Azure OpenAI Deep Dive | Video | 45 min | [Watch](url) |
```

## Notes

- YouTube playlists change frequently. Always search for the latest version.
- Some playlists are tied to specific events (Ignite, Build) and may be seasonal.
- For non-English content, add language to search: `Microsoft Learn {topic} português`.
- Complement YouTube results with MS Learn self-paced modules for a complete experience.
