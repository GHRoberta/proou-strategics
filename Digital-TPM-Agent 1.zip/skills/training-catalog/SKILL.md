---
name: training-catalog
description: >
  Unified training catalog for Microsoft Learn, ESI (Enterprise Skills Initiative),
  YouTube recorded sessions, and certification paths. Use this skill whenever the user
  asks about training, courses, certifications, learning paths, exams, skilling,
  capacitação, treinamento, upskilling, ESI catalog, MOC courses, Microsoft Learn
  modules, certification prerequisites, exam prep, recorded training videos,
  or "what training is available for X" — even if they don't say "training-catalog".
  Triggers: training, course, certification, exam, learning path, module, skilling,
  capacitação, treinamento, upskilling, ESI course, MOC, Microsoft Learn, cert path,
  exam prep, recorded sessions, YouTube Learn, training plan, course catalog,
  treinamento gravado, trilha de certificação.
---

# Training Catalog — Unified Microsoft Training Intelligence

Search, recommend, and plan Microsoft training across four sources: MS Learn Catalog API,
ESI Admin (Dynamight), YouTube Microsoft Learn, and certification paths.

## Prerequisites

### Required
- **Internet access** — for MS Learn Catalog API queries via `web_fetch`
- **Web search** — for YouTube Microsoft Learn playlist discovery

### Optional (ESI Catalog)
- **Azure CLI** — signed in as `@microsoft.com` with `az login`
- **Corporate VPN** — required to reach `esiadmin.crm.dynamics.com`
- **ESI Admin access** — user must have a security role in the ESI Admin org

If ESI access is unavailable, inform the user and proceed with MS Learn + YouTube sources only.

## Data Sources

| Source | Access Method | Content |
|--------|--------------|---------|
| MS Learn Catalog API | `web_fetch` (REST/JSON) | Modules, learning paths, certifications, exams, courses, applied skills |
| ESI Admin (Dynamight) | PowerShell + Azure CLI OData | ESI course catalog (301+ items), MOC courseware, workshops, exams |
| YouTube Microsoft Learn | `web_search` | Recorded sessions, playlists, event recordings |
| Certification Paths | Built-in reference | Cert tracks, prerequisites, exam mappings |

---

## Workflow 1: Search MS Learn Training

Use when the user asks "what training is available for X", "find modules about Y", or similar.

### Step 1: Build the API Query

Construct the URL using [MS_LEARN_API_REFERENCE.md](references/MS_LEARN_API_REFERENCE.md) query parameters:

```
https://learn.microsoft.com/api/catalog/?type={types}&product={product}&role={role}&level={level}&locale={locale}
```

**Mapping user intent to parameters:**

| User says | Parameter |
|-----------|-----------|
| "beginner", "intro", "básico" | `level=beginner` |
| "intermediate", "intermediário" | `level=intermediate` |
| "advanced", "avançado" | `level=advanced` |
| "for developers" | `role=developer` |
| "for admins", "para administradores" | `role=administrator` |
| "Azure", "about Azure" | `product=azure` |
| "Dynamics 365" | `product=dynamics-365` |
| "Microsoft 365", "M365" | `product=m365` |
| "Power Platform" | `product=power-platform` |
| "Security", "Segurança" | `product=microsoft-sentinel` or `subject=security` |
| "AI", "Copilot" | `product=microsoft-365-copilot` or `product=azure-openai` |

**Content types** — always request relevant types:

| User wants | `type=` |
|------------|---------|
| Courses, modules | `modules` |
| Learning paths, trilhas | `learningPaths` |
| Certifications | `certifications,exams` |
| Everything | `modules,learningPaths,certifications,exams,courses` |

### Step 2: Execute the Query

```
web_fetch(url="https://learn.microsoft.com/api/catalog/?type=modules,learningPaths&product=azure&level=beginner&locale=pt-br", raw=true, max_length=20000)
```

> ⚠️ Use `raw=true` since the response is JSON. Parse with inline logic.
> ⚠️ The full catalog is very large (15MB+). **Always filter** by type + at least one of: product, role, level, subject.
> ⚠️ For Portuguese content, add `&locale=pt-br`. Not all content is localized — fall back to `en-us`.

### Step 3: Present Results

Format results as a table:

```
| # | Title | Type | Level | Duration | URL |
|---|-------|------|-------|----------|-----|
| 1 | Introduction to Azure | Module | Beginner | 62 min | [Link](url) |
```

Include for each result: title, type (module/learningPath/certification), level, duration, popularity score if >0.7, and direct URL.

---

## Workflow 2: Certification Path Lookup

Use when user asks about certifications, cert tracks, exam prerequisites, or "how to get certified in X".

### Step 1: Query Certifications

```
web_fetch(url="https://learn.microsoft.com/api/catalog/?type=certifications,exams&locale=en-us", raw=true, max_length=20000)
```

### Step 2: Match and Present

1. Filter by keywords in title/summary
2. For each cert, show: title, level, associated exams, URL
3. Cross-reference with [CERTIFICATION_PATHS.md](references/CERTIFICATION_PATHS.md) for prerequisite chains
4. Recommend preparatory learning paths using Workflow 1

### Step 3: Map to ESI (if available)

If ESI access is available, check if the exam has an ESI course equivalent:
- Query ESI catalog by exam number (e.g., "AZ-900" → search `msdyn_name` contains "AZ-900")
- Show ESI delivery options alongside MS Learn self-paced paths

---

## Workflow 3: ESI Catalog Lookup

Use when user mentions ESI, MOC courses, instructor-led training, OE delivery, or private training.

### Prerequisites Check

1. Verify Azure CLI is signed in: `az account show --query user.name -o tsv`
2. Verify VPN connectivity to `esiadmin.crm.dynamics.com`
3. If either fails, inform the user and suggest MS Learn alternatives (Workflow 1)

### Step 1: Query ESI Catalog

Use the Dynamight OData pattern from [ESI_CATALOG_QUERIES.md](references/ESI_CATALOG_QUERIES.md).

**Search by keyword:**
```powershell
$filter = "statecode eq 0 and (contains(esi_title,'keyword') or contains(msdyn_name,'keyword'))"
```

**Search by solution area:** Use the `esi_catalogitemsolutionarea` lookup.

**Filter by catalog type:**
- MOC Courseware: `esi_catalogitemtype eq 859270003`
- WorkshopPlus: `esi_catalogitemtype eq 859270006`
- Practice Exam: `esi_catalogitemtype eq 859270010`

### Step 2: Present Results

```
| Catalog ID | Title | Type | Delivery | Duration | Delivered By |
|------------|-------|------|----------|----------|--------------|
| AZ-104T00  | Azure Administrator | MOC Courseware | OE and Private | 4 days | Microsoft |
```

Include: catalog ID (`msdyn_name`), title (`esi_title`), type, delivery mode, duration, description summary, prerequisites, and MS Learn URL if available.

### Step 3: Enrich with MS Learn

If the ESI course has an `esi_mslearnurl`, fetch the matching MS Learn module details.
If not, search MS Learn by course title keywords to find complementary self-paced content.

---

## Workflow 4: Find Recorded Training (YouTube)

Use when user asks for recorded sessions, video training, "treinamento gravado", or YouTube content.

### Step 1: Search YouTube Microsoft Learn

Use `web_search` to find specific playlists or recordings:

```
web_search(query="site:youtube.com/@MicrosoftLearn {topic} playlist")
```

Also reference [YOUTUBE_SEARCH_PATTERNS.md](references/YOUTUBE_SEARCH_PATTERNS.md) for known playlist URLs and search strategies.

### Step 2: Present Results

Format as:
```
| # | Title | Type | Channel | URL |
|---|-------|------|---------|-----|
| 1 | Azure Fundamentals Series | Playlist (12 videos) | Microsoft Learn | [Watch](url) |
```

---

## Workflow 5: Build Training Plan

Use when user asks for a training plan, learning path recommendation, or "capacitação para minha equipe".

### Step 1: Understand Requirements

Ask the user (if not clear):
1. **Target role** — developer, admin, architect, data scientist, etc.
2. **Product focus** — Azure, M365, Dynamics 365, Power Platform, Security
3. **Current level** — beginner, intermediate, advanced
4. **Goal** — certification, skill-up, specific project prep
5. **Preferred format** — self-paced, instructor-led (ESI), recorded video

### Step 2: Gather Content (parallel)

Run these in parallel based on user preferences:
1. MS Learn query (Workflow 1) for self-paced modules and learning paths
2. ESI catalog query (Workflow 3) for instructor-led options
3. YouTube search (Workflow 4) for recorded sessions
4. Certification lookup (Workflow 2) if cert is the goal

### Step 3: Build the Plan

Present a structured training plan:

```markdown
## Training Plan: {Role} — {Product Focus}

### Phase 1: Foundations ({level})
| # | Resource | Source | Format | Duration |
|---|----------|--------|--------|----------|
| 1 | [Module Name](url) | MS Learn | Self-paced | 2h |
| 2 | [ESI Course](url) | ESI | Instructor-led | 3 days |

### Phase 2: Intermediate
...

### Phase 3: Certification Prep
| Exam | Prep Course (ESI) | Practice Exam | Study Path (MS Learn) |
|------|-------------------|---------------|----------------------|
| AZ-104 | AZ-104T00 | AZ-104-PE | [Learning Path](url) |

### Supplementary: Recorded Sessions
| # | Video/Playlist | URL |
|---|---------------|-----|
| 1 | [Playlist Name](url) | YouTube |
```

---

## Pre-Request Validation Checklist (Safeguards)

**MANDATORY** — run these checks before any PD/OE/TSPc request or training
recommendation. These rules exist because retired courses and EN-only OE
have caused rework and TPC rejections in the past.

### Rule 1: Retirement Check

Before including any course in a PD request, verify it is **not retired**:

```powershell
# Check statuscode (not just statecode!) for each course
$courseId = "AI-102"
$url = "$base/msdyn_incidenttypes?`$filter=contains(msdyn_name,'$courseId')&`$select=msdyn_name,esi_title,statecode,statuscode,esi_retirementdate&`$top=5"
$resp = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
$resp.value | ForEach-Object {
    $status = $_.'statuscode@OData.Community.Display.V1.FormattedValue'
    Write-Host "$($_.msdyn_name): $status (retirement: $($_.esi_retirementdate))"
}
```

- `statecode eq 0` (Active) + `statuscode` = **"Retired"** → course is
  retired but record still visible. **BLOCK** — do not include in any request.
- `statecode eq 0` + `statuscode` = **"Active"** → OK to proceed.
- ⚠️ `statecode eq 0` alone is **insufficient** — always check the
  `statuscode` formatted value.

**When a course is retired:**
1. **Alert the user immediately** with course name, retirement date, and reason
2. **Search for the successor course** in the catalog (common patterns:
   AI-102 → AI-103, DP-100 → AI-300, AZ-204 → AI-200)
3. **Present the replacement** with full details (duration, credits, delivery modes)
4. **Never silently exclude** a retired course — always inform and suggest

### Rule 2: OE Language Check (Brazil-specific)

When deciding whether to request a course as PD or recommend OE instead:

- **Only consider OE as a substitute for PD if OE is available in PT-BR**
- EN-only OE does **NOT** replace PD for Brazilian customers
- Check the OE schedule or catalog for language availability before excluding
  a course from a PD request

```
IF course has OE available:
    IF OE language includes PT-BR → OE is valid substitute, inform user
    IF OE language is EN-only → OE is NOT a substitute for BR customers,
       keep as PD and inform user why
```

### Rule 3: No Silent Exclusion

**Never automatically remove a course from a request without informing the user.**

- If a course is retired → alert + suggest replacement (Rule 1)
- If a course has OE in PT-BR → inform user that OE exists, ask if they
  want to switch from PD to OE
- If a course has OE in EN-only → inform user, recommend keeping as PD
- Always let the **user decide** — present options, don't make the call

### Rule 4: Holiday Verification

Before proposing training dates for Brazilian customers:
1. Check national holidays via BrasilAPI: `https://brasilapi.com.br/api/feriados/v1/{year}`
2. Check state holidays for the customer's location (SP: Jul 9; RJ: São Jorge Apr 23, etc.)
3. Check municipal holidays if known
4. **Never schedule training on a holiday** — shift dates and flag the change

---

## Error Handling

| Error | Likely Cause | Recovery |
|-------|-------------|----------|
| MS Learn API returns empty | Too specific filters | Broaden: remove one filter, try broader product |
| MS Learn API returns 400 | Invalid parameter value | Check [MS_LEARN_API_REFERENCE.md](references/MS_LEARN_API_REFERENCE.md) for valid values |
| ESI 401 Unauthorized | Azure CLI not signed in or no access | Run `az login`, verify ESI Admin role |
| ESI no results | Course ID not found or retired | Try broader keyword search, check `statecode eq 0` |
| YouTube no relevant results | Niche topic | Try broader search terms, check alternative channels |
| Large API response truncated | Too many results | Add more filters (level, role, product) |

---

## Output Language

Match the user's language. If the user writes in Portuguese (pt-BR), present all tables and explanations in Portuguese. Use `locale=pt-br` for MS Learn API when available.

---

## References

| Reference | When to load |
|-----------|-------------|
| [MS_LEARN_API_REFERENCE.md](references/MS_LEARN_API_REFERENCE.md) | When building MS Learn API queries — field schemas, valid parameter values |
| [ESI_CATALOG_QUERIES.md](references/ESI_CATALOG_QUERIES.md) | When querying ESI Dynamight — OData templates, entity schema, OptionSet codes |
| [CERTIFICATION_PATHS.md](references/CERTIFICATION_PATHS.md) | When mapping cert tracks — prerequisite chains, exam-to-cert mappings |
| [YOUTUBE_SEARCH_PATTERNS.md](references/YOUTUBE_SEARCH_PATTERNS.md) | When searching for recorded training — known playlists, search strategies |

---

## Post-Run Reflection

After completing a multi-step workflow, follow the [core § 5 Post-Run Reflection](../core/SKILL.md#5-post-run-reflection-continuous-improvement) protocol.
