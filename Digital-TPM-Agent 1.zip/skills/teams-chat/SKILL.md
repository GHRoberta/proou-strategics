---
name: teams-chat
description: >
  Send, reply, and search Microsoft Teams chat messages via Graph API.
  Uses Device Code Flow for auth (no az CLI needed). Supports 1:1 chats,
  group chats, and channel messages. Caches tokens for reuse.
  Triggers: teams message, send teams, reply teams, teams chat, enviar teams,
  responder teams, mensagem teams.
---

# Teams Chat — Graph API Skill

> **Note:** `%WORK_BASE%` defaults to `{{WORKDIR_LOCAL}}\` but can be configured during setup.

## When to Use

Load this skill when the user wants to:

- **Send** a message in an existing Teams chat (1:1 or group)
- **Reply** to a Teams chat message
- **List** recent chats
- **Read** recent messages from a specific chat
- **Post** a message to a Teams channel
- **Search** for a person to start/find a chat

**Do NOT use** when:

- User wants to *read* Teams intelligence/summaries (use **workiq** skill instead)
- User wants to schedule a Teams meeting (use calendar tools)
- User only needs to draft text (just compose in chat, no skill needed)

## Prerequisites

1. **Internet access** to Microsoft Graph API
2. **PowerShell 5.1** (`powershell.exe`) for COM-free HTTP calls
3. First-time use requires **Device Code Flow** auth (user opens browser, enters code)
4. Token is cached at `%WORK_BASE%\.teams-token-cache.json` for reuse

## Runtime Note

All scripts below MUST run under **PowerShell 5.1** (`powershell.exe -File <script.ps1>`).
Save scripts to `%WORK_BASE%\` before executing, then clean up after.

---

## 0. Authentication Helper

### First Time: Device Code Flow

The skill uses Microsoft's public client app ID for Graph CLI tools.
Token + refresh token are cached locally for reuse.

```powershell
# --- AUTH: Device Code Flow + Token Cache ---
# Save as .ps1 and run with powershell.exe -File

$workBase = if ($env:WORK_BASE) { $env:WORK_BASE } else { '{{WORKDIR_LOCAL}}' }
$tokenCachePath = Join-Path $workBase '.teams-token-cache.json'
$clientId       = "14d82eec-204b-4c2f-b7e8-296a70dab67e"  # Microsoft Graph CLI
$tenantId       = "organizations"
$scope          = "Chat.ReadWrite User.Read ChatMessage.Send"
$graphBase      = "https://graph.microsoft.com/v1.0"

function Get-GraphToken {
    # Try cached token first
    if (Test-Path $tokenCachePath) {
        $cache = Get-Content $tokenCachePath -Raw | ConvertFrom-Json
        $expiry = [DateTimeOffset]::FromUnixTimeSeconds($cache.expires_on)
        if ($expiry -gt [DateTimeOffset]::UtcNow.AddMinutes(5)) {
            return $cache.access_token
        }
        # Try refresh
        if ($cache.refresh_token) {
            Write-Host "Refreshing token..."
            try {
                $body = @{
                    client_id     = $clientId
                    grant_type    = "refresh_token"
                    refresh_token = $cache.refresh_token
                    scope         = $scope
                }
                $resp = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
                    -Method POST -Body $body -ContentType "application/x-www-form-urlencoded"
                $newCache = @{
                    access_token  = $resp.access_token
                    refresh_token = if ($resp.refresh_token) { $resp.refresh_token } else { $cache.refresh_token }
                    expires_on    = [int][DateTimeOffset]::UtcNow.AddSeconds($resp.expires_in).ToUnixTimeSeconds()
                }
                $newCache | ConvertTo-Json | Set-Content $tokenCachePath -Force
                Write-Host "Token refreshed OK."
                return $resp.access_token
            }
            catch {
                Write-Warning "Refresh failed: $($_.Exception.Message). Starting new auth..."
            }
        }
    }

    # Device Code Flow
    Write-Host "`n=== Teams Authentication Required ==="
    $deviceBody = @{
        client_id = $clientId
        scope     = $scope
    }
    $deviceResp = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/devicecode" `
        -Method POST -Body $deviceBody -ContentType "application/x-www-form-urlencoded"

    Write-Host "`n$($deviceResp.message)`n" -ForegroundColor Yellow

    # Poll for token
    $pollBody = @{
        client_id   = $clientId
        grant_type  = "urn:ietf:params:oauth:grant-type:device_code"
        device_code = $deviceResp.device_code
    }
    $interval = $deviceResp.interval
    $maxWait  = 300  # 5 minutes
    $waited   = 0

    while ($waited -lt $maxWait) {
        Start-Sleep -Seconds $interval
        $waited += $interval
        try {
            $tokenResp = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
                -Method POST -Body $pollBody -ContentType "application/x-www-form-urlencoded"

            $newCache = @{
                access_token  = $tokenResp.access_token
                refresh_token = $tokenResp.refresh_token
                expires_on    = [int][DateTimeOffset]::UtcNow.AddSeconds($tokenResp.expires_in).ToUnixTimeSeconds()
            }
            $newCache | ConvertTo-Json | Set-Content $tokenCachePath -Force
            Write-Host "Authenticated successfully. Token cached."
            return $tokenResp.access_token
        }
        catch {
            $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($err.error -eq "authorization_pending") { continue }
            if ($err.error -eq "slow_down") { $interval += 5; continue }
            throw "Auth failed: $($err.error_description)"
        }
    }
    throw "Authentication timed out after $maxWait seconds."
}

function Invoke-Graph {
    param([string]$Uri, [string]$Method = "GET", $Body = $null)
    $token = Get-GraphToken
    $headers = @{ Authorization = "Bearer $token"; "Content-Type" = "application/json" }
    $params = @{ Uri = $Uri; Method = $Method; Headers = $headers }
    if ($Body) { $params.Body = ($Body | ConvertTo-Json -Depth 10) }
    Invoke-RestMethod @params
}
```

**IMPORTANT:** Copy the auth helper block above into EVERY script below.
The `Get-GraphToken` function handles caching automatically.

---

## 1. List Recent Chats

```powershell
# After auth helper block...

$chats = Invoke-Graph -Uri "$graphBase/me/chats?`$top=20&`$expand=members&`$orderby=lastMessagePreview/createdDateTime desc"

Write-Host "`n=== Recent Teams Chats ===" -ForegroundColor Cyan
$i = 0
foreach ($chat in $chats.value) {
    $i++
    $type = $chat.chatType  # oneOnOne, group, meeting
    $topic = if ($chat.topic) { $chat.topic } else { "No topic" }
    $members = ($chat.members | ForEach-Object { $_.displayName }) -join ", "
    $lastMsg = if ($chat.lastMessagePreview.body.content) {
        $chat.lastMessagePreview.body.content.Substring(0, [Math]::Min(60, $chat.lastMessagePreview.body.content.Length))
    } else { "(no preview)" }
    $lastTime = $chat.lastMessagePreview.createdDateTime

    Write-Host "`n[$i] $type | $topic"
    Write-Host "    Members: $members"
    Write-Host "    Last: $lastMsg"
    Write-Host "    Time: $lastTime"
    Write-Host "    ID: $($chat.id)"
}
```

---

## 2. Read Messages from a Chat

```powershell
# After auth helper block...

$chatId = "<CHAT_ID_HERE>"  # from list chats output
$count  = 10

$msgs = Invoke-Graph -Uri "$graphBase/me/chats/$chatId/messages?`$top=$count&`$orderby=createdDateTime desc"

Write-Host "`n=== Messages ===" -ForegroundColor Cyan
foreach ($msg in $msgs.value | Sort-Object createdDateTime) {
    $from = $msg.from.user.displayName
    $time = $msg.createdDateTime
    $body = $msg.body.content -replace '<[^>]+>', ''  # strip HTML tags
    $body = $body.Trim()
    if ($body.Length -gt 200) { $body = $body.Substring(0, 200) + "..." }

    Write-Host "`n[$time] $from:"
    Write-Host "  $body"
}
```

---

## 3. Send a Message to an Existing Chat

```powershell
# After auth helper block...

$chatId  = "<CHAT_ID_HERE>"
$message = "<p>Your message here. Supports <b>HTML</b> formatting.</p>"

$body = @{
    body = @{
        contentType = "html"
        content     = $message
    }
}

$result = Invoke-Graph -Uri "$graphBase/me/chats/$chatId/messages" -Method POST -Body $body

Write-Host "Message sent at $($result.createdDateTime) to chat $chatId" -ForegroundColor Green
Write-Host "Message ID: $($result.id)"
```

---

## 4. Find a Person and Their Chat

```powershell
# After auth helper block...

$searchName = "João Silva"  # name to search

# Search people
$people = Invoke-Graph -Uri "$graphBase/me/people?`$search=`"$searchName`"&`$top=5"

Write-Host "`n=== People Found ===" -ForegroundColor Cyan
foreach ($p in $people.value) {
    Write-Host "$($p.displayName) | $($p.scoredEmailAddresses[0].address) | $($p.id)"
}

# Find existing 1:1 chat with the first match
if ($people.value.Count -gt 0) {
    $targetId = $people.value[0].id
    $targetName = $people.value[0].displayName

    # Search chats for this person
    $chats = Invoke-Graph -Uri "$graphBase/me/chats?`$filter=chatType eq 'oneOnOne'&`$expand=members&`$top=50"

    $found = $chats.value | Where-Object {
        $_.members | Where-Object { $_.userId -eq $targetId }
    } | Select-Object -First 1

    if ($found) {
        Write-Host "`n1:1 chat found with $targetName" -ForegroundColor Green
        Write-Host "Chat ID: $($found.id)"
    } else {
        Write-Host "`nNo existing 1:1 chat with $targetName. Use Section 5 to create one." -ForegroundColor Yellow
    }
}
```

---

## 5. Create a New 1:1 Chat and Send Message

```powershell
# After auth helper block...

$recipientEmail = "{{EMAIL}}"
$message = "<p>Oi! Mensagem enviada via Copilot CLI.</p>"

# Create new chat
$chatBody = @{
    chatType = "oneOnOne"
    members  = @(
        @{
            "@odata.type"     = "#microsoft.graph.aadUserConversationMember"
            roles             = @("owner")
            "{{EMAIL}}" = "https://graph.microsoft.com/v1.0/users('me')"
        },
        @{
            "@odata.type"     = "#microsoft.graph.aadUserConversationMember"
            roles             = @("owner")
            "{{EMAIL}}" = "https://graph.microsoft.com/v1.0/users('$recipientEmail')"
        }
    )
}

$chat = Invoke-Graph -Uri "$graphBase/me/chats" -Method POST -Body $chatBody
Write-Host "Chat created: $($chat.id)" -ForegroundColor Green

# Send message
$msgBody = @{
    body = @{
        contentType = "html"
        content     = $message
    }
}
$result = Invoke-Graph -Uri "$graphBase/me/chats/$($chat.id)/messages" -Method POST -Body $msgBody
Write-Host "Message sent at $($result.createdDateTime)" -ForegroundColor Green
```

---

## 6. Post to a Teams Channel

```powershell
# After auth helper block...

$teamId    = "<TEAM_ID>"
$channelId = "<CHANNEL_ID>"
$message   = "<p>Update posted via Copilot CLI.</p>"

$body = @{
    body = @{
        contentType = "html"
        content     = $message
    }
}

$result = Invoke-Graph -Uri "$graphBase/teams/$teamId/channels/$channelId/messages" -Method POST -Body $body
Write-Host "Channel message posted at $($result.createdDateTime)" -ForegroundColor Green
```

---

## 7. List Teams and Channels (to find IDs)

```powershell
# After auth helper block...

$teams = Invoke-Graph -Uri "$graphBase/me/joinedTeams"

Write-Host "`n=== My Teams ===" -ForegroundColor Cyan
foreach ($team in $teams.value) {
    Write-Host "`nTeam: $($team.displayName) | ID: $($team.id)"
    $channels = Invoke-Graph -Uri "$graphBase/teams/$($team.id)/channels"
    foreach ($ch in $channels.value) {
        Write-Host "  Channel: $($ch.displayName) | ID: $($ch.id)"
    }
}
```

---

## Workflow: Copilot Agent Sending a Teams Message

When the user says "send a Teams message to [person] about [topic]":

1. **Build script** combining auth helper + Section 4 (find person) + Section 3 or 5 (send)
2. **Save** as `%WORK_BASE%\temp_teams_send.ps1`
3. **Run** with `powershell.exe -ExecutionPolicy Bypass -File %WORK_BASE%\temp_teams_send.ps1`
4. If first time, the user must complete Device Code Flow in browser
5. After success, **clean up** the temp script
6. Token is cached — subsequent sends won't need browser auth

## Workflow: Replying to a Recent Chat

When the user says "reply to [person]'s last message":

1. Use **workiq** to find the recent message context (optional)
2. **List chats** (Section 1) to find the chat ID
3. **Read messages** (Section 2) to get context
4. **Send message** (Section 3) with the reply

## Token Cache

- Location: `%WORK_BASE%\.teams-token-cache.json`
- Contains: `access_token`, `refresh_token`, `expires_on`
- Auto-refreshes when expired (no user interaction needed after first auth)
- To force re-auth, delete the cache file

## Permissions Required

The Device Code Flow will request these Graph API permissions:

| Permission | Purpose |
|---|---|
| `Chat.ReadWrite` | Read and send chat messages |
| `User.Read` | Read user profile |
| `ChatMessage.Send` | Send messages in chats |

User must consent on first use. Admin consent is NOT required for delegated permissions.

## Troubleshooting

| Issue | Solution |
|---|---|
| "Authorization pending" loops forever | User hasn't completed browser auth. Check the URL/code displayed |
| 403 Forbidden on send | Permissions not consented. Delete token cache, re-auth |
| Chat not found | Use Section 1 to list chats, copy correct ID |
| Token refresh fails | Delete `%WORK_BASE%\.teams-token-cache.json`, re-auth |
| "Insufficient privileges" for channels | Channel posting may need Teams admin consent for the app |
