---
name: oe-schedule
description: >
  Extrai a grade de turmas Open Enrollment (OE) agendadas no Dynamight
  (ESI Admin Dataverse). Permite filtrar por idioma, modalidade, curso,
  janela de datas e converter horários para Brasília (GMT-03:00) ou
  qualquer outro fuso. Use sempre que o usuário pedir "classes OE",
  "turmas abertas", "OE schedule", "grade de OE", "treinamentos abertos",
  "open enrollment", "próximas turmas", "calendário de OE", em qualquer
  janela de tempo (próximas semanas, mês, trimestre).
  Triggers: classes OE, turmas OE, grade OE, open enrollment, OE schedule,
  treinamentos abertos, agenda OE, calendar OE, calendário de OE,
  próximas turmas, turmas em português, turmas em ingles, turmas em espanhol.
---

# OE Schedule — Grade de Turmas Open Enrollment do Dynamight

Extrai turmas **Open Enrollment (OE)** agendadas do Dynamight
(`esiadmin.crm.dynamics.com`). OE = treinamentos abertos onde qualquer
aprendiz elegível pode se inscrever (diferente de Private Delivery, que
é dedicada a uma conta).

## Pré-requisitos

- Azure CLI logado (`az login` com `@microsoft.com`)
- VPN corporativa conectada
- Acesso de leitura ao ESI Admin org

> O skill **não depende** de `esi_class` (que costuma exigir privilégio
> extra). Usa `msevtmgt_event` (Marketing Event), que carrega todos os
> dados de OE/PD agendadas e geralmente é acessível.

## Mapa de campos (entidade `msevtmgt_event`)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `msevtmgt_name` | String | Nome do curso (ex.: "AI-3026 Develop AI agents on Azure") |
| `esi_deliverytype` | Picklist | **859270000 = Open Enrollment**, 859270001 = Private Delivery |
| `esi_utcstartdate` | DateTime (UTC) | Início da turma |
| `esi_utcenddate` | DateTime (UTC) | Fim da turma |
| `_esi_modalityid_value` | Lookup | VILT / ILT / Self-paced — formatted value via Prefer header |
| `_esi_primarylanguageid_value` | Lookup | Idioma da turma |
| `_esi_timezoneid_value` | Lookup | Fuso original em que a turma foi anunciada |
| `_esi_deliveryid_value` | Lookup | Número/ID da delivery (referência cruzada) |
| `esi_registrationcount` | Integer | Inscritos atuais |
| `esi_availablecount` | Integer | Vagas restantes |
| `statuscode` | Status | **1 = Active** |

## GUIDs úteis (cache)

| Item | GUID |
|------|------|
| Idioma **Portuguese** (genérico — usado em pt-BR Brasil) | `dc9f18e9-86d5-e911-a98b-000d3a30dc28` |
| Idioma **Portuguese - Brazil** (legado, raro nas OE) | `967af95a-3a1a-ee11-8f6d-6045bd02302d` |
| Idioma **Portuguese - Portugal** | `0523911b-d9a0-ea11-a812-000d3a3b1bda` |
| Idioma **Spanish** | descobrir com query `esi_languages` (`contains(esi_name,'Spanish')`) |
| Picklist **Open Enrollment** | `859270000` |

> ⚠️ Em quase 100% das turmas pt-BR no Dynamight o idioma usado é
> **"Portuguese"** (genérico) — não "Portuguese - Brazil". Sempre teste
> ambos se a contagem vier zerada.

## Workflow padrão (PowerShell)

```powershell
$token = (az account get-access-token --resource "https://esiadmin.crm.dynamics.com/" --query accessToken -o tsv 2>$null)
$headers = @{
  Authorization      = "Bearer $token"
  Accept             = "application/json"
  "OData-MaxVersion" = "4.0"
  "OData-Version"    = "4.0"
  "Prefer"           = 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
}
$base   = "https://esiadmin.crm.dynamics.com/api/data/v9.2"
$today  = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$end    = (Get-Date).AddMonths(3).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$ptLang = "dc9f18e9-86d5-e911-a98b-000d3a30dc28"  # Portuguese

$filter = "esi_deliverytype eq 859270000 " +
          "and statuscode eq 1 " +
          "and esi_utcstartdate ge $today " +
          "and esi_utcstartdate le $end " +
          "and _esi_primarylanguageid_value eq $ptLang"

$select = "msevtmgt_name,esi_utcstartdate,esi_utcenddate," +
          "_esi_modalityid_value,_esi_primarylanguageid_value," +
          "_esi_timezoneid_value,esi_registrationcount," +
          "esi_availablecount,_esi_deliveryid_value"

$url = "$base/msevtmgt_events?`$filter=$filter&`$select=$select&`$orderby=esi_utcstartdate asc&`$top=200"
$r   = Invoke-RestMethod -Uri $url -Headers $headers
```

### Conversão para Brasília (GMT-03:00)

> ⚠️ **Cuidado com PowerShell 7+**: `Invoke-RestMethod` auto-converte
> strings ISO 8601 para `[DateTime]` no fuso local. Não use
> `[datetime]::ParseExact($e.esi_utcstartdate, "yyyy-MM-ddTHH:mm:ssZ", ...)`
> — vai falhar porque o valor já é `[DateTime]`. Use cast direto:

```powershell
$tz = [TimeZoneInfo]::FindSystemTimeZoneById("E. South America Standard Time")
$ci = [Globalization.CultureInfo]::InvariantCulture

$rows = foreach ($e in $r.value) {
  $startUtc = ([datetime]$e.esi_utcstartdate).ToUniversalTime()
  $endUtc   = ([datetime]$e.esi_utcenddate).ToUniversalTime()
  $startBR  = [TimeZoneInfo]::ConvertTimeFromUtc($startUtc, $tz)
  $endBR    = [TimeZoneInfo]::ConvertTimeFromUtc($endUtc,   $tz)

  [pscustomobject]@{
    Inicio_BRT  = $startBR.ToString('dd/MM/yyyy HH:mm', $ci)
    Fim_BRT     = $endBR.ToString('dd/MM/yyyy HH:mm', $ci)
    Curso       = $e.msevtmgt_name
    Modalidade  = $e.'_esi_modalityid_value@OData.Community.Display.V1.FormattedValue'
    Idioma      = $e.'_esi_primarylanguageid_value@OData.Community.Display.V1.FormattedValue'
    Vagas_Disp  = $e.esi_availablecount
    Inscritos   = $e.esi_registrationcount
    Delivery_ID = $e.'_esi_deliveryid_value@OData.Community.Display.V1.FormattedValue'
    TZ_Original = $e.'_esi_timezoneid_value@OData.Community.Display.V1.FormattedValue'
  }
}
$rows | Export-Csv -Path ".\OE_Classes.csv" -NoTypeInformation -Encoding UTF8
```

## Filtros mais comuns

| Cenário | Trecho do `$filter` |
|---------|---------------------|
| Próximos 30 dias | `esi_utcstartdate ge $today and esi_utcstartdate le $thirtyDays` |
| Próximos 3 meses | `esi_utcstartdate ge $today and esi_utcstartdate le $threeMonths` |
| Apenas pt-BR | `_esi_primarylanguageid_value eq dc9f18e9-86d5-e911-a98b-000d3a30dc28` |
| Português + Espanhol (LATAM) | `(_esi_primarylanguageid_value eq <ptGuid> or _esi_primarylanguageid_value eq <esGuid>)` |
| Por curso | `contains(msevtmgt_name,'Copilot')` ou `startswith(msevtmgt_name,'AI-')` |
| Apenas com vagas | `esi_availablecount gt 0` |
| Por timezone Brasília | `_esi_timezoneid_value eq <brasiliaGuid>` (descobrir 1ª vez) |

## Descoberta de GUIDs (idiomas, timezones, modalidades)

```powershell
# Idioma
"$base/esi_languages?`$filter=contains(esi_name,'Spanish')&`$select=esi_languageid,esi_name&`$top=10"

# Timezone (entidade interna do Dynamics)
"$base/timezonedefinitions?`$filter=contains(standardname,'Brasil')&`$select=timezonedefinitionid,standardname"

# Modalidade
"$base/esi_trainingtypes?`$select=esi_trainingtypeid,esi_name&`$top=20"
```

Alternativa rápida: extrair direto da resposta agrupando pelo
`@OData.Community.Display.V1.FormattedValue`.

## Saída padrão

Sempre devolva ao usuário **tabela em pt-BR** com colunas:

```
| Início (BRT) | Fim (BRT) | Curso | Modalidade | Vagas | Inscritos | Delivery ID |
```

E gere CSV `OE_Classes_<filtro>_<dataref>.csv` no diretório de trabalho.
Inclua resumo curto: total, período coberto, lotadas, mais vagas,
cursos mais frequentes.

## Erros e recuperação

| Erro | Causa provável | Solução |
|------|----------------|---------|
| `403 Forbidden` em `esi_classes` | Falta privilégio `prvReadesi_class` | Use `msevtmgt_events` (este skill já faz isso) |
| `Could not find a property named 'XYZname'` | Tentou `$select` em virtual `*name` | Use `_esi_xyz_value` + header `Prefer` para FormattedValue |
| Total = 0 com `_esi_primarylanguageid_value eq <ptBR>` | GUID errado — pt-BR usa "Portuguese" genérico | Use `dc9f18e9-86d5-e911-a98b-000d3a30dc28` |
| `String 'MM/dd/yyyy HH:mm:ss' was not recognized` | Valor já é DateTime, não string | Use `([datetime]$e.field).ToUniversalTime()` |
| `401 Unauthorized` | Token expirado | Re-execute `az account get-access-token --resource "https://esiadmin.crm.dynamics.com/"` |

## Cross-reference

- Para detalhes de uma delivery específica via `_esi_deliveryid_value`,
  use o skill **private-deliveries** (entidade `esi_delivery`).
- Para SLAs e prazos de delivery, use **training-slas**.
- Para popular cards de turmas no Cockpit, use **tpm-cockpit**.
