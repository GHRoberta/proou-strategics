"""Phase 2 — Signal collection.

The agent runbook fetches raw items via MCP tools and writes them as JSON files
under data/<run_id>/inputs/. This phase normalizes them into Signal[] and
appends to signals_raw.jsonl.

Expected input files (any subset; missing ones are skipped):
  inputs/external_news.json       — [{customer_tpid, customer_name, items: [{url, title, summary, date, source_label}]}]
  inputs/internal_emails.json     — [{message_id, from, subject, received, body_preview, source_id}]
  inputs/internal_chats.json      — [{chat_id, message_id, from, sent, content, customer_tpid?, customer_name?, sensitivity?}]
  inputs/cos_items.json           — [{event_id, date, title, summary, action_items: [{owner, action, customer?}]}]
  inputs/roundup_items.json       — [{date, title, summary, offer_id?, applies_to?}]
  inputs/catalog_diff.json        — [{course_id, change_type: added|removed|updated, title, date}]
  inputs/product_news.json        — [{url, title, summary, date, product, source_label}]
  inputs/cockpit_signals.json     — [{card_id, customer, tpid, title, summary, date}] (rare; cockpit suppression will drop these)

Outputs:
  data/<run_id>/signals_raw.jsonl
  data/<run_id>/cockpit_context.json (extracted from <WORK_BASE>/kanban_data.js)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import signal as sig_mod
import cockpit


def _load_input(rd: Path, name: str):
    p = rd / "inputs" / name
    if not p.exists():
        return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def _cm(tpid, name, conf, basis):
    return sig_mod.CustomerMatch(tpid=str(tpid), name=name or "", confidence=float(conf), match_basis=basis)


def _category_for_keywords(text: str) -> str:
    t = (text or "").lower()
    rules = [
        ("M&A", ("aquisi", "merger", "acquisition", "compra", "fus")),
        ("leadership", ("ceo", "cfo", "cto", "diretor", "presidente", "appoint", "nomea")),
        ("earnings", ("resultado", "earnings", "balanço", "lucro", "receita")),
        ("regulation", ("regulação", "anvisa", "bcb", "bacen", "cvm", "regulator")),
        ("AI", ("copilot", "openai", "gpt", "ia generativa", "generative ai", "agent")),
        ("security", ("segurança", "ransomware", "breach", "vazamento")),
        ("expansion", ("expansão", "novo escritório", "abre", "open")),
        ("partnership", ("parceria", "partnership", "parceria estratégica")),
        ("product_launch", ("lança", "launch", "anuncia", "release")),
        ("deprecation", ("descontinua", "deprec", "retired", "end of life", "eol")),
        ("deadline", ("prazo", "deadline", "until", "até")),
    ]
    for cat, kws in rules:
        if any(k in t for k in kws):
            return cat
    return "other"


def collect(run_id: str) -> int:
    rd = common.run_dir(run_id)
    out: list[sig_mod.Signal] = []

    # 1. External news per customer
    ext = _load_input(rd, "external_news.json") or []
    for block in ext:
        tpid = block.get("customer_tpid")
        cname = block.get("customer_name")
        for item in block.get("items", []):
            url = item.get("url", "")
            title = item.get("title", "")
            cat = item.get("trigger_category") or _category_for_keywords(f"{title} {item.get('summary','')}")
            s = sig_mod.build(
                source="web",
                source_ref=url,
                date=item.get("date") or sig_mod.now_iso(),
                title=title,
                summary=item.get("summary", ""),
                trigger_category=cat,
                sensitivity="public",
                customer_matches=[_cm(tpid, cname, item.get("confidence", 0.85), "alias")],
                extras={"source_label": item.get("source_label")},
            )
            out.append(s)

    # 2. Internal emails
    em = _load_input(rd, "internal_emails.json") or []
    for m in em:
        cat = _category_for_keywords(f"{m.get('subject','')} {m.get('body_preview','')}")
        s = sig_mod.build(
            source="email",
            source_ref=m.get("message_id", ""),
            date=m.get("received") or sig_mod.now_iso(),
            title=m.get("subject", ""),
            summary=(m.get("body_preview") or "")[:280],
            trigger_category=cat,
            sensitivity="internal-ms",
            extras={"from": m.get("from"), "source_id": m.get("source_id")},
        )
        out.append(s)

    # 3. Internal chats
    ch = _load_input(rd, "internal_chats.json") or []
    for m in ch:
        sens = m.get("sensitivity", "internal-ms")
        cm_list = []
        if m.get("customer_tpid"):
            cm_list.append(_cm(m["customer_tpid"], m.get("customer_name"), 0.8, "chat_membership"))
        s = sig_mod.build(
            source="teams_chat",
            source_ref=f"{m.get('chat_id','')}:{m.get('message_id','')}",
            date=m.get("sent") or sig_mod.now_iso(),
            title=(m.get("content") or "")[:80],
            summary=(m.get("content") or "")[:280],
            trigger_category=_category_for_keywords(m.get("content", "")),
            sensitivity=sens,
            customer_matches=cm_list,
            extras={"from": m.get("from"), "chat_id": m.get("chat_id")},
        )
        out.append(s)

    # 4. CoS items
    co = _load_input(rd, "cos_items.json") or []
    for item in co:
        s = sig_mod.build(
            source="cos",
            source_ref=item.get("event_id", ""),
            date=item.get("date") or sig_mod.now_iso(),
            title=item.get("title", "CoS update"),
            summary=item.get("summary", "")[:280],
            trigger_category="cos_action",
            sensitivity="confidential-ms",
            extras={"action_items": item.get("action_items", [])},
        )
        out.append(s)

    # 5. Roundup
    ru = _load_input(rd, "roundup_items.json") or []
    for item in ru:
        oms = []
        if item.get("offer_id"):
            oms.append(sig_mod.OfferMatch(offer_id=item["offer_id"], catalog="Roundup", confidence=0.9))
        s = sig_mod.build(
            source="roundup",
            source_ref=item.get("id") or item.get("title", ""),
            date=item.get("date") or sig_mod.now_iso(),
            title=item.get("title", ""),
            summary=item.get("summary", "")[:280],
            trigger_category=item.get("trigger_category") or "catalog_delta",
            sensitivity="internal-ms",
            offer_matches=oms,
            extras={"applies_to": item.get("applies_to", [])},
        )
        out.append(s)

    # 6. Catalog diff
    cat = _load_input(rd, "catalog_diff.json") or []
    for item in cat:
        ctype = item.get("change_type", "updated")
        cat_name = "deprecation" if ctype == "removed" else "catalog_delta"
        s = sig_mod.build(
            source="catalog",
            source_ref=item.get("course_id", ""),
            date=item.get("date") or sig_mod.now_iso(),
            title=f"[{ctype}] {item.get('title','')}",
            summary=item.get("summary", "")[:280],
            trigger_category=cat_name,
            sensitivity="internal-ms",
            offer_matches=[sig_mod.OfferMatch(offer_id=item.get("course_id", ""), catalog="ESI", confidence=1.0)],
        )
        out.append(s)

    # 7. Product news
    pn = _load_input(rd, "product_news.json") or []
    for item in pn:
        s = sig_mod.build(
            source="product_news",
            source_ref=item.get("url", ""),
            date=item.get("date") or sig_mod.now_iso(),
            title=item.get("title", ""),
            summary=item.get("summary", "")[:280],
            trigger_category="product_launch",
            sensitivity="public",
            extras={"product": item.get("product"), "source_label": item.get("source_label")},
        )
        out.append(s)

    # 8. Cockpit signals (will be suppressed in Phase 3)
    ck = _load_input(rd, "cockpit_signals.json") or []
    for item in ck:
        s = sig_mod.build(
            source="cockpit",
            source_ref=item.get("card_id", ""),
            date=item.get("date") or sig_mod.now_iso(),
            title=item.get("title", ""),
            summary=item.get("summary", "")[:280],
            trigger_category="other",
            sensitivity="internal-ms",
            primary_source_is_cockpit=True,
            customer_matches=[_cm(item.get("tpid", ""), item.get("customer"), 1.0, "explicit_mention")] if item.get("tpid") else [],
        )
        out.append(s)

    # validate & write
    valid = []
    bad = 0
    for s in out:
        errs = sig_mod.validate(s)
        if errs:
            bad += 1
            common.log(f"invalid signal dropped: {s.signal_id} errs={errs}")
        else:
            valid.append(s)

    out_path = rd / "signals_raw.jsonl"
    n = sig_mod.write_jsonl(valid, str(out_path))
    common.log(f"wrote {n} valid signals to {out_path} (dropped {bad} invalid)")

    # cockpit context (read-only enrichment for Phase 5)
    wb = common.work_base()
    try:
        kdata = cockpit.load(wb)
        if kdata:
            ctx = cockpit.context_by_customer(kdata)
            ctx_path = rd / "cockpit_context.json"
            with open(ctx_path, "w", encoding="utf-8") as f:
                json.dump(ctx, f, indent=2, ensure_ascii=False, default=list)
            common.log(f"wrote cockpit_context.json with {len(ctx)} customers")
    except Exception as e:
        common.log(f"warn: cockpit context load failed: {e}")

    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    n = collect(args.run_id)
    print(json.dumps({"signals_written": n}))


if __name__ == "__main__":
    main()
