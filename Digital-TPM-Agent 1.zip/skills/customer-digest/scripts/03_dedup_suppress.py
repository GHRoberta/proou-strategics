"""Phase 3 — Dedup only (cockpit signals are KEPT as enrichment context).

Reads:  data/<run_id>/signals_raw.jsonl, cockpit_context.json (optional)
Writes: data/<run_id>/signals_clean.jsonl, drop_report.json

Rules (revised 2026-W18):
1. Hard dedup by dedup_key (URL canonical, message_id, hash).
2. Cockpit-derived signals are NO LONGER suppressed. They flow through and
   give the synthesis "the why" behind each customer section. The cockpit
   provides execution context; the digest reframes it as forward-looking
   news/conversation hooks. (Old rule was removed at user request.)
3. Account-level news always passes.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import signal as sig_mod


ACCOUNT_LEVEL_CATS = {"M&A", "leadership", "regulation", "product_launch", "earnings"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    raw_path = rd / "signals_raw.jsonl"
    if not raw_path.exists():
        common.log(f"no {raw_path} — Phase 2 must run first")
        return

    signals = sig_mod.load_jsonl(str(raw_path))
    common.log(f"loaded {len(signals)} raw signals")

    drop = {"cockpit_suppressed": [], "duplicates": []}
    seen: dict[str, sig_mod.Signal] = {}

    for s in signals:
        # Cockpit signals are NO LONGER suppressed (revised 2026-W18).
        # They keep flowing as enrichment context.
        if s.dedup_key in seen:
            # keep the one with higher score (or longer summary as tiebreak)
            existing = seen[s.dedup_key]
            if s.score > existing.score or (s.score == existing.score and len(s.summary) > len(existing.summary)):
                drop["duplicates"].append(existing.signal_id)
                seen[s.dedup_key] = s
            else:
                drop["duplicates"].append(s.signal_id)
            continue
        seen[s.dedup_key] = s

    clean = list(seen.values())
    out_path = rd / "signals_clean.jsonl"
    n = sig_mod.write_jsonl(clean, str(out_path))

    rep_path = rd / "drop_report.json"
    with open(rep_path, "w", encoding="utf-8") as f:
        json.dump({
            "input_count": len(signals),
            "output_count": n,
            "cockpit_suppressed_count": len(drop["cockpit_suppressed"]),
            "duplicates_dropped_count": len(drop["duplicates"]),
            "details": drop,
        }, f, indent=2, ensure_ascii=False)

    common.log(f"clean={n}  suppressed={len(drop['cockpit_suppressed'])}  dupes={len(drop['duplicates'])}")
    print(json.dumps({"clean": n, "suppressed": len(drop["cockpit_suppressed"]), "dupes": len(drop["duplicates"])}))


if __name__ == "__main__":
    main()
