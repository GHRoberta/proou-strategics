"""State management — separate cadence (last_successful_digest_at)
from per-source cursors. Cursors only advance on success.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from typing import Any

DEFAULT_TZ = timezone(timedelta(hours=-3))  # America/Sao_Paulo (no DST since 2019)


def state_path(skill_dir: str) -> str:
    return os.path.join(skill_dir, "state.json")


def load(skill_dir: str) -> dict[str, Any]:
    p = state_path(skill_dir)
    if not os.path.exists(p):
        return _default_state()
    with open(p, "r", encoding="utf-8") as f:
        s = json.load(f)
    s.setdefault("schema_version", 1)
    s.setdefault("source_cursors", {})
    s.setdefault("sources_status", {})
    return s


def save(skill_dir: str, state: dict[str, Any]) -> None:
    p = state_path(skill_dir)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


def _default_state() -> dict[str, Any]:
    return {
        "schema_version": 1,
        "last_successful_digest_at": None,
        "last_attempt_at": None,
        "current_run_id": None,
        "source_cursors": {},
        "sources_status": {},
    }


def iso_now() -> str:
    return datetime.now(DEFAULT_TZ).isoformat(timespec="seconds")


def iso_week_id(dt: datetime | None = None) -> str:
    dt = dt or datetime.now(DEFAULT_TZ)
    y, w, _ = dt.isocalendar()
    return f"{y}-W{w:02d}"


def cursor_for(state: dict, source_id: str, default_lookback_days: int = 7) -> str:
    """Get the cursor (ISO ts) for a source. Falls back to now - default_lookback_days."""
    cur = state.get("source_cursors", {}).get(source_id)
    if cur and cur != "unavailable":
        return cur
    lb = datetime.now(DEFAULT_TZ) - timedelta(days=default_lookback_days)
    return lb.isoformat(timespec="seconds")


def advance_cursor(state: dict, source_id: str, new_ts: str) -> None:
    state.setdefault("source_cursors", {})[source_id] = new_ts


def mark_status(state: dict, source_id: str, status: str) -> None:
    """status in {ok, degraded, down, skipped, unavailable_this_week}"""
    state.setdefault("sources_status", {})[source_id] = status


def days_since_last_success(state: dict) -> int | None:
    last = state.get("last_successful_digest_at")
    if not last:
        return None
    try:
        last_dt = datetime.fromisoformat(last)
    except Exception:
        return None
    delta = datetime.now(DEFAULT_TZ) - last_dt
    return delta.days


def is_rerun_same_week(state: dict, run_id: str) -> bool:
    """If we already attempted this run_id, this is a rerun — do not advance cursors."""
    return state.get("current_run_id") == run_id


def begin_run(state: dict, run_id: str) -> bool:
    """Mark the start of a run. Returns True if this is a fresh run, False if rerun."""
    is_fresh = not is_rerun_same_week(state, run_id)
    state["last_attempt_at"] = iso_now()
    state["current_run_id"] = run_id
    return is_fresh


def commit_success(state: dict, run_id: str, *, advance_cursors: dict[str, str]) -> None:
    """Commit a successful run. Advances cursors only for sources passed in."""
    state["last_successful_digest_at"] = iso_now()
    state["current_run_id"] = run_id
    for sid, ts in advance_cursors.items():
        advance_cursor(state, sid, ts)
