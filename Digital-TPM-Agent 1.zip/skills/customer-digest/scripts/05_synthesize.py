"""Phase 5 — Hook & offer synthesis (schema-constrained).

This phase builds the synthesis structure the renderer consumes. Hook generation
is **schema-constrained**: the agent (LLM) may only recommend offers from
offer_catalog.json. This script produces a deterministic skeleton; the agent
runbook fills hook narratives by post-processing synthesis_skeleton.json.

Reads:  data/<run_id>/signals_scored.jsonl, customers_scored.json,
        cockpit_context.json (optional), customer_aliases.json,
        offer_catalog.json
Writes: data/<run_id>/synthesis_skeleton.json
        (agent then writes synthesis.json with hook narratives filled in)
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import signal as sig_mod


def _load_json(p: Path, default):
    if not p.exists():
        return default
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    signals = sig_mod.load_jsonl(str(rd / "signals_scored.jsonl"))
    cust_scored = _load_json(rd / "customers_scored.json", {})
    cockpit_ctx = _load_json(rd / "cockpit_context.json", {})
    aliases = common.load_aliases()
    catalog = common.load_offer_catalog()

    sig_by_id = {s.signal_id: s for s in signals}
    sigs_by_tpid: dict[str, list[sig_mod.Signal]] = defaultdict(list)
    for s in signals:
        for cm in s.customer_matches:
            sigs_by_tpid[cm.tpid].append(s)

    # Highlights = top 3 by (#customer_matches × max severity weight via score)
    cfg = common.load_config()
    sev_w = (cfg.get("scoring", {}).get("weights", {}) or {}).get("severity", {})

    def _hl_rank(s: sig_mod.Signal) -> float:
        return len(s.customer_matches) * float(sev_w.get(s.trigger_category, 1.0)) * (1 + s.score)

    highlights = sorted(signals, key=_hl_rank, reverse=True)[:3]

    # Actions = signals with deadline OR cross-portfolio impact (>=3 customers)
    actions = []
    for s in signals:
        if s.trigger_category == "deadline" or len(s.customer_matches) >= 3 or s.trigger_category in {"deprecation", "catalog_delta"}:
            actions.append(s)
    actions = sorted(actions, key=lambda s: s.score, reverse=True)[:8]

    # Customer sections (featured only)
    featured = (cust_scored.get("buckets", {}) or {}).get("featured", [])
    watchlist = (cust_scored.get("buckets", {}) or {}).get("watchlist", [])

    customer_sections = []
    for entry in featured:
        tpid = entry["tpid"]
        cust_signals = sorted(sigs_by_tpid.get(tpid, []), key=lambda s: s.score, reverse=True)
        # find alias entry for richer context
        alias = next((a for a in aliases if str(a.get("tpid")) == str(tpid)), {})
        # cockpit context lookup by normalized name
        norm = entry["name"].upper().strip() if entry.get("name") else ""
        ctx = cockpit_ctx.get(norm)

        # candidate offers: any offer that matches recommended_for tpid OR mentioned in this customer's signals
        offer_matches_in_sigs = set()
        for s in cust_signals:
            for om in s.offer_matches:
                offer_matches_in_sigs.add(om.offer_id)
        candidate_offers = []
        for off in catalog:
            recs = off.get("recommended_for_tpids") or []
            if str(tpid) in {str(x) for x in recs} or off.get("offer_id") in offer_matches_in_sigs:
                candidate_offers.append(off)

        customer_sections.append({
            "tpid": tpid,
            "name": entry["name"],
            "score": entry["score"],
            "headline_signal_id": cust_signals[0].signal_id if cust_signals else None,
            "signals": [s.to_dict() for s in cust_signals[:8]],
            "ms_team": (alias.get("ms_team") or [])[:5],
            "customer_contacts": (alias.get("customer_contacts") or [])[:5],
            "cockpit_context": ctx,
            "candidate_offers": candidate_offers[:6],
            "_hooks_to_synthesize": True,  # agent fills below
            "hooks": [],  # agent populates from candidate_offers + signals + contacts (>=2 evidence rule)
        })

    skeleton = {
        "run_id": args.run_id,
        "highlights": [s.to_dict() for s in highlights],
        "customer_sections": customer_sections,
        "watchlist": watchlist,
        "actions": [s.to_dict() for s in actions],
        "_hook_synthesis_rules": {
            "must_select_offer_from": "offer_catalog.json",
            "min_evidence_elements": 2,
            "evidence_types": ["customer_specific_signal", "validated_offer", "relevant_contact", "timing_or_deadline", "business_event"],
            "weak_hooks_go_to": "watchlist (not main section)",
        },
    }
    out = rd / "synthesis_skeleton.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(skeleton, f, indent=2, ensure_ascii=False, default=list)

    # If no offer catalog OR no aliases, emit synthesis.json directly (skip LLM hooks)
    if not catalog or not aliases:
        common.log("offer_catalog or aliases empty — emitting synthesis.json without hooks")
        synth = dict(skeleton)
        synth["_skipped_hook_synthesis_reason"] = "offer_catalog or aliases missing"
        with open(rd / "synthesis.json", "w", encoding="utf-8") as f:
            json.dump(synth, f, indent=2, ensure_ascii=False, default=list)

    common.log(f"highlights={len(highlights)}  customer_sections={len(customer_sections)}  actions={len(actions)}")
    print(json.dumps({"highlights": len(highlights), "customer_sections": len(customer_sections), "actions": len(actions)}))


if __name__ == "__main__":
    main()
