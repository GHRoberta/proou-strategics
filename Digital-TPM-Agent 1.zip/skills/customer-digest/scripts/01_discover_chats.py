"""Phase 1 — Chat discovery & classification.

Inputs (agent writes):
  data/<run_id>/inputs/chats_raw.json
    [
      {"chat_id": "...", "topic": "Webinar MS Copilot (Ka Solution)",
       "participant_upns": ["{{EMAIL}}", "{{EMAIL}}", "{{EMAIL}}"],
       "last_message_at": "2026-05-04T..."},
      ...
    ]

Outputs:
  monitored_chats.json      — cumulative, classified, TTL 60d for inactive
  candidate_chats.json      — ambiguous review queue
  data/<run_id>/chat_classifications.json — this-run snapshot
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import classify_chat


SKILL_DIR = common.SKILL_DIR
MONITORED = SKILL_DIR / "monitored_chats.json"
CANDIDATES = SKILL_DIR / "candidate_chats.json"
TTL_DAYS = 60


def _load(p: Path, default):
    if not p.exists():
        return default
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(p: Path, data):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    inputs = rd / "inputs" / "chats_raw.json"
    if not inputs.exists():
        common.log(f"no chats_raw.json at {inputs} — agent must fetch chats via agent365-teams ListChats first")
        return

    raw = _load(inputs, [])
    aliases = common.load_aliases()
    common.log(f"classifying {len(raw)} chats against {len(aliases)} aliases")

    classifications = []
    for chat in raw:
        c = classify_chat.classify(
            chat_id=chat.get("chat_id", ""),
            topic=chat.get("topic", ""),
            participant_upns=chat.get("participant_upns", []),
            customer_aliases=aliases,
        )
        d = c.to_dict()
        d["last_message_at"] = chat.get("last_message_at")
        classifications.append(d)

    # split
    monitored_in = [c for c in classifications if c["chat_type"] in
                    {"external_customer_chat", "partner_delivery_chat", "internal_account_chat"}
                    and c["confidence"] >= 0.55]
    candidates_in = [c for c in classifications if c not in monitored_in
                     and c["customer_matches"]]  # no signal = drop entirely

    # merge with existing monitored (cumulative, by chat_id)
    monitored = _load(MONITORED, {"chats": []}).get("chats", [])
    by_id = {m["chat_id"]: m for m in monitored}
    for new in monitored_in:
        by_id[new["chat_id"]] = {**by_id.get(new["chat_id"], {}), **new}

    # TTL prune
    cutoff = datetime.now(timezone.utc) - timedelta(days=TTL_DAYS)
    kept = []
    for m in by_id.values():
        last = m.get("last_message_at")
        if last:
            try:
                if datetime.fromisoformat(last.replace("Z", "+00:00")) < cutoff:
                    continue
            except Exception:
                pass
        kept.append(m)

    _save(MONITORED, {"_schema_version": 1, "chats": kept})

    # candidates: merge by chat_id, dedupe
    cand_existing = _load(CANDIDATES, {"chats": []}).get("chats", [])
    cand_by_id = {c["chat_id"]: c for c in cand_existing}
    for c in candidates_in:
        cand_by_id[c["chat_id"]] = c
    _save(CANDIDATES, {"_schema_version": 1, "_review_action": "promote_or_drop", "chats": list(cand_by_id.values())})

    # this-run snapshot
    snapshot = rd / "chat_classifications.json"
    _save(snapshot, {"run_id": args.run_id, "classifications": classifications})

    common.log(f"monitored={len(kept)}  candidates={len(cand_by_id)}  fresh_classifications={len(classifications)}")
    print(json.dumps({"monitored": len(kept), "candidates": len(cand_by_id), "fresh": len(classifications)}))


if __name__ == "__main__":
    main()
