"""Phase 8 — Dual-language render & stitch.

Reads:  data/<run_id>/synthesis.json (PT)
        data/<run_id>/synthesis_en.json (EN, output of phase 7)
Writes: outputs/digest_<run_id>.html (single distributable HTML with PT/EN toggle)

Renders the magazine template twice (one synth per language), extracts each
<body> inner content, and stitches them into one self-contained HTML with a
sticky toggle bar at the top. Choice persists via localStorage.

UI labels (template hardcoded PT phrases) are post-translated via UI_MAP
without modifying the template.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common

try:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
except ImportError:
    print("ERROR: jinja2 not installed. Run: pip install jinja2", file=sys.stderr)
    sys.exit(2)


# Template UI labels (PT → EN). Order matters: longer phrases first when overlap exists.
UI_MAP = {
    "Customer Digest · TPM Brasil": "Customer Digest · TPM Brazil",
    "Highlights da semana": "Highlights of the week",
    "— os movimentos que afetam mais clientes": "— moves affecting most customers",
    "Customer Digest <span class=\"lead\">— o que é novo em cada conta</span>":
        "Customer Digest <span class=\"lead\">— what's new at each account</span>",
    "Cobertura completa do portfólio. Use a barra lateral à direita para navegar pelos":
        "Full portfolio coverage. Use the right sidebar to navigate the",
    "clientes.</p>": "customers.</p>",
    "Conta ativa": "Active account",
    "Conta dormente — sinal de mercado": "Dormant account — market signal",
    "O que aconteceu nesta semana": "What happened this week",
    "Notícias e sinais detectados": "News and signals detected",
    "Contexto do cockpit:": "Cockpit context:",
    "Conversas de capacitação que cabem agora": "Skilling conversations that fit now",
    "Oferta sugerida:": "Suggested offer:",
    "Falar com:": "Talk to:",
    "validado em diretório MS": "verified in MS directory",
    "não validado": "not verified",
    "Time</h4>": "Team</h4>",
    "<strong>Cliente:</strong>": "<strong>Customer:</strong>",
    "Actions cross-portfolio <span class=\"lead\">— pontos que afetam todos</span>":
        "Cross-portfolio actions <span class=\"lead\">— items that affect all</span>",
    "Fontes desta edição:": "Sources for this edition:",
    "Cockpit · Teams chats · Emails (TPM Global Community, brzmonitoring) · Weekly Roundup · CoS GTM · Web (LinkedIn, mídia setorial) · MSX · Microsoft 365 Blog · Catálogo de Skilling":
        "Cockpit · Teams chats · Emails (TPM Global Community, brzmonitoring) · Weekly Roundup · CoS GTM · Web (LinkedIn, sector media) · MSX · Microsoft 365 Blog · Skilling Catalog",
    "Cobertura:</strong>": "Coverage:</strong>",
    "contas processadas. Contatos validados contra Microsoft Graph quando indicados com ✓.":
        "accounts processed. Contacts validated against Microsoft Graph when marked with ✓.",
    "Próximos passos:</strong> use os ganchos como abertura de conversa; o cockpit segue como fonte da verdade para execução das atividades em andamento.":
        "Next steps:</strong> use the hooks as conversation openers; the cockpit remains the source of truth for execution of work-in-progress.",
    "Nesta edição</h4>": "In this edition</h4>",
    "Highlights da semana →": "Highlights of the week →",
    "Customer Digest →": "Customer Digest →",
    "Actions cross-portfolio →": "Cross-portfolio actions →",
    "Conteúdo por cliente</h3>": "Customer index</h3>",
    "Recomendação:": "Recommendation:",
    "Prazo:": "Deadline:",
    "Owner:": "Owner:",
    "Impacto:": "Impact:",
    "Atinge:": "Affects:",
    "Gerado em": "Generated on",
}

TOGGLE_CSS = """
.lang-bar { position: sticky; top: 0; z-index: 100; background: #ffffff;
            border-bottom: 1px solid #e6e6e6; padding: 8px 24px;
            display: flex; gap: 8px; align-items: center;
            font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; }
.lang-bar .label { color: #616161; margin-right: 8px; }
.lang-bar button { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px;
                   padding: 4px 14px; border: 1px solid #0067b8; background: #ffffff;
                   color: #0067b8; cursor: pointer; border-radius: 2px; }
.lang-bar button.active { background: #0067b8; color: #ffffff; }
.lang-pane[hidden] { display: none !important; }
"""

TOGGLE_JS = """
function setLang(lang) {
    document.getElementById('pt').hidden = (lang !== 'pt');
    document.getElementById('en').hidden = (lang !== 'en');
    document.getElementById('btn-pt').classList.toggle('active', lang === 'pt');
    document.getElementById('btn-en').classList.toggle('active', lang === 'en');
    try { localStorage.setItem('digest_lang', lang); } catch(e) {}
    document.documentElement.lang = (lang === 'pt') ? 'pt-BR' : 'en-US';
}
document.addEventListener('DOMContentLoaded', function() {
    var saved = 'pt';
    try { saved = localStorage.getItem('digest_lang') || 'pt'; } catch(e) {}
    setLang(saved);
});
"""


def render_one(synth: dict, run_id: str) -> str:
    env = Environment(
        loader=FileSystemLoader(str(common.TEMPLATES_DIR)),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["short_date"] = lambda s: (s or "")[:10]
    ctx = {"synth": synth, "run_id": run_id, "generated_at": "", "tz_label": "BRT", "config": {}}
    return env.get_template("digest_magazine.html.j2").render(**ctx)


def extract_body(html: str) -> str:
    m = re.search(r"<body[^>]*>(.*)</body>", html, re.DOTALL | re.IGNORECASE)
    return m.group(1) if m else html


def extract_head_inner(html: str) -> str:
    m = re.search(r"<head[^>]*>(.*)</head>", html, re.DOTALL | re.IGNORECASE)
    return m.group(1) if m else ""


def apply_ui_map(html: str) -> str:
    for pt, en in UI_MAP.items():
        html = html.replace(pt, en)
    return html


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True, help="e.g. 2026-W18")
    ap.add_argument("--no-working-copy", action="store_true",
                    help="Skip copy to WORK_BASE/digest_<run_id>.html")
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    src_pt = rd / "synthesis.json"
    src_en = rd / "synthesis_en.json"
    if not src_pt.exists() or not src_en.exists():
        common.log(f"missing inputs (need {src_pt.name} and {src_en.name}). Run phase 7 first.")
        sys.exit(1)

    pt = json.loads(src_pt.read_text(encoding="utf-8"))
    en = json.loads(src_en.read_text(encoding="utf-8"))

    pt_html = render_one(pt, args.run_id)
    en_html = apply_ui_map(render_one(en, args.run_id))

    head = extract_head_inner(pt_html)  # styles are language-agnostic
    pt_body = extract_body(pt_html)
    en_body = extract_body(en_html)

    final = (
        f'<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n{head}\n'
        f'<style>{TOGGLE_CSS}</style>\n<script>{TOGGLE_JS}</script>\n</head>\n<body>\n'
        f'<div class="lang-bar">\n'
        f'  <span class="label">Idioma / Language:</span>\n'
        f'  <button id="btn-pt" class="active" onclick="setLang(\'pt\')">PT-BR</button>\n'
        f'  <button id="btn-en" onclick="setLang(\'en\')">EN-US</button>\n'
        f'</div>\n'
        f'<div id="pt" class="lang-pane">{pt_body}</div>\n'
        f'<div id="en" class="lang-pane" hidden>{en_body}</div>\n'
        f'</body>\n</html>\n'
    )

    common.OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = common.OUTPUTS_DIR / f"digest_{args.run_id}.html"
    out_path.write_text(final, encoding="utf-8")
    common.log(f"wrote {out_path} ({out_path.stat().st_size:,} bytes)")

    if not args.no_working_copy:
        # Write to both WORK_BASE (env) and config default if both resolve and exist.
        targets = []
        wb = Path(common.work_base())
        if wb.exists():
            targets.append(wb)
        cfg_default = common.load_config().get("work_base_default")
        if cfg_default:
            cfg_path = Path(cfg_default)
            if cfg_path.exists() and cfg_path != wb:
                targets.append(cfg_path)
        for t in targets:
            wp = t / f"digest_{args.run_id}.html"
            wp.write_text(final, encoding="utf-8")
            common.log(f"wrote working copy {wp}")

    print(json.dumps({"html": str(out_path), "run_id": args.run_id}))


if __name__ == "__main__":
    main()
