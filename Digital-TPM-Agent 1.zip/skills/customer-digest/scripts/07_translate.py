"""Phase 7 — Translate synthesis.json (PT-BR → EN-US).

Reads:  data/<run_id>/synthesis.json
Writes: data/<run_id>/synthesis_en.json

Preserves HTML tags, URLs, and structured data (TPIDs, contacts, dates).
Translates only narrative text (titles, deks, narratives, hooks, etc.) and
text inside <a>/<strong>/<em> nodes via BeautifulSoup walking.

Uses deep_translator + Google Translate (free, online, no API key).
Caches identical strings to minimize calls.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common

try:
    from bs4 import BeautifulSoup, NavigableString
except ImportError:
    print("ERROR: beautifulsoup4 not installed. Run: pip install beautifulsoup4", file=sys.stderr)
    sys.exit(2)
try:
    from deep_translator import GoogleTranslator
except ImportError:
    print("ERROR: deep-translator not installed. Run: pip install deep-translator", file=sys.stderr)
    sys.exit(2)


# Field policy — controls what gets translated, what passes through.
PASSTHROUGH_KEYS = {
    "url", "source_url", "tpid", "mail", "date", "deadline",
    "verified", "name", "owner", "category", "source_label",
    "source_type", "ms_team", "customer_contacts",
    "cockpit_status", "tz_label", "run_id", "generated_at", "affects",
}
TEXT_KEYS = {
    "title", "subtitle", "dek", "headline", "rationale",
    "recommended_offer", "narrative", "h_title", "a_title",
    "sources_label", "cockpit_snapshot", "status",
}
HTML_KEYS = {"narrative_html"}


def make_translator(source_lang: str, target_lang: str):
    tr = GoogleTranslator(source=source_lang, target=target_lang)
    cache: dict[str, str] = {}

    def trans(text: str) -> str:
        if not text or not isinstance(text, str):
            return text
        text = text.strip()
        if not text or text.startswith("http") or re.fullmatch(r"[A-Z0-9\-./]+", text):
            return text
        if text in cache:
            return cache[text]
        try:
            if len(text) <= 4500:
                out = tr.translate(text) or text
            else:
                parts = re.split(r"(?<=[.!?])\s+", text)
                chunks, cur = [], ""
                for p in parts:
                    if len(cur) + len(p) + 1 > 4500:
                        chunks.append(cur)
                        cur = p
                    else:
                        cur = (cur + " " + p).strip() if cur else p
                if cur:
                    chunks.append(cur)
                out = " ".join(tr.translate(c) or c for c in chunks)
            cache[text] = out
            time.sleep(0.05)
            return out
        except Exception as e:
            common.log(f"WARN translation failed for '{text[:60]}…': {e}")
            return text

    def trans_html(html: str) -> str:
        if not html or not isinstance(html, str):
            return html
        if "<" not in html:
            return trans(html)
        soup = BeautifulSoup(html, "html.parser")
        for node in soup.find_all(string=True):
            if isinstance(node, NavigableString):
                txt = str(node)
                stripped = txt.strip()
                if stripped:
                    lead = txt[:len(txt) - len(txt.lstrip())]
                    trail = txt[len(txt.rstrip()):]
                    node.replace_with(NavigableString(lead + trans(stripped) + trail))
        return str(soup)

    def stats():
        return {"unique_strings": len(cache)}

    return trans, trans_html, stats


def translate_obj(obj, trans, trans_html):
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k in PASSTHROUGH_KEYS:
                out[k] = v
            elif k in HTML_KEYS:
                out[k] = trans_html(v) if isinstance(v, str) else v
            elif k in TEXT_KEYS:
                out[k] = trans(v) if isinstance(v, str) else translate_obj(v, trans, trans_html)
            elif k == "role" and isinstance(v, str) and len(v) > 2:
                out[k] = trans(v)
            elif k == "suggested_contact" and isinstance(v, dict):
                out[k] = {
                    kk: (trans(vv) if kk == "role" and isinstance(vv, str) and len(vv) > 2 else vv)
                    for kk, vv in v.items()
                }
            else:
                out[k] = translate_obj(v, trans, trans_html)
        return out
    if isinstance(obj, list):
        return [translate_obj(x, trans, trans_html) for x in obj]
    return obj


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True, help="e.g. 2026-W18")
    ap.add_argument("--source-lang", default="pt", help="ISO 639-1 (default: pt)")
    ap.add_argument("--target-lang", default="en", help="ISO 639-1 (default: en)")
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    src = rd / "synthesis.json"
    if not src.exists():
        common.log(f"no synthesis at {src}")
        sys.exit(1)
    dst = rd / f"synthesis_{args.target_lang}.json"

    common.log(f"loading {src}")
    data = json.loads(src.read_text(encoding="utf-8"))

    trans, trans_html, stats = make_translator(args.source_lang, args.target_lang)
    common.log(f"translating {args.source_lang} -> {args.target_lang} …")
    out = translate_obj(data, trans, trans_html)

    dst.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    common.log(f"wrote {dst} ({dst.stat().st_size:,} bytes; {stats()['unique_strings']} unique strings)")


if __name__ == "__main__":
    main()
