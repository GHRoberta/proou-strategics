"""4-class chat classifier.

Categories:
- external_customer_chat — has >=1 non-Microsoft participant on a whitelisted customer domain
- internal_account_chat — Microsoft-only members but topic/recent messages reference a customer
- partner_delivery_chat — includes partner/TSP domains, may map to 1+ customers
- ambiguous_chat — weak match; goes to candidate_chats.json review queue
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Any


MS_DOMAIN = "microsoft.com"
COMMON_PARTNER_DOMAINS = {
    # seed list — add to per-tenant config as discovered
    "kasolution.com.br", "kasolution.com",
    "withumb.com",
    "sysmap.com.br",
    "td.com.br", "td.com",
    "compass.com.br",
    "stefanini.com",
    "softek.com.br",
    "logicalis.com.br", "logicalis.com",
    "noventiq.com",
    "softline.com",
}


@dataclass
class ChatClassification:
    chat_id: str
    topic: str
    chat_type: str  # external_customer_chat | internal_account_chat | partner_delivery_chat | ambiguous_chat
    customer_matches: list[dict[str, Any]] = field(default_factory=list)
    participants: list[dict[str, Any]] = field(default_factory=list)  # [{upn, domain, is_ms}]
    has_partner: bool = False
    confidence: float = 0.0
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _extract_domain(upn: str) -> str:
    if "@" in upn:
        return upn.split("@", 1)[1].lower()
    return ""


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "")).strip().lower()


def classify(chat_id: str,
             topic: str,
             participant_upns: list[str],
             customer_aliases: list[dict[str, Any]],
             extra_partner_domains: set[str] | None = None) -> ChatClassification:
    """
    customer_aliases: list of {tpid, official_name, short_name, brands[], child_names[], domains[]}
    """
    partner_domains = (COMMON_PARTNER_DOMAINS | (extra_partner_domains or set()))

    # build participant analysis
    parts: list[dict[str, Any]] = []
    for upn in participant_upns:
        d = _extract_domain(upn)
        parts.append({"upn": upn, "domain": d, "is_ms": d.endswith(MS_DOMAIN)})

    ms_only = all(p["is_ms"] for p in parts) if parts else False
    customer_party_domains = {p["domain"] for p in parts if not p["is_ms"]}
    has_partner = bool(customer_party_domains & partner_domains)
    non_ms_non_partner = customer_party_domains - partner_domains - {""}

    # build customer matches
    matches: list[dict[str, Any]] = []
    topic_n = _norm(topic)
    for a in customer_aliases:
        tpid = a.get("tpid")
        names = [a.get("official_name", ""), a.get("short_name", "")] + (a.get("brands") or []) + (a.get("child_names") or [])
        domains = set((a.get("domains") or []))
        # domain match (strongest)
        dmatch = bool(domains & customer_party_domains)
        # alias-in-topic
        amatch = any(n and _norm(n) in topic_n for n in names if n)
        if dmatch or amatch:
            conf = 0.95 if dmatch else 0.6
            basis = "domain" if dmatch else "alias_in_topic"
            matches.append({"tpid": tpid, "name": a.get("official_name"), "confidence": conf, "match_basis": basis})

    # classify
    if non_ms_non_partner and matches:
        chat_type = "external_customer_chat"
        conf = max((m["confidence"] for m in matches), default=0.9)
        reason = f"customer-domain participant + alias match"
    elif has_partner and matches:
        chat_type = "partner_delivery_chat"
        conf = max((m["confidence"] for m in matches), default=0.7)
        reason = f"partner participant + customer alias match"
    elif ms_only and matches:
        chat_type = "internal_account_chat"
        conf = max((m["confidence"] for m in matches), default=0.6) * 0.85
        reason = "Microsoft-only chat referencing customer"
    elif matches:
        chat_type = "ambiguous_chat"
        conf = 0.4
        reason = "alias match without strong participant signal"
    else:
        chat_type = "ambiguous_chat"
        conf = 0.0
        reason = "no customer signal found"

    return ChatClassification(
        chat_id=chat_id,
        topic=topic,
        chat_type=chat_type,
        customer_matches=matches,
        participants=parts,
        has_partner=has_partner,
        confidence=round(conf, 3),
        reason=reason,
    )
