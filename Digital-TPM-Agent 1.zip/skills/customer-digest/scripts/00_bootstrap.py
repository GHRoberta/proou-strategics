"""Phase 0 — Bootstrap & validation.

Pure local checks. The agent runbook handles network probes (Graph access etc.)
and writes results to data/<run_id>/inputs/source_probes.json which this script
reads and folds into state.json.

Inputs (optional; agent provides):
  data/<run_id>/inputs/source_probes.json
    {
      "weekly_roundup": {"status": "ok", "sender": "...", "subject_regex": "..."},
      "cos": {"status": "ok|degraded|unavailable_this_week", "method": "graph|email_scan|none"},
      "<source_id>": {"status": "...", ...}
    }

Outputs:
  state.json updated (sources_status, schema_version, etc.)
  data/<run_id>/bootstrap_summary.json
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import state as state_mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()

    skill_dir = str(common.SKILL_DIR)
    st = state_mod.load(skill_dir)
    is_fresh = state_mod.begin_run(st, args.run_id)
    common.log(f"run_id={args.run_id} fresh={is_fresh}")

    rd = common.run_dir(args.run_id)
    probes_path = rd / "inputs" / "source_probes.json"
    probes = {}
    if probes_path.exists():
        with open(probes_path, "r", encoding="utf-8") as f:
            probes = json.load(f)
        common.log(f"loaded probes for {len(probes)} sources")
    else:
        common.log(f"no probes file at {probes_path} — using existing sources_status")

    # validate seed files exist
    sources = common.load_sources()
    src_ids = {s["id"] for s in sources.get("sources", [])}
    for sid, info in probes.items():
        if sid not in src_ids:
            common.log(f"warn: probe for unknown source_id {sid!r}")
        state_mod.mark_status(st, sid, info.get("status", "unknown"))
        # persist any source-specific config back to sources.json (e.g., roundup pattern)
        if "sender" in info or "subject_regex" in info:
            for s in sources["sources"]:
                if s["id"] == sid:
                    if "sender" in info:
                        s["filter"] = s.get("filter", {})
                        s["filter"]["sender"] = info["sender"]
                    if "subject_regex" in info:
                        s["filter"] = s.get("filter", {})
                        s["filter"]["subject_regex"] = info["subject_regex"]
                    s.pop("_needs_user_confirmation", None)
            with open(common.SKILL_DIR / "sources.json", "w", encoding="utf-8") as f:
                json.dump(sources, f, indent=2, ensure_ascii=False)
            common.log(f"updated sources.json for {sid}")

    # alias / catalog presence
    aliases = common.load_aliases()
    catalog = common.load_offer_catalog()
    summary = {
        "run_id": args.run_id,
        "is_fresh_run": is_fresh,
        "sources_status": st.get("sources_status", {}),
        "alias_count": len(aliases),
        "offer_catalog_count": len(catalog),
        "warnings": [],
    }
    if not aliases:
        summary["warnings"].append("customer_aliases.json empty — run aliases bootstrap before Phase 2")
    if not catalog:
        summary["warnings"].append("offer_catalog.json empty — Phase 5 will skip hook synthesis")

    state_mod.save(skill_dir, st)
    out = rd / "bootstrap_summary.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    common.log(f"wrote {out}")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
