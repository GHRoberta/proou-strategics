"""Common helpers: paths, config, logging."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent  # ~/.copilot/skills/customer-digest
SCRIPTS_DIR = SKILL_DIR / "scripts"
DATA_DIR = SKILL_DIR / "data"
OUTPUTS_DIR = SKILL_DIR / "outputs"
TEMPLATES_DIR = SKILL_DIR / "templates"


def work_base() -> str:
    cfg = load_config()
    env_var = cfg.get("work_base_env", "WORK_BASE")
    return os.environ.get(env_var) or cfg.get("work_base_default", os.getcwd())


def load_config() -> dict:
    with open(SKILL_DIR / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def load_sources() -> dict:
    with open(SKILL_DIR / "sources.json", "r", encoding="utf-8") as f:
        return json.load(f)


def load_aliases() -> list[dict]:
    p = SKILL_DIR / "customer_aliases.json"
    if not p.exists():
        return []
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f).get("aliases", [])


def save_aliases(aliases: list[dict]) -> None:
    p = SKILL_DIR / "customer_aliases.json"
    payload = {"_schema_version": 1, "_comment": "auto-managed by customer-digest", "aliases": aliases}
    with open(p, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def load_offer_catalog() -> list[dict]:
    p = SKILL_DIR / "offer_catalog.json"
    if not p.exists():
        return []
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f).get("offers", [])


def run_dir(run_id: str) -> Path:
    p = DATA_DIR / run_id
    p.mkdir(parents=True, exist_ok=True)
    return p


def log(*args, prefix: str = "[customer-digest]") -> None:
    print(prefix, *args, file=sys.stderr, flush=True)


def stderr(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)
