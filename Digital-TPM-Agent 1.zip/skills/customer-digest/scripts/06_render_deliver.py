"""Phase 6 — Render & deliver.

Reads:  data/<run_id>/synthesis.json (or synthesis_skeleton.json as fallback)
Writes: outputs/digest_<YYYY-Www>.html (magazine, used DIRECTLY as email body)
        outputs/digest_<YYYY-Www>_meta.json (for the agent to use when creating the draft)

The agent runbook then calls agent365-mail-CreateDraftMessage with:
  - body = magazine HTML (no separate email-safe version, no attachment)
  - subject = meta.subject
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import state as state_mod

try:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
except ImportError:
    print("ERROR: Jinja2 not installed. Run: pip install jinja2", file=sys.stderr)
    sys.exit(2)


def _wk(run_id: str) -> str:
    return run_id  # already YYYY-Www


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--no-local-copy", action="store_true")
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    synth_path = rd / "synthesis.json"
    if not synth_path.exists():
        synth_path = rd / "synthesis_skeleton.json"
    if not synth_path.exists():
        common.log(f"no synthesis at {synth_path}")
        sys.exit(1)
    with open(synth_path, "r", encoding="utf-8") as f:
        synth = json.load(f)

    cfg = common.load_config()
    env = Environment(
        loader=FileSystemLoader(str(common.TEMPLATES_DIR)),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["short_date"] = lambda s: (s or "")[:10]

    ctx = {
        "synth": synth,
        "run_id": args.run_id,
        "generated_at": state_mod.iso_now(),
        "tz_label": "BRT",
        "config": cfg,
    }

    magazine = env.get_template("digest_magazine.html.j2").render(**ctx)

    common.OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    mag_path = common.OUTPUTS_DIR / f"digest_{args.run_id}.html"
    meta_path = common.OUTPUTS_DIR / f"digest_{args.run_id}_meta.json"

    if not args.no_local_copy:
        with open(mag_path, "w", encoding="utf-8") as f:
            f.write(magazine)

    # week label like "Semana de DD/MM a DD/MM" using run_id week
    try:
        y, w = args.run_id.split("-W")
        d_start = datetime.fromisocalendar(int(y), int(w), 1).date()
        d_end = datetime.fromisocalendar(int(y), int(w), 7).date()
        week_label = f"{d_start.strftime('%d/%m')}–{d_end.strftime('%d/%m')}"
    except Exception:
        week_label = args.run_id

    meta = {
        "run_id": args.run_id,
        "subject": f"Customer Digest — Semana de {week_label}",
        "body_html_path": str(mag_path),
        "magazine_html_path": str(mag_path),
        "delivery_mode": "inline_body_no_attachment",
        "agent_action": "Call agent365-mail-CreateDraftMessage with To=GetMyDetails().mail, subject above, body=contents of magazine_html_path, contentType=HTML. Do NOT attach (body already contains the full digest).",
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    # Update state on success
    skill_dir = str(common.SKILL_DIR)
    st = state_mod.load(skill_dir)
    cursors = synth.get("_cursors_to_advance", {}) or {}
    state_mod.commit_success(st, args.run_id, advance_cursors=cursors)
    state_mod.save(skill_dir, st)

    common.log(f"wrote {mag_path}, {meta_path}")
    print(json.dumps({
        "magazine_html": str(mag_path),
        "meta": str(meta_path),
        "subject": meta["subject"],
    }))


if __name__ == "__main__":
    main()
