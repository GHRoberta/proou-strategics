"""Phase 9 — Outlook delivery (replace existing draft if present).

Creates / replaces an Outlook draft with:
  - To: signed-in user
  - Subject: Customer Digest — Semana <week_label>  (or --subject override)
  - Body: full HTML inline (the bilingual digest from phase 8)
  - Attachment: same HTML file (for forwarding / archival)

Deletes any pre-existing draft whose subject contains "Customer Digest" AND
the run-id week marker, to avoid stacking drafts each rerun.

Requires Outlook desktop running (uses pywin32 COM).
"""
from __future__ import annotations
import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common

try:
    import win32com.client  # type: ignore
except ImportError:
    print("ERROR: pywin32 not installed. Run: pip install pywin32", file=sys.stderr)
    sys.exit(2)


def week_label(run_id: str) -> str:
    try:
        y, w = run_id.split("-W")
        d_start = datetime.fromisocalendar(int(y), int(w), 1).date()
        d_end = datetime.fromisocalendar(int(y), int(w), 7).date()
        return f"{d_start.strftime('%d/%b')} a {d_end.strftime('%d/%b/%Y')}"
    except Exception:
        return run_id


def default_subject(run_id: str) -> str:
    try:
        _, w = run_id.split("-W")
        return f"Customer Digest — Semana {int(w)} ({week_label(run_id)})"
    except Exception:
        return f"Customer Digest — {run_id}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--subject", default=None, help="Override default subject")
    ap.add_argument("--to", default=None, help="Override To (default: signed-in user)")
    ap.add_argument("--no-working-copy", action="store_true")
    args = ap.parse_args()

    html_path = common.OUTPUTS_DIR / f"digest_{args.run_id}.html"
    if not html_path.exists():
        common.log(f"missing {html_path}. Run phase 8 first.")
        sys.exit(1)

    body = html_path.read_text(encoding="utf-8")
    common.log(f"HTML body: {len(body):,} chars")

    subject = args.subject or default_subject(args.run_id)
    week_marker = args.run_id.split("-W")[-1] if "-W" in args.run_id else args.run_id

    ol = win32com.client.Dispatch("Outlook.Application")
    ns = ol.GetNamespace("MAPI")

    # Resolve To
    to_addr = args.to
    if not to_addr:
        try:
            to_addr = ns.CurrentUser.AddressEntry.GetExchangeUser().PrimarySmtpAddress
        except Exception:
            # fallback to common.config or env
            cfg = common.load_config()
            to_addr = cfg.get("user_smtp", "")
            if not to_addr:
                common.log("ERROR: could not resolve signed-in user; pass --to <smtp>")
                sys.exit(2)

    # Delete previous drafts matching this run
    deleted = 0
    for store in ns.Stores:
        try:
            drafts = store.GetDefaultFolder(16)  # olFolderDrafts
        except Exception:
            continue
        for item in list(drafts.Items):
            try:
                subj = item.Subject or ""
                if "Customer Digest" in subj and (f"Semana {int(week_marker):d}" in subj or args.run_id in subj):
                    common.log(f"deleting stale draft: [{store.DisplayName}] {subj}")
                    item.Delete()
                    deleted += 1
            except Exception:
                continue
    common.log(f"deleted {deleted} stale draft(s)")

    mail = ol.CreateItem(0)  # olMailItem
    mail.To = to_addr
    mail.Subject = subject
    mail.HTMLBody = body
    mail.Attachments.Add(str(html_path))
    mail.Save()
    common.log(f"new draft saved | To: {to_addr} | Subject: {subject}")

    if not args.no_working_copy:
        targets = []
        wb = Path(common.work_base())
        if wb.exists():
            targets.append(wb)
        cfg_default = common.load_config().get("work_base_default")
        if cfg_default:
            cfg_path = Path(cfg_default)
            if cfg_path.exists() and cfg_path != wb:
                targets.append(cfg_path)
        for t in targets:
            dest = t / html_path.name
            shutil.copy(str(html_path), str(dest))
            common.log(f"copied to {dest}")


if __name__ == "__main__":
    main()
