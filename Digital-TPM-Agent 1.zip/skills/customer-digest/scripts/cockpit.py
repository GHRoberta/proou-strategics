"""Cockpit reader — extracts read-only context from <WORK_BASE>/kanban_data.js.

Cockpit is treated as **context only**. Signals derived directly from cockpit
get primary_source_is_cockpit=true and are dropped in Phase 3 (the cockpit
already shows them on the kanban). The exposed context is used by Phase 5 to
enrich synthesis (e.g., "you have 4 open AERs at [CLIENTE], so a hook about
their new AI initiative is timely") without repeating cockpit alerts.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any


def kanban_path(work_base: str) -> str:
    return os.path.join(work_base, "kanban_data.js")


def _strip_js_wrapper(text: str) -> str:
    """kanban_data.js starts with `window.KANBAN_DATA = {...};` — extract the JSON."""
    m = re.search(r"window\.KANBAN_DATA\s*=\s*(\{.*?\})\s*;?\s*$", text, re.DOTALL)
    if not m:
        m = re.search(r"window\.KANBAN_DATA\s*=\s*(\{.*\})", text, re.DOTALL)
    if not m:
        raise ValueError("kanban_data.js: could not find window.KANBAN_DATA assignment")
    return m.group(1)


def load(work_base: str) -> dict[str, Any] | None:
    """Load kanban data. Returns None if file missing (cockpit is optional)."""
    p = kanban_path(work_base)
    if not os.path.exists(p):
        return None
    with open(p, "r", encoding="utf-8") as f:
        text = f.read()
    payload = _strip_js_wrapper(text)
    return json.loads(payload)


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().upper())


def context_by_customer(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """
    Build a {customer_normalized_name: context} dict.
    Each context has: tpid, columns_present, attention_flagged, priority,
    virtual_team (MS + customer side), open_aers, last_intel_summary,
    last_signal_at, status_summary.
    """
    out: dict[str, dict[str, Any]] = {}
    columns = data.get("columns") or data.get("kanban", {}).get("columns") or []
    for col in columns:
        col_id = col.get("id") or col.get("status") or ""
        for card in col.get("cards", []):
            cust = _norm(card.get("customer", ""))
            if not cust:
                continue
            entry = out.setdefault(cust, {
                "customer": card.get("customer"),
                "tpid": None,
                "columns_present": set(),
                "cards": [],
                "attention_flagged": False,
                "priority_max": None,
                "virtual_team_ms": [],
                "virtual_team_customer": [],
                "open_aers": 0,
                "last_signal_at": None,
                "intel_summaries": [],
            })
            entry["columns_present"].add(col_id)

            # TPID from chips
            for chip in card.get("chips", []) or []:
                txt = chip.get("txt", "") if isinstance(chip, dict) else str(chip)
                m = re.search(r"TPID\s+(\d+)", txt)
                if m and not entry["tpid"]:
                    entry["tpid"] = m.group(1)

            # attention
            att = card.get("attention") or {}
            if att.get("flagged"):
                entry["attention_flagged"] = True

            # priority
            pri = card.get("priority") or ""
            if pri:
                if "HIGH" in pri.upper() or "🔴" in pri:
                    entry["priority_max"] = "HIGH"
                elif entry["priority_max"] is None:
                    entry["priority_max"] = pri.split("—")[0].strip()[:20]

            # virtual team
            team = card.get("team") or {}
            for member in team.get("ms", []) or []:
                if member not in entry["virtual_team_ms"]:
                    entry["virtual_team_ms"].append(member)
            for member in team.get("customer", []) or []:
                if member not in entry["virtual_team_customer"]:
                    entry["virtual_team_customer"].append(member)

            # open AERs counter (cards in pending/approved columns)
            if col_id in {"pending", "approved"}:
                entry["open_aers"] += 1

            # intel summary
            intel = card.get("intel") or {}
            for upd in intel.get("updates", []) or []:
                summ = upd.get("summary") or upd.get("text") or ""
                if summ:
                    entry["intel_summaries"].append({
                        "date": upd.get("date"),
                        "source": upd.get("source"),
                        "summary": summ[:400],
                    })
            last = intel.get("lastScannedAt")
            if last and (not entry["last_signal_at"] or last > entry["last_signal_at"]):
                entry["last_signal_at"] = last

            # store the card minimally for reference
            entry["cards"].append({
                "id": card.get("id") or card.get("title", "")[:60],
                "title": card.get("title"),
                "column": col_id,
            })

    # finalize: turn sets into lists for JSON serialization
    for entry in out.values():
        entry["columns_present"] = sorted(entry["columns_present"])
        entry["intel_summaries"] = entry["intel_summaries"][-3:]  # last 3
    return out


def alert_dedup_keys(data: dict[str, Any]) -> set[str]:
    """
    Build a set of dedup keys representing 'alerts already in cockpit'.
    Used by Phase 3 to suppress signals whose primary source is cockpit.
    Currently keys = card ids + intel update IDs + opportunity IDs found in chips.
    """
    keys: set[str] = set()
    columns = data.get("columns") or []
    for col in columns:
        for card in col.get("cards", []):
            cid = card.get("id") or card.get("title", "")[:60]
            if cid:
                keys.add(f"cockpit_card:{cid}")
            for chip in card.get("chips", []) or []:
                txt = chip.get("txt", "") if isinstance(chip, dict) else str(chip)
                m = re.search(r"AER[#\s]*([A-Z0-9-]+)", txt)
                if m:
                    keys.add(f"aer:{m.group(1)}")
    return keys
