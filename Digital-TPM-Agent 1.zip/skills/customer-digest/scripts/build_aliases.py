"""Bootstrap customer_aliases.json from customer-network outputs.

Usage:
  python build_aliases.py --customer-network-out <path>

Reads customers.json from customer-network skill (if present) and produces
a seeded customer_aliases.json with TPID, official_name, short_name, brands[],
child_names[], domains[], ms_team[], customer_contacts[].

If --customer-network-out is omitted, looks for:
  <WORK_BASE>/customers.json
  <WORK_BASE>/customers_msx.json
  ~/.copilot/skills/customer-network/customers.json
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common


CANDIDATE_PATHS = [
    "{wb}/customers.json",
    "{wb}/customers_msx.json",
    "{home}/.copilot/skills/customer-network/customers.json",
]


def find_source(explicit: str | None) -> str | None:
    if explicit and os.path.exists(explicit):
        return explicit
    wb = common.work_base()
    home = str(Path.home())
    for tpl in CANDIDATE_PATHS:
        p = tpl.format(wb=wb, home=home)
        if os.path.exists(p):
            return p
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer-network-out", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    src = find_source(args.customer_network_out)
    if not src:
        common.log("no customer-network output found. searched:")
        wb = common.work_base()
        home = str(Path.home())
        for tpl in CANDIDATE_PATHS:
            common.log(f"  - {tpl.format(wb=wb, home=home)}")
        sys.exit(2)
    common.log(f"reading {src}")

    with open(src, "r", encoding="utf-8") as f:
        data = json.load(f)

    # be tolerant of two shapes: top-level list, or {"customers": [...]}
    customers = data.get("customers") if isinstance(data, dict) else data
    if not isinstance(customers, list):
        common.log(f"unexpected shape in {src}; expected list or {{customers: [...]}}")
        sys.exit(3)

    aliases = []
    for c in customers:
        tpid = str(c.get("tpid") or c.get("TPID") or "")
        if not tpid:
            continue
        domains = c.get("domains") or c.get("whitelisted_domains") or []
        if isinstance(domains, str):
            domains = [domains]
        aliases.append({
            "tpid": tpid,
            "official_name": c.get("name") or c.get("official_name") or c.get("display_name", ""),
            "short_name": c.get("short_name") or "",
            "brands": c.get("brands") or [],
            "child_names": [ch.get("name") if isinstance(ch, dict) else ch
                            for ch in (c.get("childs") or c.get("children") or [])],
            "domains": [d.lower() for d in domains if d],
            "linkedin": c.get("linkedin") or c.get("linkedin_url") or "",
            "ms_team": c.get("ms_team") or [],
            "customer_contacts": c.get("customer_contacts") or c.get("key_contacts") or [],
        })

    common.log(f"built {len(aliases)} aliases")
    if args.dry_run:
        print(json.dumps(aliases[:3], indent=2, ensure_ascii=False))
        common.log("(dry-run; not saved)")
        return

    common.save_aliases(aliases)
    common.log(f"saved → {common.SKILL_DIR / 'customer_aliases.json'}")
    print(json.dumps({"alias_count": len(aliases)}))


if __name__ == "__main__":
    main()
