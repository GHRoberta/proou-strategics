"""Phase 4 — Customer mapping & scoring.

Reads:  data/<run_id>/signals_clean.jsonl, customer_aliases.json, config.json
Writes: data/<run_id>/signals_scored.jsonl, customers_scored.json

Steps:
1. Expand customer_matches for signals that don't have one yet, by scanning title+summary
   against alias names (subsidiary mentions, brands).
2. Score each signal (severity × source_trust × recency × customer_match_strength).
3. Aggregate per-customer scores and bucket into featured/watchlist/quiet.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import signal as sig_mod
import score as score_mod


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "")).strip().lower()


def expand_matches(signals: list[sig_mod.Signal], aliases: list[dict]) -> int:
    """Add customer_matches by scanning title+summary against alias names."""
    added = 0
    for s in signals:
        if s.customer_matches:
            continue  # respect upstream matches
        text = _norm(f"{s.title} {s.summary}")
        if not text:
            continue
        for a in aliases:
            tpid = a.get("tpid")
            names = [a.get("official_name"), a.get("short_name")] + (a.get("brands") or []) + (a.get("child_names") or [])
            for n in names:
                if n and len(_norm(n)) >= 4 and _norm(n) in text:
                    s.customer_matches.append(sig_mod.CustomerMatch(
                        tpid=str(tpid), name=a.get("official_name", ""),
                        confidence=0.7, match_basis="alias",
                    ))
                    added += 1
                    break
    return added


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()

    rd = common.run_dir(args.run_id)
    in_path = rd / "signals_clean.jsonl"
    if not in_path.exists():
        common.log(f"no {in_path}")
        return

    cfg = common.load_config()
    scoring = cfg.get("scoring", {})
    weights_cfg = scoring.get("weights", {})
    high_t = scoring.get("high_threshold", 5.0)
    medium_t = scoring.get("medium_threshold", 2.0)

    aliases = common.load_aliases()
    signals = sig_mod.load_jsonl(str(in_path))
    common.log(f"loaded {len(signals)} signals; {len(aliases)} aliases")

    expanded = expand_matches(signals, aliases)
    common.log(f"expanded {expanded} customer matches via alias scan")

    weights = {
        "severity": weights_cfg.get("severity", {}),
        "source_trust": weights_cfg.get("source_trust", {}),
        "recency_decay_per_day": weights_cfg.get("recency_decay_per_day", 0.10),
    }
    for s in signals:
        s.score = score_mod.score_signal(s, weights)

    out_path = rd / "signals_scored.jsonl"
    sig_mod.write_jsonl(signals, str(out_path))

    per_cust = score_mod.aggregate_per_customer(signals)
    buckets = score_mod.bucket(per_cust, high=high_t, medium=medium_t)
    cs_path = rd / "customers_scored.json"
    with open(cs_path, "w", encoding="utf-8") as f:
        json.dump({
            "run_id": args.run_id,
            "thresholds": {"high": high_t, "medium": medium_t},
            "buckets": {
                "featured": buckets["featured"],
                "watchlist": buckets["watchlist"],
                "quiet_count": len(buckets["quiet"]),
                "quiet_sample": [q["name"] for q in buckets["quiet"][:10]],
            },
        }, f, indent=2, ensure_ascii=False)

    common.log(f"featured={len(buckets['featured'])}  watchlist={len(buckets['watchlist'])}  quiet={len(buckets['quiet'])}")
    print(json.dumps({
        "featured": len(buckets["featured"]),
        "watchlist": len(buckets["watchlist"]),
        "quiet": len(buckets["quiet"]),
    }))


if __name__ == "__main__":
    main()
