"""Orchestrator — runs phases 0..6 in order.

Modes:
  --mode=fast          (default) skips full customer-network refresh; uses cached aliases/inputs
  --mode=full-refresh  (placeholder; agent should run customer-network rebuild before invoking)

Note: phases 0-1 require agent-pre-fetched inputs (chats_raw.json, source_probes.json).
Phase 2 requires agent-pre-fetched inputs (external_news.json, internal_*.json, etc.).
This orchestrator runs the local processing; the agent runbook handles MCP fetches.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common
import state as state_mod


PHASES = [
    ("00", "00_bootstrap.py"),
    ("01", "01_discover_chats.py"),
    ("02", "02_collect_signals.py"),
    ("03", "03_dedup_suppress.py"),
    ("04", "04_map_score.py"),
    ("05", "05_synthesize.py"),
    ("06", "06_render_deliver.py"),
]


def run_phase(script: str, run_id: str, extra: list[str] | None = None) -> int:
    p = common.SCRIPTS_DIR / script
    cmd = [sys.executable, str(p), "--run-id", run_id] + (extra or [])
    common.log(f"→ {script}")
    res = subprocess.run(cmd, cwd=str(common.SCRIPTS_DIR))
    return res.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["fast", "full-refresh"], default="fast")
    ap.add_argument("--run-id", default=None, help="ISO week id; defaults to current week")
    ap.add_argument("--from-phase", default="00", help="Resume from phase NN")
    ap.add_argument("--to-phase", default="06", help="Stop after phase NN")
    ap.add_argument("--no-local-copy", action="store_true")
    args = ap.parse_args()

    run_id = args.run_id or state_mod.iso_week_id()
    common.log(f"orchestrator: mode={args.mode} run_id={run_id} {args.from_phase}→{args.to_phase}")

    rc_total = 0
    for ph, script in PHASES:
        if ph < args.from_phase or ph > args.to_phase:
            continue
        extra = ["--no-local-copy"] if (ph == "06" and args.no_local_copy) else None
        rc = run_phase(script, run_id, extra)
        if rc != 0:
            common.log(f"phase {ph} failed (rc={rc}) — stopping")
            rc_total = rc
            break

    sys.exit(rc_total)


if __name__ == "__main__":
    main()
