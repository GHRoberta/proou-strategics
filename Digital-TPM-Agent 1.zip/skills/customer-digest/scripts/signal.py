"""Signal — the canonical schema for every input across all sources.

All collectors (Phase 2) emit Signal[] to signals_raw.jsonl. Phases 3-6
operate exclusively on Signal[]. This decouples sources from rendering and
makes cockpit dedup a one-line rule.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode


VALID_SOURCES = {
    "web", "linkedin", "teams_chat", "email", "cos", "roundup",
    "catalog", "product_news", "cockpit", "sharepoint",
}
VALID_CATEGORIES = {
    "M&A", "leadership", "earnings", "regulation", "AI", "security",
    "expansion", "partnership", "catalog_delta", "cos_action",
    "product_launch", "deprecation", "deadline", "other",
}
VALID_SENSITIVITY = {"public", "internal-ms", "confidential-ms"}


@dataclass
class CustomerMatch:
    tpid: str
    name: str
    confidence: float
    match_basis: str  # domain | alias | chat_membership | explicit_mention


@dataclass
class OfferMatch:
    offer_id: str
    catalog: str  # ESI | Learn | SWM | HVS | Roundup | Applied Skills
    confidence: float


@dataclass
class Signal:
    signal_id: str
    source: str
    source_ref: str
    date: str  # ISO 8601
    title: str
    summary: str
    customer_matches: list[CustomerMatch] = field(default_factory=list)
    offer_matches: list[OfferMatch] = field(default_factory=list)
    trigger_category: str = "other"
    sensitivity: str = "internal-ms"
    dedup_key: str = ""
    primary_source_is_cockpit: bool = False
    score: float = 0.0
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_jsonl(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, separators=(",", ":"))


def normalize_url(u: str) -> str:
    """Canonicalize a URL for dedup: strip tracking params, lowercase host, trim fragment."""
    if not u:
        return ""
    try:
        s = urlsplit(u.strip())
        host = (s.hostname or "").lower()
        if s.port:
            host = f"{host}:{s.port}"
        # strip common tracking params
        drop = {"utm_source", "utm_medium", "utm_campaign", "utm_term",
                "utm_content", "fbclid", "gclid", "mc_cid", "mc_eid"}
        q = [(k, v) for k, v in parse_qsl(s.query, keep_blank_values=False)
             if k.lower() not in drop]
        q.sort()
        path = re.sub(r"/+$", "", s.path) or "/"
        return urlunsplit((s.scheme.lower() or "https", host, path, urlencode(q), ""))
    except Exception:
        return u.strip()


def make_dedup_key(source: str, source_ref: str, title: str = "") -> str:
    """Stable dedup key. URL-typed sources canonicalize ref; others hash source|ref|title."""
    if source in {"web", "linkedin", "product_news", "sharepoint"} and source_ref.startswith(("http://", "https://")):
        return normalize_url(source_ref)
    raw = f"{source}|{source_ref}|{title.strip().lower()}"
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def make_signal_id(source: str, source_ref: str, date: str) -> str:
    raw = f"{source}|{source_ref}|{date}"
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def validate(s: Signal) -> list[str]:
    """Return list of validation errors (empty = valid)."""
    errs: list[str] = []
    if s.source not in VALID_SOURCES:
        errs.append(f"invalid source: {s.source}")
    if s.trigger_category not in VALID_CATEGORIES:
        errs.append(f"invalid trigger_category: {s.trigger_category}")
    if s.sensitivity not in VALID_SENSITIVITY:
        errs.append(f"invalid sensitivity: {s.sensitivity}")
    if not s.signal_id or not s.dedup_key:
        errs.append("signal_id and dedup_key are required")
    if not s.date:
        errs.append("date is required")
    else:
        try:
            datetime.fromisoformat(s.date.replace("Z", "+00:00"))
        except Exception:
            errs.append(f"date is not ISO-8601: {s.date}")
    if s.source == "cockpit" and not s.primary_source_is_cockpit:
        errs.append("cockpit-source signals must have primary_source_is_cockpit=true")
    for cm in s.customer_matches:
        if not (0.0 <= cm.confidence <= 1.0):
            errs.append(f"customer_match.confidence out of range: {cm.confidence}")
    for om in s.offer_matches:
        if not (0.0 <= om.confidence <= 1.0):
            errs.append(f"offer_match.confidence out of range: {om.confidence}")
    return errs


def now_iso(tz_offset_hours: int = -3) -> str:
    return datetime.now(timezone.utc).astimezone(
        timezone(__import__("datetime").timedelta(hours=tz_offset_hours))
    ).isoformat()


def build(source: str, source_ref: str, date: str, title: str, summary: str,
          *, trigger_category: str = "other", sensitivity: str = "internal-ms",
          primary_source_is_cockpit: bool = False, **kw) -> Signal:
    """Convenience builder that fills signal_id and dedup_key."""
    sig = Signal(
        signal_id=make_signal_id(source, source_ref, date),
        source=source,
        source_ref=source_ref,
        date=date,
        title=title.strip(),
        summary=summary.strip(),
        trigger_category=trigger_category,
        sensitivity=sensitivity,
        dedup_key=make_dedup_key(source, source_ref, title),
        primary_source_is_cockpit=primary_source_is_cockpit,
        **{k: v for k, v in kw.items() if k in {"customer_matches", "offer_matches", "score", "extras"}},
    )
    return sig


def load_jsonl(path: str) -> list[Signal]:
    """Read signals from a .jsonl file."""
    out: list[Signal] = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                cms = [CustomerMatch(**cm) for cm in d.pop("customer_matches", [])]
                oms = [OfferMatch(**om) for om in d.pop("offer_matches", [])]
                out.append(Signal(customer_matches=cms, offer_matches=oms, **d))
    except FileNotFoundError:
        return []
    return out


def write_jsonl(signals: list[Signal], path: str) -> int:
    """Write signals to a .jsonl file. Returns count written."""
    import os
    os.makedirs(__import__("os").path.dirname(path), exist_ok=True)
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for s in signals:
            f.write(s.to_jsonl() + "\n")
            n += 1
    return n
