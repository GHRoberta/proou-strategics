"""Top-level orchestrator for the bilingual delivery tail (phases 7–9).

After synthesis.json exists for a run, this runs:
  7) translate PT -> EN          (07_translate.py)
  8) dual-language render+stitch (08_dual_render.py)
  9) Outlook draft replacement   (09_deliver_outlook.py)

Use this when re-running just the post-synthesis steps (e.g., after editing
synthesis.json by hand or fixing a translation). For the full pipeline from
sources, use run_digest.py + then this script.
"""
from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(args_list, label):
    print(f"\n=== {label} ===", file=sys.stderr, flush=True)
    r = subprocess.run([sys.executable, *args_list], cwd=str(HERE))
    if r.returncode != 0:
        print(f"FAILED: {label} (exit {r.returncode})", file=sys.stderr)
        sys.exit(r.returncode)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--skip-translate", action="store_true",
                    help="Skip phase 7 (use existing synthesis_en.json)")
    ap.add_argument("--skip-deliver", action="store_true",
                    help="Skip phase 9 (no Outlook draft)")
    ap.add_argument("--subject", default=None)
    ap.add_argument("--to", default=None)
    args = ap.parse_args()

    if not args.skip_translate:
        run([str(HERE / "07_translate.py"), "--run-id", args.run_id], "Phase 7 — Translate PT→EN")

    run([str(HERE / "08_dual_render.py"), "--run-id", args.run_id], "Phase 8 — Dual render + stitch")

    if not args.skip_deliver:
        deliver_args = [str(HERE / "09_deliver_outlook.py"), "--run-id", args.run_id]
        if args.subject:
            deliver_args += ["--subject", args.subject]
        if args.to:
            deliver_args += ["--to", args.to]
        run(deliver_args, "Phase 9 — Outlook draft")


if __name__ == "__main__":
    main()
