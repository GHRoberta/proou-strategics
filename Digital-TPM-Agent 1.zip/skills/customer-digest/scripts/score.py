"""Relevance scoring per signal and per customer."""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from typing import Any

from signal import Signal


def score_signal(s: Signal, weights: dict[str, Any], today: datetime | None = None) -> float:
    today = today or datetime.now(timezone(timedelta(hours=-3)))
    sev_w = weights.get("severity", {})
    src_w = weights.get("source_trust", {})
    decay = float(weights.get("recency_decay_per_day", 0.10))

    sev = float(sev_w.get(s.trigger_category, sev_w.get("other", 1.0)))
    trust = float(src_w.get(s.source, 0.7))
    try:
        d = datetime.fromisoformat(s.date.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        days = max(0, (today - d).days)
    except Exception:
        days = 7
    recency = max(0.1, 1.0 - days * decay)

    cust_match_strength = max((cm.confidence for cm in s.customer_matches), default=0.0)
    return round(sev * trust * recency * (0.3 + 0.7 * cust_match_strength), 3)


def aggregate_per_customer(signals: list[Signal]) -> dict[str, dict[str, Any]]:
    """Return {tpid: {name, score, signals[]}} aggregating signal scores."""
    out: dict[str, dict[str, Any]] = {}
    for s in signals:
        for cm in s.customer_matches:
            entry = out.setdefault(cm.tpid, {"tpid": cm.tpid, "name": cm.name, "score": 0.0, "signals": []})
            entry["score"] += s.score * cm.confidence
            entry["signals"].append(s.signal_id)
    for v in out.values():
        v["score"] = round(v["score"], 3)
    return out


def bucket(per_customer: dict[str, dict[str, Any]], high: float, medium: float) -> dict[str, list[dict[str, Any]]]:
    feat, watch, quiet = [], [], []
    for entry in per_customer.values():
        if entry["score"] >= high:
            feat.append(entry)
        elif entry["score"] >= medium:
            watch.append(entry)
        else:
            quiet.append(entry)
    feat.sort(key=lambda e: e["score"], reverse=True)
    watch.sort(key=lambda e: e["score"], reverse=True)
    return {"featured": feat, "watchlist": watch, "quiet": quiet}
