# Agent runbook — `customer-digest` skill

This file documents the **agent-script handoff**: which MCP calls the agent makes, what JSON files it writes to `data/<run_id>/inputs/`, and the order to invoke the local Python phases.

The Python scripts are pure local processors. They cannot invoke MCP tools. The **agent** (powered by the LLM) is the source of all network/MCP-mediated data; it materializes that data as JSON files that the phases read.

## Run order

```
agent: probe sources           → writes inputs/source_probes.json
script: 00_bootstrap.py        → updates state.json + sources.json
agent: list & fetch chats      → writes inputs/chats_raw.json
script: 01_discover_chats.py   → writes monitored_chats.json + candidate_chats.json
agent: collect signals         → writes inputs/{external_news,internal_emails,internal_chats,cos_items,roundup_items,catalog_diff,product_news}.json
script: 02_collect_signals.py  → writes signals_raw.jsonl + cockpit_context.json
script: 03_dedup_suppress.py   → writes signals_clean.jsonl + drop_report.json
script: 04_map_score.py        → writes signals_scored.jsonl + customers_scored.json
script: 05_synthesize.py       → writes synthesis_skeleton.json
agent: fill hook narratives    → writes synthesis.json (uses skeleton + offer_catalog.json + my-voice)
script: 06_render_deliver.py   → writes outputs/digest_<id>.html + _email.html + _meta.json (PT-only, intermediate preview)
script: 07_translate.py        → writes synthesis_en.json (PT→EN via deep_translator, preserves HTML/URLs)
script: 08_dual_render.py      → writes outputs/digest_<id>.html bilingual (PT/EN toggle, sticky sidebar) + working copies
script: 09_deliver_outlook.py  → creates Outlook draft (deletes prior draft for same run, body inline + HTML attachment)
```

Or batch-run phases 02→06 with: `python run_digest.py --from-phase 02 --to-phase 06 --run-id YYYY-Www`
Then bilingual + delivery (phases 7→9) with: `python scripts/run_bilingual.py --run-id YYYY-Www`
Flags: `--skip-translate` (re-render only) | `--skip-deliver` (no Outlook draft)


## Per-source MCP recipes the agent must execute

### source_probes.json (Phase 0)
```json
{
  "agent365_mail":   {"status": "ok"},
  "agent365_teams":  {"status": "ok"},
  "weekly_roundup":  {"status": "ok", "sender": "{{EMAIL}}", "subject_regex": "Weekly Roundup|Round[- ]?up"},
  "cos":             {"status": "degraded", "method": "email_scan"},
  "tpm_sharepoint":  {"status": "ok"},
  "m365_blog":       {"status": "ok"}
}
```
- For `cos`: try `agent365-calendar-ListEvents` with `meetingTitle="CoS"` for the last 14d, then for each instance try `agent365-mail-SearchMessages` with subject regex `CoS|Chief of Staff|GTM Brasil` for fallback A. If both empty → `unavailable_this_week`.

### chats_raw.json (Phase 1)
- `agent365-teams-ListChats fetchAllPages=false` → for each: `agent365-teams-ListChatMembers` to get UPNs, `agent365-teams-ListChatMessages top=5` to confirm activity in window.
- Output one entry per chat: `{chat_id, topic, participant_upns: [...], last_message_at}`.

### external_news.json (Phase 2)
- For each customer in `customer_aliases.json` whose cockpit shows recent activity OR is in MSX my-deals:
  - `web_search` query: `"<official_name>" OR "<short_name>" notícia OR aquisição OR CEO OR resultado OR lançamento OR regulação`
  - For each result, `web_fetch` to verify date ≤ 7d, extract title/summary
  - Score gate: only keep if `trigger_category` ∈ {M&A, leadership, earnings, regulation, AI, security, expansion, partnership, product_launch}
- Output structure:
```json
[
  { "customer_tpid": "[TPID]", "customer_name": "[CLIENTE]",
    "items": [{"url": "...", "title": "...", "summary": "...", "date": "2026-05-04", "source_label": "Valor Econômico", "confidence": 0.9, "trigger_category": "expansion"}]
  }
]
```

### internal_emails.json (Phase 2)
- `agent365-mail-SearchMessagesQueryParameters` with `?$filter=receivedDateTime ge <cursor> and (from/emailAddress/address eq '{{EMAIL}}' or contains(subject,'Skilling Catalog') or contains(subject,'Roundup'))`
- One entry per message: `{message_id, from, subject, received, body_preview, source_id}` where `source_id` ∈ {`manager_emails`, `skilling_catalog`, `weekly_roundup`, `tpm_global_community`}.

### internal_chats.json (Phase 2)
- For each chat in `monitored_chats.json` where `last_message_at >= cursor`:
  - `agent365-teams-ListChatMessages top=20`
  - For each message: emit `{chat_id, message_id, from, sent, content, customer_tpid, customer_name, sensitivity}`
  - **sensitivity**: external_customer_chat → `internal-ms` (themes only, no quotes); internal_account_chat → `confidential-ms` (NEVER quoted in output, used as score boost only); partner_delivery_chat → `internal-ms`.

### cos_items.json (Phase 2)
- Per Phase 0 outcome:
  - graph: per-meeting transcript fetch (skip if 403)
  - email_scan: SearchMessages on `CoS|Chief of Staff|GTM Brasil` in window → extract action items via LLM summarization
- Each: `{event_id, date, title, summary, action_items: [{owner, action, customer?}]}`.

### roundup_items.json (Phase 2)
- Parse Weekly Roundup email body (HTML); each bullet → an item.
- Each: `{id, date, title, summary, offer_id?, applies_to?, trigger_category}`.

### catalog_diff.json (Phase 2)
- Diff `agent365-sharepoint-readSmallTextFile` on TPM SharePoint Catalog page vs cached prior version (cache at `data/_catalog_cache.json`).
- Each: `{course_id, change_type: added|removed|updated, title, date, summary?}`.

### product_news.json (Phase 2)
- `web_fetch` Microsoft 365 Blog RSS or page; only items in window.
- Each: `{url, title, summary, date, product, source_label}`.

## Hook synthesis (between Phase 5 and Phase 6)

After `05_synthesize.py` writes `synthesis_skeleton.json`, the agent loads it and for each `customer_section`:
- For each `candidate_offer` × top signals, attempt to compose a hook obeying:
  - `recommended_offer.catalog_id` MUST be in `offer_catalog.json[].offer_id`
  - At least 2 evidence elements among: `customer_specific_signal`, `validated_offer`, `relevant_contact`, `timing_or_deadline`, `business_event`
  - `suggested_contact` must come from `c.ms_team` or `c.customer_contacts`
- Append to `c.hooks[]` per the schema in `SKILL.md`
- Hooks failing the 2-evidence rule → discard or move customer to `watchlist`
- Then write `synthesis.json` (same shape as skeleton, with `hooks` filled and `_skipped_hook_synthesis_reason` removed)
- Use **my-voice** profile for tone (PT-BR, audience = self/internal peer)

## Final delivery (after Phase 9) — local `.eml`, per MANDATE M1

Deliver the digest as a local **`.eml`** draft (To = self), **not** via Outlook
COM (`09_deliver_outlook.py`) and **not** via Graph `agent365-mail-CreateDraftMessage`
— both are prohibited (they clutter the mailbox).

1. Get the user's address (`agent365-user-GetMyDetails select="mail"`).
2. Build an `.eml` (RFC-822/MIME, header `X-Unsent: 1`) with:
   - `To: user.mail`, `Subject: meta.subject`, `From: {{USER_FIRSTNAME}}`
   - body = contents of bilingual `outputs/digest_<id>.html` (HTML alternative)
   - attach `digest_<run_id>.html` from the local file
   Use the `make_eml_drafts.py` pattern in this skill / the `my-voice` §6 snippet.
3. Save to `{{WORKDIR_LOCAL}}\drafts\digest_<run_id>.eml` and **open it**
   (`start "" <path>`). **Do NOT send.** The user reviews and sends manually.


## Cursor advancement

The phases do not know what the agent fetched. The agent should write a small `inputs/_cursors.json` with the latest timestamp it advanced per source, e.g.:
```json
{ "manager_emails": "2026-05-04T17:30:00-03:00", "weekly_roundup": "2026-05-03T09:00:00-03:00" }
```
Then before delivery, merge into `synthesis.json` as `_cursors_to_advance` so Phase 6 commits them on success.

## Edge cases

- **Empty digest** (no featured customers, no highlights): still create the draft with a "quiet week" body — useful as a heartbeat. Do NOT skip.
- **Same-week rerun**: state detects same `run_id`, skip cursor advancement, overwrite outputs.
- **Gap > 10d**: agent prompts user to choose `catch-up top N` vs `last 7d window`.
- **Sensitivity violation**: never include verbatim quotes from `confidential-ms` chats; reduce to themes.
