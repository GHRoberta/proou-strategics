---
name: customer-digest
description: >
  Weekly customer-centric digest that aggregates news + signals (web/LinkedIn,
  TPM groups, CoS, Weekly Roundup, product announcements, customer-specific
  Teams chats, cockpit intel) into an evidence-backed magazine-style email
  draft. Signal-centric pipeline: every source produces normalized Signals,
  dedup'd against cockpit, mapped to customers via alias table, scored, and
  rendered into Highlights / Customer Digest / Actions sections. Output is
  an Outlook draft addressed to the user (no auto-send), with a full HTML
  "magazine" attached. Triggers: weekly digest, customer digest, gera o
  digest, news digest, what's new this week, ganchos para clientes, conversation
  hooks, customer news roundup, weekly customer briefing.
---

# Customer Digest (signal-centric, weekly)

Replaces the legacy topic-based `tpm-training-digest`. The aggregator is **the customer**. **100% portfolio coverage is mandatory** — every Top account in the user's TPM portfolio (~30 today) gets a section every week, including inactive ones (for those, surface external news + last MSX touch + re-engagement hook). Cockpit data is **context, not a gate**: deal-status updates from cockpit are not duplicated, but cockpit signals (open AERs, priority flags, last intel) enrich each customer block. Focus is on **what's NEW** (news, product launches, catalog deltas, CoS actions, conversations) — cockpit owns in-flight execution updates. The output is a draft email in Outlook (To = self) with the **full magazine HTML inline in the body** plus the same HTML as attachment.

> **Core principle:** every input from every source becomes a `Signal` in a single schema. All downstream phases (dedup, mapping, scoring, synthesis, rendering) read signals only. This decouples sources from rendering and makes the dedup-with-cockpit rule simple and testable.

## Prerequisites

- **agent365** (mail/teams/calendar/sharepoint/user) MCP server — primary data plane
- **customer-network** skill outputs available (`customers.json` with TPIDs + domains; or run customer-network first)
- **tpm-cockpit** kanban data (`<WORK_BASE>\kanban_data.js`) — read-only context for dedup
- **Outlook desktop** open (for COM-based draft delivery) OR agent365-mail draft API
- **WORK_BASE** = `{{WORKDIR}}` (default; configurable)
- **web_search** + **web_fetch** tools — for external news collection
- **Python 3.10+** (skill runs as Python scripts, not PS — consistent with `customer-network`)
- **Python packages**: `jinja2`, `beautifulsoup4`, `deep-translator`, `pywin32` — install with: `pip install jinja2 beautifulsoup4 deep-translator pywin32`

## Output

1. **Outlook draft** in user's mailbox: `Customer Digest — Semana {N} ({date_range})`, To = self, body = bilingual magazine HTML inline, attachment = same HTML for forwarding/browser.
2. **Local copy**: `<skill_dir>\outputs\digest_<YYYY-Www>.html` (single distributable file with PT-BR/EN-US toggle; ~225KB; opens standalone in any browser).
3. **Working copies**: also written to `WORK_BASE` (env var) and `work_base_default` (config) when both exist.
4. **State updated**: `state.json` — per-source cursors only advanced on success.

## The Signal schema (the spine)

```json
{
  "signal_id": "sha256(source|source_ref|date)",
  "source": "web|linkedin|teams_chat|email|cos|roundup|catalog|product_news|cockpit|sharepoint",
  "source_ref": "url|message_id|event_id|card_id",
  "date": "2026-05-04T13:00:00-03:00",
  "title": "string",
  "summary": "string (LLM-generated, <= 280 chars)",
  "customer_matches": [
    { "tpid": "[TPID]", "name": "[CLIENTE]", "confidence": 0.95, "match_basis": "domain|alias|chat_membership|explicit_mention" }
  ],
  "offer_matches": [
    { "offer_id": "MS-4017", "catalog": "ESI|Learn|SWM|Roundup", "confidence": 0.7 }
  ],
  "trigger_category": "M&A|leadership|earnings|regulation|AI|security|expansion|partnership|catalog_delta|cos_action|product_launch|deprecation|deadline|other",
  "sensitivity": "public|internal-ms|confidential-ms",
  "dedup_key": "url_canonical_or_id",
  "primary_source_is_cockpit": false,
  "score": 0.78
}
```

## Pipeline (10 phases)

| # | Script | Output | Idempotent |
|---|---|---|---|
| 0 | `00_bootstrap.py` | `state.json`, `sources_status`, customer-network cache, CoS access decision | yes |
| 1 | `01_discover_chats.py` | `monitored_chats.json`, `candidate_chats.json` (review queue) | yes (cumulative TTL 60d) |
| 2 | `02_collect_signals.py` | `data/<run_id>/signals_raw.jsonl` (one Signal per line, one file per source group) | yes (idempotent by `dedup_key`) |
| 3 | `03_dedup_suppress.py` | `data/<run_id>/signals_clean.jsonl` | yes |
| 4 | `04_map_score.py` | `data/<run_id>/customers_scored.json` (featured/watchlist/quiet buckets) | yes |
| 5 | `05_synthesize.py` | `data/<run_id>/synthesis.json` (highlights, customer sections, actions, hooks) | LLM-assisted |
| 6 | `06_render_deliver.py` | `outputs/digest_<YYYY-Www>.html` (PT-only legacy single-language render) | yes |
| **7** | **`07_translate.py`** | **`data/<run_id>/synthesis_en.json` (PT→EN, preserves HTML)** | **yes (online; deep_translator + Google)** |
| **8** | **`08_dual_render.py`** | **`outputs/digest_<YYYY-Www>.html` (bilingual, PT/EN toggle, single distributable HTML)** | **yes (overwrites phase-6 output)** |
| **9** | **`09_deliver_outlook.py`** | **Outlook draft (HTML body + same HTML attached); copies to WORK_BASE** | **yes (deletes prior matching draft)** |

**Run shortcuts:**
- Full pipeline: `python run_digest.py --mode=fast` (phases 0-6)
- Bilingual delivery tail (after synthesis): `python run_bilingual.py --run-id 2026-W18` (phases 7-9)
- Re-render only (synthesis already on disk): `python run_bilingual.py --run-id 2026-W18 --skip-translate`

**100% bilingual is mandatory.** The deliverable is always one self-contained HTML with PT-BR (default) + EN-US (toggle), styled in Microsoft Source LATAM Brasil look (Segoe-only, sticky right sidebar with per-customer index, brand bar at top, white cards on `#f2f2f2`). Choice persists via `localStorage`.

### Phase 0 — Bootstrap & validation

- Validate access to each source listed in `sources.json` (writes `sources_status[source_id] = ok|degraded|down|skipped`)
- **CoS 3-tier fallback**:
  1. Try Graph onlineMeeting transcripts (`/users/{organizerId}/onlineMeetings/{id}/transcripts`) — needs app permission `OnlineMeetingTranscript.Read.All` scoped to organizer; will likely fail without admin policy
  2. Fallback A: scan emails + Teams chats with subject/topic matching `CoS|Chief of Staff|GTM Brasil` in the run window
  3. Fallback B: mark `cos: unavailable_this_week` in state — pipeline continues
- Confirm Weekly Roundup pattern (sender + subject regex stored in `sources.json`); prompt user on first run if not configured
- Load `customer-network` outputs from cache (< 7d) or trigger `--phase=4` minimal refresh
- Load/seed `customer_aliases.json` and `offer_catalog.json`

### Phase 1 — Chat discovery & classification

- `agent365-teams ListChats` recent (paginated)
- For each chat:
  - Resolve participant domains; cross-reference with `customers.json[].domains`
  - Match chat `topic` against `customer_aliases.json` (official name + short_name + brands + child names)
  - **Classify**:
    - `external_customer_chat` — has ≥1 non-Microsoft participant on whitelisted customer domain → safe to summarize themes
    - `internal_account_chat` — Microsoft-only members but topic/recent messages clearly reference customer → use as internal signal only, never quote
    - `partner_delivery_chat` — includes partner/TSP domains, may cover 1+ customers (e.g., "Webinar MS Copilot (Ka Solution)" → [CLIENTE] + Ka + Microsoft)
    - `ambiguous_chat` — name-only or weak match → goes to `candidate_chats.json` review queue, **not** auto-promoted
- Persist `monitored_chats.json` cumulatively with TTL 60d for inactive
- Diff vs prior run: brand-new chats are flagged for synthesis attention

### Phase 2 — Signal collection (parallel, gated)

Concurrency cap = 5. Each producer outputs `Signal[]` to `signals_raw.jsonl`.

**External per active customer**:
- 1 combined `web_search` query per customer: `"{official_name}" OR "{short_name}" notícia OR aquisição OR CEO OR resultado OR lançamento OR regulação` filtered by recency
- Score gate: source trust (newsroom/IR > reputable media > LinkedIn/generic web), entity match unambiguous, trigger_category in allowed list
- LinkedIn = optional low-confidence enrichment, never sole source

**Internal global** (always all customers):
- TPM Dream Team chat (last 7d)
- My Team chat (last 7d)
- Emails: from manager (Carlos Pardo), Skilling Catalog Updates, TPM Global Community
- Office Hours / TPM Summit transcripts (calendar → onlineMeeting → transcript if available)
- **CoS** — per Phase 0 outcome
- M365 Blog (RSS or page diff)
- TPM SharePoint Catalog (page diff for new courses/changes)

**Internal per customer**:
- Messages from `monitored_chats` in window, classified by sensitivity per chat type

**Cockpit context** (read-only, from `<WORK_BASE>\kanban_data.js`):
- For each customer with a card: extract `{tpid, status_summary, attention.flagged, priority, virtual_team, last_intel_summary, open_aers}` → loaded into `cockpit_context.json`. Cockpit data **enriches** every customer block (last touch, open AERs, priority flag) but does NOT gate inclusion. Deal-status updates from cockpit are not duplicated in the digest narrative — the digest focuses on what's NEW (news, conversations, product/catalog deltas, CoS actions).

### Phase 3 — Dedup (no cockpit suppression)

1. **Hard dedup** by `dedup_key` (URL canonical, message_id, opportunity_id, card_id, alert_title hash)
2. **Cockpit data is context, not a gate**: cockpit signals enrich customer blocks (last MSX touch, open AERs, priority, virtual team). The digest does not re-narrate deal status — but cockpit facts (e.g., "AER 135312 open since 12/Apr") appear as inline context where they sharpen a hook or re-engagement narrative.
3. **What goes IN the digest**: news, product launches, catalog deltas, CoS actions, group-chat themes, conversations with Microsoft team, regulatory/M&A/leadership changes — anything NEW since last successful run.
4. **What stays OUT**: pure deal-status updates ("opportunity X moved to Propose") — cockpit owns those.

### Phase 4 — Customer mapping & 100% portfolio coverage

- Expand `customer_matches` via `customer_aliases.json` (catch subsidiary mentions, brand names)
- Compute `account_relevance_score` per customer = Σ(severity × recency_decay × confidence) over signals matched to that customer
- **100% coverage rule**: every Top account in the user's TPM portfolio (`customers.json` from customer-network) gets a section, regardless of score. Two tiers:
  - **active** — has signals this window OR cockpit recent activity (<60d) → full magazine block with hooks
  - **inactive** — no signals/activity in 60+ days → magazine block focused on (a) external news scan, (b) last MSX touch from cockpit, (c) re-engagement hook ("conversa de capacitação" angle based on industry/last-known-priority)
- No customer is dropped from the digest. The narrative depth varies; the seat at the table doesn't.

### Phase 5 — Hook & offer synthesis (schema-constrained)

LLM (Claude/GPT via subprocess to `copilot` CLI or Anthropic API) generates hooks. Strict rules:

- Offers **must** be selected from `offer_catalog.json` — LLM cannot invent
- Each hook must satisfy ≥2 of: customer-specific signal, validated offer, relevant contact, timing/deadline, business event
- **Contact validation is mandatory**: every `suggested_contact.name` MUST be resolved against the Microsoft directory (via `agent365-user-GetMultipleUsersDetails` for MS contacts, or `customer_aliases.json`/customer-network for customer contacts). Contacts that resolve get a ✓; contacts that fail directory lookup get a ⚠ and the rendered prose explicitly flags them as unverified. Never present a fabricated MS contact as validated.
- **Inactive accounts get a hook too**: when `tier=inactive`, the hook draws from external news + industry trend + the user's catalog of capacitação offers, framed as "conversation starter" rather than "next step in deal".
- **Magazine prose, not bullet lists**: hooks render as 2-4 sentence narratives with the trigger, the relevance, the offer, and the contact woven together — readable like a business magazine, not a checklist.
- Schema (one per hook, internal data structure — render is prose):

```json
{
  "customer": "[CLIENTE]",
  "hook_type": "news_to_training|internal_signal_to_offer|product_delta_to_customer|cos_to_action",
  "trigger_signal": { "signal_id": "...", "source": "...", "date": "...", "ref": "..." },
  "customer_relevance": "Why this matters specifically to [CLIENTE]",
  "recommended_offer": { "type": "course|PD|SWM|workshop|cert|briefing", "catalog_id": "MS-4017", "reason": "..." },
  "suggested_contact": { "name": "[CONTATO]", "role": "Copilot 365 owner", "reason": "..." },
  "confidence": "high|medium|low",
  "do_not_use_if": "[CLIENTE] já anunciou X publicamente"
}
```

- Highlights = top 3 signals ranked by `len(customer_matches) × max_severity` (deprecations rank high)
- Actions = signals with deadline OR cross-portfolio impact (≥3 customer_matches)

### Phase 6 — Render & deliver (full inline body + attachment)

> **Note:** Phase 6 produces a single-language (PT-BR) HTML using the magazine template. This is the **legacy/intermediate** output. The current production deliverable is built by phases 7-9 (bilingual). Phase 6 is still useful for quick PT-only previews while iterating on synthesis.

- **Magazine HTML** (`templates/digest_magazine.html.j2`):
  - Browser-quality, embedded CSS, Microsoft Source LATAM Brasil styling (Segoe-only, sticky right sidebar with per-customer index, brand bar, white cards on `#f2f2f2`)
  - Sections: 3 Highlights → Customer Digest (one block per customer, **all ~30**, active and inactive) → Actions cross-portfolio
  - Each customer block: headline, narrative_html, news context (web/LinkedIn since last run), conversations summary, hooks/offers as flowing prose, contacts with ✓/⚠ validation marks, cockpit context inline (last touch, open AERs)
- Save copy to `outputs/digest_<YYYY-Www>.html`

### Phase 7 — Translate (PT → EN)

- Loads `data/<run_id>/synthesis.json` and walks every translatable field
- **Preserves**: HTML tags, URLs, names, TPIDs, dates, contacts, structured metadata (keys in `PASSTHROUGH_KEYS` set in script)
- **Translates**: titles, deks, headlines, narratives, hooks, recommended offers, and inner text of `<a>`/`<strong>`/`<em>` nodes inside `narrative_html` (via BeautifulSoup walking)
- Engine: `deep_translator.GoogleTranslator` (free, online, no API key). String-level cache to minimize calls. Auto-chunks strings >4500 chars at sentence boundaries.
- Writes `data/<run_id>/synthesis_en.json`
- Source/target langs configurable: `--source-lang pt --target-lang en` (default)
- **Quality caveat**: machine-translated. For executive external send, recommend human pass on Highlights + Actions. News titles + customer names are passthrough — never altered.

### Phase 8 — Dual-language render & stitch

- Renders `digest_magazine.html.j2` twice — once with `synthesis.json` (PT), once with `synthesis_en.json` (EN)
- Post-translates ~30 hardcoded UI labels in the EN render via `UI_MAP` (template stays single-language to keep complexity low)
- Stitches both renders into ONE HTML file:
  - Sticky toggle bar at top: `[Idioma / Language: PT-BR | EN-US]`
  - Two `<div class="lang-pane">` containers — only one visible at a time
  - Toggle is JS-driven, persists choice in `localStorage`
  - Single `<head>` (styles language-agnostic)
- Writes `outputs/digest_<YYYY-Www>.html` (overwrites phase-6 output) + working copies to `WORK_BASE` (env) and `work_base_default` from config (both if both exist)

### Phase 9 — Outlook delivery

- Loads bilingual HTML from `outputs/`
- Resolves `To` from signed-in Outlook user (or `--to` override)
- **Deletes any prior Drafts** matching `Customer Digest` + this week-marker (avoids stacking drafts on rerun)
- Creates fresh draft: subject `Customer Digest — Semana {N} ({DD/Mmm a DD/Mmm/YYYY})`, HTML body inline (~225KB), same HTML attached
- User opens Outlook → reviews → sends manually (no auto-send)
- Updates state: advance `source_cursors[source_id]` ONLY for sources that succeeded; bump `last_successful_digest_at` after draft is saved

## State model

```json
{
  "schema_version": 1,
  "last_successful_digest_at": "2026-05-01T17:30:00-03:00",
  "last_attempt_at": "2026-05-04T17:30:00-03:00",
  "current_run_id": "2026-W19",
  "source_cursors": {
    "tpm_dream_team": "2026-04-27T00:00:00-03:00",
    "my_team_chat":   "2026-04-27T00:00:00-03:00",
    "cos":            "unavailable",
    "m365_blog":      "2026-04-27T00:00:00-03:00",
    "weekly_roundup": "2026-04-27T00:00:00-03:00"
  },
  "sources_status": {
    "cos": "down",
    "weekly_roundup": "ok"
  }
}
```

Rules:
- Re-run same `run_id` (same ISO week) reuses the run, does NOT advance cursors
- If gap > 10d since `last_successful_digest_at`, prompt: catch-up (top N) or cap at 7 days
- A failed source keeps its cursor; next run will resume from there
- Rotation: `outputs/` keeps last 12 weeks; older auto-pruned

## Modes

- `--mode=fast` (default, 5–10 min):
  - Customer-network from cache
  - Only known monitored chats + new candidates
  - External news only for active customers
  - Global sources capped (top N items each)
- `--mode=full-refresh` (20–45 min):
  - Trigger `customer-network --phase=3+3b` rebuild
  - Deep chat rediscovery (paginate all chats)
  - Revalidate every source, re-prompt for any unconfirmed config

## Catalogs

### `customer_aliases.json`
```json
[
  {
    "tpid": "[TPID]",
    "official_name": "[CLIENTE]",
    "short_name": "[CLIENTE]",
    "brands": ["[CLIENTE]", "V.tal"],
    "child_names": ["[CLIENTE]/[CLIENTE]/[CLIENTE]"],
    "linkedin_url": "https://www.linkedin.com/company/btg-pactual/",
    "newsroom_url": "https://www.btgpactual.com/imprensa",
    "tpid_history": [],
    "excluded_terms": []
  }
]
```

### `offer_catalog.json`
```json
[
  {
    "offer_id": "MS-4017",
    "catalog": "ESI",
    "type": "course",
    "title": "Microsoft 365 Copilot for Business Decision Makers",
    "audience": ["business leaders"],
    "modality": "instructor-led",
    "active": true,
    "since": "2026-01-15",
    "url": "..."
  }
]
```

Both files seeded empty on first scaffold; bootstrap (Phase 0) populates aliases from `customer-network` outputs and offers from latest TPM Roundup + ESI catalog.

## Sources matrix (15)

| # | Source | Producer | Status check |
|---|---|---|---|
| 1 | TPM Dream Team chat | `agent365-teams` | list+read |
| 2 | My Team chat (Carlos Pardo) | `agent365-teams` | list+read |
| 3 | Americas Weekly Office Hours | `agent365-calendar` + transcript | calendar query |
| 4 | Americas Weekly TPM Summit | `agent365-calendar` + transcript | calendar query |
| 5 | Emails: Skilling Catalog Updates | `agent365-mail` | search query |
| 6 | Emails from Carlos Pardo | `agent365-mail` | search query |
| 7 | Emails to TPM Global Community | `agent365-mail` | search query |
| 7b | **TPM Weekly Roundup** | `agent365-mail` | sender = `{{EMAIL}}` |
| 8 | TPM SharePoint Catalog | `agent365-sharepoint` | page fetch |
| 9 | Microsoft 365 Blog | `web_fetch` | RSS or page |
| 10 | **Microsoft Monitoring News (Brazil)** | `agent365-mail` | sender = `{{EMAIL}}` |
| 11 | **CoS recordings** (GTM Brasil weekly) | Graph + fallbacks | 3-tier per Phase 0 |
| 12 | Customer-specific Teams chats | `agent365-teams` + classification (Phase 1) | dynamic |
| 13 | LinkedIn news per customer | `web_search site:linkedin.com` | per-customer |
| 14 | Web news per customer | `web_search` | per-customer |
| 15 | Cockpit intel | `kanban_data.js` (read) | file mtime |

## Sensitivity policy

- `public` — external news, blog posts, public PR
- `internal-ms` — TPM groups, my team chat, Roundup, CoS, Office Hours, internal_account_chat
- `confidential-ms` — cockpit intel, deal status, customer escalations

Rendering:
- Public/customer-shared: explicit
- Internal: summarized abstractly, no direct quotes
- Confidential: informs synthesis only, never quoted, never in body or attachment

Email banner top-of-body: *"Internal — mixed sources, do not forward externally"*.

## Cadence

- Default: Thursday ~17:00 BRT (after CoS, before Friday planning)
- Trigger phrases: "gera o digest", "weekly digest", "customer digest", "what's new this week", "ganchos para clientes"
- Scheduled execution: optional, via Windows Task Scheduler running `python run_digest.py --mode=fast`

## Error handling

| Error | Cause | Recovery |
|---|---|---|
| customer-network outputs missing | First run, never built | Auto-trigger `--mode=full-refresh` |
| CoS Graph 403 | No app permission | Fall back per Phase 0 ladder; mark `cos: down` |
| `kanban_data.js` not found | Cockpit not built | Continue without cockpit context; warn |
| WorkIQ slow | Service degraded | Skip per-call timeout 60s; collected sources marked `degraded` |
| Outlook draft create fails | Mail tool offline | Save full HTML to `outputs/`; print mailto-style instructions |
| Web search rate limited | Too many parallel | Drop concurrency to 2 and retry once |

## Files

```
~/.copilot/skills/customer-digest/
├── SKILL.md                       # this file
├── customer-digest.agent.md       # agent definition (sister file to SKILL.md, lives here for cohesion; symlinked or referenced from ~/.copilot/agents/)
├── customer_aliases.json          # alias table (seeded from customer-network)
├── offer_catalog.json             # offer inventory (LLM-constrained)
├── sources.json                   # source registry (regex/cursors per source)
├── config.json                    # thresholds (HIGH/MEDIUM relevance, score weights)
├── state.json                     # cursors + last_successful_digest_at
├── monitored_chats.json           # cumulative chat registry (Phase 1)
├── candidate_chats.json           # review queue
├── outputs/                       # weekly HTML digests (rotation 12w)
├── data/<YYYY-Www>/               # per-run intermediate artifacts
│   ├── signals_raw.jsonl
│   ├── signals_clean.jsonl
│   ├── customers_scored.json
│   ├── synthesis.json
│   └── cockpit_context.json
├── scripts/
│   ├── signal.py                  # Signal dataclass, hashing, validators
│   ├── state.py                   # state read/write + cursor logic
│   ├── cockpit.py                 # read kanban_data.js, expose context
│   ├── classify_chat.py           # 4-class chat classifier
│   ├── score.py                   # relevance scoring
│   ├── 00_bootstrap.py
│   ├── 01_discover_chats.py
│   ├── 02_collect_signals.py
│   ├── 03_dedup_suppress.py
│   ├── 04_map_score.py
│   ├── 05_synthesize.py
│   ├── 06_render_deliver.py
│   └── run_digest.py              # orchestrator (runs 00→06)
└── templates/
    ├── digest_email.html.j2       # Outlook-safe (table+inline CSS, 700px)
    └── digest_magazine.html.j2    # browser-quality magazine
```

## Acceptance criteria

- [ ] All 16 sources have a status entry after Phase 0 (15 + Microsoft Monitoring News)
- [ ] CoS has 3-tier fallback (Graph → emails/chats → unavailable) — pipeline never blocks on CoS
- [ ] Phase 1 produces `monitored_chats.json` with 4-class labels + `candidate_chats.json`
- [ ] Every signal passes JSON schema validation (`signal.py:validate()`)
- [ ] **100% portfolio coverage**: `len(customer_blocks) == len(customers.json[Top])` (currently 30). Active and inactive accounts both render.
- [ ] **Cockpit data flows as context** in every customer block (last touch, open AERs, priority) — but deal-status updates are not narrated; the digest covers what's NEW.
- [ ] **Inactive accounts (>60d no signal) get re-engagement hook** based on industry news + capacitação catalog
- [ ] Every hook satisfies ≥2 evidence requirement (verified by `synthesize.py`'s gate)
- [ ] Offers in hooks all resolve to `offer_catalog.json` IDs
- [ ] **Every MS contact is validated** against directory (`agent365-user-GetMultipleUsersDetails`) — render shows ✓ for resolved, ⚠ for unresolved
- [ ] Highlights = exactly 3 items with source attribution
- [ ] Customer Digest reads as flowing magazine prose (2-4 sentence paragraphs), NOT bullet checklists
- [ ] **Outlook draft has the full magazine HTML inline in the body** (~100KB) AND the same HTML attached — created via Outlook desktop COM (`win32com.client`), not `agent365-mail-UpdateDraft`
- [ ] Local copy saved to `outputs/digest_<YYYY-Www>.html` AND copied to `<WORK_BASE>` for browser access
- [ ] State cursors only advance on success; rerun same week does not advance
- [ ] Mode `fast` < 10 min for ~30 customers; `full-refresh` < 45 min

## References

| Document | When to load |
|---|---|
| `signal.py` | Adding a new source or modifying schema |
| `cockpit.py` | Changing dedup logic or cockpit context shape |
| `classify_chat.py` | Tuning chat classification heuristics |
| `score.py` | Tuning relevance thresholds |
| `templates/*.j2` | Visual changes |
| Sister skills: `customer-network`, `tpm-cockpit`, `account-agent`, `my-voice` | Always-on context |

## Post-Run Reflection

After completing a workflow, follow the [core § 5 Post-Run Reflection](../core/SKILL.md#5-post-run-reflection-continuous-improvement) protocol — capture what worked, source quality observations, and threshold tuning suggestions in `data/<run_id>/reflection.md`.

## 2026-05-05 — Numeric claim provenance gate (added after fact-check sweep)

Every numerical claim inside narrative_html (patterns: 'N mil/milhões', 'N usuários/colaboradores/desenvolvedores/alunos/funcionários/gestores') MUST be either:
- accompanied by an inline <a href> citation in the SAME sentence pointing to a public source (newsroom, IR release, reputable media), OR
- explicitly tagged '(estimativa interna)' OR '(intel cockpit)' so the reader knows it is not a public number.

Use audit_numbers.py as a pre-render gate, not an advisory. Build must fail if any unsourced numeric claim is found.

Rationale: hand-curated narrative_html is hostile to fact-checking and the URL validator does not catch fabricated numbers. Sweep on 2026-W18 found 5 fabricated/wrong claims across [CLIENTE], [CLIENTE], [CLIENTE]-PR, [CLIENTE], BB after [CLIENTE] was already fixed. See plan.md for full table.
