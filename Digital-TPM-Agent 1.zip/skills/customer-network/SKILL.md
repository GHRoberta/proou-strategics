---
name: customer-network
description: >
  Maps the user's customer network — TPM portfolio Top accounts, their MSX child
  accounts, related domains (whitelisted), Microsoft account team (AE/ATS/CSAM),
  and key external contacts mined from email. Produces an interactive HTML graph
  visualization (Customer_Network_FY26.html). Use this skill whenever the user
  asks to map their customer network, build a contact map, identify key
  customer/MS contacts per account, generate a portfolio visualization, see
  child accounts of their TPM customers, or asks for a "customer network",
  "rede de clientes", "mapa de contatos", "child accounts", "contatos chave",
  "account team da minha carteira". Triggers: customer network, contact map,
  rede de clientes, mapa de clientes, mapa de contatos, child accounts,
  contas filhas, top-childs, account team, AE ATS CSAM, contatos chave,
  portfolio visualization, customer network HTML.
---

# Customer Network Map

Build a visual map of the user's customer network: Top accounts → child accounts → related domains → Microsoft account team → key external contacts (mined from email). Output is an interactive HTML graph the user can share with their leadership.

## Prerequisites

- **Azure CLI** signed in as `@microsoft.com` (`az login`)
- **Corporate VPN** with full route to Power Platform (typically `GlobalProtect`; `MSFTVPN-Manual` is often blocked by Conditional Access on `microsoftsales.crm.dynamics.com`)
- **MSX-MCP** server (for child accounts + account team)
- **Dynamight** access (ESI Admin role) for portfolio + whitelisted domains
- **agent365 / WorkIQ** for email contact mining
- Output dir: cwd or `%WORK_BASE%`

## Pipeline

### 1. Extract TPM portfolio from Dynamight (`scripts/01_extract_dynamight.py`)

```
GET systemusers?$filter=domainname eq '{userUPN}'           → systemuserid
GET accounts?$filter=_esi_tpm_value eq {systemuserid}       → top accounts (name, TPID, accountid)
GET esi_whitelisteddomains?$filter=_esi_accountid_value eq {accountid} and statecode eq 0
                                                            → domains per account
```

Filter out `esi_isunsafedomain eq true`. Save to `customers.json`:
```json
[{ "name": "...", "tpid": "...", "accountid": "...", "territory": "...",
   "segment": "...", "domains": ["acme.com", "acme.com.br", ...] }]
```

### 2. Enrich with MSX (`scripts/02_enrich_msx.py`)

For each TPID:
- Query MSX dataverse: `accounts?$filter=msp_mstopparentid eq '{tpid}'` → child accounts
  - Select: `accountid, name, parentaccountid, industrycode, customersizecode`
- ⚠️ **Account team via Dataverse is BLOCKED**: `msp_accountteam` is a virtual entity
  (federated via `Microsoft.Xrm.DataProvider.Odata.V4.Plugins.ODataRetrieveMultiplePlugin`).
  All external `GET /msp_accountteams` requests return `0x80040224` ("Both header name
  and value should be specified"). The MSX UI uses an internal API that no documented
  header unblocks. **Workaround**: derive MS team from email/Teams via WorkIQ (see step 3b).
- ⚠️ **OData URL encoding**: `urllib.request` rejects raw spaces. Use a `_enc()` helper
  that does `urllib.parse.quote(qs, safe="=&$,:/'()*")`. Don't encode `(`, `)`, `'`.
- ⚠️ **Lookup-field filters**: use `_msp_accountid_value eq <guid>` — no quotes around GUID.

Save to `customers_msx.json` (extends customers.json):
```json
{ ...prev, "childs": [{ "name": "...", "tpid": "..." }] }
```

### 3. Mine customer email contacts (`scripts/03_scan_email_contacts.py`)

For each account, scan **last 12 months** of email for top contacts. Filters out
`@microsoft.com` (those are captured in step 3b).

**Strategy A — WorkIQ (semantic):**
```
ask_work_iq("Top 20 external contacts at {AccountName} I corresponded with by email
             in the last 12 months. Return name, email, message count.")
```
Best signal but 30-60s per call. Parallelize cautiously.

**Strategy B — Graph OData (deterministic):**
For each domain → `SearchMessagesQueryParameters('?$search="from:@{domain}"')`. Aggregate sender → count, name. Filter out internal Microsoft auto-mailers.

Save to `customers_contacts.json`:
```json
{ ...prev, "customer_contacts": [{ "name": "...", "email": "...", "count": 42,
                                   "last_email": "2026-04-15" }] }
```

### 3b. Mine MS team via WorkIQ (`scripts/03b_scan_ms_team.py`)

Workaround for blocked virtual entity. For each customer, ask WorkIQ for
`@microsoft.com` colleagues who interacted with the customer's domains in the
last 12 months. Classifies role via keyword regex (AE/ATS/CSAM/GBB/SSP/SE/TPM/PARTNER).

⚠️ **WorkIQ CLI quirks on Windows:**
- `subprocess.run(..., shell=True, timeout=N)` does NOT kill child `workiq.exe`. The
  PowerShell wrapper exits but the binary persists. Use `subprocess.Popen(...)` without
  `shell=True`, then on `TimeoutExpired`: `p.kill()` + `taskkill /F /IM workiq.exe /T`.
- WorkIQ response time is highly variable (15s ↔ 4min for the same prompt). Set
  timeout=90-120s and accept that "cold" customers will return 0 results.
- WorkIQ output contains ANSI escapes + OSC 8 hyperlinks — strip with regex.

Re-run with **expanded window** (12mo + subject-line match) to catch sparse customers.
Resume support: `customers_ms_team.json` is written incrementally; cached entries
(any `ms_team_scanned=true`) are passed through unchanged. To force re-scan a customer,
remove its TPID from the JSON (don't try to "drop empties" — empty results are valid
for cold customers and dropping them just makes the next pass re-ask and re-confirm 0).

⚠️ **Don't run multiple passes hoping for better results**. WorkIQ deterministically
returns 0 for customers with no email traffic in the indexed window. A 2nd pass with
broader prompts will: (a) waste 30+ min asking the same cold customers, (b) usually
also return 0, and (c) if killed mid-stream, can corrupt cached data. One clean pass
per pipeline refresh is the right cadence.

Save to `customers_ms_team.json`:
```json
{ ...prev, "ms_team": [{ "name": "...", "email": "...", "role": "AE",
                         "role_raw": "Sr Account Executive ..." }] }
```

### 4. Build HTML viz (`scripts/04_build_html.py`)

Render `templates/network.html` with the data injected as a JSON blob. Merges layers
from `customers.json` → `customers_msx.json` → `customers_contacts.json` → `customers_ms_team.json`. Uses **vis-network** (CDN) for force-directed graph:

- **Top account** → big node (color by segment: Strategic=red, Upper Majors=blue, Majors Growth=green, Public Sector=purple)
- **Child accounts** → orange medium nodes, edge to parent
- **MS team** (AE/ATS/CSAM/etc.) → orange diamonds, edge to top
- **Customer contacts** → cyan triangles, edge to top
- **Domains** → tag chips on the side panel (not nodes — too noisy)

Side panel: select node → show details (name, TPID, segment, full domain list, all contacts, last email date). Top filter bar: search by name, filter by segment/territory, layout toggle.

Save to `Customer_Network_FY26.html` in cwd. Standalone (CDN-loaded vis-network).

## Re-run Modes

- **Full refresh** (default): re-runs all 4 steps
- **Refresh emails only** (`--phase=3`): keeps Dynamight + MSX cache, re-mines contacts
- **Refresh MS team only** (`--phase=3b`): only re-runs WorkIQ MS-colleague mining
- **HTML only** (`--phase=4`): rebuilds HTML from existing JSONs (fast iteration on viz)

## Output Format

Single HTML file the user opens locally. Optional companion `customer_network.json` with the full dataset for downstream use.

## Error Handling

| Error | Cause | Recovery |
|-------|-------|----------|
| MSX 403 "IP address is blocked" | VPN not routing Power Platform (e.g. MSFTVPN-Manual) | Connect GlobalProtect; or run `--phase=2 --skip-msx` to continue without childs |
| MSX 400 `0x80040224` on `msp_accountteams` | Virtual entity blocked | Skip — use step 3b (WorkIQ) |
| MSX OData "URL can't contain control characters" | Raw spaces in query string | Use `_enc()` helper — `urllib.parse.quote(qs, safe="=&$,:/'()*")` |
| Dynamight 401 | Token expired | `az login` then re-run |
| Dynamight zero accounts | Wrong UPN or no TPM role | Verify `domainname` match |
| [CLIENTE]-style 200+ domains | Tenant with many subdomains | Cap at top 50 by name length asc, or page next link |
| WorkIQ slow (>60s/call) | Heavy mailbox or service degradation | Lower timeout to 90s, expect partial results, retry empties later |
| WorkIQ hangs forever (timeout doesn't kill) | `shell=True` on Windows orphans `workiq.exe` | Use `Popen` (no shell=True) + `taskkill /F /IM workiq.exe /T` after `kill()` |

## References

| Document | When to load |
|----------|-------------|
| `scripts/` | Implementation scripts |
| `templates/network.html` | HTML template (vis-network) |

## Post-Run Reflection

After completing a workflow, follow the [core § 5 Post-Run Reflection](../core/SKILL.md#5-post-run-reflection-continuous-improvement) protocol.
