"""Enrich customers_msx.json with MS team derived from msp_dealteams aggregation.

Strategy:
  1. For each top customer, collect [topAccountId] + all child accountids
  2. Query opportunities (open) where _parentaccountid_value is in that set
  3. Query msp_dealteams where _msp_parentopportunityid_value is in that opp set
  4. Aggregate dealteam users (count, opp names), resolve via systemusers
     to get internalemailaddress + jobtitle
  5. Classify role (AE/ATS/CSAM/GBB/SSP/...) by job title keywords
  6. Write files/customers_dealteam.json (parallel layer to customers_ms_team.json)

This is the deterministic MSX-side replacement for the (blocked) virtual entity
msp_accountteam. Combined later in 04_build_html.py with WorkIQ email-mined data.
"""
import json, subprocess, os, urllib.request, urllib.parse, time, sys
from pathlib import Path
from collections import defaultdict

BASE_OUT = Path(os.environ.get('CN_OUT_DIR',
    str(Path(os.environ['USERPROFILE']) / '.copilot' / 'session-state' /
        'd3c66b49-0c48-44f5-a39d-618500d51d95' / 'files')))

MSX = 'https://microsoftsales.crm.dynamics.com'
CHUNK = 40   # accountids per opp query (URL length safety)
OPP_CHUNK = 50  # opportunities per dealteam query

ROLE_KEYWORDS = {
    'AE':    ['account executive', 'enterprise account exec'],
    'ATS':   ['account technology strategist', 'technology strategist'],
    'CSAM':  ['customer success account', 'csam', 'success account manager'],
    'GBB':   ['global black belt', 'gbb'],
    'SSP':   ['solution specialist', 'specialist sales', 'ssp', 'solution sales'],
    'CSA':   ['cloud solution architect', 'csa', 'solution architect'],
    'TSP':   ['technical specialist', 'tsp'],
    'STU':   ['stu lead', 'stu manager'],
    'PSE':   ['pursuit lead', 'pursuit specialist'],
    'ATU':   ['atu lead', 'atu manager'],
}

def _enc(url):
    if '?' not in url: return url
    base, q = url.split('?', 1)
    return base + '?' + urllib.parse.quote(q, safe="=&$,:/'()*")

def az_token():
    r = subprocess.run(['az', 'account', 'get-access-token', '--resource', MSX,
                        '--query', 'accessToken', '-o', 'tsv'],
                       capture_output=True, text=True, shell=True)
    if r.returncode != 0:
        print(f"az failed: {r.stderr}", file=sys.stderr); sys.exit(1)
    return r.stdout.strip()

def odata(token, url, retry=2):
    for attempt in range(retry + 1):
        try:
            req = urllib.request.Request(_enc(url), headers={
                'Authorization': f'Bearer {token}',
                'Accept': 'application/json',
                'OData-MaxVersion': '4.0', 'OData-Version': '4.0',
                'Prefer': 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
            })
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read())
        except Exception as e:
            if attempt == retry: raise
            time.sleep(2 ** attempt)

def chunked(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i+n]

def or_filter(field, ids):
    return '(' + ' or '.join(f"{field} eq {x}" for x in ids) + ')'

def classify_role(title):
    if not title: return None
    t = title.lower()
    for role, kws in ROLE_KEYWORDS.items():
        if any(k in t for k in kws):
            return role
    return None

def fetch_opps(token, account_ids):
    opps = {}
    for batch in chunked(account_ids, CHUNK):
        flt = or_filter('_parentaccountid_value', batch) + ' and statecode eq 0'
        url = f"{MSX}/api/data/v9.2/opportunities?$select=opportunityid,name&$filter={flt}&$top=500"
        try:
            data = odata(token, url)
        except Exception as e:
            print(f"  ! opp batch failed ({len(batch)} accts): {e}", file=sys.stderr)
            continue
        for o in data.get('value', []):
            opps[o['opportunityid']] = o['name']
        # paging if any
        next_link = data.get('@odata.nextLink')
        while next_link:
            try:
                data = odata(token, next_link)
            except Exception: break
            for o in data.get('value', []):
                opps[o['opportunityid']] = o['name']
            next_link = data.get('@odata.nextLink')
    return opps

def fetch_dealteams(token, opp_ids):
    members = []  # list of {user_id, user_name, opp_id, is_owner}
    for batch in chunked(opp_ids, OPP_CHUNK):
        flt = or_filter('_msp_parentopportunityid_value', batch) + ' and statecode eq 0'
        url = (f"{MSX}/api/data/v9.2/msp_dealteams"
               f"?$select=msp_dealteamid,_msp_dealteamuserid_value,_msp_parentopportunityid_value,msp_isowner"
               f"&$filter={flt}&$top=1000")
        try:
            data = odata(token, url)
        except Exception as e:
            print(f"  ! dealteam batch failed ({len(batch)} opps): {e}", file=sys.stderr)
            continue
        for m in data.get('value', []):
            uid = m.get('_msp_dealteamuserid_value')
            if not uid: continue
            members.append({
                'user_id': uid,
                'user_name': m.get('_msp_dealteamuserid_value@OData.Community.Display.V1.FormattedValue') or '',
                'opp_id': m.get('_msp_parentopportunityid_value'),
                'is_owner': (m.get('msp_isowner@OData.Community.Display.V1.FormattedValue') == 'Active'),
            })
        next_link = data.get('@odata.nextLink')
        while next_link:
            try:
                data = odata(token, next_link)
            except Exception: break
            for m in data.get('value', []):
                uid = m.get('_msp_dealteamuserid_value')
                if not uid: continue
                members.append({
                    'user_id': uid,
                    'user_name': m.get('_msp_dealteamuserid_value@OData.Community.Display.V1.FormattedValue') or '',
                    'opp_id': m.get('_msp_parentopportunityid_value'),
                    'is_owner': (m.get('msp_isowner@OData.Community.Display.V1.FormattedValue') == 'Active'),
                })
            next_link = data.get('@odata.nextLink')
    return members

def fetch_users(token, user_ids):
    users = {}
    for batch in chunked(list(user_ids), CHUNK):
        flt = or_filter('systemuserid', batch)
        url = (f"{MSX}/api/data/v9.2/systemusers"
               f"?$select=systemuserid,fullname,internalemailaddress,jobtitle,title"
               f"&$filter={flt}&$top=500")
        try:
            data = odata(token, url)
        except Exception as e:
            print(f"  ! user batch failed: {e}", file=sys.stderr)
            continue
        for u in data.get('value', []):
            users[u['systemuserid']] = {
                'name': u.get('fullname') or '',
                'email': u.get('internalemailaddress') or '',
                'jobtitle': u.get('jobtitle') or u.get('title') or '',
            }
    return users

def aggregate(members, users):
    by_user = defaultdict(lambda: {'opp_ids': set(), 'is_owner': False})
    for m in members:
        u = by_user[m['user_id']]
        u['opp_ids'].add(m['opp_id'])
        if m['is_owner']: u['is_owner'] = True
    out = []
    for uid, agg in by_user.items():
        info = users.get(uid, {})
        name = info.get('name') or next(
            (m['user_name'] for m in members if m['user_id'] == uid), uid)
        email = info.get('email', '')
        title = info.get('jobtitle', '')
        out.append({
            'name': name, 'email': email, 'title': title,
            'role': classify_role(title),
            'opp_count': len(agg['opp_ids']),
            'is_owner': agg['is_owner'],
        })
    out.sort(key=lambda x: (-x['opp_count'], x['name']))
    return out

def main():
    src = BASE_OUT / 'customers_msx.json'
    out_path = BASE_OUT / 'customers_dealteam.json'
    customers = json.loads(src.read_text(encoding='utf-8'))
    token = az_token()
    if not token:
        print("No MSX token", file=sys.stderr); sys.exit(1)

    results = []
    for i, c in enumerate(customers, 1):
        name = c['name']; tpid = c.get('tpid', '')
        acct_ids = [c['accountid']] + [ch['accountid'] for ch in c.get('childs', [])]
        acct_ids = list(dict.fromkeys(acct_ids))  # dedup, preserve order
        print(f"[{i}/{len(customers)}] {name} (TPID={tpid}, {len(acct_ids)} accts)")

        opps = fetch_opps(token, acct_ids)
        print(f"   opps={len(opps)}")
        if not opps:
            results.append({**c, 'ms_team': [], 'dealteam_scanned': True,
                            'dealteam_opp_count': 0})
            continue

        members = fetch_dealteams(token, list(opps.keys()))
        user_ids = {m['user_id'] for m in members}
        print(f"   dealteam_rows={len(members)} unique_users={len(user_ids)}")

        users = fetch_users(token, user_ids) if user_ids else {}
        team = aggregate(members, users)
        print(f"   team={len(team)}")

        results.append({**c, 'ms_team': team, 'dealteam_scanned': True,
                        'dealteam_opp_count': len(opps)})
        # incremental save
        out_path.write_text(json.dumps(results + customers[i:], indent=2,
                                       ensure_ascii=False), encoding='utf-8')

    out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False),
                        encoding='utf-8')
    total_team = sum(1 for r in results if r['ms_team'])
    print(f"\n[done] wrote {out_path}: {len(results)} customers, {total_team} with team")

if __name__ == '__main__':
    main()
