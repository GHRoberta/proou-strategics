"""Enrich customers.json with MSX child accounts + account team.
Requires MSX MCP access (Power Platform reachable - VPN routing required).
Writes files/customers_msx.json.

NOTE: This script uses az CLI direct OData against MSX Dataverse
(microsoftsales.crm.dynamics.com). Same pattern as Dynamight but different host.
"""
import json, subprocess, sys, os, urllib.request, urllib.parse
from pathlib import Path

def _enc(url):
    """URL-encode the query string of an OData URL (safe-encode spaces, quotes, parens)."""
    if '?' not in url: return url
    base, q = url.split('?', 1)
    return base + '?' + urllib.parse.quote(q, safe="=&$,:/'()*")

BASE_OUT = Path(os.environ.get('CN_OUT_DIR',
    str(Path(os.environ['USERPROFILE']) / '.copilot' / 'session-state' /
        'd3c66b49-0c48-44f5-a39d-618500d51d95' / 'files')))

def az_token(resource):
    r = subprocess.run(['az', 'account', 'get-access-token', '--resource', resource,
                        '--query', 'accessToken', '-o', 'tsv'],
                       capture_output=True, text=True, shell=True)
    return r.stdout.strip()

def odata(token, url):
    url = _enc(url)
    req = urllib.request.Request(url, headers={
        'Authorization': f'Bearer {token}',
        'Accept': 'application/json',
        'OData-MaxVersion': '4.0', 'OData-Version': '4.0',
        'Prefer': 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
    })
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

ROLE_KEYWORDS = {
    'AE':   ['account executive', 'enterprise account exec'],
    'ATS':  ['account technology strategist', 'ats'],
    'CSAM': ['customer success account manager', 'csam'],
    'GBB':  ['global black belt', 'gbb'],
    'SSP':  ['solution specialist', 'ssp', 'specialist seller'],
    'SE':   ['solution engineer', 'cloud solution architect', 'csa'],
}
def classify_role(role_text):
    if not role_text: return 'Other'
    rt = role_text.lower()
    for k, kws in ROLE_KEYWORDS.items():
        if any(kw in rt for kw in kws): return k
    return 'Other'

def main():
    src = BASE_OUT / 'customers.json'
    out = BASE_OUT / 'customers_msx.json'
    customers = json.loads(src.read_text(encoding='utf-8'))
    token = az_token('https://microsoftsales.crm.dynamics.com/')
    if not token:
        print('No MSX token', file=sys.stderr); sys.exit(1)
    base = 'https://microsoftsales.crm.dynamics.com/api/data/v9.2'

    # Resume support
    done = {}
    if out.exists():
        try:
            for c in json.loads(out.read_text(encoding='utf-8')):
                if c.get('msx_enriched'): done[c['tpid']] = c
        except Exception: pass

    results = []
    for i, c in enumerate(customers, 1):
        tpid = c.get('tpid')
        if not tpid:
            print(f"  [{i}] SKIP {c['name']} - no TPID"); results.append(c); continue
        if tpid in done:
            print(f"  [{i}] CACHED {c['name']}"); results.append(done[tpid]); continue
        c2 = dict(c)
        try:
            # Child accounts: anything with msp_mstopparentid = tpid (but not the top itself)
            childs = odata(token, f"{base}/accounts?$filter=msp_mstopparentid eq '{tpid}'"
                                  " and statecode eq 0"
                                  "&$select=accountid,name,parentaccountid,industrycode,customersizecode&$top=200")
            c2['childs'] = [{'accountid': x['accountid'], 'name': x['name'],
                             'industry': x.get('industrycode@OData.Community.Display.V1.FormattedValue'),
                             'size': x.get('customersizecode@OData.Community.Display.V1.FormattedValue')}
                            for x in childs['value'] if x['name'] != c['name']]
        except Exception as e:
            print(f"  err childs {c['name']}: {e}"); c2['childs'] = []
        try:
            # Account team via msp_accountteams (custom MSX entity)
            team = odata(token, f"{base}/msp_accountteams?$filter=_msp_accountid_value eq {c['accountid']}"
                                "&$select=msp_fullname,msp_rolename,msp_roletype,msp_solutionarea,msp_title,_msp_systemuserid_value"
                                "&$expand=msp_systemuserid($select=fullname,internalemailaddress,jobtitle)&$top=200")
            c2['ms_team'] = []
            for m in team['value']:
                u = m.get('msp_systemuserid') or {}
                role_name = m.get('msp_rolename') or m.get('msp_roletype@OData.Community.Display.V1.FormattedValue') or ''
                jobtitle = u.get('jobtitle') or m.get('msp_title') or ''
                c2['ms_team'].append({
                    'name': m.get('msp_fullname') or u.get('fullname',''),
                    'email': u.get('internalemailaddress',''),
                    'jobtitle': jobtitle,
                    'solution_area': m.get('msp_solutionarea@OData.Community.Display.V1.FormattedValue',''),
                    'role_raw': role_name,
                    'role': classify_role(role_name or jobtitle)
                })
        except Exception as e:
            print(f"  err team {c['name']}: {e}"); c2['ms_team'] = []
        c2['msx_enriched'] = True
        print(f"  [{i}] {c['name'][:40]:40s} childs={len(c2['childs']):3d} team={len(c2['ms_team']):3d}")
        results.append(c2)
        out.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f"\nSaved -> {out}")

if __name__ == '__main__':
    main()
