"""Scan MS team (Microsoft colleagues) per customer using WorkIQ CLI.
Reads files/customers.json, writes files/customers_ms_team.json incrementally.
Asks WorkIQ for @microsoft.com people with whom I've collaborated about each account.
"""
import json, subprocess, sys, time, re, os, shutil
from pathlib import Path

WORKIQ = shutil.which('workiq') or 'workiq'
ANSI_RE = re.compile(r'\x1b\[[0-9;]*[A-Za-z]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x07')

BASE = Path(os.environ['USERPROFILE']) / '.copilot' / 'session-state' / 'd3c66b49-0c48-44f5-a39d-618500d51d95' / 'files'
SRC = BASE / 'customers.json'
OUT = BASE / 'customers_ms_team.json'
LOG = BASE / 'ms_team_scan.log'

ROLE_KEYWORDS = {
    'AE':   ['account executive', 'enterprise account exec', 'global account'],
    'ATS':  ['account technology strategist', 'technology strategist'],
    'CSAM': ['customer success account manager', 'csam'],
    'GBB':  ['global black belt'],
    'SSP':  ['solution specialist', 'specialist seller', 'ssp'],
    'SE':   ['solution engineer', 'cloud solution architect', 'csa'],
    'TPM':  ['technical program manager', 'tpm', 'training program manager'],
    'PARTNER': ['partner'],
}
def classify_role(text):
    if not text: return 'Other'
    t = text.lower()
    for k, kws in ROLE_KEYWORDS.items():
        if any(kw in t for kw in kws): return k
    return 'Other'

def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    try: print(line, flush=True)
    except UnicodeEncodeError: print(line.encode('ascii','replace').decode('ascii'), flush=True)
    with open(LOG, 'a', encoding='utf-8') as f: f.write(line + "\n")

def workiq_ask(question, timeout=90):
    try:
        p = subprocess.Popen([WORKIQ, 'ask', '-q', question],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, encoding='utf-8', errors='replace')
        try:
            out, err = p.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill()
            try: p.communicate(timeout=5)
            except Exception: pass
            # Hard-kill any orphan workiq.exe
            try:
                subprocess.run(['taskkill', '/F', '/IM', 'workiq.exe', '/T'],
                               capture_output=True, timeout=10)
            except Exception: pass
            return "ERROR: timeout"
        if p.returncode != 0:
            return f"ERROR rc={p.returncode}: {(err or '')[:300]}"
        clean = ANSI_RE.sub('', out or '')
        clean = re.sub(r'\]8;;[^\\]*\\', '', clean)
        return clean
    except Exception as e:
        return f"ERROR: {e}"

def parse_team(text):
    """Extract Microsoft people (name, email, role/title) from WorkIQ markdown table."""
    people = []
    seen = set()
    for line in text.splitlines():
        if '|' not in line: continue
        cells = [c.strip() for c in line.split('|') if c.strip()]
        if len(cells) < 2: continue
        email_cell = next((c for c in cells if '@microsoft.com' in c.lower()), None)
        if not email_cell: continue
        m = re.search(r'([\w\.\-\+]+@microsoft\.com)', email_cell, re.I)
        if not m: continue
        email = m.group(1).lower()
        if email in seen: continue
        name = cells[0] if cells[0] != email_cell else ''
        name = re.sub(r'\[\d+\]', '', name).strip()
        if name.lower() in ('name','contact','person','---'): continue
        # Role/title: look in remaining cells (not name, not email)
        role_text = ''
        for c in cells:
            if c == name or c == email_cell: continue
            if re.match(r'^~?\s*\d+\s*$', c): continue  # skip pure counts
            role_text = c; break
        seen.add(email)
        people.append({
            'name': name,
            'email': email,
            'role_raw': role_text,
            'role': classify_role(role_text)
        })
    return people[:25]

def main():
    customers = json.loads(SRC.read_text(encoding='utf-8'))
    done = {}
    if OUT.exists():
        try:
            for c in json.loads(OUT.read_text(encoding='utf-8')):
                if c.get('ms_team_scanned'):
                    done[c['tpid']] = c
        except Exception: pass
    log(f"Starting MS team scan: {len(customers)} customers, {len(done)} cached")
    results = []
    for i, c in enumerate(customers, 1):
        cached = done.get(c['tpid'])
        if cached:
            log(f"  [{i}/{len(customers)}] SKIP {c['name']} (cached, team={len(cached.get('ms_team') or [])})")
            results.append(cached); continue
        domains = c.get('domains', [])[:3]
        domain_hint = ', '.join(domains) if domains else c['name']
        q = (f"Microsoft people I emailed about {c['name'][:50]} last 12 months. "
             f"Markdown table: Name | Email | Title. Max 15. No prose.")
        log(f"  [{i}/{len(customers)}] Asking for MS team of {c['name'][:50]}...")
        t0 = time.time()
        raw = workiq_ask(q)
        people = parse_team(raw)
        # safety: drop self
        people = [p for p in people if p['email'] != '{{EMAIL}}']
        elapsed = time.time() - t0
        log(f"     -> {len(people)} MS people in {elapsed:.0f}s")
        c2 = dict(c)
        c2['ms_team'] = people
        c2['ms_team_scanned'] = True
        c2['ms_team_raw'] = raw[:8000]
        results.append(c2)
        OUT.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding='utf-8')
    log(f"DONE: wrote {OUT}")

if __name__ == '__main__':
    main()
