"""Extract TPM portfolio from Dynamight (ESI Admin Dataverse).
Pulls user's TPM accounts + whitelisted domains. Writes files/customers.json.
"""
import json, subprocess, sys, os
from pathlib import Path

USER_UPN = os.environ.get('CN_USER_UPN', '{{EMAIL}}')
BASE_OUT = Path(os.environ.get('CN_OUT_DIR',
    str(Path(os.environ['USERPROFILE']) / '.copilot' / 'session-state' /
        'd3c66b49-0c48-44f5-a39d-618500d51d95' / 'files')))
BASE_OUT.mkdir(parents=True, exist_ok=True)

def az_token(resource):
    r = subprocess.run(['az', 'account', 'get-access-token', '--resource', resource,
                        '--query', 'accessToken', '-o', 'tsv'],
                       capture_output=True, text=True, shell=True)
    return r.stdout.strip()

def odata(token, url):
    import urllib.request, urllib.parse
    req = urllib.request.Request(url, headers={
        'Authorization': f'Bearer {token}',
        'Accept': 'application/json',
        'OData-MaxVersion': '4.0', 'OData-Version': '4.0',
        'Prefer': 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'
    })
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

def main():
    token = az_token('https://esiadmin.crm.dynamics.com/')
    if not token:
        print('Failed to get Dynamight token. Run: az login', file=sys.stderr); sys.exit(1)
    base = 'https://esiadmin.crm.dynamics.com/api/data/v9.2'
    me = odata(token, f"{base}/systemusers?$filter=domainname eq '{USER_UPN}'&$select=systemuserid,fullname")
    if not me['value']:
        print(f'User {USER_UPN} not found in Dynamight', file=sys.stderr); sys.exit(1)
    me_id = me['value'][0]['systemuserid']
    print(f"Resolved {me['value'][0]['fullname']} -> {me_id}")
    accts = odata(token, f"{base}/accounts?$filter=_esi_tpm_value eq {me_id}"
                         "&$select=name,accountid,esi_tpid,esi_territory,esi_segment&$top=500")
    print(f"TPM accounts: {len(accts['value'])}")
    out = []
    for a in accts['value']:
        aid = a['accountid']
        try:
            doms = odata(token, f"{base}/esi_whitelisteddomains?$filter=_esi_accountid_value eq {aid}"
                                " and statecode eq 0&$select=esi_domain,esi_isunsafedomain&$top=200")
            d = sorted(set(x['esi_domain'].lower() for x in doms['value']
                           if x.get('esi_domain') and not x.get('esi_isunsafedomain')))
        except Exception as e:
            print(f"  err {a['name']}: {e}"); d = []
        out.append({
            'name': a['name'], 'tpid': a.get('esi_tpid'), 'accountid': aid,
            'territory': a.get('esi_territory'), 'segment': a.get('esi_segment'),
            'domains': d
        })
        print(f"  {a['name'][:50]:50s} {a.get('esi_tpid','-'):10s} {len(d)} doms")
    (BASE_OUT / 'customers.json').write_text(
        json.dumps(out, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f"\nSaved -> {BASE_OUT/'customers.json'}")

if __name__ == '__main__':
    main()
