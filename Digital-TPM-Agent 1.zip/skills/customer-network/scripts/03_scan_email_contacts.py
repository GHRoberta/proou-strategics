"""Scan email contacts per TPM customer using WorkIQ CLI.
Reads files/customers.json, writes files/customers_contacts.json incrementally.
"""
import json, subprocess, sys, time, re, os, shutil
from pathlib import Path

WORKIQ = shutil.which('workiq') or 'workiq'

# ANSI code stripper: CSI sequences (colors), OSC 8 hyperlinks, BEL, etc.
ANSI_RE = re.compile(r'\x1b\[[0-9;]*[A-Za-z]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x07')

BASE = Path(os.environ['USERPROFILE']) / '.copilot' / 'session-state' / 'd3c66b49-0c48-44f5-a39d-618500d51d95' / 'files'
SRC = BASE / 'customers.json'
OUT = BASE / 'customers_contacts.json'
LOG = BASE / 'email_scan.log'

def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    try:
        print(line, flush=True)
    except UnicodeEncodeError:
        print(line.encode('ascii', 'replace').decode('ascii'), flush=True)
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(line + "\n")

def workiq_ask(question, timeout=180):
    try:
        r = subprocess.run(
            [WORKIQ, 'ask', '-q', question],
            capture_output=True, text=True, timeout=timeout,
            encoding='utf-8', errors='replace', shell=True
        )
        if r.returncode != 0:
            return f"ERROR rc={r.returncode}: {r.stderr[:300]}"
        # Strip ANSI codes
        clean = ANSI_RE.sub('', r.stdout or '')
        # Also strip remaining OSC 8 hyperlink markup that may persist
        clean = re.sub(r'\]8;;[^\\]*\\', '', clean)
        return clean
    except Exception as e:
        return f"ERROR: {e}"

def parse_contacts(text):
    """Extract name+email pairs from WorkIQ response markdown table."""
    contacts = []
    seen = set()
    # Pattern A: markdown table rows  | Name | email | count |
    for line in text.splitlines():
        if '|' not in line: continue
        cells = [c.strip() for c in line.split('|') if c.strip()]
        if len(cells) < 2: continue
        # Find the cell with @
        email_cell = next((c for c in cells if '@' in c), None)
        if not email_cell: continue
        m = re.search(r'([\w\.\-\+]+@[\w\.\-]+\.\w+)', email_cell)
        if not m: continue
        email = m.group(1).lower()
        if email in seen: continue
        # Name is usually the first cell (or one before email cell)
        name = cells[0] if cells[0] != email_cell else ''
        # Strip trailing markdown ref e.g. "Name [1]" or "Name (5)"
        name = re.sub(r'\[\d+\]', '', name).strip()
        if name.lower() in ('name', 'contact', 'person', '---'): continue
        # Count: look for ~N or just digits in any cell
        cnt = 0
        for c in cells:
            cm = re.search(r'~?\s*(\d{1,4})', c)
            if cm and c != name:
                cnt = int(cm.group(1)); break
        seen.add(email)
        contacts.append({'name': name, 'email': email, 'count': cnt})
    # Pattern B fallback: "Name <email>"
    if not contacts:
        for m in re.finditer(r'([A-Z][\w\sÀ-ÿ\.\-\']{2,50}?)\s*[<\(\|]\s*([\w\.\-\+]+@[\w\.\-]+\.\w+)', text):
            email = m.group(2).lower()
            if email in seen: continue
            seen.add(email)
            contacts.append({'name': m.group(1).strip(), 'email': email, 'count': 0})
    return contacts[:20]

def main():
    customers = json.loads(SRC.read_text(encoding='utf-8'))
    # Resume support: if OUT exists, skip already-processed accounts
    done = {}
    if OUT.exists():
        try:
            existing = json.loads(OUT.read_text(encoding='utf-8'))
            for c in existing:
                # Only skip if scan was successful (got contacts). Re-try empties.
                if c.get('contacts_scanned') and (c.get('customer_contacts') or []):
                    done[c['tpid']] = c
        except Exception:
            pass
    log(f"Starting scan: {len(customers)} customers, {len(done)} already done")
    results = []
    for i, c in enumerate(customers, 1):
        if c['tpid'] in done:
            log(f"  [{i}/{len(customers)}] SKIP {c['name']} (cached)")
            results.append(done[c['tpid']])
            continue
        domains = c.get('domains', [])[:3]
        domain_hint = ', '.join(domains) if domains else c['name']
        q = (f"List external people I have exchanged emails with in the last 12 months "
             f"whose email domain is one of: {domain_hint}. "
             f"For each person, give their display name and email. "
             f"Approximate message counts are welcome but optional. "
             f"Format the answer as a simple markdown table with columns Name | Email | Count "
             f"(use ~ or 'n/a' if count unknown). "
             f"Just give what you can find — partial results are fine. "
             f"Skip @microsoft.com addresses. No need for citations or prose.")
        log(f"  [{i}/{len(customers)}] Asking WorkIQ for {c['name']}...")
        t0 = time.time()
        raw = workiq_ask(q)
        elapsed = time.time() - t0
        contacts = parse_contacts(raw)
        # Filter out @microsoft.com
        contacts = [x for x in contacts if not x['email'].endswith('@microsoft.com')]
        log(f"     -> {len(contacts)} contacts in {elapsed:.0f}s")
        c2 = dict(c)
        c2['customer_contacts'] = contacts
        c2['contacts_scanned'] = True
        c2['scan_raw'] = raw[:8000]
        results.append(c2)
        # Persist incrementally
        OUT.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding='utf-8')
    log(f"DONE: wrote {OUT}")

if __name__ == '__main__':
    main()
