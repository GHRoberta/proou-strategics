"""Build Customer_Network_FY26.html from JSONs in files/.
Picks best available source: customers_contacts.json > customers_msx.json > customers.json.
Embeds data as JSON in the HTML template.
"""
import json, os, sys, datetime
from pathlib import Path

BASE_OUT = Path(os.environ.get('CN_OUT_DIR',
    str(Path(os.environ['USERPROFILE']) / '.copilot' / 'session-state' /
        'd3c66b49-0c48-44f5-a39d-618500d51d95' / 'files')))
SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_DIR / 'templates' / 'network.html'

OUT_HTML = Path(os.environ.get('CN_HTML_OUT',
    str(Path.cwd() / 'Customer_Network_FY26.html')))

def load_best(*names):
    for n in names:
        p = BASE_OUT / n
        if p.exists():
            return json.loads(p.read_text(encoding='utf-8')), n
    raise FileNotFoundError(f'None of {names} found in {BASE_OUT}')

def _norm_name(s):
    return ''.join(ch.lower() for ch in (s or '') if ch.isalnum())

def merge_team(primary, supplemental):
    """Merge two ms_team lists. Primary entries kept; supplemental ones added
    only if not already present (by email or normalized name)."""
    seen_emails = {(p.get('email') or '').lower() for p in primary if p.get('email')}
    seen_names  = {_norm_name(p.get('name')) for p in primary if p.get('name')}
    out = list(primary)
    for s in (supplemental or []):
        em = (s.get('email') or '').lower()
        nm = _norm_name(s.get('name'))
        if em and em in seen_emails: continue
        if nm and nm in seen_names:  continue
        s2 = dict(s); s2['source'] = s2.get('source') or 'workiq'
        out.append(s2)
        if em: seen_emails.add(em)
        if nm: seen_names.add(nm)
    return out

def merge(base, *layers):
    """Merge layered enrichment by tpid (latest non-empty wins per field)."""
    by_tpid = {c.get('tpid'): dict(c) for c in base}
    for layer in layers:
        for c in layer:
            t = c.get('tpid')
            if t and t in by_tpid:
                by_tpid[t].update({k:v for k,v in c.items() if v not in (None,'',[],{})})
    return list(by_tpid.values())

def main():
    src = json.loads((BASE_OUT/'customers.json').read_text(encoding='utf-8'))
    layers = []
    # Order: msx childs/domains -> customer contacts -> dealteam (primary MS team) -> workiq team (supplemental)
    for n in ('customers_msx.json', 'customers_contacts.json',
              'customers_dealteam.json', 'customers_ms_team.json'):
        p = BASE_OUT / n
        if p.exists():
            layers.append((n, json.loads(p.read_text(encoding='utf-8'))))
            print(f'  + {n}')
        else:
            print(f'  - {n} (not found)')

    # Build base from all layers except the two team sources
    non_team_layers = [d for n, d in layers if n not in (
        'customers_dealteam.json', 'customers_ms_team.json')]
    customers = merge(src, *non_team_layers)

    # Now overlay ms_team: dealteam first (primary), then merge workiq (supplemental)
    dealteam_by_tpid = {c.get('tpid'): c for n, d in layers
                        if n == 'customers_dealteam.json' for c in d}
    workiq_by_tpid = {c.get('tpid'): c for n, d in layers
                      if n == 'customers_ms_team.json' for c in d}
    for c in customers:
        t = c.get('tpid')
        primary = (dealteam_by_tpid.get(t) or {}).get('ms_team') or []
        supplemental = (workiq_by_tpid.get(t) or {}).get('ms_team') or []
        # tag source on primary entries
        primary = [{**p, 'source': p.get('source') or 'msx_dealteam'} for p in primary]
        c['ms_team'] = merge_team(primary, supplemental)
    # Sort by segment then name
    customers.sort(key=lambda c: (c.get('segment') or '', c.get('name') or ''))

    payload = {
        'generated_at': datetime.datetime.now().isoformat(timespec='seconds'),
        'customers': customers,
        'stats': {
            'accounts': len(customers),
            'with_team': sum(1 for c in customers if c.get('ms_team')),
            'with_childs': sum(1 for c in customers if c.get('childs')),
            'with_contacts': sum(1 for c in customers if c.get('customer_contacts')),
            'total_domains': sum(len(c.get('domains') or []) for c in customers),
            'total_contacts': sum(len(c.get('customer_contacts') or []) for c in customers),
        }
    }
    title = f"Customer Network — {{USER_NAME}} · FY26 ({payload['stats']['accounts']} contas, {payload['stats']['total_contacts']} contatos)"
    html = TEMPLATE.read_text(encoding='utf-8')
    html = html.replace('__TITLE__', title)
    html = html.replace('__DATA__', json.dumps(payload, ensure_ascii=False))
    OUT_HTML.write_text(html, encoding='utf-8')
    print(f'\nStats: {payload["stats"]}')
    print(f'\nSaved -> {OUT_HTML}')

if __name__ == '__main__':
    main()
