---
name: workiq-patterns
description: Patterns for querying WorkIQ (Microsoft 365 data) effectively. Load this skill when querying emails, Teams chats, calendar, meeting transcripts, or SharePoint documents via WorkIQ MCP or CLI.
---

# WorkIQ Query Patterns

## Two Access Modes

### MCP Server (preferred in interactive sessions)
Use the `ask_work_iq` tool directly. Returns structured responses. No parsing needed.

### CLI (for automation scripts only)
```powershell
$result = & workiq ask -q "your question"
```
- Always use `-q` flag (not positional args)
- Returns markdown prose -- parse with `Remove-Markdown` and `Test-IsBoilerplate`
- Takes 30-60 seconds per query
- `workiq ask` (no -q) enters REPL mode for multi-turn follow-ups

## 7 Data Sources Available
1. **Emails** (Mail.Read) -- sender, subject, body, attachments
2. **Calendar** -- meetings, attendees, times, locations
3. **Meeting Transcripts** (OnlineMeetingTranscript.Read.All) -- actual spoken content from Teams meetings
4. **Teams Chats** (Chat.Read) -- 1:1 and group chat messages
5. **Teams Channels** (ChannelMessage.Read.All) -- channel posts (separate from chats)
6. **SharePoint/OneDrive** (Sites.Read.All) -- documents and files
7. **People Directory** (People.Read.All) -- contact information

## Effective Query Patterns

### Account-Scoped Queries
Always include the account name to scope results:
- "Show me emails from the past 7 days related to **{AccountName}**"
- "Show me Teams chat messages from today in any chat with **{AccountShort}** in the title"

### Time-Scoped Queries
Be explicit about time ranges:
- "from today" / "from this week" / "from the past 30 days"
- "from January 2026" (for historical)

### Meeting Transcripts (high value, underused)
- "Show me transcripts from Teams meetings in the past 7 days that involved {AccountName} contacts"
- Ask for: speaker names, key discussion points, decisions made, action items mentioned

### Cross-Source Queries
Query each source separately for best results (combined queries return less detail):
1. Teams chats first (fastest signal)
2. Emails second (formal communication)
3. Calendar third (upcoming engagement)
4. Transcripts fourth (deepest content)

## Auth Notes
- Auth: MSAL + WAM (Windows Account Manager) -- silent SSO
- Refresh tokens: 90-day sliding window
- `Start-Job` loses auth -- always query inline
- EULA accepted once: `workiq accept-eula`

## Related Skills
- **teams-search**: Detailed patterns for searching Teams chats/channels via WorkIQ CLI (FlightDeck). Load that skill for Teams-specific search workflows, digest scanning, and troubleshooting Graph API CA blocks.
- **teams-chat**: For *sending* Teams messages (uses Graph API, not WorkIQ).
