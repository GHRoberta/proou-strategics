---
name: account-ops
description: Standard patterns for Work Hub account operations. Load this skill when working on account folders, dashboards, automation scripts, or scaling operations to new accounts.
---

# Account Operations Patterns

## Architecture: Shared Scripts + Per-Account Config

All agent scripts live in `scripts\agent_scripts\` (single codebase). Each account has thin launcher scripts and an `account_config.json` with account-specific values.

### Shared scripts (scripts\agent_scripts\)
```
agent_common.ps1        -- Config loader, shared helpers (dot-sourced by all scripts)
tactical_pulse.ps1      -- Morning/afternoon signal collection
strategic_sweep.ps1     -- Weekly deep analysis + Sunday Reader
meeting_prep.ps1        -- Pre-meeting briefing
post_to_teams.ps1       -- Teams channel posting (webhook)
setup_scheduler.ps1     -- Task Scheduler registration
```

### Per-account folder (accounts\<Account>\)
```
account_brief.md         -- Synthesized intelligence (read first for any account work)
account_profile.html     -- Visual profile card (static, from CRM data)
account_details_raw.txt  -- Raw CRM/commercial export
dashboard.html           -- Live mission control
strategic_motions.html   -- Strategic playbook
briefings\               -- Generated meeting prep briefings
agent\
  account_config.json    -- Account-specific config (name, domain, webhook, OneNote IDs)
  run_pulse_now.ps1      -- Thin launcher -> shared tactical_pulse.ps1
  run_sweep_now.ps1      -- Thin launcher -> shared strategic_sweep.ps1
  run_meeting_prep.ps1   -- Thin launcher -> shared meeting_prep.ps1
  run_setup_scheduler.ps1-- Thin launcher -> shared setup_scheduler.ps1
  post_custom.ps1        -- Thin launcher -> shared post_to_teams.ps1
  agent_state.json       -- Runtime state (auto-generated)
  pulse_log.txt          -- Logs (auto-generated)
  research\              -- Raw WorkIQ query dumps
```

### account_config.json required fields
- `account_name` (full name), `account_short` (for queries), `domain`
- `webhook_url` (Power Automate Workflow URL, empty OK)
- `onenote_section_ids.external`, `.internal` (empty OK -- skips OneNote)
- `scheduler_prefix`, `contacts_domain_patterns`, `stock_ticker`

## Data Source Priority (for any account question)
1. `account_brief.md` -- always start here
2. WorkIQ (emails, Teams, calendar, transcripts) -- current state
3. SQLite DB (`workhub.db`) -- historical trends and portfolio view
4. SharePoint files -- shared documents
5. OneNote -- meeting notes (via Copilot Search or COM API)

## Key Operations

### Morning Pulse
Runs via Task Scheduler. Queries WorkIQ for today's signals, classifies relevance, updates dashboard, writes to DB, posts actionable items to Teams.

### Strategic Sweep
Runs weekly (Friday). Deep analysis: all sources, OneNote maintenance, Sunday Reader HTML generation, full DB update.

### Scaling to New Accounts
1. Create folder structure: `accounts\<Account>\agent\` and `briefings\`
2. Create `account_config.json` with account-specific values
3. Copy launcher scripts from any existing account (identical -- paths are dynamic)
4. Create `dashboard.html` (copy template, clear data, set account name)
5. Create `strategic_motions.html` (empty template)
6. Create `account_brief.md` from WorkIQ research
7. Create Power Automate Workflow for Teams channel, add webhook URL to config
8. Look up OneNote section IDs via COM API, add to config
9. Run `run_setup_scheduler.ps1` to register tasks
10. Run `run_pulse_now.ps1` to populate first data

## Dashboard Design
- Self-contained HTML (inline CSS, no external deps)
- CSS design system: card-based, Segoe UI, color-coded badges
- Variables: --bg, --accent, --green, --amber, --red, --purple, --teal
- No emojis in body text; OK in h2 section headers only

## Database Queries (via Python bridge)
```powershell
python "scripts\db_ops.py" query-portfolio          # Cross-account health
python "scripts\db_ops.py" query-signals "Account" 7  # Last 7 days
python "scripts\db_ops.py" query-open-actions        # All open action items
python "scripts\db_ops.py" query-contacts "Account"  # Contact frequency
```
