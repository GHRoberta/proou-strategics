Below is an **exhaustive extraction of every piece of text content** available in the PowerPoint you uploaded: [FY26 Scale Deliveries Guidance.pptx](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true&EntityRepresentationId=cf114a49-3b9f-466f-acc3-63696d904d88). I preserved **all numbers, dates, rates, class sizes, limits, thresholds, eligibility rules, planning/agenda guidance, SWM rules, moderator rules, and links** exactly as they appear in the deck. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)

---

# [FY26 Scale Deliveries Guidance.pptx](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true&EntityRepresentationId=cf114a49-3b9f-466f-acc3-63696d904d88) — Full content extraction (all slides) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)

## File-level / master text present in deck (appears before Slide 1 in extraction)
- **FY26 Scale Deliveries Guidance** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Click to edit Master title style [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Click to edit Master text styles [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Second level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Third level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Fourth level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Fifth level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Click to edit Master title style [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Click to edit Master title style [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Click to edit Master title style [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Click to edit Master text styles [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Second level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Third level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Fourth level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Fifth level [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_1>
### Courses at scale: Guidance
Organizational Skilling Catalog  
H2 scale course expansion  
INTERNAL ONY  
March 3, 2026  
Microsoft confidential  
4/22/2026 9:32 AM© Microsoft Corporation. All rights reserved. MICROSOFT MAKES NO WARRANTIES, EXPRESS, IMPLIED OR STATUTORY, AS TO THE INFORMATION IN THIS PRESENTATION. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)

---

## <slide_2>
### Courses eligible for scale deliveries
- What to know… [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- H2 Catalog shift to frontier firm skilling include added scale options [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Limited number of courses are now available to request at higher volumes in a shortened scale format without SWR approval [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TPMS: Build in extra time for proper planning with your customer, TSP or MTT [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Guidance for choosing traditional versus scale formats should be considered [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Work with your TPC to ensure proper credit and delivery planning [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale deliveries utilize current content, without labs and reduced breaks. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft confidential [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

Also present on the slide:
- “- Title” [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_3>
### Scale delivery guidance
- Standard course sizes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Courses at scale [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Standard size courses are best when:**
- Individuals, teams or targeted base of learners [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- MTT consultative experience is preferred [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Hands-on learning is desired [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Interaction and asking questions is key for more technical content or advanced learners [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Scale size courses are best when:**
- Very large base of learners [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Customer is educated about a less interactive learning event [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Labs, MTT interaction and experiential learning are not key to outcomes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Customer already has topic champions or established base of knowledge [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Work with your customer, MTT or TSP to plan and set expectations for your scale delivery! [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft confidential [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

Also present on the slide:
- “- Title” [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_4>
### Table: Eligible courses / BYOL / PDc & TSPc deliveries / Scale guidance / Scale delivery options

**Header columns (exact text):**
1) Eligible courses [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
2) BYOL needed [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
3) PDc Delivery  
   - PDc (link present)  
   - rate card (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
4) TSPc Delivery  
   - TSPc rate card (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
5) Scale content guidance [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
6) SCALE: PDc Delivery  
   - PDc (link present)  
   - rate card (link present)  
   - **NO LABs** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
7) SCALE: TSPc Delivery  
   - TSPc rate card (link present)  
   - **NO LABs / Add moderator for 50+** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: AI-3025**
- Eligible course: **AI-3025** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: (blank) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - AI-3025 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .5 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-40 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - With labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Minimum of 2 sessions [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery: Not applicable [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance: No changes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery: Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - AI-3025 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4004.x**
- Eligible course: **MS-4004.x** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: _M365 License_ [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - MS-4004.1 through MS.4004.10 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 45 min modules [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .25/Module [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - VILT Class size: 5-40 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Min 4 / max 6 per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - MS-4004.1 through MS.4004.10 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance: No changes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Option: CEUTS [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - MS-4004.1 through MS.4004.10 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 45 min modules [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Max size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4018**
- Eligible course: **MS-4018** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: _M365 License_ [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - MS-4018 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-40 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - With labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - MS-4018 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - With labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - Select 3-5 modules [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - No labs/exercises in any scale deliveries [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - MS-4018.S01 through MS-4018.S07 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 7 modules / 1-hour ea [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .5/Module [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 200 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Min of 3 / max of 5 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - MS-4018.1 through MS-4018.7 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 7 modules / 1-hour ea [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4021**
- Eligible course: **MS-4021** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: (blank) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - Copilot Immersion Experience [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - MS-4021.1 through MS-4021.13 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 20 max [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 13 sessions with labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 6-9 sessions over 2-3 days [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery: Not applicable [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - See TSP instructions for delivering MS-4021 CIE content as a course, select modules [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery: Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - MS-4021.1 through MS-4021.13 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 13 modules / 1.5 hours ea [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4023 (SWM)**
- Eligible course: **MS-4023 (SWM)** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: _Copilot Chat_ [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery: Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery: Not applicable [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - Select 2-3 modules [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - **NEW: MS-4023 Webinar available 3/31 as OE course (MS-4023.OE)** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - MS-4023 (SWM) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1.5-hour module [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 600 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Min of 2 / max of 3 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - MS-4023 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1.5-hour module [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑depdendent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4022**
- Eligible course: **MS-4022** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: (blank) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - MS-4022 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3 hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .5 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-25 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - W/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - MS-4022 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3 hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1/2-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - w/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance: No changes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery: Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - MS-4022 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

### “Scale options” section (below the table)
- **Scale options** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- **Resources** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Training Deck v2.pptx (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc rate card (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- FY26 Class Capacities (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Localization table (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Planning Notes:**
- Standard SLA’s apply [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale deliveries include NO LABs, [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Added moderators and credits may be required [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**NEW item:**
- **NEW:** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- **MS-4023: Transform ideas into actions with Copilot Chat** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Available 3/31 as an OE option structured like the popular SWM sessions. This is an easy way to scale this course for any sized customer! (Course: MS-4023.OE) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Expanded scale options [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft confidential [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_5>
### Table: Additional eligible courses & scale options (expanded)

**Header columns (same structure as slide 4):**
- Eligible courses [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery (PDc + rate card links present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery (TSPc rate card link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery (PDc + rate card links present) **NO LABs** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery (TSPc rate card link present) **NO LABs / Add moderator for 50+** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: GH-300 / .s**
- Eligible courses: **GH-300 / .s** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: n/a [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - GH-300 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-25 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - W/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - GH-300 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - w/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - **Plan w/ MTT or TSP**: For scale remove labs and breaks, may also select modules to fit needs and set customer expectations [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - GH-300.s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 200 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 2 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - GH-300.s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4019 / s / .1-4**
- Eligible courses: **MS-4019 / s / .1-4** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: (blank) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - MS-4019 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-25 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - W/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - MS-4019 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - w/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - **Plan w/ MTT or TSP**: Remove labs and breaks, may also select modules to fit needs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - MS-4019.s (SWM) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1.5-hour module [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 600 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Min of 2 / max of 3 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - MS-4019.1 through MS-4019.4 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1 hour per module [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: AB-731 / .s and AB-730 / .s**
- Eligible courses: **AB-731 / .s** and **AB-730 / .s** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: (blank) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - AB-731, AB-730 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-25 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - W/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - AB-731, AB-730 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - w/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - **Plan w/ MTT or TSP**: Remove labs and breaks, may also select modules to fit needs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - AB-731.s, AB-730.s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 200 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 2 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - AB-731.s, AB-730.s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: No program limit; TSP‑dependent [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: MS-4014 / .s and MS-4017 / .s**
- Eligible courses: **MS-4014 / .s** and **MS-4017 / .s** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: n/a [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - MS-4014, MS-4017 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-25 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - W/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - MS-4014, MS-4017 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - w/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - **Plan w/ MTT or TSP**: Remove labs and breaks, may also select modules to fit needs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - MS-4014.s, MS-4017.s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 200 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 2 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Please utilize SWR for TSPc scale request for these courses [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Row: AZ-2007 / .s and DP-605 / .s**
- Eligible courses: **AZ-2007 / .s** and **DP-605 / .s** [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- BYOL needed: n/a [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc Delivery:
  - AZ-2007, DP-605 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 5-25 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - W/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- TSPc Delivery:
  - AZ-2007, DP-605 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 1-day (all modules) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - TSPc rate: 1-day rate [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: 10-20 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - w/ Labs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale content guidance:
  - **Plan w/ MTT or TSP**: Remove labs and breaks, may also select modules to fit needs [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: PDc Delivery:
  - AZ-2007.s, DP-605.s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 3-hours [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - PDc rate: .75/session [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Class size: up to 200 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Moderator: 1 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - 2 sessions per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- SCALE: TSPc Delivery:
  - Not eligible [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
  - Please utilize SWR for TSPc scale request for these courses [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Final blank row:** all cells blank (as displayed). [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

### “Scale options” section (below the table)
- Scale options [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale Options [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Expanded scale options [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Standard Deliveries [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Resources**
- TSPc Training Deck v2.pptx (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PDc rate card (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- FY26 Class Capacities (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Localization table (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Planning Notes:**
- Standard SLA’s apply [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale deliveries include NO LABs, [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Added moderators and credits may be required [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft confidential [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_6>
### Scale course planning guidance - PD

**General Scale planning guidance:**
- Course codes ending in .s [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- One time zone and one language per day [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- At least a 60‑minute break between sessions [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Exception: for MS-4018.S01-MS-4018.S07, a 30-minute break is acceptable, provided there is a minimum 60-minute lunch. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Session times between 8:00am and 5:00pm [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- MTT only (Note: will be reviewed in June.) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Additional SWM or modular session planning guidance:**  
Course codes: MS-4023 SWM, MS-4019.s SWM, MS-4018.S01 through MS-4018.S07 [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- If TPMs request more than one day: [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- No more than 3 delivery days per week [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- No more than 4 delivery days per request [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Delivery spread over no more than 2 weeks (non‑consecutive weeks are OK) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

**Scale Course Agenda**
- Modified SWM data sheets are on slides 8-9. (MS-4023 SWM, MS-4019.S SWM) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Scale course that will be delivered in the 3-hour format, have the same agenda as the 1-day course but with demos in place of labs. Data sheets available in the Organizational Skilling catalog deck (https://aka.ms/course_catalog) are available to convey the agenda of the course. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft confidential [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

Also present on the slide:
- “Title” [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_7>
### SWM datasheets
- SWM datasheets [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_8>
### Get started with Microsoft 365 Copilot and Agents — Course MS-4019.S
- Private Delivery: 90 minutes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- This course examines what agents are and how to use pre-built, first party agents in Microsoft 365 Copilot. Explore how Copilot works alongside you in Word, Excel, and PowerPoint to help create, edit, and refine high‑quality content from start to finish. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- What you learn: Find out how AI-powered assistants provide real-time support and help users navigate complex tasks. This course will walk through Researcher, Analyst, Prompt Coach, Idea Coach, Writing Coach along with Edit with Copilot in Word, Excel and PowerPoint. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- This course is designed for business users wanting to enhance their productivity and efficiency with Microsoft 365 Copilot. Users should have a foundational understanding of Microsoft 365 applications. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Get started with agents [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Explore prebuilt Microsoft 365 Copilot agents [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Edit with Copilot in Word, Excel, and PowerPoint [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- To book this course, contact your Training Program Manager [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Explore the expanded learning paths on Microsoft Learn (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Watch the expanded Course Video (http://aka.ms/MS-4019onYouTube) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PD [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Private delivery (contact your TPM) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Next steps Agenda [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Skills-based instructor-led training course description [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Audience profile [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_9>
### Explore Microsoft 365 Copilot Chat (private delivery) — Course MS-4023
- Private delivery: 90 minutes [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- This instructor-led, large-scale webinar is designed to teach business users the basics of using Microsoft 365 Copilot Chat and crafting effective prompts. Attendees work with use case examples and learn about data protection, Copilot Pages, and agents. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- What you learn: Get the opportunity to ask questions about Copilot Chat in real time, along with access to the associated Microsoft Learn learning path as an additional resource for interactive experiences. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- This course is designed for business users who are new to Microsoft 365 Copilot. Note that it doesn’t cover licensed Copilot use or Copilot in applications like Word, Excel, and PowerPoint. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Get started with Microsoft 365 Copilot Chat [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Accessing Copilot Chat [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Write effective prompts to achieve optimal results [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Copilot prompt gallery [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Prompting best practices [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft 365 Copilot Pages [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Simplify workflows and automate tasks with agents in Copilot Chat [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- View full course agenda online (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- To book this course, contact your Training Program Manager (TPM) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Explore the expanded learning paths on Microsoft Learn (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Watch Course Videos (link present) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- To complete the exercises in this course, learners must have a Microsoft 365 license. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- PD [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Private delivery (contact your TPM) [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Next steps Agenda [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Audience profile [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Skills-based instructor-led training course description [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## <slide_10>
### Thank you!
- Thank you! [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- Microsoft confidential [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

# What the deck **does NOT** contain (important given your request)
You asked for anything related to **AER/CRM rules, partner rules, attainment rules, TSP credits, MTT, Scale Deliveries, High Volume Sessions, SWM**, etc. The deck **does include** concrete rules for: **scale eligibility per course, PDc/TSPc delivery limits, class sizes, moderator requirements (including “Add moderator for 50+”), SWM/day-per-week constraints, breaks, time windows, and “MTT only” planning guidance**. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

However, in the extracted content of [FY26 Scale Deliveries Guidance.pptx](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true&EntityRepresentationId=cf114a49-3b9f-466f-acc3-63696d904d88), I **do not see explicit “AER/CRM rules,” “attainment rules,” “TSP credits,” or a step-by-step “approval workflow”** beyond references like “without SWR approval,” “Work with your TPC,” “Work with your TPC to ensure proper credit and delivery planning,” and “Please utilize SWR for TSPc scale request for these courses.” [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

Those may exist in:
- the linked **PDc rate card** (CRM link), [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- the linked **TSPc Training Deck v2.pptx**, [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- the linked **FY26 Class Capacities** deck, [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  
- or the linked **Localization table**. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)  

---

## One (necessary) follow-up to truly satisfy “ALL content” across the referenced rules
Do you want me to also **open and extract the content from the linked resources** (especially **TSPc Training Deck v2.pptx**, **FY26 Class Capacities**, and the **Localization table**) so we can capture the **TSP credits / CRM / approval workflow / attainment** details that appear to live outside this deck? If yes, tell me **which links to include**, or paste the files here so I can extract them fully as well. [1](https://microsoft.sharepoint.com/teams/ESI/_layouts/15/Doc.aspx?sourcedoc=%7B981E8EAB-AE3C-4AB5-B076-4616CB200F76%7D&file=FY26%20Scale%20Deliveries%20Guidance.pptx&action=edit&mobileredirect=true)