# extracted: 2026-04-27T13:37:16-03:00
# source: FY26 SLAs.pptx (WWL)
# url: https://microsoft.sharepoint.com/:p:/t/WWL/cQqcOpS9kWgYRazycu1qvUFEEgUC4iROcPcutVaWPOBRkeERSw


