---
name: swm-hvs-scale-rules
description: >
  Authoritative FY26 rule catalog for Skilling While Migrating (SWM) sessions
  delivered via MTT, High Volume Sessions (Copilot Online Platform), TSPc
  Scale Deliveries, and Private Delivery scale (.s) variants. Combines the
  FY26 SLAs deck (WWL), TSPc Training Deck v2 (TPM team), and FY26 Scale
  Deliveries Guidance (ESI team). ALWAYS load — and ALERT the user — when
  their request involves SWM, scale delivery, any ".s" course code (e.g.
  MS-4019.s, MS-4018.S01-S07, GH-300.s, AB-730.s, AZ-2007.s, DP-605.s),
  High Volume Copilot / Online Platform 10-100, TSPc credits/tokens/AER
  allocation, MTT scheduling, moderator requirements, scale class size,
  "no labs" rule, modular sessions, or scale agenda. Triggers (PT-BR + EN):
  SWM, Skilling While Migrating, high volume, alta volumetria, scale
  delivery, scale course, .s curso, módulo SWM, MTT, Microsoft Technical
  Trainer, TSP credits, créditos TSP, TSPc, AER allocation, alocação AER,
  token TSP, moderator, moderador, online platform, Copilot webinar,
  MS-4023, modular session.
---

# SWM / High Volume / Scale Deliveries — FY26 rule catalog

> **Activation rule:** if the user's request mentions ANY trigger keyword
> above, START your reply with a short callout box like:
>
> > ⚠️ **Validating against FY26 SWM/HVS/Scale rules** — see § X applicable
>
> Then perform the validation against the relevant section before proceeding.

---

## 0. Source decks (always link these in your answer)

| Deck | URL | Owner | Last refresh signal |
|---|---|---|---|
| **FY26 SLAs.pptx** | https://microsoft.sharepoint.com/:p:/t/WWL/cQqcOpS9kWgYRazycu1qvUFEEgUC4iROcPcutVaWPOBRkeERSw | WWL Delivery Operations | 2026-02-13 |
| **TSPc Training Deck v2.pptx** | https://microsoft.sharepoint.com/:p:/t/TrainingProgramManager/cQrTwt6OTTBcTo7ESKEt5xZfEgUCDFy47W8j7NjRtlsF6P3IAA | TPM team | (versioned) |
| **FY26 Scale Deliveries Guidance.pptx** | https://microsoft.sharepoint.com/:p:/t/ESI/cQqrjh6YPK61SrB2RhbLIA92EgUCdwsyu8yWyI8BWXSn__tXRA | ESI | 2026-03-03 (H2 update) |

**Refresh policy:** if last validated reading is older than 30 days OR the
user explicitly says "buscar a versão mais recente / refresh policy / valide
contra a versão atual", re-extract these decks via `workiq.ask_work_iq`
with `fileUrls=[…]` BEFORE answering. Cache extraction in
`{{COPILOT_HOME}}\skills\swm-hvs-scale-rules\_cache_*.md`.

---

## 1. Course eligibility matrix (Standard vs SCALE)

> Source: **FY26 Scale Deliveries Guidance**, slides 4-5.
> Convention: **".s" suffix = Scale variant** (no labs, expanded class size).
>
> **🔑 Key reading rule for SCALE TSPc column:** every course listed there
> has **`Class size: No program limit; TSP-dependent`** — meaning the TSP
> partner sets the cap (not Microsoft). Rate is also TSP-dependent (not flat).
> This is FUNDAMENTALLY DIFFERENT from the **HVS Online Platform 10-100**
> modality (§ 5c) which IS capped at 10-100 learners with a flat 18-credit
> rate. Do **not** conflate the two paths.
>
> **🔑 Key reading rule for column header (per source PPT slide):**
> > **SCALE: TSPc Delivery — NO LABs / Add moderator for 50+**
>
> So for ANY course in the SCALE TSPc column: no labs, and 1 moderator
> required when the class size is ≥ 50 learners.

### 1a. Primary scale matrix — slide 4 (1:1 with source PPT)

> 🔑 **GOLDEN RULE — every course in this matrix HAS a SCALE TSPc path.**
> Even when the SCALE PDc column says "Not eligible", the SCALE TSPc
> column is ALWAYS populated with a valid scale option (no program limit;
> TSP-dependent rate). Never tell the user "this course can't be done
> at scale" for any of the 6 courses below.

> Column headers (verbatim from the source slide):
> - **Standard Deliveries:** PDc Delivery (PDc rate card) · TSPc Delivery (TSPc rate card)
> - **Scale Options ⭐ Expanded:** Scale content guidance · **SCALE: PDc Delivery** (PDc rate card · NO LABs) · **SCALE: TSPc Delivery** (TSPc rate card · NO LABs / Add moderator for 50+)
> - **Planning notes** (left margin of slide): Standard SLAs apply · Scale deliveries include NO LABs · Added moderators and credits may be required.

| Eligible courses | BYOL needed | PDc Delivery (Std) | TSPc Delivery (Std) | Scale content guidance | SCALE: PDc Delivery (NO LABs) | SCALE: TSPc Delivery (NO LABs / +moderator if ≥50) |
|---|---|---|---|---|---|---|
| **AI-3025** | — | AI-3025 · 3h · PDc rate .5 · Class 5-40 · w/labs · min 2 sessions | **Not applicable** | No changes | **Not eligible** | **AI-3025** · 3h · TSPc rate: dependent · **Class size: No program limit; TSP-dependent** |
| **MS-4004.x** | M365 License | MS-4004.1 → MS-4004.10 · 45-min modules · PDc rate .25/Module · VILT class 5-40 · min 4 / max 6 per day | MS-4004.1 → MS-4004.10 · TSPc rate: 1-day rate · Class 10-20 | No changes | **Not eligible** · Option: **CEUTS** | **MS-4004.1 → MS-4004.10** · 45-min modules · TSPc rate: dependent · **Max size: No program limit; TSP-dependent** |
| **MS-4018** | M365 License | MS-4018 · 1-day (all modules) · PDc rate 1 · Class 5-40 · w/labs | MS-4018 · 1-day (all modules) · TSPc rate: 1-day rate · Class 10-20 · w/labs | **Select 3-5 modules** · No labs/exercises in any scale deliveries | **MS-4018.S01 → MS-4018.S07** · 7 modules / 1-hour ea · PDc rate .5/Module · **Class size: up to 200** · 1 moderator · min 3 / max 5 sessions per day | **MS-4018.1 → MS-4018.7** · 7 modules / 1-hour ea · TSPc rate: dependent · **Class size: No program limit; TSP-dependent** |
| **MS-4021** | — | Copilot Immersion Experience · MS-4021.1 → MS-4021.13 · PDc rate .75/session · Class 20 max · 13 sessions w/labs · 6-9 sessions over 2-3 days | **Not applicable** | See TSP instructions for delivering MS-4021 CIE content as a course, select modules | **Not eligible** | **MS-4021.1 → MS-4021.13** · 13 modules / 1.5 hours ea · TSPc rate: dependent · **Class size: No program limit; TSP-dependent** |
| **MS-4023 (SWM)** "Transform ideas into actions with Copilot Chat" | Copilot Chat | **Not eligible** | **Not applicable** | **Select 2-3 modules** · **NEW: MS-4023 Webinar available 3/31 as OE course (MS-4023.OE)** | **MS-4023 (SWM)** · 1.5-hour module · PDc rate .75/session · **Class size: up to 600** · 1 moderator · min 2 / max 3 sessions per day | **MS-4023** · 1.5-hour module · TSPc rate: dependent · **Class size: No program limit; TSP-dependent** |
| **MS-4022** | — | MS-4022 · 3h · PDc rate .5 · Class 5-25 · w/Labs | MS-4022 · 3h · TSPc rate: 1/2-day rate · Class 10-20 · w/Labs | No changes | **Not eligible** | **MS-4022** · 3h · TSPc rate: dependent · **Class size: No program limit; TSP-dependent** |

> **Resources** (left margin of slide): TSPc Training Deck v2.pptx · PDc rate card · FY26 Class Capacities · Localization table.

### 1b. Expanded scale matrix (slide 5)

| Course | BYOL | PDc Std | TSPc Std | SCALE PDc (.s) | SCALE TSPc |
|---|---|---|---|---|---|
| **GH-300 / .s** | n/a | 1-day · rate 1 · 5-25 · w/labs | 1-day rate · 10-20 · w/labs | **GH-300.s** · 3h · .75/session · **up to 200** · 1 moderator · 2 sessions per day | GH-300.s · 3h · TSP-dep · no program limit |
| **MS-4019 / .s / .1-4** | — | 1-day · rate 1 · 5-25 · w/labs | 1-day rate · 10-20 · w/labs | **MS-4019.s (SWM)** · 1.5h module · .75/session · **up to 600** · 1 moderator · min 2 / max 3 sessions per day | MS-4019.1-.4 · 1h per module · TSP-dep · no program limit |
| **AB-731 / .s** & **AB-730 / .s** | — | 1-day · rate 1 · 5-25 · w/labs | 1-day rate · 10-20 · w/labs | **AB-731.s, AB-730.s** · 3h · .75/session · **up to 200** · 1 moderator · 2 sessions per day | AB-731.s, AB-730.s · 3h · TSP-dep · no program limit |
| **MS-4014 / .s** & **MS-4017 / .s** | n/a | 1-day · rate 1 · 5-25 · w/labs | 1-day rate · 10-20 · w/labs | **MS-4014.s, MS-4017.s** · 3h · .75/session · **up to 200** · 1 moderator · 2 sessions per day | **Not eligible** — use **SWR** for TSPc scale request |
| **AZ-2007 / .s** & **DP-605 / .s** | n/a | 1-day · rate 1 · 5-25 · w/labs | 1-day rate · 10-20 · w/labs | **AZ-2007.s, DP-605.s** · 3h · .75/session · **up to 200** · 1 moderator · 2 sessions per day | **Not eligible** — use **SWR** for TSPc scale request |

### 1c. NEW for FY26 H2 (released 3/31/2026)

- **MS-4023.OE** — Webinar OE option, structured like the SWM session.
  Easy way to scale Copilot Chat for any sized customer.

---

## 2. SCALE planning rules (PD / MTT)

> Source: FY26 Scale Deliveries Guidance, slide 6.

### 2a. General scale planning (course codes ending in `.s`)

| Rule | Value |
|---|---|
| Time zones per day | **1 only** |
| Languages per day | **1 only** |
| Break between sessions | **≥ 60 min** |
| Exception: MS-4018.S01-S07 break | **30 min OK** if lunch ≥ 60 min |
| Session window | **8:00 am – 5:00 pm** (local) |
| Trainer pool | **MTT only** (under review June 2026) |
| Scale class size cap | per course (max 600 for MS-4023 / MS-4019.s) |
| Moderator | **+1 required** for sessions ≥ 50 learners (TSPc rule, slide 4 column header) |
| Labs | **NO LABs in any scale delivery** |

### 2b. Multi-day SWM / modular planning (MS-4023 SWM, MS-4019.s SWM, MS-4018.S01-S07)

| Rule | Limit |
|---|---|
| Delivery days **per week** | **≤ 3** |
| Delivery days **per request** | **≤ 4** |
| Delivery spread | **≤ 2 weeks** (non-consecutive weeks OK) |

### 2c. Agenda

- Modified SWM data sheets are on slides 8-9 of source deck (MS-4023 SWM, MS-4019.s SWM)
- 3-hour scale formats use the same agenda as the 1-day course but **demos in place of labs**
- Data sheets: https://aka.ms/course_catalog
- MS-4019 expanded video: http://aka.ms/MS-4019onYouTube
- MS-4019.S Private Delivery format: **90 minutes**

---

## 3. SLAs (FY26 SLAs deck, last updated 2026-02-13)

### 3a. Open Enrollment (OE) & Multi-Account Private Delivery (MA-D)

| Phase | SLA |
|---|---|
| Submission | Bulk deliveries to Delivery Operations **≤ 12 weeks** before Official Start Date |
| Excess MTT capacity request (SPOC) | **≤ 30 days** before Official Start Date |
| Trainer Assign + Dispatch | 3-5 BD (1 BD pickup + 2-4 BD execution) |
| Reg Page + LxP Publication | 1 BD |
| Skillable Labs provisioning | 2 BD before Class Start |
| **Total estimated** | **4-6 BD** |

### 3b. Private Delivery & TPM-Requested MA-D

| Phase | SLA |
|---|---|
| Submission window | **5-10 weeks** before Official Start Date (status: Pending Approval) |
| Trainer Assign + Dispatch | 3-6 BD (1 BD pickup + Classic/SBILT 2 BD or **Blended 5 BD** execution) |
| Reg + Publication | 1 BD |
| Skillable Labs provisioning | 2 BD before Class Start |
| **Total estimated** | **4-7 BD** |
| Out of SLA | **Auto-rejected** unless https://aka.ms/ESIExceptionReq approved |

### 3c. Virtual Training Day (VTD)

| Phase | SLA |
|---|---|
| Forecast template submission | **≤ 30 days** before event start |
| Forecast cadence | due **20th** of month for following+1 month (e.g., Jan 20 → March deliveries) |
| Trainer Assign + Dispatch | 5 BD (1 BD pickup + 4 BD execution) |
| Publication | 1 BD |
| **Total estimated** | **8 BD** |
| Reporting | Event team validates WWL report **within 24 h** of confirmation |
| Exception | <30 days requires **{{EMAIL}}** (subject "Exception Request") |
| If MASH reg details missing | Status moves to **DelOps ON HOLD** |

### 3d. TSPc (Training Service Partner Credits)

| Phase | SLA |
|---|---|
| AER Submission | (not specified in slide; default best-effort) |
| Activate Add-on Offer + send token to TSP | **1 BD** after ALL approval |
| Edit / Credit Back (incl. AER resubmission) | **2 BD** total (1 BD AER submit + 1 BD edit/credit back) |
| Increase to quantity post-AER | **NEW AER required** |
| Token credit-back | **Requires TSP confirmation** of token usage |
| ALL approval time | **NOT counted** in SLA |

### 3e. Video Recording Review

| Phase | SLA |
|---|---|
| Submission status "Ready for Scheduling" | **≤ 12 weeks** before request date |
| Trainer Assign + Dispatch | 3 BD |
| **Total estimated** | **3 BD** |

---

## 4. TSPc operational rules (TSPc Training Deck v2)

### 4a. AER lifecycle status

| Status | Trigger |
|---|---|
| **Submitted** | TPM/TPC submits new AER |
| **Committed** | ALL approves TSPc → **budget debited** |
| **Allocated** | TPM/TPC activates offer → 45-day expiry starts → TSP Engagement + Token auto-generated → TPM/TPC sends TSP letter with Token ID |
| **Utilized** | TSP reports training as completed → reporting validated → payment raised |
| **Remaining** | TSPc available for commit/allocation in given month |

### 4b. Activation rule

- Activate from **Area Empowerments view** (NOT directly on the offer) so an Engagement record is created.
- TSP Token email **ownership must be assigned** before sending.
- 45-day expiry begins on **Allocation**.

### 4c. Cancellation / credit-back

| Scenario | Path |
|---|---|
| Approved (NOT yet allocated) | Open offer → **Decline Offer** → credits back to ALL budget → status "Offer Cancelled" |
| Allocated | Open TSP Engagement → **Exceptions** → New TSP Exception → type "Credit Back Modality Quantity" → edit modality qty (partial/full) → enter reason → save |
| Reason field | **Required** (audit trail for ALL/TPM) |
| Credit back amount | System-calculated; only **available modality qty** can be credited |

### 4d. Course eligibility for SCALE TSPc

Per TSPc deck: only courses **under 4 hours, no labs**.
Per Scale Deliveries deck: explicit list above (§ 1).
**MS-4018.S** modules and **High Volume Copilot** courses are enabled for business user scale sessions.

---

## 5. TSPc rate card tiers (TSPc deck slide content)

> Credits are allocated **by modality and quantity** (NOT by learner / voucher).

> 🚨 **GOLDEN RULE — ALWAYS use the LATEST rate card, never quote from this skill.**
> The numbers below are *illustrative tier samples* extracted from a snapshot of
> the TSPc deck. Rate cards are refreshed periodically (FY boundaries, mid-year
> repricings, country tier reshuffles). Before quoting ANY credit number to a
> TSP, partner, or in an AER:
>
> 1. Open the **latest** TSPc rate card (link in § 10 / source deck § 0).
> 2. Confirm the country **region** (Brazil = **Region 4** per the official FY26 TSPc Rate Card, verified 24-Jun-2026 — the earlier "Tier 3" was wrong; still re-verify the latest card).
> 3. Confirm the **modality SKU** (Per Class 1-Day vs ARB vs Online Platform vs HVS 10-100 vs Copilot High Volume vs Per-Module SCALE TSPc).
> 4. **State the rate-card date/version in the AER comments** (e.g., "TSPc Rate Card v.FY26-Q3, retrieved 2026-04-27").
>
> If the latest rate card has not been opened in this session, retrieve it
> *before* answering. Stale cached numbers in this skill MUST NOT be used as
> the source of truth.

> 🧑‍🤝‍🧑 **GOLDEN RULE — Co-instructor must be made EXPLICIT in the request.**
> When a session uses **instructor + co-instructor** (e.g., 50+ learners
> moderator rule, multi-language delivery, accessibility support, or partner
> staffing model), the AER / TSP request must:
>
> 1. **Name both roles** in the request body: "1 lead instructor + 1 co-instructor"
>    (or "1 instructor + 1 moderator" if it's the moderator role per § 1a column header).
> 2. **State whether the rate is per-instructor or per-session** — most TSPc
>    rates are per-session and **already include** the moderator; per-instructor
>    pricing applies only when partner staffs a true co-instructor (split
>    delivery, language pair, etc.).
> 3. **Add the moderator/co-instructor credit line separately** if the rate
>    card breaks it out (e.g., "+0.5 credit per session for moderator if ≥50
>    learners" — verify in latest rate card).
> 4. Match § 1a column header rule: "**NO LABs / Add moderator for 50+**"
>    — for class size ≥ 50, moderator presence is mandatory and must appear
>    in the AER.

### 5a. Tier definition (high-level — see deck for full country list)

| Tier | Examples |
|---|---|
| **Tier 1** | Australia, UK, Japan |
| **Tier 5** (lowest cost) | India, Malaysia, Morocco, South Africa, Thailand |
| **Regions 2-4** | Intermediate — 🇧🇷 **Brazil = Region 4** (see § 5b for the full official table) |

### 5b. Official FY26 TSPc Rate Card — full regional table (🇧🇷 Brazil = Region 4)

> ✅ **Verified from the official TSPc Rate Card slide (Training Program Manager SP site) — {{USER_FIRSTNAME}}, 24-Jun-2026.** This SUPERSEDES the earlier "Brazil = Tier 3 / 1-day = 28 (or 36)" assumptions, which were WRONG. **Brazil is Region 4.** A standard **1-day private VILT class (10–20 learners) in Brazil = 18 TSPc credits/turma.** (Golden rule still applies: re-open the latest card before quoting and record the version/date in the AER.)

| Region | Per-Learner 1-Day | Per-Learner ARB | Per-Learner Online Platform | Per-Class 1-Day (10–20) | Per-Class ARB (10–20) | Per-Class Copilot (High Vol.) | Per-Customer Online Platform (10–100) |
|---|---|---|---|---|---|---|---|
| 1 | 4 | 12 | 1 | 36 | 120 | 13 | 18 |
| 2 | 3 | 10 | 1 | 30 | 100 | 10 | 18 |
| 3 | 2 | 8 | 1 | 24 | 80 | 8 | 18 |
| **4 — 🇧🇷 Brazil** | **2** | **6** | **1** | **18** | **60** | **6** | **18** |
| 5 | 1 | 4 | 1 | 12 | 40 | 4 | 18 |

> 🇧🇷 **Brazil (Region 4) quick reference:**
> - **Standard 1-day private VILT class (≤20 learners) = 18 credits/turma** ← use for GH-100/200/300/500, AZ-2007 (non-scale), MS-4018 1-day, etc.
> - ARB class (10–20) = **60 credits/turma**
> - Per-learner 1-day = **2**/learner · per-learner ARB = **6**/learner
> - **Copilot High-Volume / SCALE per-course session = 6 credits/session/instructor** (Region 4). With the mandatory co-instructor for ≥50 learners (§ 1a column header) = **6 × 2 = 12 per class** — always state both sides of the math: "6 credits/session/instructor × 2 = 12 per class".
> - Online Platform 10–100 (HVS) = **18 credits** flat (per customer).

### 5c. **High Volume Copilot (Online Platform)** specifics

> ⚠️ **Do NOT confuse with SCALE TSPc per-course delivery (§ 1).** HVS /
> Online Platform 10-100 is a **separate modality** from the per-course
> SCALE TSPc rows in the matrix. The two co-exist:
>
> | Path | Cap per session | Rate per session | When to use |
> |---|---|---|---|
> | **SCALE TSPc per-course** (§ 1, e.g., MS-4023 1.5h, MS-4004.x 45min, MS-4018.1-.7 1h, MS-4021.1-.13 1.5h, MS-4022 3h, AI-3025 3h) | **No program limit · TSP-dependent** | **TSP-dependent** (negotiated with partner) | Customer wants the actual course module delivered at scale (e.g., 500 employees in one Copilot Chat session). Use this for big classes. |
> | **HVS / Online Platform 10-100** (this section) | **10-100 learners** | **18 credits flat** (all tiers) | Generic Copilot scale enablement webinars where the partner uses the HVS modality SKU. Use only when both sides agree on the HVS SKU. |
>
> **Bottom line:** if the user says "X people in one session for course Y",
> the right path is almost always **SCALE TSPc per-course (§ 1)** with
> partner setting the cap — NOT HVS 10-100.

**HVS / Online Platform 10-100 modality details:**
- **10-100 learners per session** (single class hard cap)
- Flat tier rate (**18 credits** all tiers — Online Platform 10-100 SKU)
- Used for generic business user scale enablement webinars
- Counts as TSPc Scale delivery

> 🇧🇷 **Brazil = Region 4** (official FY26 TSPc Rate Card, verified 24-Jun-2026; see § 5b). Re-verify the latest deck for exact per-modality rates.

---

## 6. Validation checklist (use BEFORE submitting any AER / talking to MTT or TSP)

### 6a. SWM (MS-4023, MS-4019.s)
- [ ] Course code is **`.s`** or `MS-4023` exact
- [ ] Format: **1.5h module**
- [ ] Class size ≤ **600** (PDc) or **TSP-dep** (TSPc)
- [ ] **1 moderator** assigned
- [ ] **NO labs**, demos in place
- [ ] If multi-day: ≤ 3 days/week, ≤ 4 days/request, ≤ 2 weeks spread
- [ ] One time zone, one language per day
- [ ] Break between sessions ≥ 60 min (≥ 30 if MS-4018.S01-S07 + lunch ≥ 60)
- [ ] 8 am - 5 pm local
- [ ] **MTT-only** trainer (PD path)
- [ ] PD AER submitted within SLA: **5-10 weeks** before Start Date

### 6b. High Volume / Online Platform (10-100) — _the 10-100 SKU only_
- [ ] TSPc only (not PDc HVS)
- [ ] **10-100 learners** per session (hard cap of THIS SKU)
- [ ] Course is HVS-eligible (Copilot scale courses)
- [ ] TSP partner identified + token allocation plan
- [ ] AER submitted; TSP confirms token usage for credit-back
- [ ] _If learners > 100, do NOT use HVS 10-100 → switch to SCALE TSPc
      per-course (§ 6e) where Class size = "No program limit; TSP-dependent"_

### 6e. SCALE TSPc per-course delivery (§ 1 SCALE TSPc column)
- [ ] Course is in the SCALE TSPc column of § 1 matrix
- [ ] **NO LABs** (column header rule)
- [ ] **+1 moderator** if class size ≥ 50 learners (column header rule)
- [ ] Class size: any (NO program limit) — confirm partner can deliver
- [ ] Rate: TSP-dependent — get partner cotation BEFORE submitting AER
- [ ] **Latest TSPc rate card consulted** (date/version recorded in AER comments) — never use cached numbers from this skill (§ 5 golden rule)
- [ ] **🇧🇷 Brazil (Region 4) quick math (FY26 TSPc Rate Card):** 6 credits/session/instructor → with co-instructor (50+ learners) = **6 × 2 = 12 per class**. Multiply by # of sessions/courses for the bundle total. Always state the math explicitly.
- [ ] **Instructor + co-instructor / moderator stated EXPLICITLY** in the request body when applicable (≥50 learners, multi-language, accessibility, partner split-delivery model) — see § 5 golden rule
- [ ] One AER per course (modality / quantity per offer line)
- [ ] Multi-module courses (MS-4018.S, MS-4021.1-.13, MS-4004.1-.10): pick
      the specific modules being delivered, not the whole series unless intended

### 6c. Scale PDc (.s) other than SWM
- [ ] Course code ends in **`.s`** AND course is in the matrix (§ 1)
- [ ] Class size ≤ **200** (most .s) or **600** (SWM variants)
- [ ] **1 moderator** if size ≥ 50
- [ ] No labs, demos only
- [ ] **2 sessions/day max** (3-hour format) OR **3-5 sessions/day** (MS-4018.S 1-hour format)
- [ ] Standard PD SLA (5-10 weeks)

### 6d. SCALE TSPc on courses that say "Not eligible"
- ❌ MS-4014, MS-4017, AZ-2007, DP-605 — for these, **submit SWR** (Scale Workshop Request) instead of TSPc Scale.

---

## 7. How to use this skill in conversation

When the user asks anything in scope (training request, delivery planning,
AER prep, partner email, kanban card update touching SWM/HVS/scale):

1. **Surface the alert callout** at the top of your response.
2. **Identify the scenario** (SWM via MTT? HVS via TSPc? Scale PDc?).
3. **Map to the matrix** (§ 1) and confirm course code + variant.
4. **Run the relevant § 6 checklist** silently, then list red flags + green confirmations.
5. **Quote the SLA** (§ 3) the user must hit.
6. **Cite the source deck** with the URLs in § 0 (so the user can audit).

When the user provides numbers (class size, sessions, days, weeks):
- Validate against § 2 / § 6 immediately.
- If a violation: refuse silently → explain rule → propose compliant variant.

When the user wants to **validate post-execution** (was a SWM properly run?):
- Cross-check: course code in title, # of attendees vs cap, # sessions/day,
  moderator presence, MTT trainer attribution, TSPc utilization status,
  ESI Admin (Dynamight) AER status (Allocated → Utilized within 45 days).
- Flag mismatches against the matrix.

---

## 8. Cache + refresh

- Cache extraction artifacts under
  `{{COPILOT_HOME}}\skills\swm-hvs-scale-rules\_cache_<deck>.md`
  with a header `# extracted: <ISO timestamp> · source: <URL>`.
- TTL: **30 days**. After that, re-run `workiq.ask_work_iq` with the URL
  in `fileUrls` to refresh.
- If the user explicitly says "buscar versão mais atual" / "force refresh",
  ignore the cache and re-extract.

---

## 9. Anti-patterns

- ❌ Quoting class sizes from memory — always look at § 1.
- ❌ **Saying "this course can't be done at scale" for ANY of the 6 courses on slide 4 (AI-3025, MS-4004.x, MS-4018, MS-4021, MS-4023 SWM, MS-4022).** They ALL have a SCALE TSPc path with no program limit. The "Not eligible" labels apply only to SCALE PDc, never to SCALE TSPc on this slide.
- ❌ **Confusing "SCALE TSPc per-course" (no program limit, TSP-dep) with "HVS Online Platform 10-100" (hard 10-100 cap, 18 credits flat).** They are TWO different paths in TSPc Scale. See § 5c table.
- ❌ Telling the user "you can't have 500 learners in one session" for any course in the SCALE TSPc column of § 1 — class size is **TSP-dependent**, not Microsoft-capped.
- ❌ Approving a TSPc SCALE for MS-4014/MS-4017/AZ-2007/DP-605 — these need **SWR**, not TSPc scale (per § 1b — these are the ONLY courses where SCALE TSPc is "Not eligible").
- ❌ Letting an MS-4023 SWM (PDc path) exceed 3 sessions per day or spread > 2 weeks.
- ❌ Allowing > 50 learners without a moderator on TSPc Scale (column header rule: "Add moderator for 50+").
- ❌ Allowing labs in any scale delivery (column header rule: "NO LABs").
- ❌ Promising < 5-week PD turnaround without an approved Exception Request.
- ❌ Scheduling an MTT outside 8 am - 5 pm local or across 2 time zones in a day.
- ❌ Quoting ALL approval into TSPc SLA total (it's excluded).
- ❌ Quoting a flat credit rate for SCALE TSPc per-course offers — rate is **TSP-dependent**, must get partner cotation first.
- ❌ **Quoting credit numbers from this skill's § 5 sample table without re-checking the LATEST rate card** — the FY26 deck is refreshed periodically; § 5 numbers are illustrative only. Always state "TSPc Rate Card v.<version>, retrieved <YYYY-MM-DD>" in AER comments.
- ❌ **Submitting an AER with class size ≥ 50 (or partner co-instructor / split delivery / multi-language) without naming "1 instructor + 1 co-instructor" (or "1 instructor + 1 moderator") explicitly in the request body.** Implicit moderator assumption = TSP credit dispute risk. See § 5 golden rule.
- ❌ Citing rules without linking the source deck (§ 0).

---

## 10. Where to get more detail / linked artifacts

- **PDc rate card** (link from source deck — periodic refresh)
- **TSPc rate card** (link from source deck — full country tier table)
- **FY26 Class Capacities** (link from Scale Deliveries deck)
- **Localization table** (link from Scale Deliveries deck)
- **Course catalog / data sheets:** https://aka.ms/course_catalog
- **MS-4019 video:** http://aka.ms/MS-4019onYouTube
- **PD/Exception Request:** https://aka.ms/ESIExceptionReq
- **VTD exception email:** {{EMAIL}} (subject "Exception Request")
