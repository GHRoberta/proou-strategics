---
name: capacitacao-kickoff-email
description: >
  Gera o email de boas-vindas / próximos passos enviado a uma conta
  (cliente) após a primeira reunião de capacitação ESI. Consolida o
  que foi discutido na reunião (gravação/transcrição), apresenta o
  programa ESI, anexa os 3 materiais padrão (LxP / Agendamento de
  prova / Grade de turmas abertas como .eml repassável) e formaliza
  os próximos passos com owners. Cria como rascunho no Outlook,
  endereçado aos participantes da reunião + virtual team Microsoft.
  Use sempre que o usuário pedir "email de boas-vindas para [conta]",
  "email de próximos passos da reunião com [conta]", "kickoff de
  capacitação", "follow-up da reunião de capacitação", "ESI welcome
  email", "material e próximos passos", "primeiro email para o
  cliente após reunião de capacitação".
  Triggers: email boas-vindas capacitação, kickoff ESI, próximos passos
  reunião capacitação, ESI welcome, material e próximos passos,
  follow-up reunião capacitação, primeiro email cliente ESI,
  onboarding de conta capacitação.
---

# Capacitação Kickoff Email — Boas-vindas + Próximos Passos pós reunião ESI

Gera o **email-rascunho de kickoff** que enviamos ao cliente logo após a
primeira reunião de capacitação ESI. É o "pacote de entrada" da conta no
programa: recapitula o acordado, apresenta o ESI, entrega os materiais
operacionais e formaliza próximos passos com owner por item.

Modelo de referência: `ESI - Material e Próximos Passos | Capacitação <NomeDaConta>`.

## Quando usar (vs. outros skills)

| Cenário | Skill |
|---------|-------|
| Primeiro email pós-reunião de descoberta de capacitação | **este skill** |
| Apenas divulgar a grade OE (sem reunião associada, ex.: para TPC interna) | `oe-grade-email` |
| Plano de capacitação completo em PPTX (trilha didática) | `learning-trail-pptx` |
| Update mensal/quinzenal de status do programa | (criar skill próprio) |

## Pré-requisitos

- Acesso à gravação / transcrição da reunião (Stream/Teams) **ou** notas
  do usuário com os pontos discutidos. **Não invente conteúdo de reunião.**
- Os 2 PDFs padrão disponíveis localmente em `{{WORKDIR}}\`:
  - `Agendamento da prova com desconto.pdf` (~1.85 MB) — instruções para vincular conta pessoal × corporativa e ganhar 50% off em provas
  - `Portal de Experiencia do Aluno - LxP.pdf` (~2.0 MB) — passo a passo do LxP (portal do aluno)
- Email recente com a grade OE em pt-BR (gerado pelo skill `oe-grade-email`)
  — vamos transformá-lo em `.eml` repassável.
- VPN + `az login` (para Graph + Dataverse, caso precise consultar grade nova).

## Estrutura padrão do email (NÃO pular seções)

Ordem fixa — ajuda o cliente a navegar entre kickoffs de programas
diferentes:

1. **Saudação + agradecimento + frase de contexto** (1 parágrafo)
2. **Estrutura da jornada acordada** — `<u>` no título, lista numerada
   das camadas/trilhas combinadas. Inclua a mistura ao vivo / gravado /
   autoguiado quando fizer sentido pela escala.
3. **O que o programa ESI oferece** — bullets fixos: TPM dedicado,
   instrutores Microsoft (turmas abertas + dedicadas), 50% off
   certificações, plano de capacitação personalizado, painel de métricas.
4. **Anexos deste email** — lista numerada batendo 1:1 com os 3 anexos.
   Sempre nessa ordem: (1) LxP, (2) Agendamento de prova, (3) Grade OE
   como `.eml`.
5. **Dois portais à disposição** — Microsoft Learn (e-mail pessoal) ×
   ESI (e-mail corporativo). Bullets curtos do que cada um faz.
6. **Callout IMPORTANTE no-show** — caixa amarela com borda vermelha
   (style abaixo). 3 faltas sem cancelar = bloqueio.
7. **Próximos passos definidos na reunião** — lista numerada, cada item
   com **owner explícito em itálico**. Tirar literalmente da gravação;
   não inventar.
8. **Sugestão de ação imediata** — 1 parágrafo orientando a área de
   RH/Comunicação a já encaminhar o `.eml` da grade enquanto o resto é
   desenhado.
9. **Links úteis** (2 fixos) — URLs validadas:
   - Portal ESI / LxP: `https://esi.microsoft.com` (ou `https://aka.ms/ESI-LxP`)
   - Org Reporting (CxP): `https://esicxp.microsoft.com`
   - Catálogo ESI (API): `https://learn.microsoft.com/api/catalog/`
   > ⚠️ **NUNCA usar** `learningportal.microsoft.com` (morto) nem
   > `aka.ms/interskilling-org-reporting` (quebrado → Bing). Validado em 2026-05-25.
10. **Despedida + assinatura** — assinatura **vem do profile `my-voice`
    §2.3 Full** (não hardcode). Saudação de fechamento usa `my-voice`
    §4 Mode A (External Client) — tipicamente `Atenciosamente,` ou
    `Abraços,` conforme o tom da reunião.

### Snippets HTML reutilizáveis

```html
<!-- Cabeçalho de seção -->
<p style="margin:18px 0 6px"><b><u>Estrutura da jornada acordada</u></b></p>

<!-- Callout IMPORTANTE -->
<p style="background-color:#FFF4CE; padding:10px; border-left:4px solid #D83B01">
<b>IMPORTANTE</b> — sempre que um colaborador se inscrever em um treinamento
ou prova e não puder comparecer, oriente que <b>cancele a inscrição</b>.
O portal bloqueia novas inscrições para colaboradores que faltarem em
<b>3 sessões seguidas sem cancelar</b> (no-show).
</p>

<!-- Assinatura: SEMPRE carregue do profile my-voice (não hardcode aqui) -->
<!-- Variante a usar para kickoff: 2.3 Full (primeiro contato formal externo) -->
<!-- Veja: {{COPILOT_HOME}}\skills\my-voice\voice-profile.md §2.3 -->
```

⚠️ **NÃO hardcode a assinatura neste skill.** Antes de montar o body,
carregue [`my-voice/voice-profile.md`](../my-voice/voice-profile.md) e use
a **variante 2.3 Full** (primeiro contato formal externo). Justificativa:
título, telefone e email mudam — manter um único source of truth evita
quebra silenciosa em N skills.

```text
view: {{COPILOT_HOME}}\skills\my-voice\voice-profile.md
# Use seção §2.3 Full HTML signature
```

Wrap o body inteiro em:
```html
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body dir="ltr" style="font-family:Aptos,Calibri,sans-serif; font-size:11pt; color:#000">
... conteúdo ...
</body></html>
```

## Recipientes

- **TO**: todos os participantes da reunião pelo lado do **cliente**
  (UPNs do domínio do cliente). Resolver via `agent365-user-GetMultipleUsersDetails`
  se só tiver display name.
- **CC**: virtual team Microsoft da conta (mínimo: ATU lead + AE da conta).
  Padrão LASA: `{{EMAIL}}`, `{{EMAIL}}`.
  Para outras contas, verificar account team via MSX (`msx-mcp-get_account_overview` → seção `team`).
- **From**: usuário ({{USER_FIRSTNAME}}).

## Workflow

### Passo 1 — Coletar inteligência da reunião

Use `workiq-ask_work_iq` com query estilo:

> "Liste os pontos discutidos e os next steps acordados na minha última
> reunião com [Conta] sobre capacitação ESI. Cite participantes, owner
> de cada next step e prazos mencionados."

Se a transcrição estiver no SharePoint/OneDrive, passe a URL via `fileUrls`.
**Não invente próximos passos** — se faltar info, pergunte ao usuário.

### Passo 1.5 — Validar TODOS os links antes de montar o body

**OBRIGATÓRIO** — qualquer URL incluída no email deve ser verificada via
`web_fetch` antes de inserir no HTML. Links quebrados causam feedback
negativo do cliente (incidente XPI, maio 2026).

```
Para cada URL no email:
1. web_fetch(url=<URL>, max_length=500)
2. Se falhar (fetch error) → URL morta → NÃO incluir, buscar alternativa
3. Se redirecionar para Bing/Google → aka.ms expirado → NÃO incluir
4. Se retornar login page ("Entrar") → OK (recurso auth-gated, normal)
5. Se retornar conteúdo real → ✅ OK
```

**URLs validadas (fonte de verdade, atualizada 2026-05-25):**

| Recurso | URL correta | Status |
|---------|-------------|--------|
| Portal ESI / LxP | `https://esi.microsoft.com` | ✅ |
| Portal ESI (aka.ms) | `https://aka.ms/ESI-LxP` | ✅ |
| Org Reporting (CxP) | `https://esicxp.microsoft.com` | ✅ |
| ~~Org Reporting (antigo)~~ | ~~`https://esi.microsoft.com/orgreporting`~~ | ⚠️ Rota do LxP, não é o CxP |
| Catálogo ESI (API) | `https://learn.microsoft.com/api/catalog/` | ✅ |

**URLs MORTAS (NÃO usar):**

| URL quebrada | Problema | Substituir por |
|-------------|----------|---------------|
| `learningportal.microsoft.com` | Domínio morto | `esi.microsoft.com` |
| `aka.ms/interskilling-org-reporting` | Redireciona p/ Bing | `esicxp.microsoft.com` |
| `esi.microsoft.com/orgreporting` | Rota do LxP (portal do aluno), NÃO é o CxP admin | `esicxp.microsoft.com` |

O anexo 3 é o **email original** (sent) com a grade OE consolidada,
salvo como `.eml` para que o cliente possa repassar integralmente para
RH/Comunicação Interna.

```python
# Buscar email sent recente com a grade
# (use agent365-mail-SearchMessagesQueryParameters com $filter por subject)

# Extrair body via agent365-mail-GetMessage(preferHtml=true)
# Output > 50KB → vai para arquivo temp; parse com Python depth-tracking
# pulando o "CorrelationId" trailing.

# Construir .eml
from email.message import EmailMessage
msg = EmailMessage()
msg["Subject"] = subject_original
msg["From"]    = from_addr
msg["To"]      = to_original
msg["Date"]    = sent_date_rfc2822
msg.set_content("Conteudo HTML - abra em cliente compativel.")
msg.add_alternative(html_body, subtype="html")

with open(r"{{WORKDIR}}\Grade_OE_<MesIni>_<MesFim>_<Ano>.eml","wb") as f:
    f.write(bytes(msg))
```

> ⚠️ Inline images (CIDs) do email original quebram no `.eml` puro —
> aceitável, pois o conteúdo textual + grade são auto-suficientes.
> Avise o usuário se a grade depender muito de imagens embutidas.

### Passo 3 — Localizar os 3 anexos locais (para embutir no `.eml`)

Com a rota `.eml` (MANDATE M1), os anexos vão embutidos direto dos arquivos
locais (MIME) — sem SharePoint URI e sem limite de base64 em args MCP:

```
1. Confirmar os 3 arquivos na pasta local (OneDrive sincronizado):
   {{WORKDIR}}\<filename>
2. Ler cada arquivo em bytes e anexar com msg.add_attachment(...) no .eml
```

### Passo 4 — Gerar o draft como `.eml` local (MANDATE M1)

Monte um `.eml` (RFC-822/MIME) e **abra-o** — **NÃO** use
`agent365-mail-CreateDraftMessage` nem Outlook COM (proibidos; entopem a pasta
Rascunhos). Snippet canônico em `my-voice/voice-profile.md` §6.

```
Subject:  "ESI - Material e Próximos Passos | Capacitação <Conta>"
From:     {{USER_NAME}} <{{EMAIL}}>
To:       [participantes_cliente]
Cc:       [virtual_team_microsoft]
X-Unsent: 1
Body:     <html completo conforme snippets>  (set_content + add_alternative)
Anexos:   os 3 arquivos embutidos DIRETO dos arquivos locais (Passo 3) — MIME
Salvar:   {{WORKDIR_LOCAL}}\drafts\Capacitacao_<Conta>_kickoff.eml
Abrir:    subprocess.Popen(['cmd','/c','start','', str(eml)], shell=False)
```

**Não envie** — o `.eml` abre no new Outlook pronto para revisão e envio humano.

### Passo 5 — Verificar e reportar

Confirmar que o `.eml` em `{{WORKDIR_LOCAL}}\drafts\` abriu e contém os 3 anexos
(LxP / Agendamento / grade `.eml`) e devolver ao usuário o **caminho do arquivo**.

## Erros e recuperação

| Erro | Causa | Solução |
|------|-------|---------|
| `IrresolvableConflict` ao deletar/atualizar anexo em paralelo | changeKey ficou stale | Serializar: deletar 1 → esperar resposta → próximo |
| `403 Forbidden` no Graph `/messages/{id}/$value` | Token az CLI não tem `Mail.ReadWrite` | Use a rota build-from-body com `EmailMessage` (este skill já faz isso) |
| Outlook COM não acha o sent email | Cache local não sincronizou ainda | Use Graph (`SearchMessagesQueryParameters` com `$filter=subject eq ...`) |
| Anexo `.eml` aparece como texto bagunçado no Outlook | Faltou `add_alternative(html, subtype='html')` | O `.eml` precisa do MIME multipart/alternative |
| Inline images quebradas no `.eml` | CIDs sem o `.eml` ter as partes embutidas | Aceitável; avisar usuário. Para reproduzir 100%, exportar `.msg` direto pelo Outlook |
| `xlsx` corrompido quando geramos por libs Python sem template | Limites do `openpyxl` em estilos | Prefira `.eml` para anexar grade (este skill já faz isso) |
| Body do email vazio depois do `UpdateDraft` | Edição prévia em OWA inseriu styles que confundem o re-apply | Re-apply o HTML limpo via `UpdateDraft body` — OWA-styles são sobrescritos |

## Checklist final antes de devolver ao usuário

- [ ] TO contém todos os participantes do cliente da reunião
- [ ] CC contém o virtual team Microsoft (mínimo ATU + AE)
- [ ] Subject segue padrão `ESI - Material e Próximos Passos | Capacitação <Conta>`
- [ ] Próximos passos são literais da reunião, com owner em itálico
- [ ] Anexo 1 = LxP PDF (não confundir com CxP — CxP é portal admin)
- [ ] Anexo 2 = Agendamento de prova com desconto
- [ ] Anexo 3 = `Grade_OE_<período>.eml` (não xlsx — xlsx tende a corromper)
- [ ] Callout IMPORTANTE de no-show presente
- [ ] Links validados via `web_fetch` (Passo 1.5) — nenhum link morto ou redirecionando para Bing
- [ ] URLs do portal ESI usam `esi.microsoft.com` (NÃO `learningportal.microsoft.com`)
- [ ] Org Reporting usa `esi.microsoft.com/orgreporting` (NÃO `aka.ms/interskilling-org-reporting`)
- [ ] Assinatura padrão (3 linhas)
- [ ] Draft criado, **não enviado** — devolver `webLink` ao usuário

## Cross-reference

- Para gerar a grade OE que vira o `.eml`: skill **oe-grade-email**
- Para extrair turmas direto do Dynamight (caso precise grade nova): skill **oe-schedule**
- Para identificar virtual team da conta no MSX: skill **account-agent** ou ferramenta `msx-mcp-get_account_overview`
- Para coletar pontos da reunião: skill **workiq-patterns**
