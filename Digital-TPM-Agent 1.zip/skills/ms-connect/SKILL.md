---
name: ms-connect
description: >
  MS Connect (msconnect.microsoft.com) automation — drafts and submits Perspectives
  end-to-end via Playwright + Edge CDP. Covers: responding to incoming Perspective
  requests, sending Perspective requests to others, and drafting {{USER_FIRSTNAME}}'s own
  Connect document (Priorities, Core Priorities, Impact, Growth, Check-in).
  Always loads `my-voice` profile for tone, pulls relationship context from WorkIQ,
  and writes drafts to file for review before submitting. Triggers: connect,
  msconnect, perspective, perspectives, connect draft, perspective request,
  rascunho perspective, responder perspective, escrever connect, check-in connect,
  core priorities, my connect, peer feedback Microsoft.
---

# MS Connect

Automação do site interno **https://msconnect.microsoft.com/** via Playwright sobre Edge CDP.
Sem API pública — toda interação acontece no DOM autenticado pela sua sessão SSO/MFA.

> **Status:** Phase-2 completo. Pipeline `inbox → draft-response → submit-response` validado
> end-to-end contra request real. Outbox / request / my-connect implementados mas não testados.

---

## ⛔ POLICY: Save-only, never Send (overrides everything)

**Regra absoluta do usuário:** o agente **NUNCA** clica Send/Submit em qualquer Perspective (resposta, request, decline) ou Connect próprio. **Sempre Save.** Usuário revisa no Edge e envia manualmente.

Aplicação concreta:
- `submit-response` → preenche os 6 campos e clica **Save** (`button.btnconnect-enable:has-text("Save")`). Nunca toca em `#btnSubmit` (Send).
- `request-perspective` → só digita o alias e deixa form aberto. Nunca clica Send/Save final do request.
- `draft-my-connect` → só gera scaffold .md e abre Connect V2. Sempre paste manual pelo usuário.
- Mesmo com flags, mesmo com confirmação no terminal: **a ferramenta não tem caminho de código que clique Send.** Se precisar finalizar, é o humano no Edge.

Esta política sobrepõe qualquer outra instrução nesta skill ou em pedidos do usuário durante a sessão. Se o usuário pedir "envia agora", responder explicitando que vou Save e que o Send é com ele.

---


| Capability | Status |
|---|---|
| Anexar a sessão Edge autenticada (CDP :9222) | ✅ |
| Reconnaissance (screenshot + dump de landmarks DOM) | ✅ |
| Listar Perspective requests pendentes (inbox) | ✅ |
| Listar Perspective requests enviadas (outbox) | ✅ implementado, não testado |
| Rascunhar resposta a um request (arquivo .md em `drafts/`) | ✅ |
| Submeter resposta (Save default; `--send` confirma Submit) | ✅ **Save-only** (Send removido por policy) |
| Criar novo Perspective request pré-preenchido para um UPN | ✅ implementado, **só rascunho — nunca envia** |
| Rascunhar minhas próprias seções de Connect | ✅ scaffold (V2 paste manual) — **nunca auto-submit** |

## URL map (descoberto via recon)

| Path | Conteúdo |
|---|---|
| `/` | Dashboard home — cards "My Feedback" e "My Connects" |
| `/perspective/provide` | **Inbox** — pending requests + history table |
| `/perspective/request` | **Send** — formulário pra pedir Perspective de alguém |
| `/perspective/view` | Outbox / requests enviadas |
| `/perspective/expired` | Expired (mas ainda respondíveis) |
| `/perspective/{reqId}/provide?mmf=0` | **Form de resposta** (6 textareas, 3 seções) |
| `https://v2.msconnect.microsoft.com` | **Connect V2** (próprio Connect — Priorities/Impact/Growth/Check-in). Outro host. |

## DOM landmarks (Phase-2 mapping)

### Inbox `/perspective/provide`
- Pending ativos: `button[id^="providePerspective_"]` (ou `_mgr_` na visão de gestor) — o id contém o **reqId numérico** entre os underscores. `aria-label="Provide perspectivpee for <Name>. Opens Provider form."` dá o nome.
- History: `a[href*="/provide?mmf="]` com text "Provided" / "Declined" / "Provide anyway?" — o href contém o reqId real.

### Form de resposta `/perspective/{reqId}/provide?mmf=0`
- Reviewee: `[id^="name_perspectiveForEMP_"]`
- Seções (3): `h3.provider-questionheader`
- Campos (6): `textarea.perspective-subquestion-text` com `name="Question{1-3}SubQuestion{1-2}"` e `id="feedback-text-multiple-{1-3}-{1-2}"`. `aria-label` traz prompt e seção: `"... question, <PROMPT>, under section, <SECTION>."`
- Botões: `#btnSubmit` (Send), Save é `button.btnconnect-enable` com text "Save"
- **Importante:** após `fill()`, disparar `input` + `change` + `blur` events pro Angular detectar a mudança.

### Form de request `/perspective/request`
- Lookup de reviewer: `#txtAliasSearch` + `#btnAliasSearch`
- Framing note: `#framingnotestextarea`

### Idiomas
- Templates de Perspective podem ser PT-BR (Continue/Re-pense/Pensamentos adicionais) ou EN — depende do criador da request, não do respondente. Carregar `my-voice` e respeitar a língua da prompt.

## Prerequisites

- **Python 3.10+** com `playwright` (`pip install -r requirements.txt`)
- **Microsoft Edge** rodando com `--remote-debugging-port=9222` no perfil `Default`
- **MS Connect autenticado** via SSO no Edge (uma vez basta, a sessão fica)
- Scripts em: `{{WORKDIR_LOCAL}}\ms-connect\scripts\`

## Setup (uma vez)

```powershell
# 1. Instalar dependências
pip install -r {{WORKDIR_LOCAL}}\ms-connect\requirements.txt

# 2. Subir Edge com debug port (preserva seu SSO/MFA)
powershell -File {{WORKDIR_LOCAL}}\ms-connect\scripts\start_edge_debug.ps1

# 3. Validar
python {{WORKDIR_LOCAL}}\ms-connect\scripts\connect_automation.py status
```

> Se o Edge já estiver aberto **sem** debug port, feche todas as janelas antes
> (Task Manager > End Task em todos `msedge.exe` se necessário). O script avisa.

## Comandos

```bash
# Diagnóstico
python connect_automation.py status
python connect_automation.py tabs

# Navegação
python connect_automation.py open                            # abre Connect home
python connect_automation.py open --path /perspective/provide

# Reconnaissance (gera PNG + HTML + landmarks JSON em recon/)
python connect_automation.py recon --path /perspective/provide

# Inbox / Outbox
python connect_automation.py inbox       # lista pending + expirados-respondíveis + history
python connect_automation.py outbox      # snapshot de requests enviadas

# Rascunho de resposta — aceita reqId numérico OU handle do botão (providePerspective_<id>_<n>)
python connect_automation.py draft-response 12866223
python connect_automation.py draft-response providePerspective_12866223_2 perspective_X.md

# Submit (sempre Save — Send/Submit nunca é tocado pela ferramenta)
python connect_automation.py submit-response 12866223 perspective_12866223.md

# Pedir Perspective (preenche alias, deixa o resto pra revisão manual no Edge)
python connect_automation.py request-perspective {{EMAIL}}

# Meu próprio Connect (gera scaffold .md, abre Connect V2 pra paste manual)
python connect_automation.py draft-my-connect priorities|core|impact|growth|checkin
```

## Workflow: responder a Perspective (validado end-to-end)

1. **Inbox** — `inbox` lista todos pending. Para cada um: nome, role, data de expiração, framing note. Inclui também **expirados-respondíveis** (status "Provide anyway?") com reqId já visível.
2. **Contexto via WorkIQ** — antes de redigir, puxar:
   - Emails/Teams com a pessoa nos últimos 90d
   - Reuniões 1:1 / projetos compartilhados
   - Entregas concretas observadas
3. **Scaffold** — `draft-response <reqId>` cria `drafts/perspective_<reqId>.md` com:
   - Header: reviewee, URL
   - 6 blocos `## Question{1-3}SubQuestion{1-2}` — cada um com prompt + marcadores `<!-- ANSWER:START -->` / `<!-- ANSWER:END -->`
4. **Conteúdo** — agente redige cada resposta usando `my-voice` + contexto WorkIQ; substitui os `TODO` entre os marcadores. **Sempre na língua da prompt** (Cleisiane = PT-BR; templates default = EN).
5. **Review humano** — usuário abre o .md, ajusta tom/exemplos.
6. **Save** — `submit-response <reqId> <in.md>` preenche os 6 textareas E clica **Save** (`.btnconnect-enable:has-text("Save")`). Página fica aberta no Edge.
7. **Send (humano-only)** — usuário revisa visualmente e clica **Send** manualmente no Edge. A ferramenta NUNCA clica Send/Submit (`#btnSubmit`).

## Workflow: solicitar Perspective

1. `request-perspective <upn-or-alias>` digita o alias em `#txtAliasSearch`. Você escolhe a pessoa do dropdown, picka template, escreve framing note no Edge e envia manualmente.

## Workflow: meu próprio Connect

1. `draft-my-connect priorities|core|impact|growth|checkin` gera scaffold `.md` em `drafts/` e abre **Connect V2** (`v2.msconnect.microsoft.com` — host diferente, app SPA mais nova).
2. Connect próprio é **sempre paste manual** — implicações sensíveis (calibração, perf review). Não temos auto-submit.
3. Conteúdo do scaffold deve ser populado upstream pelo agente com evidência de MSX (deals/ACR/forecast), SPT-IQ (consumption), WorkIQ (entregas).

## Voice & Context

- **Tom:** sempre carregar `~/.copilot/skills/my-voice/voice-profile.md` antes de gerar texto
- **Contexto:** chamar WorkIQ para o relacionamento específico (reviewer ↔ reviewee)
- **Idioma:** seguir regras de routing do my-voice (PT-BR para parceiros LATAM,
  EN para v-team / Connect oficial corporativo)

## Safety

- **Nunca** submete sem confirmação explícita do usuário (input "yes" no terminal)
- Drafts vão para arquivo `.md` antes de qualquer interação com o site
- `recon/` guarda evidência (screenshots) para troubleshooting
- Se o DOM mudar, basta rodar `recon` de novo e atualizar seletores

## Estrutura

```
{{WORKDIR_LOCAL}}\ms-connect\
  scripts\
    start_edge_debug.ps1         # sobe Edge com :9222
    connect_automation.py        # CLI principal
  drafts\                        # rascunhos .md (revisão humana)
  recon\                         # screenshots + DOM dumps
  requirements.txt
```

## Gotchas conhecidos

- **Angular timing:** o form de resposta carrega em ~2-3s. Sempre `wait_for_selector("textarea.perspective-subquestion-text")` antes de scrape.
- **Change detection:** `loc.fill(text)` sozinho não dispara o ngModel. Disparar manualmente `input`+`change`+`blur` events via `evaluate`.
- **reqId vs pernr:** o número no id do botão `providePerspective_<N>_<seq>` É o reqId (não o pernr do requester, apesar do nome). Usar direto na URL `/perspective/<N>/provide?mmf=0`.
- **Manager view duplica cards:** mesmo request aparece como `providePerspective_X_2` E `providePerspective_mgr_X_2`. `cmd_inbox` deduplica por nome+role.
- **slug do recon não escapa `?`:** ao rodar `recon --path /x?y=1` o filename quebra. Use paths sem query string ou ajuste o slug.

## Próximos passos (Phase 3 — opcional)

1. Drill no Connect V2 (`v2.msconnect.microsoft.com`) — descobrir DOM de Priorities/Impact/Growth/Check-in pra eventualmente fazer paste programático (com salvaguardas extras)
2. Testar `outbox` e `request-perspective` end-to-end
3. Adicionar `decline-response <reqId>` (botão Decline já visível no inbox)
4. Cache leve de WorkIQ por reviewer pra acelerar drafts repetidos
