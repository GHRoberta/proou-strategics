---
name: tpm-intel-refresh
description: >
  Incremental refresh of the "📡 Recent intel" feed on the back of every
  TPM Cockpit card EXCEPT cards in the Done column. Scans the user's M365
  emails + Teams chats (group chats incluidos) via WorkIQ for the window
  since each card's `intel.lastScannedAt`, dedupes, sorts newest-first,
  and writes the deltas into `kanban_data.js` using `intel_scan.py`.
  Use whenever the user asks to refresh / update / atualizar the cards'
  intel, recent activity feed, "verso do cartão", or asks for any variant
  of "rode o intel scan", "atualize as informações dos cartões",
  "varra emails e Teams para os cartões". Triggers: refresh intel,
  update cards intel, atualizar intel, varrer cartões, scan emails Teams,
  atualizar verso dos cartões, rodar intel_scan, recent intel feed.
---

# TPM Intel Refresh — incremental scan for all non-Done cards

> Companion skill to **tpm-cockpit**. The cockpit skill owns the data
> model + view. This skill owns the **operational refresh** of the
> `card.intel` block across the active pipeline.

## When to use

ALWAYS when the user asks to:
- Refresh / update / re-scan the "intel feed" on cards
- Look for new emails / Teams messages relevant to cards' content
- Update the back-of-card recent activity
- Run the incremental delta scan (vs starting over)

DO NOT use this skill for:
- Cards in the **Done** column — their intel is frozen at scan time;
  re-scanning closed deliveries adds noise without value
- Cards in the **Inactive** (`backlog`) column — handled by audit rule
  R0b_INACTIVE_RECENT_ACTIVITY (see tpm-cockpit § 6); presence of
  recent activity is a *signal to promote*, not to enrich
- The first-time intel build on a brand-new card — the first scan can
  be done by this skill too, but it will run an unbounded 90-day query

## 1. Files in play

| Path | Role |
|---|---|
| `{{WORKDIR}}\kanban_data.js` | Source of truth. Each card may carry `intel: { lastScannedAt, updates:[…] }`. |
| `{{WORKDIR}}\intel_scan.py` | The injector. Supports `--columns`, `--inject FILE`, `--list`, `--since`. |
| `{{WORKDIR}}\kanban_view.html` | Renders the feed via `renderIntel()` on the back of each card. |

## 2. Scope (which cards to scan)

**Target columns (in order of priority):**
1. `discussion` — pipeline conversations (highest signal density)
2. `submit` — awaiting TPC submission
3. `pending` — awaiting [CONTATO]'s approval
4. `approved` — Executing (operational signals: scheduling, attendance)

**Excluded columns:**
- `done` — closed; do not re-scan
- `backlog` (Inactive) — see § 1 disclaimer above

The scan is invoked as:

```powershell
cd '{{WORKDIR}}'
python intel_scan.py --columns discussion,submit,pending,approved --list
```

Or, equivalently (since the scope is "everything except Done"):

```powershell
python intel_scan.py --columns all --list
```

The `all` keyword expands to `discussion,submit,pending,approved,done`,
so when you really want to **exclude Done**, use the explicit comma-list.

## 3. The 4-step refresh workflow

### Step 1 — Discover scope and per-card cursor

```powershell
python intel_scan.py --columns discussion,submit,pending,approved --list
```

For each row, capture:
- Column id
- Customer name
- `lastScannedAt` (ISO timestamp; `—` means never scanned)
- Update count (for sanity)

**Group by customer** — one customer can have multiple cards across
columns (e.g., [CLIENTE] Seguros has 2 in `pending`; [CLIENTE]
has 2 in `approved`). One WorkIQ query per customer covers all of
them; the injector replicates the deltas to every matching card.

### Step 2 — Compute the per-customer "since" cursor

For each customer, take the **earliest** `lastScannedAt` across that
customer's targeted cards (so we don't miss anything for any of them).
If any card has `lastScannedAt = —`, treat the cursor as "90 days ago"
(date.today() − 90).

> **Rule of thumb:** if all cursors are within 24h of now, skip the
> customer (no meaningful delta to fetch). Tell the user "no refresh
> needed" instead of burning a WorkIQ call.

### Step 3 — Parallel WorkIQ queries

Fire **one `workiq.ask_work_iq` call per customer** in parallel.
WorkIQ handles emails + Teams (1:1, group chats, channel) + meetings
in a single query.

**Query template** (adapt the topic context per card content):

```
List up to 6 most relevant emails and Teams messages from the last
{N} days (since {YYYY-MM-DD}) about {CUSTOMER} related to {topic
hints derived from card title/AER/training code}. For each: date
YYYY-MM-DD, source (email/teams), sender name, 1-2 sentence summary.
Order most recent to oldest.
```

**Topic hints** — pull from the card's title and chips:
- Training codes (MS-4023, AI-3025, AZ-104, …)
- AER IDs if present
- Partner/TSP name (Green, Fast Lane, KA Solution)
- Delivery model keywords (TSPc, PD, SWM, Copilot Chat webinars)
- Specific people ([CONTATO], Carlos, customer POC if known)

**Avoid topic drift:** if a customer has cards in multiple columns
with different content (e.g., [CLIENTE] has both AI-900 done cards and a
new MS-4023 approved card), formulate ONE query that covers all
relevant topics so a single payload entry can be replicated to all
cards. Do **not** run separate per-card queries for the same customer.

> ⚠️ **When scopes diverge** (e.g., one customer has 3 active cards:
> TSPc MS-4023 + PD MS-4019 + SWM webinar), broadcasting all signals
> to all cards causes cross-contamination (false attention flags,
> sibling-AER mentions on wrong cards). For those customers, use
> **scoped payload entries** (see Step 4 below) so each signal only
> lands on the card whose AER scope matches.

### Step 4 — Build payload + inject

The injector supports **three routing modes**, mixable in the same
payload:

**(a) Broadcast — legacy default** (no scope; signal lands on every
card with the matching `customer`):

```json
{
  "[CLIENTE] Seguros": [
    {"date":"2026-04-24","source":"email","from":"[CONTATO]","summary":"…"},
    {"date":"2026-04-23","source":"teams","from":"{{USER_NAME}}","summary":"…"}
  ]
}
```

**(b) Key-scoped** — the customer key carries `|| AER-XXX`; the entire
group is routed only to cards owning that AER:

```json
{
  "[CLIENTE] || AER-137527": [
    {"date":"2026-05-13","source":"email","from":"Microsoft ESI","summary":"MS-4019.S delivery 102659 Ready for Scheduling"}
  ]
}
```

**(c) Per-update scope** — mix scoped and broadcast updates under a
single customer key by tagging individual updates with `scope`:

```json
{
  "[CLIENTE]": [
    {"date":"…","source":"email","summary":"AER-137527 PD signal","scope":"AER-137527"},
    {"date":"…","source":"email","summary":"AER-136867 TSPc signal","scope":"AER-136867"},
    {"date":"…","source":"teams","summary":"Customer Mauro caixa.gov.br — general"}
  ]
}
```

**Routing rules** (most-specific wins):
1. Update has `scope: "AER-XXX"` → only cards whose `aer.id`/`aers[].id`
   matches.
2. Key has `|| AER-XXX` suffix → same rule applies to the whole group.
3. Neither → broadcast (legacy behavior preserved for backwards compat).

The `scope` field is **metadata for the injector only** — it is stripped
from persisted update entries (you won't see it on the card markdown
after inject).

Then inject:

```powershell
python intel_scan.py --columns discussion,submit,pending,approved `
  --inject _intel_payload_YYYYMMDD.json
```

The injector:
- Looks up cards by `customer` name (exact match) across the targeted
  columns.
- Applies scope filter per the routing rules above.
- Dedupes against existing `updates` using key
  `(date, source, summary[:80])`.
- Sorts the resulting feed newest-first.
- Bumps `intel.lastScannedAt` to the current timestamp (or to the value
  passed via `--since` if explicitly overriding).

After injection, **delete the temporary payload file** — it's a
single-use artifact, not a long-lived asset.

## 4. Customer-name matching gotchas

`kanban_data.js` uses display names that don't always match the
WorkIQ-returned canonical name. Known aliases (V1.1):

| Variants present in cards | Notes |
|---|---|
| `[CLIENTE] Seguros` vs `[CLIENTE]` | TWO distinct customers (insurance vs bank). NEVER merge their intel. |
| `[CLIENTE]` vs `[CLIENTE]` | Same customer, two casings. Build payload entries under BOTH keys when both exist on the board. |
| `[CLIENTE]` vs `[CLIENTE]` | Same. Same fix as above. |
| `[CLIENTE]` vs `[CLIENTE] Brasil` | Same. Same fix. |
| `[CLIENTE]` vs `[CLIENTE] — Manual SWM` | Manual SWM is a legacy bucket, no recent activity expected. **Skip.** |
| `[CLIENTE]` vs `[CLIENTE] — Manual SWM` | Same. Skip the Manual SWM bucket. |
| `[CLIENTE] SP` | Single key. Multiple Done cards under same customer name — all get same intel. |

**Pattern:** when an aliased customer appears across different cards,
the payload should include BOTH spellings as top-level keys with the
same updates list. The injector matches by exact string equality.

## 5. The "no signal" case

WorkIQ may legitimately return "no operational signals in the
specified window" (e.g., [CLIENTE] during execution lulls). Two valid
responses:

1. **If the customer has cards in `discussion` with intel** → backfill
   the empty cards' `intel` from the discussion intel of the same
   customer name. This was done in V1.1 phase-2 for [CLIENTE]/[CLIENTE]/
   [CLIENTE] Done cards. Use the inline backfill snippet (§ 6).
2. **Otherwise** → leave the card's intel empty and report it. Do NOT
   fabricate updates. The empty state is a valid finding — show it in
   the recap.

## 6. Inline helpers

### 6a. Backfill empty cards from same-customer Discussion intel

Save as `_backfill.py`, run, delete:

```python
import re, json, pathlib, datetime
p = pathlib.Path('kanban_data.js')
t = p.read_text(encoding='utf-8')
m = re.search(r'^(window\.KANBAN_DATA\s*=\s*)(\{.*\})\s*;?\s*$', t, re.DOTALL)
prefix, body = m.group(1), m.group(2)
d = json.loads(body)
disc = {c['customer']: c['intel'] for col in d['columns']
        if col['id'] == 'discussion' for c in col['cards'] if c.get('intel')}
now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
TARGET = {'submit', 'pending', 'approved'}   # NOT 'done'
n = 0
for col in d['columns']:
    if col['id'] not in TARGET: continue
    for c in col['cards']:
        if c.get('intel', {}).get('updates'): continue
        if c.get('customer') in disc:
            c['intel'] = {'lastScannedAt': now, 'updates': list(disc[c['customer']]['updates'])}
            n += 1
p.write_text(prefix + json.dumps(d, indent=2, ensure_ascii=False) + ';\n', encoding='utf-8')
print(f'Backfilled {n}')
```

### 6b. Quick "what changed" diff (after injection)

```powershell
python intel_scan.py --columns discussion,submit,pending,approved --list `
  | Select-String -Pattern 'updates=0|lastScan=—'
```

Anything still showing `updates=0` or `lastScan=—` after a refresh is
either (a) Manual SWM legacy or (b) a customer with no signals.
Report both classes explicitly to the user.

## 7. Rate limit / efficiency rules

- **Parallelize WorkIQ calls** — issue all per-customer queries in a
  single response. Typical refresh = 10–15 customers across the four
  target columns.
- **Don't re-scan customers whose `lastScannedAt` is < 24h old** unless
  the user explicitly says "force refresh".
- **Don't query Done cards.** Their cursor is frozen. If the user
  insists, use `--columns done` separately and warn that signals will
  mostly be retrospective (post-mortem feedback, attainment reports).
- Cap each WorkIQ query at **6 results** for incremental refreshes
  (vs 8 for first-time scans) — the delta window is shorter, so 6 is
  almost always more than enough.

## 8. Reporting back to the user

After every run, output:

```
Refreshed N cards across M customers
  + new updates per card (counts)
  ⚠ no signals: <list of customers>
  🛑 skipped (recent scan <24h): <list of customers>
  📦 Manual SWM legacy (intentionally empty): [CLIENTE] — Manual SWM, [CLIENTE] — Manual SWM
```

Include a single-sentence summary of the most newsworthy delta
(e.g., "Biggest signal: [CLIENTE] Brasil PD MS-4018 reschedule confirmed
for June by Carlos on 2026-04-20").

## 9. Anti-patterns (do NOT do)

- ❌ Re-scan Done cards by default. They are frozen retrospective.
- ❌ Run sequential per-card WorkIQ queries when a single per-customer
  query covers all that customer's cards.
- ❌ Key the payload by `(column, customer)` — the injector keys by
  `customer` ONLY and replicates to all matches. Doing per-column keys
  defeats the whole multi-card-per-customer pattern.
- ❌ Fabricate updates when WorkIQ returns no results. Empty is OK.
- ❌ Edit `kanban_data.js` by hand. Always go through `intel_scan.py`
  so dedup, sort, and the `lastScannedAt` bump are consistent.
- ❌ Forget to delete the temporary payload JSON after injection.
- ❌ Forget to also include the lowercase variant of customer names
  that exist in both casings on the board ([CLIENTE]/[CLIENTE], etc.).

## 10. End-to-end example session

```
User: "atualiza o intel dos cartões"

Agent (this skill):
  1. python intel_scan.py --columns discussion,submit,pending,approved --list
  2. Compute per-customer earliest cursor (skip <24h)
  3. Parallel workiq.ask_work_iq × N (one per customer, scoped to relevant topics)
  4. Build _intel_payload_YYYYMMDD.json
  5. python intel_scan.py --columns discussion,submit,pending,approved --inject _intel_payload_YYYYMMDD.json
  6. Remove the payload file
  7. (Optional) Run §6a backfill if some cards are still empty
  8. Report counts + newsworthy delta + empty/skipped lists
```
