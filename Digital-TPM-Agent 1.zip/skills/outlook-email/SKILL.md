---
name: outlook-email
description: >
  Compose, send, reply, forward, and search Outlook emails via COM automation.
  Requires Outlook desktop to be running. Supports To/CC/BCC, HTML body,
  attachments, Reply/ReplyAll/Forward on received messages, and inbox search.
  Triggers: send email, compose email, reply to email, forward email, draft email,
  outlook, new message, respond to, answer email, buscar email, enviar email.
---

# Outlook Email — COM Automation Skill

> ⛔ **DEPRECATED transport (2026-06-12).** Outlook COM is **prohibited** per
> MANDATE **M1** (`~/.copilot/copilot-instructions.md`) and `my-voice` §6: COM
> fails on new Outlook and clutters the mailbox. **Default to the local `.eml`
> route** — build the message, save to `{{WORKDIR_LOCAL}}\drafts\`, and open it
> (canonical snippet in `my-voice/voice-profile.md` §6, working example in
> `oe-grade-email/save_oe_eml.py`). Also banned: Graph
> `agent365-mail-CreateDraftMessage` (mailbox drafts). Use the COM examples
> below **only** if the user explicitly insists on COM this time.

## When to Use

Load this skill when the user wants to:

- **Compose** a new email (with To, CC, BCC, attachments, HTML body)
- **Reply** or **Reply All** to a received email
- **Forward** an email
- **Search** inbox for specific emails (by sender, subject, date)
- **List** recent emails to pick one for reply/forward

**Do NOT use** when:
- User wants to *read* email intelligence (use **workiq** skill instead)
- User wants MSX-specific email drafts (use **msx-copilot-tools**)
- Outlook desktop is not running

## Prerequisites

1. **Outlook desktop must be running** — COM connects to the live Outlook process
2. **PowerShell 5.1** (`powershell.exe`) — COM interop requires .NET Framework
3. The user's default email account in Outlook will be used as sender

## Runtime Note

All scripts below MUST run under **PowerShell 5.1** (`powershell.exe`), NOT pwsh.
Use: `powershell.exe -Command "& { <script> }"` or `powershell.exe -File <script.ps1>`

---

## 1. Compose & Send a New Email

### Minimal Example (display draft)

```powershell
powershell.exe -Command "& {
    $ol   = New-Object -ComObject Outlook.Application
    $mail = $ol.CreateItem(0)
    $mail.To      = 'recipient@example.com'
    $mail.Subject = 'Subject line'
    $mail.HTMLBody = '<p>Email body here</p>'
    $mail.Display()   # opens draft for review
}"
```

### Full Example (CC, BCC, attachments, importance, send)

```powershell
powershell.exe -Command "& {
    param(
        [string]$To,
        [string]$CC        = '',
        [string]$BCC       = '',
        [string]$Subject,
        [string]$Body,
        [string]$BodyFormat = 'HTML',     # HTML | Plain
        [string[]]$Attachments = @(),
        [string]$Importance = 'Normal',   # Low | Normal | High
        [switch]$Send,                     # if set, sends immediately; else displays draft
        [switch]$ReadReceipt
    )

    $ol   = New-Object -ComObject Outlook.Application
    $mail = $ol.CreateItem(0)

    $mail.To  = $To
    if ($CC)  { $mail.CC  = $CC }
    if ($BCC) { $mail.BCC = $BCC }
    $mail.Subject = $Subject

    # Body format
    if ($BodyFormat -eq 'HTML') {
        $mail.HTMLBody = $Body
    } else {
        $mail.Body = $Body
    }

    # Importance: 0=Low, 1=Normal, 2=High
    $mail.Importance = switch ($Importance) {
        'Low'    { 0 }
        'High'   { 2 }
        default  { 1 }
    }

    if ($ReadReceipt) {
        $mail.ReadReceiptRequested = $true
    }

    # Attachments
    foreach ($att in $Attachments) {
        if (Test-Path $att) {
            $mail.Attachments.Add((Resolve-Path $att).Path) | Out-Null
        } else {
            Write-Warning \"Attachment not found: $att\"
        }
    }

    if ($Send) {
        $mail.Send()
        Write-Host 'Email sent successfully.'
    } else {
        $mail.Display()
        Write-Host 'Draft opened in Outlook for review.'
    }
}" -To 'recipient@example.com' -Subject 'Hello' -Body '<p>Content</p>' -CC 'cc@example.com' -Attachments 'C:\file.pdf'
```

### Signature Handling

Outlook automatically appends the user's default signature when `Display()` is called.
To **preserve the signature** while setting HTML body:

```powershell
$mail.Display()                         # trigger signature insertion
$mail.HTMLBody = $Body + $mail.HTMLBody  # prepend your content before signature
```

---

## 2. Search Emails (Find Messages to Reply/Forward)

### Search by Subject

```powershell
powershell.exe -Command "& {
    $ol    = New-Object -ComObject Outlook.Application
    $ns    = $ol.GetNamespace('MAPI')
    $inbox = $ns.GetDefaultFolder(6)  # 6 = olFolderInbox

    $filter = ""@SQL=""""urn:schemas:httpmail:subject"""" LIKE '%search term%'""
    $items  = $inbox.Items.Restrict($filter)

    $results = @()
    foreach ($item in $items) {
        $results += [PSCustomObject]@{
            EntryID     = $item.EntryID
            Subject     = $item.Subject
            From        = $item.SenderName
            ReceivedAt  = $item.ReceivedTime.ToString('yyyy-MM-dd HH:mm')
        }
    }
    $results | Sort-Object ReceivedAt -Descending | Select-Object -First 10 |
        Format-Table -AutoSize
}"
```

### Search by Sender

```powershell
$filter = "@SQL=""urn:schemas:httpmail:fromemail"" LIKE '%sender@example.com%'"
```

### Search by Date Range

```powershell
$filter = "@SQL=""urn:schemas:httpmail:datereceived"" >= '2026-03-01' AND ""urn:schemas:httpmail:datereceived"" <= '2026-03-17'"
```

### Combined Search (Subject + Sender + Date)

```powershell
$filter = "@SQL=""urn:schemas:httpmail:subject"" LIKE '%keyword%' AND ""urn:schemas:httpmail:fromemail"" LIKE '%sender@%' AND ""urn:schemas:httpmail:datereceived"" >= '2026-03-01'"
```

### List Recent Inbox Emails (last N)

```powershell
powershell.exe -Command "& {
    $ol    = New-Object -ComObject Outlook.Application
    $ns    = $ol.GetNamespace('MAPI')
    $inbox = $ns.GetDefaultFolder(6)
    $items = $inbox.Items
    $items.Sort('[ReceivedTime]', $true)  # descending

    $results = @()
    $count = 0
    foreach ($item in $items) {
        if ($count -ge 20) { break }
        if ($item.Class -eq 43) {  # 43 = olMail
            $results += [PSCustomObject]@{
                Index      = $count
                EntryID    = $item.EntryID
                Subject    = $item.Subject
                From       = $item.SenderName
                ReceivedAt = $item.ReceivedTime.ToString('yyyy-MM-dd HH:mm')
                HasAttach  = $item.Attachments.Count -gt 0
            }
            $count++
        }
    }
    $results | Format-Table -AutoSize
}"
```

---

## 3. Reply to an Email

### Reply (to sender only)

```powershell
powershell.exe -Command "& {
    param([string]$EntryID, [string]$ReplyBody)

    $ol   = New-Object -ComObject Outlook.Application
    $ns   = $ol.GetNamespace('MAPI')
    $msg  = $ns.GetItemFromID($EntryID)
    $reply = $msg.Reply()

    # Prepend reply text before quoted original
    $reply.HTMLBody = $ReplyBody + $reply.HTMLBody
    $reply.Display()   # or $reply.Send()
}" -EntryID '<entry-id-from-search>' -ReplyBody '<p>Thank you for your email.</p>'
```

### Reply All

```powershell
$reply = $msg.ReplyAll()
$reply.HTMLBody = $ReplyBody + $reply.HTMLBody
$reply.Display()
```

### Forward

```powershell
powershell.exe -Command "& {
    param([string]$EntryID, [string]$ForwardTo, [string]$ForwardBody)

    $ol   = New-Object -ComObject Outlook.Application
    $ns   = $ol.GetNamespace('MAPI')
    $msg  = $ns.GetItemFromID($EntryID)
    $fwd  = $msg.Forward()

    $fwd.To = $ForwardTo
    $fwd.HTMLBody = $ForwardBody + $fwd.HTMLBody
    $fwd.Display()   # or $fwd.Send()
}" -EntryID '<entry-id>' -ForwardTo 'someone@example.com' -ForwardBody '<p>FYI - see below.</p>'
```

---

## 4. Reply with Attachments

```powershell
$reply = $msg.Reply()
$reply.HTMLBody = $ReplyBody + $reply.HTMLBody
$reply.Attachments.Add('C:\path\to\file.pdf') | Out-Null
$reply.Display()
```

---

## 5. Read Email Body (for context before replying)

```powershell
powershell.exe -Command "& {
    param([string]$EntryID)
    $ol  = New-Object -ComObject Outlook.Application
    $ns  = $ol.GetNamespace('MAPI')
    $msg = $ns.GetItemFromID($EntryID)

    Write-Host '=== FROM ===' $msg.SenderName '<' $msg.SenderEmailAddress '>'
    Write-Host '=== DATE ===' $msg.ReceivedTime
    Write-Host '=== SUBJECT ===' $msg.Subject
    Write-Host '=== TO ===' $msg.To
    Write-Host '=== CC ===' $msg.CC
    Write-Host '=== BODY ==='
    $msg.Body  # plain text version
}" -EntryID '<entry-id>'
```

---

## 6. Workflow — Full Reply Flow

The typical workflow for replying to an email:

1. **Search** for the email (Section 2)
2. **Read** the email body for context (Section 5)
3. **Compose reply** text (use AI to help draft)
4. **Reply/ReplyAll/Forward** (Section 3)
5. **Review** the draft in Outlook, then send manually (or auto-send)

### Example: Find and Reply to Latest Email from Someone

```powershell
powershell.exe -Command "& {
    param([string]$SenderEmail, [string]$ReplyBody, [switch]$ReplyAll, [switch]$Send)

    $ol    = New-Object -ComObject Outlook.Application
    $ns    = $ol.GetNamespace('MAPI')
    $inbox = $ns.GetDefaultFolder(6)

    # Find latest email from sender
    $filter = ""@SQL=""""urn:schemas:httpmail:fromemail"""" LIKE '%$SenderEmail%'""
    $items  = $inbox.Items.Restrict($filter)
    $items.Sort('[ReceivedTime]', $true)

    $msg = $items.GetFirst()
    if (-not $msg) {
        Write-Error ""No email found from $SenderEmail""
        return
    }

    Write-Host ""Found: [$($msg.Subject)] from $($msg.SenderName) at $($msg.ReceivedTime)""

    if ($ReplyAll) {
        $reply = $msg.ReplyAll()
    } else {
        $reply = $msg.Reply()
    }

    $reply.HTMLBody = $ReplyBody + $reply.HTMLBody

    if ($Send) {
        $reply.Send()
        Write-Host 'Reply sent.'
    } else {
        $reply.Display()
        Write-Host 'Reply draft opened for review.'
    }
}" -SenderEmail '{{EMAIL}}' -ReplyBody '<p>Thanks! I will review and get back to you.</p>'
```

---

## 7. Outlook Folder Constants

| Constant | Value | Folder |
|----------|-------|--------|
| olFolderInbox | 6 | Inbox |
| olFolderSentMail | 5 | Sent Items |
| olFolderDrafts | 16 | Drafts |
| olFolderDeletedItems | 3 | Deleted Items |
| olFolderOutbox | 4 | Outbox |
| olFolderJunk | 23 | Junk Email |

---

## 8. Common Pitfalls

| Pitfall | Solution |
|---------|----------|
| **COM fails in pwsh/PS7** | Always use `powershell.exe` (PS 5.1) |
| **COM hangs / zombie instances** | If COM calls hang, close and reopen Outlook, or kill zombie `OUTLOOK.EXE` processes |
| **Signature disappears** | Call `Display()` first, then prepend to `HTMLBody` |
| **EntryID changes across sessions** | EntryIDs are stable within a profile but may change after PST moves |
| **Security prompt** | Outlook may show a security dialog for programmatic access — user must click Allow |
| **Large search results** | Always limit with `Select-Object -First N` or date filters |
| **HTML encoding** | Use HTML entities for accented characters (PT-BR): `á`→`&#225;` `ã`→`&#227;` `ç`→`&#231;` `é`→`&#233;` `õ`→`&#245;` `ú`→`&#250;` etc. PS 5.1 COM corrupts raw UTF-8 in HTMLBody |
| **Script vs inline** | For complex scripts, write to a `.ps1` temp file and run via `powershell.exe -File` to avoid escaping issues |

---

## 9. HTML Email Templates

### Professional Reply Template

```html
<div style="font-family: Calibri, sans-serif; font-size: 11pt;">
    <p>Hi {{Name}},</p>
    <p>{{Body}}</p>
    <p>Best regards,<br/>{{USER_FIRST_NAME}}</p>
</div>
<hr/>
```

### Action Required Template

```html
<div style="font-family: Calibri, sans-serif; font-size: 11pt;">
    <p style="color: #c00; font-weight: bold;">⚡ Action Required</p>
    <p>Hi {{Name}},</p>
    <p>{{Body}}</p>
    <p>Please respond by <strong>{{Deadline}}</strong>.</p>
    <p>Thanks,<br/>{{USER_FIRST_NAME}}</p>
</div>
```
