"""Gera .eml (RFC 822) a partir do HTML produzido por `build_oe_email.py`
e abre no handler default (new Outlook / Outlook web / cliente padrão).

Regra de transporte (MANDATE M1): NUNCA usar Outlook COM nem Graph
`agent365-mail-CreateDraftMessage` (ver voice-profile.md §6). Rota canônica:
.eml local em {{WORKDIR_LOCAL}}\drafts + abrir.

Uso:
    python save_oe_eml.py
    python save_oe_eml.py --html X --eml Y --subject "..."
"""
import pathlib, sys, subprocess, argparse
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

DEFAULT_ROOT = pathlib.Path(r'{{WORKDIR}}')  # intermediários (HTML)
DRAFT_DIR    = pathlib.Path(r'{{WORKDIR_LOCAL}}\drafts')  # MANDATE M1: .eml em working dir LOCAL
DRAFT_DIR.mkdir(parents=True, exist_ok=True)
DEFAULT_HTML = DEFAULT_ROOT / '_oe_email_body.html'
DEFAULT_EML  = DRAFT_DIR / 'OE_Grade_ESI_PTBR.eml'
DEFAULT_SUBJ = 'Grade de turmas Microsoft ESI — convite para inscrição (PT-BR)'

ap = argparse.ArgumentParser()
ap.add_argument('--html', type=pathlib.Path, default=DEFAULT_HTML)
ap.add_argument('--eml',  type=pathlib.Path, default=DEFAULT_EML)
ap.add_argument('--subject', default=DEFAULT_SUBJ)
ap.add_argument('--to', default='[Destinatário]')
ap.add_argument('--no-open', action='store_true')
args = ap.parse_args()

if not args.html.exists():
    sys.exit(f'HTML body não encontrado: {args.html}  — rode build_oe_email.py antes')

html_body = args.html.read_text(encoding='utf-8')

msg = EmailMessage()
msg['Subject'] = args.subject
msg['From'] = '{{USER_NAME}} <{{EMAIL}}>'
msg['To'] = args.to
msg['Date'] = formatdate(localtime=True)
msg['Message-ID'] = make_msgid(domain='microsoft.com')
msg['X-Unsent'] = '1'  # marca como draft em vários clientes
msg.set_content('Este email contém conteúdo HTML. Use um cliente compatível para visualizar.')
msg.add_alternative(html_body, subtype='html')

args.eml.write_bytes(bytes(msg))
size_kb = args.eml.stat().st_size / 1024
print(f'✓ .eml gerado: {args.eml.name} ({size_kb:.1f} KB)')
print(f'  Caminho: {args.eml}')

if not args.no_open:
    subprocess.Popen(['cmd', '/c', 'start', '', str(args.eml)], shell=False)
    print('✓ Aberto no handler default')
