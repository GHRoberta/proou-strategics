---
name: oe-grade-email
description: >
  Gera um email HTML profissional com a grade de turmas Open Enrollment
  (OE) próximas, agrupadas por mês, com títulos em português simplificado,
  link de inscrição no ESI, público-alvo, objetivo e benefício de cada
  curso. Cria como rascunho no Outlook do usuário (não envia). Use sempre
  que o usuário pedir "email com grade de OE", "newsletter de turmas
  abertas", "email para [pessoa] com calendário de treinamentos", "envia
  para [TPC] a grade de turmas", "agenda OE em email", ou similar.
  Triggers: email grade OE, email turmas, newsletter OE, calendário OE
  por email, grade em email, agenda treinamentos email, draft Outlook
  treinamentos, comunicar turmas abertas.
---

# OE Grade Email — Email HTML com Grade de Turmas Abertas

Gera um email-rascunho no Outlook contendo a grade de turmas OE próximas,
visualmente formatado em **cards agrupados por mês**, com títulos em
português simplificado, código original como tag colorida, e link de
inscrição no ESI para cada turma.

## Pré-requisitos

- Skill **`oe-schedule`** já executado (gera o CSV-base com as turmas)
- Acesso ao Outlook do usuário via `agent365-mail-*`
- Python 3 (apenas stdlib + leitura de CSV)

## Workflow

### 1. Obter a grade base

Use o skill **`oe-schedule`** com filtros desejados (idioma, janela de
datas) e salve em CSV no diretório de trabalho. Exemplo:
`OE_Classes_PT_<period>.csv`. Colunas obrigatórias:
`Inicio_BRT, Fim_BRT, Curso, Modalidade, Idioma, Vagas_Disp, Delivery_ID`.

### 2. Confirmar destinatário e contexto

**Pergunte ao usuário** antes de gerar:
- Para quem é o email (nome completo + email)?
- Conta/cliente associado (ex.: [CLIENTE], [CLIENTE])?
- Janela de tempo (ex.: "próximos 3 meses", "Q4")?
- Algum filtro extra (ex.: só com vagas, modalidade VILT)?

### 3. Mapear códigos de curso → título PT simplificado

Mantenha um `COURSE_META` dict no script gerador. Cada entrada:

```python
"MS-4018": {
    "title_pt":   "Microsoft 365 Copilot — Redigir, analisar e apresentar",
    "audience":   "Usuários finais de M365 que querem ganhar produtividade com IA",
    "objective":  "Capacitar a usar o Copilot no Word, Excel, PowerPoint e Outlook",
    "benefit":    "Reduz tempo em tarefas repetitivas e acelera análises",
    "esi_url":    "https://esi.microsoft.com/...",  # link real de inscrição
},
```

Cobertura mínima recomendada para o catálogo Brasil 2026:
`AI-3025, AI-3026, MS-4018, MS-4012, AZ-2017, AZ-2003, SC-5004, PL-1000, ...`

> ⚠️ **Sempre simplifique o título em PT** — o nome original (ex.:
> "MS-4018 Draft, analyze, and present with Microsoft 365 Copilot") fica
> apenas como **tag colorida pequena** ao lado do título amigável.

### 4. Gerar HTML

**Estrutura do card** (uma turma):

```
┌─────────────────────────────────────────────────────────┐
│ [TAG: MS-4018]      📅 12/05/2026  •  09:00–17:00 BRT   │
│                                                          │
│ Microsoft 365 Copilot — Redigir, analisar e apresentar  │
│                                                          │
│ 🎯 Público:    Usuários finais de M365...               │
│ 📘 Objetivo:   Capacitar a usar o Copilot...            │
│ ✨ Benefício:  Reduz tempo em tarefas repetitivas...    │
│                                                          │
│ 🎟️ 23 vagas restantes      ▶ Inscrever-se no ESI →      │
└─────────────────────────────────────────────────────────┘
```

Agrupe os cards **por mês** com cabeçalho colorido (`Abril 2026`,
`Maio 2026`, …). Use `Segoe UI` e cores Microsoft (`#0078D4` headings,
`#003A70` títulos, `#605E5C` subtítulos).

### 5. ⚠️ Python f-string + Python <3.12 (gotcha)

Não pode usar barra invertida em expressão de f-string:

```python
# ❌ SyntaxError no Python <3.12
html = f"<span>{c["color"]}</span>"

# ✅ Funciona
color = c["color"]
html = f"<span>{color}</span>"
```

Sempre extraia o valor para uma variável local antes de interpolar.

### 6. Gerar o rascunho como `.eml` local (MANDATE M1)

Use o script `.eml` deste skill — **NÃO** use `agent365-mail-CreateDraftMessage`
nem Outlook COM (proibidos; entopem a pasta Rascunhos). O `.eml` é salvo em
`{{WORKDIR_LOCAL}}\drafts\` e aberto no new Outlook.

```powershell
python build_oe_email.py            # gera o HTML (_oe_email_body.html)
python save_oe_eml.py `             # gera o .eml em {{WORKDIR_LOCAL}}\drafts e abre
  --to "{{EMAIL}}" `
  --subject "Grade de turmas Microsoft (Abr-Jun/2026) - convite para inscricao"
```

Re-geração: regere o HTML e rode `save_oe_eml.py` de novo (sobrescreve o `.eml`).
Sempre **deixe como rascunho** — o `.eml` abre pronto; o usuário revisa e envia.
Reporte o **caminho do `.eml`** e confirme que abriu.

### 7. Limpeza

Apague o script gerador e arquivos intermediários (`_email_*.py`,
`_email_*.html`, `_email_payload.json`) após sucesso. Mantenha o CSV
da grade caso o usuário queira reutilizar.

## Cobertura mínima de campos por turma

| Campo | Origem | Obrigatório |
|-------|--------|-------------|
| Código (tag) | CSV → coluna `Curso` (primeiro token: `MS-4018`) | Sim |
| Título PT simplificado | `COURSE_META[code].title_pt` | Sim |
| Data e hora | CSV → `Inicio_BRT` / `Fim_BRT` | Sim |
| Modalidade | CSV → `Modalidade` (VILT/ILT) | Opcional (badge) |
| Vagas | CSV → `Vagas_Disp` | Sim |
| Público-alvo | `COURSE_META[code].audience` (≤ 20 palavras) | Sim |
| Objetivo | `COURSE_META[code].objective` (≤ 20 palavras) | Sim |
| Benefício | `COURSE_META[code].benefit` (≤ 20 palavras) | Sim |
| Link ESI | `COURSE_META[code].esi_url` | Sim |

## Histórico

- **Edmilce ([CLIENTE]), Abr/2026** — 34 turmas Abr–Jun 2026, 16 cursos
  únicos, ~40 KB HTML, draft `AAkALgAAAAAAHYQDEapmEc2byACqAC...`
  atualizado via `UpdateDraft`.

## Cross-reference

- **`oe-schedule`** — gera o CSV-base de turmas OE
- **`private-deliveries`** — para grade de PD (não OE)
- **`learning-trail-pptx`** — para criar trilha de capacitação completa
  (não apenas grade de turmas)
