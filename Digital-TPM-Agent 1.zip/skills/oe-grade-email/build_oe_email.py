"""Gera HTML do email OE Grade (PT-BR) — template canônico.

Lê CSV gerado pela skill `oe-schedule` (default: OE_Classes_PTBR_3M.csv em
ghcli-working/), monta cards agrupados por código de curso (1 card por
curso, N botões "Inscrever-se" por data) divididos em 6 domínios
(Segurança, Azure, Dados, IA, GitHub, Copilot). Output: HTML pronto pra
embutir num .eml (ver `save_oe_eml.py` complementar).

Uso:
    python build_oe_email.py            # paths default
    python build_oe_email.py --csv X --out Y  # paths customizados

Sempre seguido de:
    python save_oe_eml.py               # gera .eml e abre no handler default

Regra de transporte: NUNCA usar Outlook COM (ver voice-profile.md §6
"Transport: NO Outlook COM"). Sempre rota .eml + auto-open.
"""
import csv, pathlib, datetime, html, sys, argparse
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# ──────── paths (overridable via CLI) ────────
DEFAULT_ROOT = pathlib.Path(r'{{WORKDIR}}')
DEFAULT_CSV  = DEFAULT_ROOT / 'OE_Classes_PTBR_3M.csv'
DEFAULT_OUT  = DEFAULT_ROOT / '_oe_email_body.html'

ap = argparse.ArgumentParser()
ap.add_argument('--csv', type=pathlib.Path, default=DEFAULT_CSV)
ap.add_argument('--out', type=pathlib.Path, default=DEFAULT_OUT)
args = ap.parse_args()
CSV_PATH = args.csv
OUT_HTML = args.out

# ──────── COURSE_META (18 cursos únicos) ────────
COURSE_META = {
    'SC-100': {
        'title_pt': 'Microsoft Cybersecurity Architect — desenho de arquitetura Zero Trust',
        'audience': 'Arquitetos de segurança, líderes técnicos de SecOps e identidade.',
        'objective': 'Desenhar arquitetura de segurança end-to-end com Microsoft 365 Defender, Sentinel, Purview e Azure Security.',
        'benefit':  'Habilita o time a propor e justificar arquiteturas Zero Trust alinhadas ao framework MCRA/MCSB.',
    },
    'SC-200': {
        'title_pt': 'Microsoft Security Operations Analyst — defesa com Defender e Sentinel',
        'audience': 'Analistas de SOC, blue team, profissionais de Threat Hunting.',
        'objective': 'Investigar, responder e caçar ameaças com Microsoft 365 Defender e Microsoft Sentinel (SIEM/SOAR).',
        'benefit':  'Reduz MTTR de incidentes e aumenta cobertura de detecção em ambientes Microsoft.',
    },
    'AZ-400': {
        'title_pt': 'Microsoft DevOps Engineer — CI/CD, IaC e observabilidade em Azure',
        'audience': 'Engenheiros DevOps, SREs e líderes técnicos de plataforma.',
        'objective': 'Implementar pipelines CI/CD com GitHub Actions/Azure DevOps, Infrastructure as Code (Bicep/Terraform) e observabilidade.',
        'benefit':  'Acelera entrega e melhora confiabilidade — base para certificação AZ-400.',
    },
    'DP-605': {
        'title_pt': 'Power BI — preparação, modelagem e visualização de dados',
        'audience': 'Analistas de dados, BI developers, profissionais de FP&A e Operações.',
        'objective': 'Conectar, transformar (Power Query), modelar (DAX) e visualizar dados em Power BI.',
        'benefit':  'Habilita autonomia em self-service BI — base para Power BI Data Analyst Associate.',
    },
    'DP-700': {
        'title_pt': 'Microsoft Fabric Data Engineer — engenharia de dados na plataforma unificada',
        'audience': 'Engenheiros de dados, arquitetos de dados, profissionais de Lakehouse/Warehouse.',
        'objective': 'Construir Lakehouses, pipelines de ingestão (Data Factory), notebooks Spark e Real-Time Intelligence em Microsoft Fabric.',
        'benefit':  'Capacita a operar a plataforma de dados unificada da Microsoft — base para certificação DP-700.',
    },
    'AI-3025': {
        'title_pt': 'Work smarter with AI — produtividade individual com IA',
        'audience': 'Knowledge workers de qualquer área que querem ganhar produtividade com IA generativa.',
        'objective': 'Aplicar IA generativa no dia a dia: prompts efetivos, fluxos com Copilot e padrões de uso responsável.',
        'benefit':  'Workshop curto e prático (~3h) — ganho de produtividade imediato sem pré-requisitos técnicos.',
    },
    'AI-3026': {
        'title_pt': 'Develop AI agents on Azure — construindo agentes com Azure AI Foundry',
        'audience': 'Desenvolvedores, arquitetos de soluções IA e líderes técnicos de inovação.',
        'objective': 'Projetar e implementar agentes IA com Azure AI Foundry, Semantic Kernel e padrões de orchestration.',
        'benefit':  'Saída acelerada para projetos de agentes em produção — alinhado à estratégia Azure AI.',
    },
    'AB-730': {
        'title_pt': 'Transform business workflows with generative AI — IA generativa em processos',
        'audience': 'Líderes de área de negócio, gerentes de produto, BPM e transformação digital.',
        'objective': 'Identificar oportunidades de IA generativa em workflows existentes e prototipar soluções com Copilot Studio.',
        'benefit':  'Mapeia ROI de IA em processos reais — ponte entre negócio e tecnologia.',
    },
    'AB-731': {
        'title_pt': 'Drive AI transformation in your organization — estratégia executiva de IA',
        'audience': 'Executivos, diretores, líderes de transformação e responsáveis por estratégia de IA.',
        'objective': 'Estruturar roadmap de adoção de IA na empresa: governança, capacitação, casos de uso priorizados e métricas.',
        'benefit':  'Acelera definição da estratégia corporativa de IA com framework Microsoft.',
    },
    'AI-901': {
        'title_pt': 'Introduction to AI in Azure — fundamentos de IA na nuvem Microsoft',
        'audience': 'Profissionais de qualquer perfil iniciando em IA — pré-requisito zero.',
        'objective': 'Compreender conceitos de ML, Computer Vision, NLP e IA generativa usando serviços Azure AI.',
        'benefit':  'Porta de entrada para o ecossistema Azure AI — base para Azure AI Fundamentals (AI-900).',
    },
    'AI-103': {
        'title_pt': 'Develop AI apps and agents on Azure — Azure AI Engineer trail',
        'audience': 'Desenvolvedores que querem construir apps inteligentes com Azure AI Services.',
        'objective': 'Implementar soluções com Azure OpenAI, Azure AI Search, Speech, Vision e Document Intelligence.',
        'benefit':  'Trilha técnica completa para Azure AI Engineer Associate — projetos prontos para produção.',
    },
    'GH-300': {
        'title_pt': 'GitHub Copilot — desenvolvimento assistido por IA',
        'audience': 'Desenvolvedores de qualquer linguagem que usam (ou querem usar) GitHub Copilot no IDE.',
        'objective': 'Dominar prompts, Chat, agentes e padrões de uso responsável do GitHub Copilot em VS Code, Visual Studio e JetBrains.',
        'benefit':  'Acelera produtividade do dev — base para certificação GitHub Copilot.',
    },
    'GH-900': {
        'title_pt': 'GitHub Foundations — fundamentos da plataforma GitHub',
        'audience': 'Devs, DevOps, gerentes técnicos e profissionais novos no ecossistema GitHub.',
        'objective': 'Dominar repositórios, branches, pull requests, GitHub Actions e colaboração no GitHub.',
        'benefit':  'Base sólida para uso de GitHub na empresa — pré-requisito recomendado para GH-300.',
    },
    'PL-7008': {
        'title_pt': 'Microsoft Copilot Studio — construindo agentes low-code',
        'audience': 'Makers do Power Platform, business analysts e desenvolvedores citizen.',
        'objective': 'Construir agentes conversacionais com Copilot Studio, integrar com Dataverse, Power Automate e APIs.',
        'benefit':  'Permite times de negócio criarem agentes próprios — democratiza IA com governança.',
    },
    'MS-4014': {
        'title_pt': 'Microsoft 365 Copilot — fundação para construir e estender agentes',
        'audience': 'Devs e arquitetos de soluções que vão estender o M365 Copilot com agentes e plugins.',
        'objective': 'Entender a arquitetura de extensibilidade do M365 Copilot, plugins, conectores e Copilot Studio.',
        'benefit':  'Base técnica para os módulos MS-4015/4016/4017 de extensão e customização.',
    },
    'MS-4017': {
        'title_pt': 'Microsoft 365 Copilot — administração e extensão',
        'audience': 'Administradores M365, time de governança e líderes de plataforma de produtividade.',
        'objective': 'Configurar, governar e estender o M365 Copilot: rollout, segurança, compliance e customização avançada.',
        'benefit':  'Capacita o time de TI a operar o Copilot em produção com controle e segurança.',
    },
    'MS-4018': {
        'title_pt': 'Microsoft 365 Copilot — redigir, analisar e apresentar',
        'audience': 'Usuários finais de M365 (todas as áreas) que querem produtividade com Copilot no dia a dia.',
        'objective': 'Aplicar o Copilot no Word, Excel, PowerPoint e Outlook com prompts efetivos e padrões de uso.',
        'benefit':  'Adoção rápida pelos usuários finais — ganho de horas/semana em tarefas repetitivas.',
    },
    'MS-4019': {
        'title_pt': 'Microsoft 365 Copilot — agentes que transformam processos de negócio',
        'audience': 'Power users, líderes de área e makers que vão criar agentes para processos específicos.',
        'objective': 'Projetar e construir agentes M365 Copilot para automatizar fluxos recorrentes de negócio.',
        'benefit':  'Eleva o Copilot de "assistente individual" para "automação de processos" — alto impacto.',
    },
}

DOMAIN_ORDER = ['Segurança', 'Azure', 'Dados', 'IA', 'GitHub', 'Copilot']
DOMAIN_META = {
    'Segurança': {'icon': '🛡️', 'color': '#8E562E'},
    'Azure':     {'icon': '☁️', 'color': '#0078D4'},
    'Dados':     {'icon': '📊', 'color': '#107C10'},
    'IA':        {'icon': '🧠', 'color': '#5C2D91'},
    'GitHub':    {'icon': '🐙', 'color': '#171515'},
    'Copilot':   {'icon': '🤖', 'color': '#003A70'},
}

CODE_TAG_COLOR = {  # per family
    'SC': '#8E562E', 'AZ': '#0078D4', 'DP': '#107C10',
    'AI': '#5C2D91', 'AB': '#5C2D91',
    'MS': '#003A70', 'GH': '#171515', 'PL': '#742774',
}

def fmt_date(date_br):
    # "27/05/2026 09:00 - 17:00" -> ("27/05/2026", "09:00 - 17:00")
    parts = date_br.split(' ', 1)
    d, t = parts[0], parts[1]
    # Add weekday for friendly read
    try:
        dt = datetime.datetime.strptime(d, '%d/%m/%Y')
        weekdays = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']
        wd = weekdays[dt.weekday()]
        return f'{wd} {d}', t
    except Exception:
        return d, t

def code_family(code):
    return code.split('-')[0]

# ──────── load CSV ────────
rows = []
with open(CSV_PATH, encoding='utf-8') as f:
    for r in csv.DictReader(f):
        rows.append(r)

# Reclassify: GH-* -> GitHub (CSV has them under Copilot)
for r in rows:
    if code_family(r['Codigo']) == 'GH':
        r['Dominio'] = 'GitHub'

# group by domain (respect DOMAIN_ORDER)
by_domain = {d: [] for d in DOMAIN_ORDER}
for r in rows:
    d = r['Dominio']
    if d not in by_domain:
        continue
    by_domain[d].append(r)

# sort each by start date
def sort_key(r):
    d_part = r['DataBR'].split(' ')[0]
    t_part = r['DataBR'].split(' ')[1]
    return datetime.datetime.strptime(f'{d_part} {t_part}', '%d/%m/%Y %H:%M')

for d in by_domain:
    by_domain[d].sort(key=sort_key)

# within each domain, group sessions by Codigo (preserving first-seen order)
def group_by_code(items):
    groups = {}
    for r in items:
        groups.setdefault(r['Codigo'], []).append(r)
    return groups

# ──────── HTML build ────────
def session_row(r):
    """One date row inside a grouped card: date | vagas | botão"""
    date_label, time_label = fmt_date(r['DataBR'])
    vagas = int(r['Vagas'])
    vagas_html = ('<span style="color:#D83B01;font-weight:600">⚠️ lotada</span>'
                  if vagas == 0
                  else f'<span style="color:#107C10;font-weight:600">🎟️ {vagas} vagas</span>')
    btn_color = '#A19F9D' if vagas == 0 else '#0078D4'
    btn_label = 'Lotada' if vagas == 0 else '▶ Inscrever-se'
    link = r['Link']
    return f'''<tr>
  <td style="padding:6px 0;border-top:1px dashed #E1DFDD;font-size:10.5pt;color:#323130">📅 <b>{date_label}</b> · {time_label} BRT</td>
  <td align="center" style="padding:6px 10px;border-top:1px dashed #E1DFDD;font-size:10pt">{vagas_html}</td>
  <td align="right" style="padding:6px 0;border-top:1px dashed #E1DFDD"><a href="{link}" style="display:inline-block;background:{btn_color};color:#FFF;font-size:10pt;font-weight:600;padding:5px 12px;border-radius:4px;text-decoration:none">{btn_label}</a></td>
</tr>'''

def grouped_card_html(code, sessions):
    """One card per course code, with N date rows."""
    family = code_family(code)
    tag_color = CODE_TAG_COLOR.get(family, '#605E5C')
    first = sessions[0]
    meta = COURSE_META.get(code, {
        'title_pt': first['Nome'],
        'audience': '—',
        'objective': '—',
        'benefit': '—',
    })
    title_pt = meta['title_pt']
    audience = meta['audience']
    objective = meta['objective']
    benefit = meta['benefit']
    n = len(sessions)
    n_label = '1 turma' if n == 1 else f'{n} turmas'
    session_rows = '\n'.join(session_row(s) for s in sessions)

    return f'''
<table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin:0 0 14px;border:1px solid #E1DFDD;border-radius:8px;background:#FAFAFA">
  <tr>
    <td style="padding:14px 16px 12px">
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
          <td>
            <span style="display:inline-block;background:{tag_color};color:#FFF;font-size:10pt;font-weight:600;padding:2px 8px;border-radius:4px;letter-spacing:0.3px">{code}</span>
          </td>
          <td align="right" style="color:#605E5C;font-size:10pt">{n_label}</td>
        </tr>
      </table>
      <p style="margin:10px 0 8px;font-size:12pt;font-weight:600;color:#003A70;line-height:1.3">{title_pt}</p>
      <p style="margin:4px 0;font-size:10.5pt;color:#323130;line-height:1.45"><b>🎯 Público:</b> {audience}</p>
      <p style="margin:4px 0;font-size:10.5pt;color:#323130;line-height:1.45"><b>📘 Objetivo:</b> {objective}</p>
      <p style="margin:4px 0;font-size:10.5pt;color:#323130;line-height:1.45"><b>✨ Benefício:</b> {benefit}</p>
      <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:10px;border-collapse:collapse">
        {session_rows}
      </table>
    </td>
  </tr>
</table>'''

def domain_section(dom, items):
    if not items:
        return ''
    meta = DOMAIN_META[dom]
    groups = group_by_code(items)
    cards = '\n'.join(grouped_card_html(code, sessions) for code, sessions in groups.items())
    n_courses = len(groups)
    n_classes = sum(len(s) for s in groups.values())
    label = f'{n_courses} curso · {n_classes} turma' if n_courses == 1 else f'{n_courses} cursos · {n_classes} turmas'
    return f'''
<p style="margin:28px 0 12px;padding:8px 14px;background:{meta['color']};color:#FFF;font-size:13pt;font-weight:600;border-radius:6px">{meta['icon']} {dom} <span style="opacity:0.85;font-weight:400">({label})</span></p>
{cards}'''

sections = '\n'.join(domain_section(d, by_domain[d]) for d in DOMAIN_ORDER)
total_classes = sum(len(by_domain[d]) for d in DOMAIN_ORDER)
total_courses = sum(len(group_by_code(by_domain[d])) for d in DOMAIN_ORDER)

# derive period label from min/max dates in CSV (e.g. "junho a agosto de 2026")
PT_MONTHS = ['janeiro','fevereiro','março','abril','maio','junho',
             'julho','agosto','setembro','outubro','novembro','dezembro']
all_dts = [sort_key(r) for r in rows if r['Dominio'] in by_domain]
if all_dts:
    dt_min, dt_max = min(all_dts), max(all_dts)
    if dt_min.year == dt_max.year:
        period_label = f'{PT_MONTHS[dt_min.month-1]} a {PT_MONTHS[dt_max.month-1]} de {dt_min.year}'
    else:
        period_label = f'{PT_MONTHS[dt_min.month-1]}/{dt_min.year} a {PT_MONTHS[dt_max.month-1]}/{dt_max.year}'
else:
    period_label = 'próximos meses'

# ──────── full email body ────────
EMAIL = f'''<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body dir="ltr" style="font-family:Aptos,Calibri,sans-serif;font-size:11pt;color:#000;max-width:760px;margin:0 auto;padding:0 8px">

<p>Olá [Nome], tudo bem?</p>

<p>Conforme alinhado, compartilho com você a <b>grade de turmas abertas do portal ESI Microsoft em português</b>, com sessões previstas para os próximos 3 meses — disponíveis para qualquer aprendiz interessado.</p>

<p>A inscrição é feita diretamente no portal ESI, clicando em <b>"Inscrever-se"</b> na data desejada de cada curso. São <b>{total_courses} cursos</b> com <b>{total_classes} turmas</b> no total, organizados por domínio de conhecimento:</p>

<p style="margin:14px 0 0;padding:10px 14px;background:#F3F2F1;border-left:3px solid #0078D4;font-size:10.5pt;color:#605E5C">
📅 Janela: {period_label} &nbsp;·&nbsp;
🌐 Idioma: português (BR) &nbsp;·&nbsp;
💻 Modalidade: VILT (online ao vivo) &nbsp;·&nbsp;
💸 Gratuito para clientes Microsoft elegíveis
</p>

{sections}

<p style="margin-top:28px">Fico à disposição para qualquer dúvida ou para construir uma <b>trilha customizada para o seu time</b>, combinando essas turmas abertas com sessões dedicadas (Private Deliveries) para os perfis prioritários.</p>

<p>Abraços,</p>

<p style="margin-top:24px">{{USER_NAME}}<br>
<span style="color:#605E5C">Sr Learning &amp; Skilling Manager — Microsoft Brasil</span></p>

</body></html>'''

OUT_HTML.write_text(EMAIL, encoding='utf-8')
print(f'✓ Wrote {OUT_HTML.name} — {len(EMAIL):,} chars')
print(f'  {total_courses} cursos únicos · {total_classes} turmas no total · {sum(1 for d in DOMAIN_ORDER if by_domain[d])} domínios')
for d in DOMAIN_ORDER:
    items = by_domain[d]
    if not items: continue
    groups = group_by_code(items)
    print(f'  · {d}: {len(groups)} curso{"s" if len(groups)!=1 else ""} ({len(items)} turma{"s" if len(items)!=1 else ""})')
