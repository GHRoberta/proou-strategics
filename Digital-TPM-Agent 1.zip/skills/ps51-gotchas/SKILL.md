---
name: ps51-gotchas
description: PowerShell 5.1 compatibility rules and common pitfalls. Load this skill when writing or editing PowerShell scripts that must run under Windows PowerShell 5.1 (not pwsh/PS7).
---

# PowerShell 5.1 Gotchas

These rules are mandatory when writing scripts for the Work Hub automation pipeline. All scheduled tasks run under PS 5.1 (powershell.exe), NOT pwsh.

## String and Encoding Issues
- **Em-dashes (U+2014) are fatal** -- they act as phantom string terminators. Always use `--`.
- **No non-ASCII in script files** -- no smart quotes, bullets, em-dashes, or Unicode symbols.
- **`Out-File -Encoding UTF8` writes BOM** -- Python must read with `encoding="utf-8-sig"`.
- **`$variable?` in double-quoted strings** -- PS treats `?` as part of the name. Use `${variable}?`.
- **Regex `${1}` in double-quoted strings** -- build replacement separately: `$rep = '${1}' + $value + '${2}'`

## Array and Pipeline Issues
- **`ConvertTo-Json` on single-item array** produces `{}` not `[{}]`. Fix:
  ```powershell
  if ($arr.Count -eq 1) { $json = "[$json]" }
  ```
- **Pipeline results may be strings, not arrays** -- always wrap in `@()` for reliable `.Count`.

## Error Handling
- **Empty `catch {}` blocks are invalid** -- use `catch { $null = $null }`.
- **`$_.ScriptStackTrace` doesn't exist** -- use `$_.InvocationInfo.PositionMessage`.

## Interop
- **COM interop requires PS 5.1** -- `powershell.exe -STA -NoProfile -ExecutionPolicy Bypass`.
- **pwsh CANNOT do Office COM** -- .NET Core lacks PIA support. This is permanent.
- **`Start-Job` loses auth context** -- WAM/MSAL tokens don't transfer. Run WorkIQ calls inline.

## Validation
Always parse-check before declaring a script done:
```powershell
powershell.exe -NoProfile -Command {
    $e=$null; $t=$null
    [System.Management.Automation.Language.Parser]::ParseFile("script.ps1",[ref]$t,[ref]$e)|Out-Null
    if($e.Count -eq 0){"OK"}else{$e}
}
```
