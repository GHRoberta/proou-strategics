"""Single source of truth for the Portfolio Analytics pipeline.

Consolidates the constants that were previously duplicated across
macc_aggregate.py / build_top50.py / team_tpids.json:
  - the 30 managed-portfolio accounts (TPID -> short name, vertical)
  - data-source identifiers (Power BI datasets, MSX Insights reports, Dataverse)
  - the DAX measure / OData role labels discovered this session
  - scope exclusions (foreign / non-Brazil-HQ accounts)
  - shared filesystem paths

Every pipeline script imports from here so a TPID or an ID is edited in ONE place.
Verified 2026-07-01/03. See SKILL.md for provenance and gotchas.
"""
import subprocess
from pathlib import Path

# ---------------------------------------------------------------- auth
PBI_RESOURCE = "https://analysis.windows.net/powerbi/api"
PBI_EXECUTE_URL = "https://api.powerbi.com/v1.0/myorg/datasets/{dataset}/executeQueries"

def get_token(resource: str) -> str:
    """Fetch an AAD access token for `resource` via the Azure CLI.

    Uses PowerShell to invoke `az` (az is az.cmd on Windows and is not directly
    spawnable from Python subprocess). Requires a prior `az login`.
    """
    r = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         f"az account get-access-token --resource '{resource}' --query accessToken -o tsv"],
        capture_output=True, text=True)
    tok = (r.stdout or "").strip()
    if not tok:
        raise RuntimeError(f"az token failed for {resource}: {(r.stderr or '')[:200]}")
    return tok

# ---------------------------------------------------------------- paths
DATA_DIR = Path(__file__).resolve().parent                       # pipeline data + outputs
HUB_DIR = DATA_DIR.parent                                        # C:\...\ghcli-working
PBI_PROFILE = HUB_DIR / ".pbi_profile"                           # cached Edge profile (auth)
CARTEIRA_DASHBOARD = HUB_DIR / "Carteira_FY27_Copilot_Dashboard.html"
TOP50_DASHBOARD = HUB_DIR / "Top50_MACC_Copilot_Brasil.html"

# ---------------------------------------------------------------- data sources
# Power BI semantic model "M365 Copilot Usage" (IDEAs, daily refresh)
PBI_COPILOT_USAGE = "5c6c70ac-f04e-4809-8f6a-c53cb4354e6e"
# Measure for paid seats (suffix is REQUIRED or it won't resolve); Brazil = Field Region "BRA"
COPILOT_SEATS_MEASURE = "Paid Available Units (M365 Copilot)"
COPILOT_REGION = "BRA"

# MSX Insights portal report "MACC Balances and Shortfall" (aka.ms/maccbalanceshortfall)
# Canonical MACC utilization source; UI-only (not queryable via powerbi-remote MCP).
MSXI_MACC_REPORT = "15b4d62d-805a-4ec9-ac6d-ca006ad4eeee"
MSXI_REPORT_URL = "https://msxinsights.microsoft.com/User/report/{report}?login_hint={upn}"

# Dataverse (MSX D365) — AE/ATS/CSAM come from entity msp_accountteam
DATAVERSE_BASE = "https://microsoftsales.crm.dynamics.com/api/data/v9.2"
DATAVERSE_RESOURCE = "https://microsoftsales.crm.dynamics.com/"
PARENTING_LEVEL_TOP = 861980000                                  # msp_parentinglevelcode "Top"
ROLE_AE = "ATU Account Executive"                                # msp_rolename
ROLE_ATS = "ATU Account Technology Strategist"                   # msp_rolename
ROLE_CSAM_TITLE = "Customer Success Account Mgmt IC"             # msp_standardtitle (roletype CSU)

USER_UPN = "{{EMAIL}}"

# ---------------------------------------------------------------- managed portfolio (30)
# TPID -> (short display name, vertical). Order = the FY27 dashboard order.
# >>> PERSONALIZE: replace with YOUR managed accounts.
# TPID -> (short display name, vertical). Get each TPID from MSX.
PORTFOLIO = {
    "000000":   ("Example Account A", "Banking"),
    "000001":   ("Example Account B", "Energy"),
    "000002":   ("Example Account C", "Government"),
}
PORTFOLIO_TPIDS = list(PORTFOLIO.keys())
VERT = {tp: v for tp, (_, v) in PORTFOLIO.items()}
SHORTNAME = {tp: n for tp, (n, _) in PORTFOLIO.items()}

# ---------------------------------------------------------------- scope
# Study scope = clients headquartered in Brazil. Exclude foreign/global.
# Foreign accounts are detected dynamically by non-Brazil MSX sales unit
# (see is_brazil_unit); this set is for named manual exclusions only.
EXCLUDE_TPIDS = {
    "26717164",  # LG - Lugar de Gente (HQ Goiânia/BR) — excluded per user request 2026-07-03
}

def is_brazil_unit(unit: str) -> bool:
    """True if the MSX 'To Direct Sales Unit' indicates a Brazil-HQ account."""
    u = (unit or "").lower()
    return "brazil" in u or "brasil" in u

# ---------------------------------------------------------------- output artifacts
MACC_XLSX = DATA_DIR / "macc_portfolio.xlsx"          # raw export from MSX Insights
MACC_ALL_JSON = DATA_DIR / "macc_all.json"            # {tpid: {name,committed,consumed,end,unit}} (all BRA MACC accts)
MACC_BY_TPID_JSON = DATA_DIR / "macc_by_tpid.json"    # portfolio-only MACC summary (carteira dashboard)
SEATS_JSON = DATA_DIR / "seats_by_tpid.json"          # {tpid: {name,paid}}
OPP_SEATS_JSON = DATA_DIR / "opp_seats_by_tpid.json"  # {tpid: {n,seats,top_name,top_seats}} open M365 Copilot opps (FY27)
ATTAINMENT_JSON = HUB_DIR / "attainment_summary.json" # FY26 TPM Learner Target Attainment: [{account,trained,rows,tpid}] (PD+TSP); refresh via pbi_export_attainment.py
TEAM_JSON = DATA_DIR / "team_by_tpid.json"            # {tpid: {name,ae,ats,csam,...}}
TOP50_JSON = DATA_DIR / "top50_macc_seats.json"       # ranked rows for the Top50 portal
