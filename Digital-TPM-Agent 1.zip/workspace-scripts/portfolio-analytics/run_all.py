"""One-shot orchestrator for the portfolio-analytics pipeline.

  python run_all.py                 # reuse cached MACC xlsx; refresh seats+team; rebuild+render+validate
  python run_all.py --refresh-macc  # also re-scrape the MSX Insights MACC portal via Edge (headed)
  python run_all.py --skip-team     # keep existing team_by_tpid.json (team pull is the slow step)

Stages: pull_macc → pull_seats → pull_opp_seats → pull_team → build_top50 → render_top50 → aggregate_macc → render_carteira → validate.
Stops at the first failing stage.
"""
import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(desc, args):
    print(f"\n=== {desc} ===", flush=True)
    r = subprocess.run(args, cwd=str(HERE))
    if r.returncode != 0:
        print(f"✗ stage failed ({desc}) rc={r.returncode}", file=sys.stderr)
        sys.exit(r.returncode)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--refresh-macc", action="store_true", help="re-scrape MSX Insights MACC portal")
    ap.add_argument("--skip-team", action="store_true", help="reuse existing team_by_tpid.json")
    a = ap.parse_args()
    py = sys.executable

    run("1/9 pull MACC", [py, "pull_macc.py"] + (["--refresh"] if a.refresh_macc else []))
    run("2/9 pull seats", [py, "pull_seats.py"])
    run("3/9 pull FY27 Copilot opp seats (PBI universe + MSX Dataverse)", [py, "pull_opp_seats.py"])
    if not a.skip_team:
        run("4/9 pull team (AE/ATS/CSAM)", [py, "pull_team.py"])
    else:
        print("\n=== 4/9 pull team — SKIPPED ===")
    run("5/9 build top20 ranking", [py, "build_top50.py"])
    run("6/9 render top20 portal", [py, "render_top50.py"])
    run("7/9 aggregate carteira MACC", [py, "aggregate_macc.py"])
    run("8/9 refresh carteira dashboard MACC", [py, "render_carteira.py"])
    run("9/9 validate dashboards", ["node", "validate_dashboard.js"])
    print("\n✅ pipeline complete")
    return 0


if __name__ == "__main__":
    sys.exit(main())
