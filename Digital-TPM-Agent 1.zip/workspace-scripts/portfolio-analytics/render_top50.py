"""Stage 5 — render the Top-50 portal (self-contained HTML).

Reads top50_macc_seats.json and writes Top50_MACC_Copilot_Brasil.html:
KPIs + MACC×seats scatter + sortable/filterable table with AE/ATS/CSAM and the
carteira-beyond-50 rows. Validate afterwards with validate_dashboard.js.
"""
import json
import re
import sys
from datetime import datetime

import portfolio_config as cfg


def _short(n):
    n = n.strip()
    if sum(c.isupper() for c in n if c.isalpha()) > 0.7 * max(1, sum(c.isalpha() for c in n)):
        n = n.title()
    n = re.split(r"\s[–-]\s|\s\(|,\s", n)[0]
    n = re.sub(r"\b(S\.?A\.?|S/A|Ltda\.?|Sa)\b\.?$", "", n).strip()
    return n[:24]


def main():
    if not cfg.TOP50_JSON.exists():
        print("ERROR: run build_top50.py first", file=sys.stderr)
        return 2
    data = json.load(open(cfg.TOP50_JSON, encoding="utf-8"))
    today = datetime.now().strftime("%d/%m/%Y")
    for d in data:
        d["short"] = _short(d["name"])
    tot_c = sum(d["committed"] for d in data)
    tot_s = sum(d["seats"] for d in data)
    n_car = sum(1 for d in data if d["carteira"] and not d.get("beyond"))
    verts = sorted({d["vert"] for d in data})
    DATA_JS = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    VERT_OPTS = "".join(f'<option value="{v}">{v}</option>' for v in verts)

    html = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Top 50 Clientes Brasil · MACC × M365 Copilot</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Segoe UI',system-ui,sans-serif;background:#f3f2f1;color:#201f1e;padding:24px;max-width:1440px;margin:0 auto}}
h1{{font-size:23px;font-weight:600;color:#0b3b6f}}
.sub{{color:#605e5c;font-size:13px;margin:4px 0 20px}}
.kpis{{display:grid;grid-template-columns:repeat(7,1fr);gap:14px;margin-bottom:22px}}
.kpi{{background:#fff;border-radius:10px;padding:16px 18px;box-shadow:0 1px 3px rgba(0,0,0,.08);border-left:4px solid #0078d4}}
.kpi .v{{font-size:24px;font-weight:700;color:#0b3b6f}}.kpi .l{{font-size:12px;color:#605e5c;margin-top:2px}}
.kpi.g{{border-left-color:#107c10}}.kpi.o{{border-left-color:#d83b01}}.kpi.p{{border-left-color:#5c2d91}}.kpi.m{{border-left-color:#008272}}.kpi.d{{border-left-color:#c239b3}}.kpi.t{{border-left-color:#038387}}
.panel{{background:#fff;border-radius:10px;padding:18px;box-shadow:0 1px 3px rgba(0,0,0,.08);margin-bottom:20px}}
.panel h2{{font-size:15px;color:#0b3b6f;margin-bottom:12px}}
.controls{{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:14px}}
input,select{{padding:8px 10px;border:1px solid #c8c6c4;border-radius:6px;font-size:13px;font-family:inherit}}
input{{flex:1;min-width:160px}}
.seg{{display:inline-flex;border:1px solid #c8c6c4;border-radius:6px;overflow:hidden}}
.seg button{{border:0;background:#fff;padding:8px 14px;font-size:13px;cursor:pointer;font-family:inherit;color:#3b3a39}}
.seg button.on{{background:#0078d4;color:#fff;font-weight:600}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{background:#faf9f8;text-align:left;padding:9px 7px;cursor:pointer;user-select:none;border-bottom:2px solid #edebe9;white-space:nowrap;position:sticky;top:0}}
th:hover{{color:#0078d4}}
td{{padding:8px 7px;border-bottom:1px solid #f3f2f1;vertical-align:middle}}
tr:hover td{{background:#f8fbff}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
.rk{{color:#a19f9d;font-weight:700;width:26px;text-align:right}}
.money{{color:#107c10;font-weight:600}}.seats{{color:#5c2d91;font-weight:600}}.fy27{{color:#c239b3;font-weight:700}}.trn{{color:#038387;font-weight:700}}
.sc{{font-weight:700;color:#0b3b6f}}
.badge{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600}}
.b-car{{background:#eff6fc;color:#0078d4}}.b-fora{{background:#fdf0e6;color:#d83b01}}
.tag{{background:#f5f5f5;color:#605e5c;padding:2px 7px;border-radius:4px;font-size:11px}}
.count{{font-size:12px;color:#605e5c;margin-bottom:8px}}
.chartwrap{{overflow-x:auto}} svg{{display:block}} .legend{{font-size:11px;fill:#605e5c}}
.dot{{fill-opacity:.72;stroke:#fff;stroke-width:1.2;cursor:pointer}}
.note{{font-size:11px;color:#a19f9d;margin-top:6px}}
.ppl{{font-size:12px;color:#3b3a39;white-space:nowrap}}.exrow td{{background:#fcfbf9}}.ex{{color:#d83b01;font-weight:700}}
.foot{{font-size:11px;color:#a19f9d;text-align:center;margin-top:16px}}
@media(max-width:1200px){{.kpis{{grid-template-columns:repeat(3,1fr)}}}}@media(max-width:820px){{.kpis{{grid-template-columns:repeat(2,1fr)}}}}
</style></head><body>
<h1>Top 20 Clientes Brasil (+ carteira) · MACC × M365 Copilot · pipeline FY27 · time de conta</h1>
<div class="sub">Universo: {len(data)} clientes (top 20 por score <b>+ todas as contas da carteira</b>) · <b>FY26 Copilot Seats</b> = licenças pagas hoje (M365 Copilot Usage · Paid Available Units) · <b>FY27 Copilot (opps)</b> = seats em oportunidades M365 Copilot abertas no MSX (flag Is M365 Copilot · inclui bundles E7/ME7) · <b>FY26 Trained Learners</b> = alunos treinados no FY26 (PD + TSP · relatório FY26 TPM Learner Target Attainment) · score = média de <b>MACC ÷ máx</b> e <b>FY26 seats ÷ máx</b> (peso igual) · MACC: MSX Insights · Time AE/ATS/CSAM: MSX Core Account Team · atualiz. {today}</div>
<div class="kpis">
<div class="kpi"><div class="v" id="k-n">{len(data)}</div><div class="l">Clientes no ranking</div></div>
<div class="kpi p"><div class="v" id="k-car">{n_car}</div><div class="l">Na carteira / fora</div></div>
<div class="kpi m"><div class="v" id="k-macc">—</div><div class="l">MACC fechado (Σ)</div></div>
<div class="kpi o"><div class="v" id="k-seats">—</div><div class="l">FY26 seats pagos (Σ)</div></div>
<div class="kpi d"><div class="v" id="k-opp">—</div><div class="l">FY27 seats em opps (Σ)</div></div>
<div class="kpi t"><div class="v" id="k-trn">—</div><div class="l">FY26 treinados (Σ)</div></div>
<div class="kpi g"><div class="v" id="k-gov">—</div><div class="l">Setor público no ranking</div></div>
</div>
<div class="panel"><h2>Mapa MACC fechado (Y) × FY26 Copilot Seats (X) · escala log · azul = carteira, laranja = fora</h2>
<div class="chartwrap"><svg id="scat" width="1120" height="470" viewBox="0 0 1120 470"></svg></div>
<div class="note">Bolha ∝ score combinado. Contas com 0 em um eixo aparecem no piso do respectivo eixo.</div></div>
<div class="panel"><h2>Ranking combinado</h2>
<div class="controls">
<div class="seg"><button data-f="todos" class="on" onclick="setF('todos')">Todos</button><button data-f="carteira" onclick="setF('carteira')">Carteira</button><button data-f="fora" onclick="setF('fora')">Fora</button></div>
<input id="q" placeholder="🔎 buscar cliente…" oninput="render()">
<select id="vf" onchange="render()"><option value="">Todos os setores</option>{VERT_OPTS}</select>
</div>
<div class="count" id="cnt"></div>
<table><thead><tr>
<th onclick="sortBy('rank')">#</th><th onclick="sortBy('name')">Cliente</th>
<th onclick="sortBy('carteira')">Carteira?</th><th onclick="sortBy('vert')">Setor</th>
<th class="num" onclick="sortBy('committed')">MACC fechado</th>
<th onclick="sortBy('end')">MACC prazo</th>
<th class="num" onclick="sortBy('util')">MACC util.</th>
<th class="num" onclick="sortBy('seats')">FY26 Copilot Seats</th>
<th class="num" onclick="sortBy('opp_seats')">FY27 Copilot (opps)</th>
<th class="num" onclick="sortBy('trained')">FY26 Trained Learners</th>
<th class="num" onclick="sortBy('score')">Score ▾</th>
<th onclick="sortBy('ae')">AE (owner)</th>
<th onclick="sortBy('ats')">ATS</th>
<th onclick="sortBy('csam')">CSAM</th>
</tr></thead><tbody id="tb"></tbody></table></div>
<div class="foot">{{AGENT_NAME}} · dados internos Microsoft · MACC fechado = Consumption Commitment (compromisso Azure assinado) · FY26 Copilot Seats = Paid Available Units M365 Copilot (licenças pagas hoje) · FY27 Copilot (opps) = Σ seats de oportunidades M365 Copilot <b>abertas</b> no MSX (flag Is M365 Copilot · inclui bundles E7/ME7) · projetado FY27 = FY26 + opps (ver tooltip) · FY26 Trained Learners = alunos treinados no FY26 por conta (PD + TSP · relatório "FY26 TPM Learner Target Attainment") · Score = média normalizada de MACC e FY26 seats (peso igual) · "Carteira" = {len(cfg.PORTFOLIO_TPIDS)} contas TPM {{USER_FIRSTNAME}} (todas incluídas; as além do top-20 com rank real*) · AE/ATS/CSAM = MSX Core Account Team (AE = ATU Account Executive/owner · ATS = Account Technology Strategist · CSAM = Customer Success Account Mgr; "—" = papel não atribuído no MSX).</div>
<script>
const DATA={DATA_JS};
const MES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
let filt='todos',sortKey='score',sortDir=-1;
function fmt(n){{return (n||0).toLocaleString('pt-BR')}}
function money(n){{if(n>=1e9)return '$'+(n/1e9).toFixed(2).replace('.',',')+'bi';if(n>=1e6)return '$'+(n/1e6).toFixed(0)+'M';if(n>=1e3)return '$'+(n/1e3).toFixed(0)+'K';return n?'$'+Math.round(n):'—'}}
function md(s){{if(!s)return '—';const p=s.split('-');return MES[+p[1]-1]+'/'+p[0].slice(2)}}
function norm(s){{return (s||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase()}}
function setF(f){{filt=f;document.querySelectorAll('.seg button').forEach(b=>b.classList.toggle('on',b.dataset.f===f));render()}}
function sortBy(k){{if(sortKey===k)sortDir*=-1;else{{sortKey=k;sortDir=(k==='name'||k==='vert'||k==='end'||k==='ae'||k==='ats'||k==='csam')?1:-1}}render()}}
function subset(){{
  const q=norm(document.getElementById('q').value),vf=document.getElementById('vf').value;
  return DATA.filter(d=>(filt==='todos'||(filt==='carteira'&&d.carteira)||(filt==='fora'&&!d.carteira))
    &&norm(d.name).includes(q)&&(!vf||d.vert===vf));
}}
const W=1120,H=470,pL=70,pR=30,pT=18,pB=52;
const xdom=[Math.log10(0.5),Math.log10(40000)],ydom=[Math.log10(0.3),Math.log10(300)];
function xs(v){{return pL+(Math.log10(Math.max(v,0.5))-xdom[0])/(xdom[1]-xdom[0])*(W-pL-pR)}}
function ys(vM){{return H-pB-(Math.log10(Math.max(vM,0.3))-ydom[0])/(ydom[1]-ydom[0])*(H-pT-pB)}}
function scatter(rows){{
  let s='';
  [1,10,100,1000,10000].forEach(t=>{{const x=xs(t);s+=`<line x1="${{x}}" y1="${{pT}}" x2="${{x}}" y2="${{H-pB}}" stroke="#f0f0f0"/><text x="${{x}}" y="${{H-pB+16}}" text-anchor="middle" class="legend">${{t>=1000?t/1000+'k':t}}</text>`}});
  [1,10,100].forEach(t=>{{const y=ys(t);s+=`<line x1="${{pL}}" y1="${{y}}" x2="${{W-pR}}" y2="${{y}}" stroke="#f0f0f0"/><text x="${{pL-8}}" y="${{y+4}}" text-anchor="end" class="legend">$${{t}}M</text>`}});
  s+=`<text x="${{(pL+W-pR)/2}}" y="${{H-6}}" text-anchor="middle" class="legend">FY26 Copilot seats pagos (log) →</text>`;
  s+=`<text x="16" y="${{(pT+H-pB)/2}}" text-anchor="middle" class="legend" transform="rotate(-90,16,${{(pT+H-pB)/2}})">MACC fechado US$ (log) →</text>`;
  const srt=[...rows].sort((a,b)=>b.score-a.score);
  srt.forEach((d,i)=>{{
    const cx=xs(d.seats),cy=ys(d.committed/1e6),r=Math.max(4,Math.min(17,4+d.score/6));
    const col=d.carteira?'#0078d4':'#d83b01';
    s+=`<circle class="dot" cx="${{cx.toFixed(1)}}" cy="${{cy.toFixed(1)}}" r="${{r.toFixed(1)}}" fill="${{col}}"><title>${{d.name}} — MACC ${{money(d.committed)}}, ${{fmt(d.seats)}} seats, score ${{d.score}}</title></circle>`;
    if(i<9)s+=`<text x="${{(cx+r+3).toFixed(1)}}" y="${{(cy+3).toFixed(1)}}" class="legend" style="font-size:10px">${{d.short}}</text>`;
  }});
  document.getElementById('scat').innerHTML=s;
}}
function render(){{
  let r=subset();
  r.sort((a,b)=>{{let x=a[sortKey],y=b[sortKey];if(x==null)x=-1;if(y==null)y=-1;if(typeof x==='string')return x.localeCompare(y)*sortDir;return (x-y)*sortDir}});
  document.getElementById('k-n').textContent=r.length;
  document.getElementById('k-car').textContent=r.filter(d=>d.carteira).length+' / '+r.filter(d=>!d.carteira).length;
  document.getElementById('k-macc').textContent=money(r.reduce((s,d)=>s+d.committed,0));
  document.getElementById('k-seats').textContent=fmt(r.reduce((s,d)=>s+d.seats,0));
  document.getElementById('k-opp').textContent=fmt(r.reduce((s,d)=>s+(d.opp_seats||0),0));
  document.getElementById('k-trn').textContent=fmt(r.reduce((s,d)=>s+(d.trained||0),0));
  document.getElementById('k-gov').textContent=r.filter(d=>d.gov).length;
  document.getElementById('cnt').textContent=r.length+' clientes';
  document.getElementById('tb').innerHTML=r.map(d=>`<tr class="${{d.beyond?'exrow':''}}">
   <td class="rk" title="${{d.beyond?'carteira — rank real além do top-50':''}}">${{d.rank}}${{d.beyond?'<span class="ex">*</span>':''}}</td>
   <td><b>${{d.name}}</b></td>
   <td><span class="badge ${{d.carteira?'b-car':'b-fora'}}">${{d.carteira?'Carteira':'Fora'}}</span></td>
   <td><span class="tag">${{d.vert}}</span></td>
   <td class="num money">${{d.committed?money(d.committed):'—'}}</td>
   <td>${{md(d.end)}}</td>
   <td class="num">${{d.util!=null?d.util+'%':'—'}}</td>
   <td class="num seats">${{d.seats?fmt(d.seats):'—'}}</td>
   <td class="num fy27" title="FY26: ${{fmt(d.seats)}} pagas · FY27 opps: ${{fmt(d.opp_seats)}} (${{d.opp_n}} opp${{d.opp_n===1?'':'s'}})${{d.opp_top?' · maior: '+d.opp_top:''}} · projetado ~${{fmt(d.fy27_total)}}">${{d.opp_seats?('+'+fmt(d.opp_seats)):'—'}}</td>
   <td class="num trn" title="Trained Learners FY26 (PD + TSP) · relatório FY26 TPM Learner Target Attainment">${{d.trained?fmt(d.trained):'—'}}</td>
   <td class="num sc">${{d.score.toFixed(1)}}</td>
   <td class="ppl">${{d.ae||'—'}}</td>
   <td class="ppl">${{d.ats||'—'}}</td>
   <td class="ppl">${{d.csam||'—'}}</td></tr>`).join('');
  scatter(r);
}}
render();
</script></body></html>"""

    tot_opp = sum(d.get("opp_seats", 0) for d in data)
    tot_trn = sum(d.get("trained", 0) for d in data)
    cfg.TOP50_DASHBOARD.write_text(html, encoding="utf-8")
    print(f"✅ {cfg.TOP50_DASHBOARD.name}: {len(data)} rows · Σmacc=${tot_c/1e9:.2f}bi · ΣFY26seats={tot_s:,} · ΣFY27opps={tot_opp:,} · ΣFY26trained={tot_trn:,} · carteira(top20)={n_car}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
