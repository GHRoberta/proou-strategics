"""Stage 4 — combined ranking: MACC committed × Copilot paid seats.

Score = mean of the two normalized axes (committed/max, seats/max), equal weight.
Scope = clients HQ'd in Brazil (foreign sales units + manual EXCLUDE dropped).
Output rows = top-50 by score PLUS every managed-portfolio account (carteira),
even when a carteira account ranks beyond 50 (flagged `beyond`, with real rank).

Exposes `select_scope()` so pull_team.py fetches AE/ATS/CSAM for exactly the
accounts that will appear (top-50 ∪ carteira) — no chicken-and-egg with team.

Output: top50_macc_seats.json
"""
import json
import re
import sys

import portfolio_config as cfg

TOP_N = 20  # reduced ranking cut (was 50); list = top-N by score ∪ every carteira account

GOV_RX = re.compile(
    r"TRIBUNAL|MINIST[EÉ]RIO|SECRETARIA|PREFEITURA|GOVERNO|BANCO CENTRAL|\bTCU\b|\bSTF\b|SUPREMO|"
    r"[CLIENTE]|[CLIENTE]|PRODERJ|PRODEMGE|CODEPLAN|CIA PROCESSAMENTO|[CLIENTE]|[CLIENTE]|FIESP|FIEPR|"
    r"CONFEDERA|FEDERACAO|FEDERA[ÇC][AÃ]O|PRESID[EÊ]NCIA|CONTAS|FAZENDA|PROCURADORIA|REP[UÚ]BLICA|"
    r"MINAS E ENERGIA|COMUNICAC|INFRAESTRUTURA|SA[UÚ]DE|EDUCA[ÇC]|ELETROBRAS|UNIVERSID|USP|UNESP|CNI\b", re.I)


def _load(path):
    return json.load(open(path, encoding="utf-8")) if path.exists() else {}


def _universe(macc, seats):
    """Merge MACC + seats into a Brazil-scoped universe (drops foreign/excluded)."""
    foreign = {tp for tp, m in macc.items() if not cfg.is_brazil_unit(m.get("unit", ""))}
    # carteira accounts are ALWAYS in scope (never dropped as foreign/excluded)
    drop = (cfg.EXCLUDE_TPIDS | foreign) - set(cfg.PORTFOLIO_TPIDS)
    univ = {}
    for tp, m in macc.items():
        if tp in drop:
            continue
        univ[tp] = {"tpid": tp, "name": m["name"], "committed": float(m.get("committed", 0)),
                    "consumed": float(m.get("consumed", 0)), "end": m.get("end"), "seats": 0}
    for tp, s in seats.items():
        if tp in drop:
            continue
        univ.setdefault(tp, {"tpid": tp, "name": s["name"], "committed": 0.0,
                             "consumed": 0.0, "end": None, "seats": 0})
        univ[tp]["seats"] = int(s["paid"])
        univ[tp]["name"] = univ[tp].get("name") or s["name"]
    # every carteira account must be present, even at 0/0 (source real MACC if any)
    for tp in cfg.PORTFOLIO_TPIDS:
        if tp not in univ:
            m = macc.get(tp, {})
            s = seats.get(tp, {})
            univ[tp] = {"tpid": tp, "name": m.get("name") or cfg.SHORTNAME.get(tp, s.get("name", tp)),
                        "committed": float(m.get("committed", 0)), "consumed": float(m.get("consumed", 0)),
                        "end": m.get("end"), "seats": int(s.get("paid", 0))}
    return univ, drop


def _score(univ):
    max_c = max((a["committed"] for a in univ.values()), default=0) or 1
    max_s = max((a["seats"] for a in univ.values()), default=0) or 1
    for a in univ.values():
        a["score"] = round((a["committed"] / max_c + a["seats"] / max_s) / 2 * 100, 2)
        a["carteira"] = a["tpid"] in cfg.PORTFOLIO
        a["gov"] = bool(GOV_RX.search(a["name"]))
        a["vert"] = cfg.VERT.get(a["tpid"], "Público" if a["gov"] else "Privado")
        a["util"] = round(a["consumed"] / a["committed"] * 100, 1) if a["committed"] else None
    return sorted(univ.values(), key=lambda x: -x["score"])


def select_scope(macc, seats):
    """TPIDs whose team we must fetch = top-50 by score ∪ every carteira account."""
    univ, _ = _universe(macc, seats)
    ranked = _score(univ)
    return {a["tpid"] for a in ranked[:TOP_N]} | set(cfg.PORTFOLIO_TPIDS)


def build(macc, seats, team, opp, trained):
    univ, _ = _universe(macc, seats)
    ranked = _score(univ)
    for i, a in enumerate(ranked, 1):
        a["rank"] = i
        t = team.get(a["tpid"], {})
        a["ae"], a["ats"], a["csam"] = t.get("ae"), t.get("ats"), t.get("csam")
        o = opp.get(a["tpid"], {})
        a["opp_seats"] = int(o.get("seats", 0))
        a["opp_n"] = int(o.get("n", 0))
        a["opp_top"] = o.get("top_name")
        a["fy27_total"] = a["seats"] + a["opp_seats"]
        a["trained"] = int(trained.get(a["tpid"], 0))
    top = ranked[:TOP_N]
    top_ids = {a["tpid"] for a in top}
    extras = [a for a in ranked if a["carteira"] and a["tpid"] not in top_ids]
    final = top + extras
    for a in final:
        a["beyond"] = a["tpid"] not in top_ids
    return final


def main():
    macc = _load(cfg.MACC_ALL_JSON)
    seats = _load(cfg.SEATS_JSON)
    team = _load(cfg.TEAM_JSON)
    opp = _load(cfg.OPP_SEATS_JSON)
    att = _load(cfg.ATTAINMENT_JSON)
    trained = {}
    for e in (att if isinstance(att, list) else []):
        tp = str(e.get("tpid"))
        trained[tp] = trained.get(tp, 0) + int(e.get("trained") or 0)
    if not macc and not seats:
        print("ERROR: run pull_macc.py and pull_seats.py first", file=sys.stderr)
        return 2
    final = build(macc, seats, team, opp, trained)
    keys = ("rank", "tpid", "name", "carteira", "gov", "vert", "committed",
            "consumed", "util", "end", "seats", "opp_seats", "opp_n", "opp_top",
            "fy27_total", "trained", "score", "ae", "ats", "csam", "beyond")
    cfg.TOP50_JSON.write_text(
        json.dumps([{k: a[k] for k in keys} for a in final], ensure_ascii=False, indent=1),
        encoding="utf-8")
    ncar = sum(1 for a in final if a["carteira"] and not a["beyond"])
    cov = sum(1 for a in final if a.get("ae"))
    opp_tot = sum(a["opp_seats"] for a in final)
    trn_tot = sum(a["trained"] for a in final)
    print(f"✅ {cfg.TOP50_JSON.name}: {len(final)} rows (top{TOP_N} + {len(final) - TOP_N} carteira extras)")
    print(f"   top{TOP_N} carteira/fora = {ncar}/{TOP_N - ncar}  ·  Σ FY27 opp seats={opp_tot:,}  ·  Σ FY26 trained={trn_tot:,}  ·  team on {cov}/{len(final)}"
          + ("" if team else "  (no team_by_tpid.json yet — run pull_team.py)"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
