"""Stage 3 — Core Account Team (AE / ATS / CSAM) per account.

Source: MSX D365 Dataverse entity `msp_accountteam` (the "Core Account Team"
tab in MSX), via OData REST. Role identification:
  AE   = msp_rolename == 'ATU Account Executive'   (== the account owner)
  ATS  = msp_rolename == 'ATU Account Technology Strategist'
  CSAM = msp_standardtitle == 'Customer Success Account Mgmt IC' (roletype CSU)

The core roles hang off the Top-parent account (msp_parentinglevelcode Top),
except for strategic accounts ([CLIENTE]/[CLIENTE]) where they sit on the operating
account under a "Strategic ..." title — so we probe the Top parent first, then
the person-owned operating accounts, until the ATU roles are found. NOTE: the
`get_account_overview` MSX tool returns only the *extended* team (CSU/STU/M&O)
and NOT these core ATU roles — this entity is the correct source.

Scope = build_top50.select_scope (top-50 ∪ carteira). Output: team_by_tpid.json.
"""
import json
import sys
import time
import urllib.parse
import urllib.request

import portfolio_config as cfg
import build_top50

RESOURCE = cfg.DATAVERSE_RESOURCE
BASE = cfg.DATAVERSE_BASE
RFLT = (f"(msp_rolename eq '{cfg.ROLE_AE}' or msp_rolename eq '{cfg.ROLE_ATS}' or "
        f"(msp_roletype eq 'CSU' and msp_standardtitle eq '{cfg.ROLE_CSAM_TITLE}'))")


def _get(url, token):
    req = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {token}", "Accept": "application/json",
        "Prefer": 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode("utf-8"))


def _pick_csam(cands):
    """Prefer the account-level IC CSAM (title 'Customer Success Acct Manager'),
    FTE over vendor (v-), else the first."""
    def base(c):
        t = (c.get("title") or "").lower()
        return ("account manager" in t or "acct manager" in t) and not any(
            x in t for x in ("prin", "sr ", "mgmt", "mgr mgmt"))
    fte = [c for c in cands if not (c["email"] or "").lower().startswith("v-")]
    for pool in (fte, cands):
        b = [c for c in pool if base(c)]
        if b:
            return b[0]
        if pool:
            return pool[0]
    return None


def _team_on(guid, token):
    url = (f"{BASE}/msp_accountteams?$select=msp_fullname,msp_rolename,msp_standardtitle,"
           f"msp_internalemailaddress,msp_title&$top=80&$filter="
           + urllib.parse.quote(f"_msp_accountid_value eq {guid} and " + RFLT))
    ae = ats = None
    seen, csams = set(), []
    for r in _get(url, token)["value"]:
        fn, rn = r.get("msp_fullname"), r.get("msp_rolename")
        if rn == cfg.ROLE_AE and not ae:
            ae = fn
        elif rn == cfg.ROLE_ATS and not ats:
            ats = fn
        elif r.get("msp_standardtitle") == cfg.ROLE_CSAM_TITLE and fn and fn not in seen:
            seen.add(fn)
            csams.append({"name": fn, "email": r.get("msp_internalemailaddress") or "",
                          "title": r.get("msp_title")})
    return ae, ats, csams


def _account_candidates(tp, token):
    """Top-parent account first, then person-owned operating accounts (shortest name)."""
    accs = _get(f"{BASE}/accounts?$select=accountid,name,_ownerid_value,msp_parentinglevelcode"
                f"&$top=200&$filter=" + urllib.parse.quote(f"msp_mstopparentid eq '{tp}'"), token)["value"]
    owner = None
    for a in accs:
        ov = a.get("_ownerid_value@OData.Community.Display.V1.FormattedValue", "")
        if ov and "Account Owner" not in ov and "LATAM" not in ov:
            owner = ov
            break
    cands = [a["accountid"] for a in accs
             if a.get("msp_parentinglevelcode@OData.Community.Display.V1.FormattedValue") == "Top"]
    persons = [a for a in accs if (lambda ov: ov and "Account Owner" not in ov and "LATAM" not in ov)(
        a.get("_ownerid_value@OData.Community.Display.V1.FormattedValue", ""))]
    persons.sort(key=lambda a: len(a.get("name", "")))
    cands += [a["accountid"] for a in persons[:7]]
    out, seen = [], set()
    for g in cands:
        if g not in seen:
            seen.add(g)
            out.append(g)
    return out, owner


def main():
    macc = json.load(open(cfg.MACC_ALL_JSON, encoding="utf-8")) if cfg.MACC_ALL_JSON.exists() else {}
    seats = json.load(open(cfg.SEATS_JSON, encoding="utf-8")) if cfg.SEATS_JSON.exists() else {}
    if not macc and not seats:
        print("ERROR: run pull_macc.py and pull_seats.py first", file=sys.stderr)
        return 2
    scope = sorted(build_top50.select_scope(macc, seats),
                   key=lambda tp: tp not in cfg.PORTFOLIO)  # carteira first
    token = cfg.get_token(RESOURCE)

    out = {}
    for i, tp in enumerate(scope, 1):
        name = cfg.SHORTNAME.get(tp) or macc.get(tp, {}).get("name") or seats.get(tp, {}).get("name", tp)
        rec = {"name": name, "ae": None, "ats": None, "csam": None, "csam_all": [], "owner": None}
        try:
            cands, rec["owner"] = _account_candidates(tp, token)
            for g in cands:
                ae, ats, csams = _team_on(g, token)
                if ae or ats:
                    rec["ae"], rec["ats"], rec["csam_all"] = ae, ats, csams
                    c = _pick_csam(csams)
                    rec["csam"] = c["name"] if c else None
                    break
                time.sleep(0.05)
            if not rec["ae"] and rec["owner"]:
                rec["ae"] = rec["owner"]
        except Exception as e:
            rec["error"] = str(e)[:150]
        out[tp] = rec
        print(f"[{i:>2}/{len(scope)}] {name[:26]:26} AE={rec['ae']} | ATS={rec['ats']} | CSAM={rec['csam']}",
              flush=True)
        time.sleep(0.05)

    cfg.TEAM_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    n_ae = sum(1 for v in out.values() if v["ae"])
    n_ats = sum(1 for v in out.values() if v["ats"])
    n_cs = sum(1 for v in out.values() if v["csam"])
    print(f"\n✅ {cfg.TEAM_JSON.name}: {len(out)} accounts · AE={n_ae} ATS={n_ats} CSAM={n_cs}")
    if out and n_ae == 0:
        print("✗ no AE resolved for ANY account — Dataverse auth/endpoint likely failed", file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
