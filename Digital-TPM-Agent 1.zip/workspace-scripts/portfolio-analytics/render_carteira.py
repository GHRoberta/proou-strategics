"""Stage 6b — refresh the Carteira FY27 dashboard's MACC enrichment in place.

The Carteira dashboard embeds its data inline; its non-MACC columns come from
pre-existing Work Hub inputs (assembled separately). This stage regenerates ONLY
the `const MACC={...}` block from macc_by_tpid.json so a MACC refresh actually
reaches the deliverable (KPIs recompute in-browser from the merged DATA).

Idempotent: replaces exactly one line. Run aggregate_macc.py first.
"""
import json
import re
import sys

import portfolio_config as cfg

PATTERN = re.compile(r"(?m)^const MACC=\{.*\};$")


def main():
    if not cfg.MACC_BY_TPID_JSON.exists():
        print("ERROR: run aggregate_macc.py first (no macc_by_tpid.json)", file=sys.stderr)
        return 2
    if not cfg.CARTEIRA_DASHBOARD.exists():
        print(f"ERROR: {cfg.CARTEIRA_DASHBOARD.name} not found", file=sys.stderr)
        return 2

    macc = json.load(open(cfg.MACC_BY_TPID_JSON, encoding="utf-8"))
    compact = {tp: {"c": round(v["committed"]), "u": round(v["consumed"]),
                    "p": v["util_pct"], "e": v["end"], "r": v["risk"], "n": v["n_macc"]}
               for tp, v in macc.items() if v.get("has_macc")}
    js = "const MACC=" + json.dumps(compact, ensure_ascii=False, separators=(",", ":")) + ";"

    html = cfg.CARTEIRA_DASHBOARD.read_text(encoding="utf-8")
    new_html, n = PATTERN.subn(lambda _: js, html)
    if n != 1:
        print(f"ERROR: expected exactly one `const MACC=...;` line, found {n} "
              f"(dashboard structure changed — inspect before re-running)", file=sys.stderr)
        return 3
    cfg.CARTEIRA_DASHBOARD.write_text(new_html, encoding="utf-8")
    tc = sum(v["c"] for v in compact.values())
    print(f"✅ {cfg.CARTEIRA_DASHBOARD.name}: MACC block refreshed for {len(compact)} accounts "
          f"(Σ committed=${tc/1e9:.2f}bi)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
