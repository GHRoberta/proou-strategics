"""Stage 2b — FY27 open M365 Copilot opportunity seats per account (fresh, authoritative).

Two authoritative sources, joined by Opportunity ID:
  1. PBI "M365 Copilot Usage" · 'Opportunity Pipeline' table — the seat authority.
     Universe = Is M365 Copilot(Opportunity)=Yes AND MSX Status=Open, seats>0.
     This INCLUDES E7/ME7 bundles (flag-based), which a name search for "Copilot"
     would miss (e.g. [CLIENTE] ME7 = 104K). Written to open_copilot_opps.json.
  2. MSX Dataverse — the opp -> account -> TPID map:
       opportunity._parentaccountid_value -> account.msp_mstopparentid (= TPID).
     The 'Opportunity Pipeline' PBI table has NO account/TPID column and its
     'Customer' relationship does not propagate the seat measure, so the ONLY
     reliable per-account roll-up is by Opportunity ID (verified 2026-07-03).

Scope TPIDs = every row in top50_macc_seats.json UNION the managed portfolio,
so whatever lands in the reduced top-20 + carteira list is always covered.

Output: opp_seats_by_tpid.json  {tpid: {n, seats, top_name, top_seats}}.
"""
import json
import sys
import urllib.parse
import urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import portfolio_config as cfg

UNIVERSE_JSON = cfg.DATA_DIR / "open_copilot_opps.json"
OUT_JSON = cfg.DATA_DIR / "opp_seats_by_tpid.json"


# ----------------------------------------------------------------- PBI universe
def _pbi_rows(token, dax):
    body = json.dumps({"queries": [{"query": dax}]}).encode("utf-8")
    req = urllib.request.Request(
        cfg.PBI_EXECUTE_URL.format(dataset=cfg.PBI_COPILOT_USAGE), data=body,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.loads(r.read().decode("utf-8"))["results"][0]["tables"][0]["rows"]


def refresh_universe():
    """Re-pull the open M365 Copilot opportunity universe (id, name, seats) from PBI."""
    token = cfg.get_token(cfg.PBI_RESOURCE)
    dax = (
        "EVALUATE FILTER(SUMMARIZECOLUMNS("
        "'Opportunity Pipeline'[Opportunity ID], 'Opportunity Pipeline'[Opportunity Name], "
        "'Opportunity Pipeline'[Is M365 Copilot(Opportunity)], 'Opportunity Pipeline'[MSX Status], "
        "\"seats\", [Seats (Opportunity)]), "
        "[Is M365 Copilot(Opportunity)]=\"Yes\" && [MSX Status]=\"Open\" && [seats]>0)"
    )
    out = []
    for row in _pbi_rows(token, dax):
        oid = (row.get("Opportunity Pipeline[Opportunity ID]") or "").lower()
        if not oid:
            continue
        out.append({"id": oid,
                    "name": row.get("Opportunity Pipeline[Opportunity Name]"),
                    "seats": int(row.get("[seats]") or 0)})
    UNIVERSE_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"✅ {UNIVERSE_JSON.name}: {len(out)} open M365 Copilot opps (Σseats={sum(o['seats'] for o in out):,})")
    return {o["id"]: o for o in out}


# ----------------------------------------------------------------- Dataverse
def _dv_get_all(token, entity, select, filt):
    """GET all pages of a Dataverse entity ($select, $filter)."""
    q = {"$select": select, "$filter": filt}
    url = f"{cfg.DATAVERSE_BASE}/{entity}?" + urllib.parse.urlencode(q)
    rows = []
    while url:
        req = urllib.request.Request(url, headers={
            "Authorization": f"Bearer {token}", "Accept": "application/json",
            "OData-Version": "4.0", "Prefer": "odata.maxpagesize=5000"})
        with urllib.request.urlopen(req, timeout=180) as r:
            j = json.loads(r.read().decode("utf-8"))
        rows.extend(j.get("value", []))
        url = j.get("@odata.nextLink")
    return rows


def _chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def account_map(token, tpids):
    """{accountGUID -> TPID} for every account record under the given TPIDs."""
    amap = {}
    for grp in _chunks(list(tpids), 40):
        filt = " or ".join(f"msp_mstopparentid eq '{t}'" for t in grp)
        for a in _dv_get_all(token, "accounts", "accountid,msp_mstopparentid", filt):
            tp = a.get("msp_mstopparentid")
            if tp is not None:
                amap[a["accountid"].lower()] = str(tp)
    return amap


def open_opps_by_account(token, account_guids):
    """{opportunityGUID -> accountGUID} for OPEN opps parented to those accounts."""
    omap = {}
    guids = list(account_guids)
    for grp in _chunks(guids, 30):
        clause = " or ".join(f"_parentaccountid_value eq {g}" for g in grp)
        filt = f"statecode eq 0 and ({clause})"
        for o in _dv_get_all(token, "opportunities", "opportunityid,_parentaccountid_value", filt):
            pa = (o.get("_parentaccountid_value") or "").lower()
            omap[o["opportunityid"].lower()] = pa
    return omap


# ----------------------------------------------------------------- scope + join
def scope_tpids():
    tp = set(cfg.PORTFOLIO_TPIDS)
    if cfg.TOP50_JSON.exists():
        for a in json.load(open(cfg.TOP50_JSON, encoding="utf-8")):
            tp.add(str(a["tpid"]))
    return tp


def main():
    universe = refresh_universe()                       # {oppid -> {id,name,seats}}
    dv = cfg.get_token(cfg.DATAVERSE_RESOURCE)

    tpids = scope_tpids()
    amap = account_map(dv, tpids)                       # accountGUID -> TPID
    print(f"   accounts under {len(tpids)} TPIDs: {len(amap)} records")

    omap = open_opps_by_account(dv, amap.keys())        # oppGUID -> accountGUID (open only)
    print(f"   open opportunities parented to those accounts: {len(omap)}")

    agg = {}
    for oid, o in universe.items():
        acc = omap.get(oid)
        if not acc:
            continue
        tp = amap.get(acc)
        if not tp:
            continue
        d = agg.setdefault(tp, {"n": 0, "seats": 0, "top_name": None, "top_seats": 0})
        d["n"] += 1
        d["seats"] += o["seats"]
        if o["seats"] > d["top_seats"]:
            d["top_seats"] = o["seats"]
            d["top_name"] = o["name"]

    OUT_JSON.write_text(json.dumps(agg, ensure_ascii=False, indent=1), encoding="utf-8")
    tot = sum(d["seats"] for d in agg.values())
    print(f"✅ {OUT_JSON.name}: {len(agg)} accounts with open Copilot opp seats (Σ={tot:,})")
    top = sorted(agg.items(), key=lambda kv: -kv[1]["seats"])[:8]
    for tp, d in top:
        print(f"   {cfg.SHORTNAME.get(tp, tp)[:24]:24} {tp:9} n={d['n']:<3} seats={d['seats']:,}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
