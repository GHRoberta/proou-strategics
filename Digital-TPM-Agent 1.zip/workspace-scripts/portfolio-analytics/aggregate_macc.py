"""Stage 4b — portfolio MACC summary for the Carteira FY27 dashboard.

Reads the same macc_portfolio.xlsx and emits a per-portfolio-TPID summary with a
committed-weighted term-vs-consumption risk flag. Feeds the MACC columns of
Carteira_FY27_Copilot_Dashboard.html.

Output: macc_by_tpid.json
"""
import json
import sys
import warnings

import pandas as pd

import portfolio_config as cfg

warnings.filterwarnings("ignore")


def main():
    if not cfg.MACC_XLSX.exists():
        print("ERROR: run pull_macc.py --refresh first (no macc_portfolio.xlsx)", file=sys.stderr)
        return 2
    df = pd.read_excel(cfg.MACC_XLSX)
    df["TPID"] = df["To Direct Top Parent ID"].astype("Int64")
    df = df[df["MACC Status"].astype(str).str.strip().str.lower() == "active"]

    out = {}
    for tp in (int(t) for t in cfg.PORTFOLIO_TPIDS):
        rows = df[df["TPID"] == tp]
        if len(rows) == 0:
            out[str(tp)] = {"has_macc": False}
            continue
        committed = float(rows["Consumption Commitment"].sum())
        consumed = float(rows["Decrement"].sum())
        balance = float(rows["Balance"].sum())
        util = consumed / committed if committed else 0.0
        w = rows["Consumption Commitment"].fillna(0)
        months = float((rows["% Months Complete"].fillna(0) * w).sum() / w.sum()) if w.sum() else 0.0
        end = pd.to_datetime(rows["End Date"]).max()
        risk = "At Risk" if months - util > 0.05 else ("Exceeding" if util - months > 0.05 else "On Track")
        out[str(tp)] = {
            "has_macc": True, "name": rows.iloc[0]["To Direct Top Parent Name"],
            "n_macc": int(len(rows)), "committed": round(committed, 2), "consumed": round(consumed, 2),
            "balance": round(balance, 2), "util_pct": round(util * 100, 1),
            "months_pct": round(months * 100, 1),
            "end": end.strftime("%Y-%m-%d") if pd.notna(end) else None, "risk": risk}

    cfg.MACC_BY_TPID_JSON.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    withmacc = [v for v in out.values() if v.get("has_macc")]
    tc = sum(v["committed"] for v in withmacc)
    tu = sum(v["consumed"] for v in withmacc)
    print(f"✅ {cfg.MACC_BY_TPID_JSON.name}: {len(withmacc)}/{len(cfg.PORTFOLIO_TPIDS)} carteira accounts with active MACC")
    print(f"   Σ committed=${tc/1e9:.2f}bi  Σ consumed=${tu/1e9:.2f}bi  util={tu/tc*100:.0f}%" if tc else "")
    return 0


if __name__ == "__main__":
    sys.exit(main())
