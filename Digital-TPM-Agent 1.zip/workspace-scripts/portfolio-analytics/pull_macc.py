"""Stage 1 — MACC balances per account.

Acquires the "MACC Balances and Shortfall" report from the MSX Insights portal
(the canonical, current per-account committed / consumed / end-date source; it is
UI-only and NOT queryable via the powerbi-remote MCP) and derives a normalized
per-TPID JSON.

  --refresh : drive Edge (persistent .pbi_profile) → Portfolio tab → Export data
              → macc_portfolio.xlsx. Omit to just re-derive JSON from the last xlsx.

Outputs: macc_portfolio.xlsx (raw), macc_all.json ({tpid:{name,committed,consumed,end,unit}}).
See references/DATA_SOURCES.md §MACC for provenance and the export gotchas.
"""
import argparse
import sys
import time
import warnings

import pandas as pd
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

import portfolio_config as cfg

warnings.filterwarnings("ignore")


def _log(m=""):
    print(m, flush=True)


def _find_pbi_frame(page):
    for f in page.frames:
        try:
            if f.evaluate("document.querySelectorAll('visual-container-modern,.visualContainer').length") > 0:
                return f
        except Exception:
            pass
    return None


def _dismiss_modal(page):
    for sel in ('button:has-text("Dismiss All")', 'button:has-text("Close")', 'button[aria-label="Close"]'):
        try:
            b = page.locator(sel).first
            if b.is_visible(timeout=1200):
                b.click(); time.sleep(1); return
        except Exception:
            continue


def _click_tab(page, name):
    try:
        return bool(page.evaluate(
            """(name)=>{const els=[...document.querySelectorAll('button[role="tab"]')]
              .filter(e=>(e.getAttribute('name')||e.getAttribute('data-content')||e.innerText||'').trim()===name);
              if(!els.length)return false;const m=els[els.length-1];m.scrollIntoView({block:'center'});m.click();return true;}""",
            name))
    except Exception:
        return False


def export_xlsx():
    """Drive Edge to export the Portfolio table to macc_portfolio.xlsx."""
    url = cfg.MSXI_REPORT_URL.format(report=cfg.MSXI_MACC_REPORT, upn=cfg.USER_UPN)
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            str(cfg.PBI_PROFILE), channel="msedge", headless=False,
            viewport={"width": 1680, "height": 1050}, accept_downloads=True,
            args=["--disable-blink-features=AutomationControlled",
                  "--auth-server-allowlist=*.microsoft.com,*.microsoftonline.com"])
        page = ctx.new_page()
        _log(f"→ {url[:90]} …")
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=120_000)
        except Exception as e:
            _log(f"  nav: {e}")

        deadline = time.time() + 180
        frame = None
        while time.time() < deadline:
            frame = _find_pbi_frame(page)
            if frame:
                break
            time.sleep(2)
        if not frame:
            ctx.close(); raise RuntimeError("no Power BI iframe rendered (auth expired? sign in to Edge)")
        time.sleep(5); _dismiss_modal(page); time.sleep(1)

        _log("→ Portfolio tab"); _click_tab(page, "Portfolio"); time.sleep(14)
        _dismiss_modal(page); frame = _find_pbi_frame(page)

        # detailed account table = the visible visual whose text has these headers
        target, best_area = None, 0
        handles = []
        for qs in (".visualContainer", "visual-container-modern", "visual-container"):
            try:
                handles += frame.query_selector_all(qs)
            except Exception:
                pass
        for h in handles:
            try:
                txt = h.inner_text() or ""
            except Exception:
                continue
            if "% Commit Complete" in txt or ("Consumption Commitment" in txt and "Balance" in txt):
                bb = h.bounding_box()
                if bb and bb["width"] * bb["height"] > best_area:
                    best_area, target = bb["width"] * bb["height"], h
        if target is None:
            ctx.close(); raise RuntimeError("MACC Portfolio table visual not found")

        target.scroll_into_view_if_needed(timeout=8000); target.hover(timeout=5000); time.sleep(1.5)
        more = None
        for _ in range(3):
            for msel in ('button[aria-label="More options"]', 'button[title="More options"]', '[aria-label*="More options"]'):
                more = target.query_selector(msel)
                if more:
                    break
            if more:
                break
            target.hover(); time.sleep(1)
        if not more:
            ctx.close(); raise RuntimeError("could not open the visual's More options menu")
        more.click(); time.sleep(1)

        exp = False
        for sel in ('div[role="menuitem"]:has-text("Export data")', 'button:has-text("Export data")', 'text="Export data"'):
            for c in (page, frame):
                try:
                    e = c.locator(sel).first
                    if e.is_visible(timeout=1500):
                        e.click(); exp = True; break
                except Exception:
                    continue
            if exp:
                break
        if not exp:
            ctx.close(); raise RuntimeError("Export data menu item not found")
        time.sleep(1.5)

        # export dialog renders INSIDE the iframe; default "Data with current layout" + .xlsx
        try:
            with page.expect_download(timeout=150_000) as dl:
                done = False
                for c in (frame, page):
                    for sel in ('button[data-testid="export-button"]', 'button.primary:has-text("Export")',
                                'button:has-text("Export"):not(:has-text("data"))', 'button:has-text("Export")'):
                        try:
                            b = c.locator(sel).last
                            if b.is_visible(timeout=1500):
                                b.click(); done = True; break
                        except Exception:
                            continue
                    if done:
                        break
            dl.value.save_as(str(cfg.MACC_XLSX))
            _log(f"✅ exported → {cfg.MACC_XLSX.name}")
        except PWTimeout:
            ctx.close(); raise RuntimeError("export download did not start within 150s")
        ctx.close()


def derive_json():
    """macc_portfolio.xlsx → macc_all.json (all active MACC accounts, incl. foreign)."""
    df = pd.read_excel(cfg.MACC_XLSX)
    df = df[df["MACC Status"].astype(str).str.strip().str.lower() == "active"]
    df["TPID"] = df["To Direct Top Parent ID"].astype("Int64")
    g = df.groupby("TPID").agg(
        name=("To Direct Top Parent Name", "first"),
        committed=("Consumption Commitment", "sum"),
        decrement=("Decrement", "sum"),
        unit=("To Direct Sales Unit", "first"),
        end=("End Date", "max")).reset_index()
    recs = {}
    for _, r in g.iterrows():
        _end = pd.to_datetime(r["end"])
        recs[str(int(r.TPID))] = {
            "name": r["name"], "committed": round(float(r.committed)),
            "consumed": round(float(r.decrement)),
            "end": (str(_end.date()) if pd.notna(_end) else None), "unit": r["unit"]}
    import json
    cfg.MACC_ALL_JSON.write_text(json.dumps(recs, ensure_ascii=False, indent=1), encoding="utf-8")
    _log(f"✅ {cfg.MACC_ALL_JSON.name}: {len(recs)} active MACC accounts")
    return recs


def main(refresh: bool):
    if refresh or not cfg.MACC_XLSX.exists():
        if not cfg.MACC_XLSX.exists():
            _log("(no cached xlsx — forcing browser export)")
        export_xlsx()
    else:
        _log(f"(reusing cached {cfg.MACC_XLSX.name}; pass --refresh to re-scrape)")
    derive_json()
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--refresh", action="store_true", help="re-scrape the MSX Insights portal via Edge")
    sys.exit(main(ap.parse_args().refresh))
