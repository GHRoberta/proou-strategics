"""Health check / test routine for the portfolio-analytics pipeline.

Read-only. Verifies the pipeline "is working" across four layers:
  1. config integrity   (30 unique portfolio TPIDs, complete metadata)
  2. tooling / deps      (pandas, playwright, node, jsdom)
  3. live access         (Dataverse + Power BI tokens, cached Edge profile)   [skip with --offline]
  4. artifacts & output  (each JSON present, valid, sane counts; dashboards pass jsdom)

Exit code 0 only if every non-skipped critical check passes.

  python healthcheck.py            # full check
  python healthcheck.py --offline  # skip token/browser-profile checks (validate artifacts only)
"""
import argparse
import importlib
import json
import subprocess
import sys
from pathlib import Path

import portfolio_config as cfg

HERE = Path(__file__).resolve().parent
OK, FAIL, WARN, SKIP = "✓", "✗", "!", "–"
rows = []
crit_fail = False


def check(label, fn, critical=True):
    global crit_fail
    try:
        ok, detail = fn()
    except Exception as e:
        ok, detail = False, f"{type(e).__name__}: {str(e)[:90]}"
    mark = OK if ok else (FAIL if critical else WARN)
    if not ok and critical:
        crit_fail = True
    rows.append((mark, label, detail))


def skip(label, detail=""):
    rows.append((SKIP, label, detail))


# ---- 1. config integrity
def _cfg_tpids():
    n = len(cfg.PORTFOLIO_TPIDS)
    dup = n != len(set(cfg.PORTFOLIO_TPIDS))
    complete = all(tp in cfg.VERT and tp in cfg.SHORTNAME for tp in cfg.PORTFOLIO_TPIDS)
    return (n == 30 and not dup and complete), f"{n} TPIDs, unique={not dup}, metadata_complete={complete}"


# ---- 2. tooling
def _import(mod):
    def f():
        importlib.import_module(mod)
        return True, "importable"
    return f


def _node_pkg(pkg):
    def f():
        r = subprocess.run(["node", "-e", f"require.resolve('{pkg}')"], cwd=str(cfg.HUB_DIR),
                           capture_output=True, text=True)
        return r.returncode == 0, ("resolved" if r.returncode == 0 else r.stderr.strip()[:80])
    return f


def _node():
    r = subprocess.run(["node", "--version"], capture_output=True, text=True)
    return r.returncode == 0, r.stdout.strip()


# ---- 3. live access
def _token(resource, name):
    def f():
        t = cfg.get_token(resource)
        return bool(t) and len(t) > 100, f"{name} token len={len(t)}"
    return f


def _profile():
    return cfg.PBI_PROFILE.exists(), str(cfg.PBI_PROFILE)


# ---- 4. artifacts
def _json_dict(path, min_n, required_keys):
    def f():
        d = json.load(open(path, encoding="utf-8"))
        assert isinstance(d, dict), "not a dict"
        assert len(d) >= min_n, f"only {len(d)} (< {min_n})"
        if d and required_keys:
            sample = next(iter(d.values()))
            miss = [k for k in required_keys if k not in sample]
            assert not miss, f"missing keys {miss}"
        return True, f"{len(d)} entries"
    return f


def _macc_all():
    return _json_dict(cfg.MACC_ALL_JSON, 40, ["name", "committed", "consumed", "end", "unit"])()


def _seats():
    return _json_dict(cfg.SEATS_JSON, 100, ["name", "paid"])()


def _team():
    d = json.load(open(cfg.TEAM_JSON, encoding="utf-8"))
    ae = sum(1 for v in d.values() if v.get("ae"))
    return (len(d) >= 40 and ae >= 30), f"{len(d)} accounts, AE coverage={ae}"


def _opp_seats():
    return _json_dict(cfg.OPP_SEATS_JSON, 20, ["n", "seats"])()


def _macc_by_tpid():
    d = json.load(open(cfg.MACC_BY_TPID_JSON, encoding="utf-8"))
    withm = sum(1 for v in d.values() if v.get("has_macc"))
    return (len(d) == 30 and withm >= 20), f"{len(d)} carteira accounts, {withm} with active MACC (expect 30 / ≥20)"


def _top50():
    d = json.load(open(cfg.TOP50_JSON, encoding="utf-8"))
    assert isinstance(d, list) and len(d) >= 30, f"only {len(d)} rows"
    tpids = {r["tpid"] for r in d}
    miss = [tp for tp in cfg.PORTFOLIO_TPIDS if tp not in tpids]
    assert not miss, f"carteira TPIDs missing: {miss}"
    top = [r for r in d if not r.get("beyond")]
    assert len(top) == 20, f"expected 20 top rows, got {len(top)}"
    assert all("opp_seats" in r and "fy27_total" in r and "trained" in r for r in d), "rows missing FY27 opp / FY26 trained fields"
    car = sum(1 for r in top if r["carteira"])
    return True, f"{len(d)} rows (top20 + {len(d) - 20} carteira), all 30 carteira present, top20 carteira={car}"


def _xlsx():
    return cfg.MACC_XLSX.exists(), f"{cfg.MACC_XLSX.stat().st_size // 1024} KB" if cfg.MACC_XLSX.exists() else "missing"


def _dashboards():
    r = subprocess.run(["node", "validate_dashboard.js"], cwd=str(HERE), capture_output=True, text=True)
    tail = (r.stdout or "").strip().splitlines()[-1] if r.stdout else (r.stderr or "")[:80]
    return r.returncode == 0, tail


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--offline", action="store_true")
    off = ap.parse_args().offline

    print("portfolio-analytics · health check\n")
    check("config: 30 unique portfolio TPIDs + metadata", _cfg_tpids)
    check("dep: pandas", _import("pandas"))
    check("dep: playwright", _import("playwright"))
    check("dep: node runtime", _node)
    check("dep: jsdom (node)", _node_pkg("jsdom"))

    if off:
        skip("live: Dataverse token", "--offline")
        skip("live: Power BI token", "--offline")
        skip("live: cached Edge profile", "--offline")
    else:
        check("live: Dataverse token (az)", _token(cfg.DATAVERSE_RESOURCE, "dataverse"))
        check("live: Power BI token (az)", _token(cfg.PBI_RESOURCE, "powerbi"))
        check("live: cached Edge .pbi_profile", _profile, critical=False)

    check("data: macc_all.json", _macc_all)
    check("data: seats_by_tpid.json", _seats)
    check("data: opp_seats_by_tpid.json (FY27)", _opp_seats)
    check("data: team_by_tpid.json", _team)
    check("data: macc_by_tpid.json (carteira)", _macc_by_tpid)
    check("data: top50_macc_seats.json", _top50)
    check("data: macc_portfolio.xlsx", _xlsx, critical=False)
    check("output: dashboards pass jsdom", _dashboards)

    w = max(len(l) for _, l, _ in rows)
    for mark, label, detail in rows:
        print(f"  {mark}  {label.ljust(w)}   {detail}")
    print("\n" + ("❌ HEALTH CHECK FAILED" if crit_fail else "✅ ALL CRITICAL CHECKS PASSED"))
    return 1 if crit_fail else 0


if __name__ == "__main__":
    sys.exit(main())
