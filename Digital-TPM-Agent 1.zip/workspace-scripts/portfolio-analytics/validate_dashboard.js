// Validate portfolio-analytics dashboards with jsdom (browser-faithful).
//
// Runs each dashboard's inline <script> in a real DOM and asserts:
//   - zero script errors (catches the window-global collision class of bug)
//   - the account table actually rendered rows
//   - no literal "undefined" / "NaN" leaked into KPI values
//
//   node validate_dashboard.js            # validate both known dashboards
//   node validate_dashboard.js <file>     # validate one HTML file
const fs = require("fs");
const path = require("path");
const { JSDOM, VirtualConsole } = require("jsdom");

const HUB = path.resolve(__dirname, "..");
const DEFAULTS = [
  path.join(HUB, "Top50_MACC_Copilot_Brasil.html"),
  path.join(HUB, "Carteira_FY27_Copilot_Dashboard.html"),
];

function validate(file) {
  if (!fs.existsSync(file)) return { file, ok: false, why: "file not found" };
  const html = fs.readFileSync(file, "utf8");
  const errs = [];
  const vc = new VirtualConsole();
  vc.on("jsdomError", (e) => errs.push(String(e.message || e)));
  vc.on("error", (...a) => errs.push("console.error: " + a.join(" ")));
  const dom = new JSDOM(html, { runScripts: "dangerously", resources: "usable", virtualConsole: vc });
  const doc = dom.window.document;
  return new Promise((resolve) => {
    setTimeout(() => {
      const rows = doc.querySelectorAll("#tb tr").length;
      const kpis = [...doc.querySelectorAll(".kpi .v")].map((e) => e.textContent.trim());
      const badKpi = kpis.find((t) => /undefined|NaN/.test(t));
      const ok = errs.length === 0 && rows > 0 && !badKpi;
      resolve({
        file: path.basename(file), ok, rows,
        errors: errs.slice(0, 4),
        why: badKpi ? `bad KPI value "${badKpi}"` : (rows === 0 ? "no table rows rendered" : ""),
      });
    }, 1500);
  });
}

(async () => {
  const files = process.argv.slice(2);
  const targets = files.length ? files : DEFAULTS;
  let allOk = true;
  for (const f of targets) {
    const r = await validate(f);
    allOk = allOk && r.ok;
    console.log(`${r.ok ? "PASS" : "FAIL"}  ${r.file}  (rows=${r.rows ?? 0})${r.why ? "  ← " + r.why : ""}`);
    (r.errors || []).forEach((e) => console.log("      " + e));
  }
  console.log(allOk ? "\n✅ dashboards VALID" : "\n❌ dashboard validation FAILED");
  process.exit(allOk ? 0 : 1);
})();
