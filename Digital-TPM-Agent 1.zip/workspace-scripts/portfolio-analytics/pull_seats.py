"""Stage 2 — M365 Copilot paid seats per account (Brazil).

Thin roll-up over the Power BI "M365 Copilot Usage" semantic model. The seats
authority is the `copilot-usage` plugin skill; this only fetches
[Paid Available Units (M365 Copilot)] by TPID for Brazil (Field Region = BRA)
plus explicit coverage of every portfolio + MACC TPID, via the executeQueries
REST endpoint (the /myorg/datasets/{id}/executeQueries form, WITHOUT /groups/).

Output: seats_by_tpid.json  ({tpid: {name, paid}}).
"""
import json
import sys
import urllib.request

import portfolio_config as cfg


def _run_dax(token, dax):
    body = json.dumps({"queries": [{"query": dax}]}).encode("utf-8")
    req = urllib.request.Request(
        cfg.PBI_EXECUTE_URL.format(dataset=cfg.PBI_COPILOT_USAGE), data=body,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode("utf-8"))["results"][0]["tables"][0]["rows"]


def main():
    token = cfg.get_token(cfg.PBI_RESOURCE)
    m = f"[{cfg.COPILOT_SEATS_MEASURE}]"

    # q1: top-150 Brazil accounts by paid seats
    q1 = (f'EVALUATE TOPN(150, FILTER(SUMMARIZECOLUMNS(\'Customer\'[TPID], \'Customer\'[Customer Name], '
          f'TREATAS({{"{cfg.COPILOT_REGION}"}},\'Customer\'[Field Region]), "Paid", {m}), [Paid]>0), [Paid], DESC)')

    # q2: guarantee coverage of portfolio + all MACC accounts (may be sub-150)
    macc = json.load(open(cfg.MACC_ALL_JSON, encoding="utf-8")) if cfg.MACC_ALL_JSON.exists() else {}
    want = sorted({*cfg.PORTFOLIO_TPIDS, *macc.keys()})
    tset = ",".join(want)
    q2 = (f'EVALUATE SUMMARIZECOLUMNS(\'Customer\'[TPID], \'Customer\'[Customer Name], '
          f'KEEPFILTERS(TREATAS({{{tset}}},\'Customer\'[TPID])), "Paid", {m})')

    seats = {}
    for dax in (q1, q2):
        for row in _run_dax(token, dax):
            tp = str(row.get("Customer[TPID]"))
            nm = row.get("Customer[Customer Name]")
            paid = int(row.get("[Paid]") or 0)
            if tp in ("None", "") or paid <= 0:
                continue
            if tp not in seats or paid > seats[tp]["paid"]:
                seats[tp] = {"name": nm, "paid": paid}

    cfg.SEATS_JSON.write_text(json.dumps(seats, ensure_ascii=False, indent=1), encoding="utf-8")
    top = sorted(seats.values(), key=lambda x: -x["paid"])[:5]
    print(f"✅ {cfg.SEATS_JSON.name}: {len(seats)} accounts with paid seats")
    print("   top: " + " | ".join(f"{d['name'][:18]}={d['paid']:,}" for d in top))
    return 0


if __name__ == "__main__":
    sys.exit(main())
