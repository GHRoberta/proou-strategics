"""
cockpit_serve.py — Live-reload server for the TPM Cockpit.

Runs three things in one process:
  1. A tiny HTTP server on http://localhost:8765/ that serves the working
     directory with `Cache-Control: no-store` so a plain F5 always pulls
     the freshest kanban_data.js.
  2. A polling watcher (mtime-based, no external deps) that rebuilds
     kanban_data.js whenever any file under cockpit-cards/ changes.
  3. An auto-launch of kanban_view.html in the default browser.

Usage:
    python cockpit_serve.py            # serve + watch + open browser
    python cockpit_serve.py --no-open  # serve + watch only

Stop with Ctrl+C.
"""
from __future__ import annotations

import argparse
import http.server
import socketserver
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

# When launched with redirected stdout (e.g. Start-Process -RedirectStandardOutput),
# Windows defaults to cp1252 and the emoji status prints raise UnicodeEncodeError,
# which crashed the whole server on startup. Force UTF-8 so it stays up.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

ROOT = Path(__file__).resolve().parent
CARDS_DIR = ROOT / "cockpit-cards"
PORT = 8765
POLL_INTERVAL_S = 1.0


class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, format: str, *args) -> None:  # noqa: A002
        # Silence per-request noise; keep the watcher logs readable.
        first = args[0] if args else ""
        if isinstance(first, str) and "kanban_data.js" in first:
            return
        try:
            sys.stderr.write("  HTTP %s\n" % (format % args))
        except Exception:
            sys.stderr.write(f"  HTTP {format!r} args={args!r}\n")


def _snapshot_mtimes() -> dict[Path, float]:
    out: dict[Path, float] = {}
    if not CARDS_DIR.exists():
        return out
    for p in CARDS_DIR.rglob("*"):
        if p.is_file() and p.suffix in {".md", ".yml", ".yaml", ".json"}:
            try:
                out[p] = p.stat().st_mtime
            except OSError:
                pass
    return out


def _run_build() -> bool:
    print("🔨 Rebuilding kanban_data.js…")
    proc = subprocess.run(
        [sys.executable, str(ROOT / "cockpit_build.py")],
        cwd=str(ROOT),
        env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"},
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if proc.returncode == 0:
        # Show only the success summary line
        for line in proc.stdout.splitlines():
            if line.startswith("✅") or line.startswith("   "):
                print("   " + line)
        return True
    print("❌ Build failed:")
    print(proc.stdout)
    print(proc.stderr)
    return False


def _watcher_loop(stop: threading.Event) -> None:
    last = _snapshot_mtimes()
    while not stop.wait(POLL_INTERVAL_S):
        try:
            now = _snapshot_mtimes()
        except Exception as e:
            print(f"⚠️  Watcher snapshot error: {e}")
            continue
        if now != last:
            changed = [
                p.relative_to(ROOT)
                for p in set(now) | set(last)
                if last.get(p) != now.get(p)
            ]
            print(f"📝 Detected change in {len(changed)} file(s): " + ", ".join(str(c) for c in changed[:3]) + (" …" if len(changed) > 3 else ""))
            _run_build()
            last = _snapshot_mtimes()  # re-snapshot in case build touched files


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-open", action="store_true", help="don't auto-open the browser")
    ap.add_argument("--no-initial-build", action="store_true", help="skip the initial rebuild on startup")
    args = ap.parse_args()

    if not args.no_initial_build:
        _run_build()

    stop = threading.Event()
    watcher = threading.Thread(target=_watcher_loop, args=(stop,), daemon=True)
    watcher.start()

    handler = NoCacheHandler
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", PORT), handler) as httpd:
        url = f"http://localhost:{PORT}/kanban_view.html"
        print(f"🚀 TPM Cockpit live server: {url}")
        print(f"   Watching: {CARDS_DIR.relative_to(ROOT)}/  (poll every {POLL_INTERVAL_S}s)")
        print("   Edit any .md → save → F5 in browser.  Ctrl+C to stop.")
        if not args.no_open:
            webbrowser.open(url)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n👋 Stopping…")
        finally:
            stop.set()
            httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
