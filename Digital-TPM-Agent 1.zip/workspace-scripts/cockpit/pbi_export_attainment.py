"""
PBI Attainment Exporter — uses Playwright to drive the official "Export data"
button on the Delivery Details visual of the FY26 TPM Learner Target Attainment
report. Replaces the DSR-scraping pipeline (pbi_attainment_scraper.py +
decode_attainment.py) with a single deterministic step.

Run:
    python pbi_export_attainment.py            # headed (first run)
    python pbi_export_attainment.py --headless # silent (after profile cached)

First run: complete sign-in (and account picker) once. Profile is persisted
in `.pbi_profile/`. Subsequent runs use cached cookies + auto-click the
account tile if the picker reappears, allowing zero-touch headless operation.

Output:
    attainment_FY26.xlsx          # raw export from PBI (summarized data)
    attainment_summary.json       # per-account aggregates
    attainment_rows.json          # flat row dicts (for debugging)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

REPORT_URL = (
    "https://msit.powerbi.com/Redirect?action=OpenReport"
    "&appId=62ab3a32-dfac-4de4-b771-0e088930a964"
    "&reportObjectId=a1e7e754-3728-4b6f-9868-dd9cb9b43c2b"
    "&ctid={{TENANT_ID}}"
    "&reportPage=b663309b930d9e675ea4"
    "&pbi_source=appShareLink"
)

USER_UPN = "{{EMAIL}}"

WORKDIR = Path(__file__).resolve().parent
PROFILE = WORKDIR / ".pbi_profile"
EXCEL_OUT = WORKDIR / "attainment_FY26.xlsx"
SUMMARY_OUT = WORKDIR / "attainment_summary.json"
ROWS_OUT = WORKDIR / "attainment_rows.json"


def _try_click_account_tile(page, log) -> bool:
    """If the MS account picker is showing, click our tile."""
    selectors = [
        f'div[data-test-id="{USER_UPN}"]',
        f'div[role="button"]:has-text("{USER_UPN}")',
        f'small:has-text("{USER_UPN}")',
        f'div.table:has-text("{USER_UPN}")',
        f'text={USER_UPN}',
    ]
    for sel in selectors:
        try:
            loc = page.locator(sel).first
            if loc.is_visible(timeout=1500):
                log(f"  → clicking account tile via {sel}")
                loc.click()
                return True
        except Exception:
            continue
    return False


def _wait_for_landing(page, log, timeout_s: int = 300) -> bool:
    deadline = time.time() + timeout_s
    last_url = ""
    while time.time() < deadline:
        try:
            u = page.url
        except Exception:
            return False
        if u != last_url:
            log(f"  url: {u[:130]}")
            last_url = u
        if "powerbi.com" in u and "/Redirect" not in u and "login.microsoft" not in u.lower() and "login.live" not in u.lower():
            log(f"  ✅ landed: {u[:90]}")
            return True
        # Retry account picker click each loop
        if "login.microsoftonline.com" in u or "login.live.com" in u:
            if _try_click_account_tile(page, log):
                time.sleep(2)
        time.sleep(1.5)
    # Timed out — diagnostic dump
    try:
        page.screenshot(path=str(WORKDIR / "pbi_export_debug.png"), full_page=True)
        log(f"  📸 screenshot → pbi_export_debug.png   (url={page.url[:120]})")
    except Exception as e:
        log(f"  screenshot fail: {e}")
    return False


def _find_report_frame(page):
    """Return the iframe containing the actual report (cross-origin)."""
    for f in page.frames:
        url = f.url or ""
        if "reportEmbed" in url or ("powerbi.com" in url and "embed" in url.lower()):
            return f
    return None


def _trigger_export(page, log) -> Path | None:
    """
    Hover the Delivery Details visual, click its '...' menu, choose
    'Export data' → 'Summarized data' → .xlsx, intercept the download.
    """
    log("\n⏳ waiting 25s for visuals to render before triggering export …")
    time.sleep(25)

    frame = _find_report_frame(page) or page
    log(f"  using frame: {getattr(frame, 'url', '<page>')[:90]}")

    # The Delivery Details table is the last/largest visual on the page.
    # We click the "More options" (...) button on it. PBI visuals expose
    # that button only on hover, so we hover first.
    visual_selectors = [
        'visual-container:has(visual-modern-tile-table)',
        'visual-container[class*="tableEx"]',
        'div.visualContainer:has([role="grid"])',
        'visual-container',
    ]
    target = None
    for sel in visual_selectors:
        try:
            els = frame.locator(sel)
            n = els.count()
            log(f"  selector '{sel}' → {n} matches")
            if n:
                # Pick the largest visual = most likely the data table
                target = els.last
                break
        except Exception as e:
            log(f"    selector error: {e}")
    if target is None:
        log("  ❌ could not locate any visual-container")
        return None

    try:
        target.scroll_into_view_if_needed(timeout=10_000)
        target.hover(timeout=5_000)
        time.sleep(1.5)
    except Exception as e:
        log(f"  hover error: {e}")

    # Click the "..." (More options) — aria-label is "More options"
    more_selectors = [
        'button[aria-label="More options"]',
        'button[title="More options"]',
        'i.glyphicon-more',
        '[aria-label*="More options"]',
    ]
    clicked_more = False
    for sel in more_selectors:
        try:
            btn = target.locator(sel).last
            if btn.is_visible(timeout=2000):
                btn.click()
                clicked_more = True
                log(f"  ✅ clicked More options via {sel}")
                break
        except Exception:
            continue
    if not clicked_more:
        log("  ❌ could not click More options on the visual")
        return None

    time.sleep(1)

    # Click "Export data" in the popup menu (rendered at root, not inside frame)
    export_clicked = False
    for sel in [
        'div[role="menuitem"]:has-text("Export data")',
        'div.pbi-menu-item:has-text("Export data")',
        'button:has-text("Export data")',
        'text="Export data"',
    ]:
        for ctx_obj in (page, frame):
            try:
                el = ctx_obj.locator(sel).first
                if el.is_visible(timeout=2000):
                    el.click()
                    export_clicked = True
                    log(f"  ✅ clicked Export data via {sel}")
                    break
            except Exception:
                continue
        if export_clicked:
            break
    if not export_clicked:
        log("  ❌ could not click Export data")
        return None

    time.sleep(1.5)

    # Export dialog: choose "Summarized data" + .xlsx, click Export, capture download
    # Try selecting summarized data radio if present
    for sel in [
        'input[type="radio"][value="summarized"]',
        'label:has-text("Summarized data")',
        'text="Summarized data"',
    ]:
        try:
            el = page.locator(sel).first
            if el.is_visible(timeout=1500):
                el.click()
                log(f"  ✅ selected Summarized data")
                break
        except Exception:
            continue

    # Now hit the Export button in the dialog and intercept the download
    try:
        with page.expect_download(timeout=120_000) as dl_info:
            for sel in [
                'button:has-text("Export"):not(:has-text("data"))',
                'button.dialog-action-btn:has-text("Export")',
                'button[data-testid="export-button"]',
                'button:has-text("Export")',
            ]:
                try:
                    btn = page.locator(sel).last
                    if btn.is_visible(timeout=1500):
                        btn.click()
                        log(f"  ✅ clicked dialog Export via {sel}")
                        break
                except Exception:
                    continue
        download = dl_info.value
        download.save_as(str(EXCEL_OUT))
        log(f"  ✅ downloaded → {EXCEL_OUT}")
        return EXCEL_OUT
    except PWTimeout:
        log("  ❌ download did not start within 2 min")
        return None


def _decrypt_to_csv(xls_path: Path, log) -> Path | None:
    """
    PBI exports are MIP/AIP-encrypted XLS (sensitivity label baked in).
    Drive Excel via COM to convert to plain CSV — Excel auto-decrypts
    transparently for the signed-in user.
    """
    try:
        import win32com.client as w
    except ImportError:
        log("  installing pywin32 …")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pywin32", "-q"])
        import win32com.client as w

    csv_path = xls_path.with_suffix(".csv")
    src = str(xls_path.resolve())
    dst = str(csv_path.resolve())
    if csv_path.exists():
        csv_path.unlink()
    log(f"  decrypting via Excel COM → {csv_path.name}")
    xl = w.Dispatch("Excel.Application")
    xl.Visible = False
    xl.DisplayAlerts = False
    try:
        wb = xl.Workbooks.Open(src)
        wb.Sheets(1).SaveAs(dst, FileFormat=6)  # 6 = xlCSV
        wb.Close(False)
    finally:
        xl.Quit()
    if not csv_path.exists():
        log("  ❌ Excel COM did not write CSV")
        return None
    return csv_path


def aggregate(xls_path: Path, log):
    import pandas as pd

    csv_path = _decrypt_to_csv(xls_path, log)
    if csv_path is None:
        return

    # Header row is at index 5 (lines 0-3 = applied-filters banner; line 4 blank)
    df = None
    for skip in (5, 4, 3, 2, 1, 0):
        try:
            tmp = pd.read_csv(csv_path, encoding="cp1252", skiprows=skip)
            if any("trained" in str(c).lower() for c in tmp.columns):
                df = tmp
                log(f"  detected header at skiprows={skip}")
                break
        except Exception:
            continue
    if df is None:
        log("  ❌ could not locate header row")
        return

    log(f"  shape: {df.shape}")

    def find(*needles):
        for n in needles:
            for c in df.columns:
                if str(c).strip().lower() == n.lower():
                    return c
        for n in needles:
            for c in df.columns:
                if n.lower() in str(c).strip().lower():
                    return c
        return None

    c_acc = find("Account Name", "AccountName", "Customer", "Account")
    c_trained = find("Trained Learners", "Learners Trained", "Trained")
    c_tpid = find("TPID")
    c_delivery = find("Delivery ID")
    c_status = find("Delivery Status")
    c_type = find("Delivery Type")

    if c_acc is None or c_trained is None:
        log(f"  ⚠️ missing required cols. Got: {list(df.columns)}")
        return

    df[c_trained] = pd.to_numeric(df[c_trained], errors="coerce").fillna(0).astype(int)
    df = df[df[c_acc].notna()].copy()

    grouped = df.groupby(c_acc, dropna=True).agg(
        trained=(c_trained, "sum"),
        rows=(c_trained, "count"),
    ).reset_index().sort_values("trained", ascending=False)

    summary = []
    for _, r in grouped.iterrows():
        item = {"account": str(r[c_acc]), "trained": int(r["trained"]), "rows": int(r["rows"])}
        if c_tpid is not None:
            tp = df[df[c_acc] == r[c_acc]][c_tpid].dropna()
            if not tp.empty:
                item["tpid"] = str(tp.iloc[0]).split(".")[0]
        summary.append(item)

    SUMMARY_OUT.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    ROWS_OUT.write_text(df.to_json(orient="records", force_ascii=False, indent=2), encoding="utf-8")

    grand = sum(a["trained"] for a in summary)
    log(f"\n  → {len(df)} rows · {len(summary)} accounts · grand total trained: {grand:,}")
    log(f"  → {SUMMARY_OUT}")
    log(f"  → {ROWS_OUT}")
    log(f"\n  Top 15 accounts:")
    for a in summary[:15]:
        log(f"     {a['trained']:>7,}  {a['account']}")


def main(headless: bool = False):
    def log(msg=""):
        print(msg, flush=True)

    log(f"PBI Export Attainment | headless={headless}")
    log(f"Profile: {PROFILE}")

    # Append login_hint to skip account picker on first sign-in
    url = REPORT_URL + f"&login_hint={USER_UPN}"

    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            str(PROFILE),
            channel="msedge",
            headless=headless,
            viewport={"width": 1600, "height": 1000},
            accept_downloads=True,
            args=[
                "--disable-blink-features=AutomationControlled",
                f"--auth-server-allowlist=*.microsoft.com,*.microsoftonline.com",
            ],
        )
        page = ctx.new_page()
        log(f"\n→ Navigating to report …")
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=120_000)
        except Exception as e:
            log(f"  initial nav: {e}")

        if not _wait_for_landing(page, log):
            log("⚠️ did not land on report; aborting")
            ctx.close()
            return 1

        xlsx = _trigger_export(page, log)
        ctx.close()

    if not xlsx or not xlsx.exists():
        log("\n❌ export failed")
        return 2

    log(f"\n→ Aggregating {xlsx.name} …")
    aggregate(xlsx, log)
    log("\n✅ done")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--headless", action="store_true", help="Run Edge headless (after profile cached)")
    args = ap.parse_args()
    sys.exit(main(headless=args.headless))
