#!/usr/bin/env python
"""verify_no_pii.py — generic anonymization re-check for the Digital TPM Agent.

Scans a folder for content that would localize the package to a person:
emails, phone numbers, Windows user paths, and any terms you list in an optional
denylist file (one term per line). Prints every hit. Exit code 1 if any HARD hit.

  python verify_no_pii.py [TARGET_DIR] [--denylist mylist.txt]

Ships with NO embedded personal data — the patterns are generic. Use it before
sharing your own copy to confirm you didn't paste anything private.
"""
import argparse
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

KEEP_EXT = {".md", ".py", ".js", ".ps1", ".txt", ".json", ".yml", ".yaml",
            ".css", ".ini", ".cfg", ".toml", ".sh", ".bat", ".cmd"}
GENERIC = ("example.", "externalcompany.", "cliente.", "contoso.", "email.")
# generic/placeholder user segments that are NOT a real identity
GENERIC_USER = {"username", "user", "users", "you", "name", "alias", "youruser",
                "yourname", "youralias", "seunome", "usuario", "<username>"}

PATTERNS = {
    "email": re.compile(r"\b[\w.+-]+@(?!OData\.)[A-Za-z][\w-]*\.[A-Za-z][\w.]*"),
    "phone": re.compile(r"(?<![\w-])(?:\+\d{2}\s?)?\(?\d{2}\)?\s?9?\d{4}[\s-]?\d{4}(?![\w-])"),
    "win user path": re.compile(r"[A-Za-z]:\\Users\\[^\\\s\"']+"),
    "posix user path": re.compile(r"/(?:home|Users)/[^/\s\"']+"),
}


def scan(target: Path, denylist):
    deny = [re.compile(r"\b" + re.escape(t) + r"\b", re.I) for t in denylist]
    hard, soft = [], []
    for f in target.rglob("*"):
        if not f.is_file() or f.suffix.lower() not in KEEP_EXT:
            continue
        try:
            txt = f.read_text(encoding="utf-8")
        except Exception:
            continue
        rel = f.relative_to(target)
        for label, rx in PATTERNS.items():
            for m in rx.finditer(txt):
                s = m.group(0)
                if "{{" in s or "[" in s:
                    continue
                if label == "email" and s.split("@", 1)[1].lower().startswith(GENERIC):
                    continue
                if label in ("win user path", "posix user path"):
                    seg = re.split(r"[\\/]", s)[-1].strip("<>%").lower()
                    if seg in GENERIC_USER:
                        continue
                (soft if label == "email" else hard).append((str(rel), label, s))
        for i, rx in enumerate(deny):
            m = rx.search(txt)
            if m:
                hard.append((str(rel), f"denylist:{denylist[i]}", m.group(0)))
    return hard, soft


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", nargs="?", default=".")
    ap.add_argument("--denylist")
    a = ap.parse_args()
    denylist = []
    if a.denylist and Path(a.denylist).exists():
        denylist = [l.strip() for l in Path(a.denylist).read_text(encoding="utf-8").splitlines()
                    if l.strip() and not l.startswith("#")]
    hard, soft = scan(Path(a.target), denylist)
    print(f"=== verify_no_pii: {len(hard)} hard · {len(soft)} soft (review) ===")
    for rel, label, s in sorted(set(hard))[:200]:
        print(f"  HARD [{label}] {rel} :: {s}")
    for rel, label, s in sorted(set(soft))[:60]:
        print(f"  soft [{label}] {rel} :: {s}")
    return 1 if hard else 0


if __name__ == "__main__":
    sys.exit(main())
